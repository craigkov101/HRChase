package com.ckz.hrchase.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import org.json.JSONArray
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.util.concurrent.ConcurrentHashMap

class MlbApi {
    private val base = "https://statsapi.mlb.com"
    private val savantBase = "https://baseballsavant.mlb.com"

    private data class CachedText(val value: String, val expiresAtMs: Long)
    private val responseCache = ConcurrentHashMap<String, CachedText>()
    private val requestLocks = ConcurrentHashMap<String, Mutex>()

    private companion object {
        const val SECOND = 1_000L
        const val MINUTE = 60 * SECOND
        const val HOUR = 60 * MINUTE
    }

    suspend fun fetchSchedule(date: LocalDate): List<GameInfo> {
        val url = "$base/api/v1/schedule?sportId=1&date=$date&hydrate=probablePitcher,team,linescore"
        val ttl = when {
            date.isBefore(LocalDate.now()) -> 6 * HOUR
            date == LocalDate.now() -> 45 * SECOND
            else -> 3 * MINUTE
        }
        val body = try {
            getCached(url, ttl)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (firstError: Throwable) {
            // The schedule is the one request the whole board depends on. Retry once for brief
            // MLB/CDN/mobile-network hiccups instead of immediately leaving the app empty.
            delay(550)
            try {
                getCached(url, ttl)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Throwable) {
                throw firstError
            }
        }
        val root = JSONObject(body)
        val dates = root.optJSONArray("dates") ?: return emptyList()
        if (dates.length() == 0) return emptyList()
        val games = dates.optJSONObject(0)?.optJSONArray("games") ?: return emptyList()
        return buildList {
            for (i in 0 until games.length()) {
                val g = games.optJSONObject(i) ?: continue
                val teams = g.optJSONObject("teams") ?: continue
                val awayObj = teams.optJSONObject("away") ?: continue
                val homeObj = teams.optJSONObject("home") ?: continue
                val awayTeamObj = awayObj.optJSONObject("team") ?: continue
                val homeTeamObj = homeObj.optJSONObject("team") ?: continue
                val statusObj = g.optJSONObject("status")
                val venueObj = g.optJSONObject("venue")

                add(
                    GameInfo(
                        gamePk = g.optLong("gamePk"),
                        gameDate = parseInstant(g.optString("gameDate")),
                        status = statusObj?.optString("abstractGameState") ?: "Preview",
                        detailedStatus = statusObj?.optString("detailedState") ?: "Scheduled",
                        awayTeam = parseTeam(awayTeamObj),
                        homeTeam = parseTeam(homeTeamObj),
                        venueName = venueObj?.optString("name") ?: "Unknown park",
                        awayProbablePitcher = awayObj.optJSONObject("probablePitcher")?.let(::parsePerson),
                        homeProbablePitcher = homeObj.optJSONObject("probablePitcher")?.let(::parsePerson)
                    )
                )
            }
        }
    }

    suspend fun fetchScheduleRange(startDate: LocalDate, endDate: LocalDate): List<GameInfo> {
        val url = "$base/api/v1/schedule?sportId=1&startDate=$startDate&endDate=$endDate&gameType=R&hydrate=probablePitcher,team"
        val ttl = if (endDate.isBefore(LocalDate.now())) 8 * HOUR else 8 * MINUTE
        val root = JSONObject(getCached(url, ttl))
        val dates = root.optJSONArray("dates") ?: return emptyList()
        return buildList {
            for (d in 0 until dates.length()) {
                val dateObj = dates.optJSONObject(d) ?: continue
                val games = dateObj.optJSONArray("games") ?: continue
                for (i in 0 until games.length()) {
                    val g = games.optJSONObject(i) ?: continue
                    val teams = g.optJSONObject("teams") ?: continue
                    val awayObj = teams.optJSONObject("away") ?: continue
                    val homeObj = teams.optJSONObject("home") ?: continue
                    val awayTeamObj = awayObj.optJSONObject("team") ?: continue
                    val homeTeamObj = homeObj.optJSONObject("team") ?: continue
                    val statusObj = g.optJSONObject("status")
                    val venueObj = g.optJSONObject("venue")
                    add(
                        GameInfo(
                            gamePk = g.optLong("gamePk"),
                            gameDate = parseInstant(g.optString("gameDate")),
                            status = statusObj?.optString("abstractGameState") ?: "Preview",
                            detailedStatus = statusObj?.optString("detailedState") ?: "Scheduled",
                            awayTeam = parseTeam(awayTeamObj),
                            homeTeam = parseTeam(homeTeamObj),
                            venueName = venueObj?.optString("name") ?: "Unknown park",
                            awayProbablePitcher = awayObj.optJSONObject("probablePitcher")?.let(::parsePerson),
                            homeProbablePitcher = homeObj.optJSONObject("probablePitcher")?.let(::parsePerson)
                        )
                    )
                }
            }
        }
    }

    suspend fun fetchGameFeed(gamePk: Long, cacheTtlMs: Long = 60 * SECOND): GameFeedSnapshot {
        val root = JSONObject(getCached("$base/api/v1.1/game/$gamePk/feed/live", cacheTtlMs))
        val officialDate = root.optJSONObject("gameData")
            ?.optJSONObject("datetime")
            ?.optString("officialDate")
            ?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            ?: Instant.now().atZone(ZoneOffset.UTC).toLocalDate()

        return GameFeedSnapshot(
            gamePk = gamePk,
            officialDate = officialDate,
            root = root,
            awayLineupIds = extractBattingOrder(root, "away"),
            homeLineupIds = extractBattingOrder(root, "home"),
            battedBalls = extractBattedBalls(root, gamePk, officialDate),
            plateDiscipline = extractPlateDiscipline(root),
            pitchLocations = extractPitchLocations(root, gamePk, officialDate),
            weather = extractWeather(root)
        )
    }


    /**
     * Career batter-vs-pitcher results from MLB StatsAPI's vsPlayer stat type.
     * MLB can return more than one stat block/split, so we aggregate each block and keep
     * the one with the largest plate-appearance sample (normally the career-total block).
     */
    suspend fun fetchHittingVsPitcherStats(batterId: Int, pitcherId: Int): BatterVsPitcherStats? {
        val url = "$base/api/v1/people/$batterId/stats?stats=vsPlayer&group=hitting&opposingPlayerId=$pitcherId&sportId=1"
        return runCatching {
            val root = JSONObject(getCached(url, 6 * HOUR))
            val blocks = root.optJSONArray("stats") ?: return@runCatching null
            val parsed = buildList {
                for (i in 0 until blocks.length()) {
                    val block = blocks.optJSONObject(i) ?: continue
                    val splits = block.optJSONArray("splits") ?: continue
                    val rows = buildList {
                        for (j in 0 until splits.length()) {
                            val stat = splits.optJSONObject(j)?.optJSONObject("stat") ?: continue
                            add(parseBatterVsPitcherRow(stat))
                        }
                    }
                    if (rows.isNotEmpty()) add(aggregateBatterVsPitcher(rows))
                }
            }
            parsed.maxByOrNull { maxOf(it.plateAppearances, it.atBats) }
                ?.takeIf { it.plateAppearances > 0 || it.atBats > 0 }
        }.getOrNull()
    }

    private fun parseBatterVsPitcherRow(obj: JSONObject): BatterVsPitcherStats = BatterVsPitcherStats(
        atBats = obj.optIntOrNull("atBats") ?: 0,
        plateAppearances = obj.optIntOrNull("plateAppearances") ?: 0,
        hits = obj.optIntOrNull("hits") ?: 0,
        doubles = obj.optIntOrNull("doubles") ?: 0,
        triples = obj.optIntOrNull("triples") ?: 0,
        homeRuns = obj.optIntOrNull("homeRuns") ?: 0,
        walks = obj.optIntOrNull("baseOnBalls") ?: obj.optIntOrNull("walks") ?: 0,
        strikeouts = obj.optIntOrNull("strikeOuts") ?: 0,
        hitByPitch = obj.optIntOrNull("hitByPitch") ?: 0,
        sacFlies = obj.optIntOrNull("sacFlies") ?: 0,
        avg = obj.optDoubleOrNull("avg"),
        obp = obj.optDoubleOrNull("obp"),
        slg = obj.optDoubleOrNull("slg"),
        ops = obj.optDoubleOrNull("ops")
    )

    private fun aggregateBatterVsPitcher(rows: List<BatterVsPitcherStats>): BatterVsPitcherStats {
        val ab = rows.sumOf { it.atBats }
        val paRaw = rows.sumOf { it.plateAppearances }
        val hits = rows.sumOf { it.hits }
        val doubles = rows.sumOf { it.doubles }
        val triples = rows.sumOf { it.triples }
        val hrs = rows.sumOf { it.homeRuns }
        val walks = rows.sumOf { it.walks }
        val ks = rows.sumOf { it.strikeouts }
        val hbp = rows.sumOf { it.hitByPitch }
        val sf = rows.sumOf { it.sacFlies }
        val pa = if (paRaw > 0) paRaw else ab + walks + hbp + sf
        val avg = if (ab > 0) hits.toDouble() / ab else null
        val totalBases = hits + doubles + 2 * triples + 3 * hrs
        val slg = if (ab > 0) totalBases.toDouble() / ab else null
        val obpDenom = ab + walks + hbp + sf
        val obp = if (obpDenom > 0) (hits + walks + hbp).toDouble() / obpDenom else null
        val ops = if (obp != null && slg != null) obp + slg else null
        return BatterVsPitcherStats(
            atBats = ab, plateAppearances = pa, hits = hits, doubles = doubles, triples = triples,
            homeRuns = hrs, walks = walks, strikeouts = ks, hitByPitch = hbp, sacFlies = sf,
            avg = avg, obp = obp, slg = slg, ops = ops
        )
    }


    /**
     * Statcast occurrence counts for a specific pitch type. For hitters, eventType can be
     * "homeRun" to answer which pitches their HRs came against. For pitchers, omit eventType
     * and the same endpoint provides how often they throw that pitch type. MLB's metricAverages
     * response exposes numOccurrences on each player split, so we only need counts here.
     */
    suspend fun fetchPitchTypeOccurrences(
        playerIds: List<Int>,
        season: Int,
        pitchType: String,
        group: String,
        eventType: String? = null
    ): Map<Int, Int> {
        if (playerIds.isEmpty()) return emptyMap()
        val ids = playerIds.distinct().joinToString(",")
        val metric = if (group.equals("pitching", true)) "releaseSpeed" else "launchSpeed"
        val event = eventType?.let { "&eventType=${URLEncoder.encode(it, StandardCharsets.UTF_8.name())}" }.orEmpty()
        val url = "$base/api/v1/stats/metrics?personIds=$ids&group=$group&stats=metricAverages&metrics=$metric&season=$season&pitchType=$pitchType$event&limit=5000"
        return runCatching {
            val root = JSONObject(getCached(url, 30 * MINUTE))
            val blocks = root.optJSONArray("stats") ?: return@runCatching emptyMap()
            val out = mutableMapOf<Int, Int>()
            for (i in 0 until blocks.length()) {
                val block = blocks.optJSONObject(i) ?: continue
                val blockPlayerId = block.optJSONObject("player")?.optInt("id")?.takeIf { it > 0 }
                val splits = block.optJSONArray("splits") ?: continue
                for (j in 0 until splits.length()) {
                    val split = splits.optJSONObject(j) ?: continue
                    val playerId = split.optJSONObject("player")?.optInt("id")?.takeIf { it > 0 }
                        ?: blockPlayerId
                        ?: continue
                    val count = split.optIntOrNull("numOccurrences")
                        ?: split.optJSONObject("stat")?.optIntOrNull("count")
                        ?: 0
                    if (count > 0) out[playerId] = (out[playerId] ?: 0) + count
                }
            }
            out
        }.getOrDefault(emptyMap())
    }



    /**
     * Bulk Statcast pitch-arsenal leaderboard. Unlike the StatsAPI metricAverages endpoint,
     * this endpoint is specifically designed to return one row per player/pitch type and
     * includes actual pitch usage plus SLG/xSLG/hard-hit outcomes. One request covers the
     * entire league, so the app does not need dozens of player-by-player calls.
     */
    suspend fun fetchSavantPitchArsenalStats(
        season: Int,
        playerType: String
    ): Map<Int, List<SavantPitchArsenalRow>> {
        val safeType = if (playerType.equals("pitcher", true)) "pitcher" else "batter"
        val url = "$savantBase/leaderboard/pitch-arsenal-stats?type=$safeType&year=$season&min=1&minPitches=1&csv=true"
        return runCatching {
            val rows = parseCsv(getTextCached(url, "text/csv", 45 * MINUTE))
            rows.mapNotNull { row ->
                val playerId = row["player_id"]?.trim()?.toIntOrNull() ?: return@mapNotNull null
                val code = row["pitch_type"]?.trim()?.uppercase()?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
                val pitches = row["pitches"]?.replace(",", "")?.trim()?.toIntOrNull() ?: 0
                if (pitches <= 0) return@mapNotNull null
                SavantPitchArsenalRow(
                    playerId = playerId,
                    code = code,
                    name = row["pitch_name"]?.trim()?.takeIf { it.isNotBlank() } ?: pitchTypeName(code),
                    pitches = pitches,
                    usagePct = row["pitch_usage"]?.trim()?.toDoubleOrNull(),
                    plateAppearances = row["pa"]?.replace(",", "")?.trim()?.toIntOrNull() ?: 0,
                    slg = row["slg"]?.trim()?.toDoubleOrNull(),
                    xslg = (row["est_slg"] ?: row["xslg"])?.trim()?.toDoubleOrNull(),
                    woba = row["woba"]?.trim()?.toDoubleOrNull(),
                    xwoba = (row["est_woba"] ?: row["xwoba"])?.trim()?.toDoubleOrNull(),
                    hardHitPct = row["hard_hit_percent"]?.trim()?.toDoubleOrNull(),
                    whiffPct = (row["whiff_percent"] ?: row["whiff_pct"] ?: row["whiff%"] )?.trim()?.toDoubleOrNull(),
                    strikeoutPct = (row["k_percent"] ?: row["strikeout_percent"] ?: row["k_pct"])?.trim()?.toDoubleOrNull(),
                    putAwayPct = (row["put_away"] ?: row["putaway_percent"] ?: row["put_away_percent"])?.trim()?.toDoubleOrNull()
                )
            }.groupBy { it.playerId }
        }.getOrDefault(emptyMap())
    }

    /**
     * Direct season HR pitch-type history for today's hitters. Baseball Savant supports
     * repeated batters_lookup[] filters, so we request only today's players in chunks rather
     * than downloading every pitch from the season. Rows are individual HR-ending pitches.
     */
    suspend fun fetchSavantHomeRunPitchCounts(
        playerIds: List<Int>,
        season: Int
    ): Map<Int, Map<String, Int>> {
        if (playerIds.isEmpty()) return emptyMap()
        val merged = mutableMapOf<Int, MutableMap<String, Int>>()
        playerIds.distinct().chunked(40).forEach { chunk ->
            val lookups = chunk.joinToString("&") { "batters_lookup%5B%5D=$it" }
            val url = "$savantBase/statcast_search/csv?all=true&type=details&player_type=batter" +
                "&hfGT=R%7C&hfSea=$season%7C&hfAB=home%5C.%5C.run%7C" +
                "&min_pitches=0&min_results=0&min_pas=0&group_by=name-event&sort_order=desc&$lookups"
            val rows = runCatching { parseCsv(getTextCached(url, "text/csv", 30 * MINUTE)) }.getOrDefault(emptyList())
            rows.forEach { row ->
                val batterId = row["batter"]?.trim()?.toIntOrNull() ?: return@forEach
                if (batterId !in chunk) return@forEach
                val event = row["events"]?.trim()?.lowercase().orEmpty()
                if (event.isNotBlank() && event != "home_run" && event != "home run") return@forEach
                val code = row["pitch_type"]?.trim()?.uppercase()?.takeIf { it.isNotBlank() } ?: return@forEach
                val byPitch = merged.getOrPut(batterId) { mutableMapOf() }
                byPitch[code] = (byPitch[code] ?: 0) + 1
            }
        }
        return merged.mapValues { it.value.toMap() }
    }



    /**
     * Official Statcast contact-quality leaderboard. This supplies the stable season foundation
     * (barrels, EV50, hard-hit, sweet spot) so recent five-game Gameday samples are not asked to
     * represent a hitter's true power skill by themselves.
     */
    suspend fun fetchSavantStatcastContact(
        season: Int,
        playerType: String
    ): Map<Int, StatcastContactProfile> {
        val safeType = if (playerType.equals("pitcher", true)) "pitcher" else "batter"
        val url = "$savantBase/leaderboard/statcast?type=$safeType&year=$season&min=1&csv=true"
        return runCatching {
            parseCsv(getTextCached(url, "text/csv", 45 * MINUTE)).mapNotNull { row ->
                val playerId = csvInt(row, "player_id", "id") ?: return@mapNotNull null
                playerId to StatcastContactProfile(
                    battedBallEvents = csvInt(row, "attempts", "bbe", "batted_ball_events") ?: 0,
                    avgLaunchAngle = csvDouble(row, "launch_angle_avg", "avg_hit_angle", "avg_launch_angle"),
                    sweetSpotPct = csvPct(row, "sweet_spot_percent", "anglesweetspotpercent", "sweet_spot_pct"),
                    maxExitVelocity = csvDouble(row, "exit_velocity_max", "max_hit_speed", "max_exit_velocity"),
                    avgExitVelocity = csvDouble(row, "exit_velocity_avg", "avg_hit_speed", "avg_exit_velocity"),
                    ev50 = csvDouble(row, "ev50"),
                    maxDistanceFt = csvDouble(row, "distance_max", "max_distance"),
                    avgDistanceFt = csvDouble(row, "distance_avg", "avg_distance"),
                    hardHitPct = csvPct(row, "hard_hit_percent", "ev95percent", "hard_hit_pct"),
                    barrels = csvInt(row, "barrel_ct", "barrels") ?: 0,
                    barrelPct = csvPct(row, "barrels_per_bip", "brl_percent", "barrel_batted_rate"),
                    barrelPerPaPct = csvPct(row, "barrels_per_pa", "brl_pa", "barrel_pa_rate")
                )
            }.toMap()
        }.getOrDefault(emptyMap())
    }

    /** Expected outcome stats remove much of the defense/park noise from raw results. */
    suspend fun fetchSavantExpectedStats(
        season: Int,
        playerType: String
    ): Map<Int, ExpectedStatsProfile> {
        val safeType = if (playerType.equals("pitcher", true)) "pitcher" else "batter"
        val url = "$savantBase/leaderboard/expected_statistics?type=$safeType&year=$season&position=&team=&filterType=pa&min=1&csv=true"
        return runCatching {
            parseCsv(getTextCached(url, "text/csv", 45 * MINUTE)).mapNotNull { row ->
                val playerId = csvInt(row, "player_id", "entity_id", "id") ?: return@mapNotNull null
                playerId to ExpectedStatsProfile(
                    plateAppearances = csvInt(row, "pa") ?: 0,
                    battedBalls = csvInt(row, "bip", "bbe") ?: 0,
                    avg = csvDouble(row, "ba", "avg"),
                    xAvg = csvDouble(row, "est_ba", "xba", "x_ba"),
                    slg = csvDouble(row, "slg"),
                    xSlg = csvDouble(row, "est_slg", "xslg", "x_slg"),
                    woba = csvDouble(row, "woba"),
                    xWoba = csvDouble(row, "est_woba", "xwoba", "x_woba"),
                    era = csvDouble(row, "era"),
                    xEra = csvDouble(row, "xera", "est_era")
                )
            }.toMap()
        }.getOrDefault(emptyMap())
    }

    /** Hawk-Eye bat tracking is support evidence, not a replacement for Barrel%. */

    /**
     * Statcast adjusted expected-home-run leaderboard. xHR uses each tracked home run's
     * trajectory across all 30 parks and then adjusts for the environment in which it was hit.
     * We use it as a slow-moving power/HR-quality signal, never as a standalone prediction.
     */
    suspend fun fetchSavantExpectedHomeRuns(
        season: Int,
        playerType: String
    ): Map<Int, ExpectedHomeRunProfile> {
        val safeType = if (playerType.equals("pitcher", true)) "Pitcher" else "Batter"
        val playerParam = if (safeType == "Pitcher") "&player_type=Pitcher" else "&player_type=Batter"
        val url = "$savantBase/leaderboard/home-runs?year=$season$playerParam&csv=true"
        return runCatching {
            parseCsv(getTextCached(url, "text/csv", 90 * MINUTE))
                .mapNotNull { row ->
                    // Savant can return multiple variants. Prefer the environment-adjusted xHR row.
                    val type = (row["type"] ?: row["hr_type"]).orEmpty().trim()
                    if (type.isNotBlank() && !type.equals("adj_xhr", true) && !type.contains("adjust", true)) {
                        return@mapNotNull null
                    }
                    val playerId = csvInt(row, "player_id") ?: return@mapNotNull null
                    playerId to ExpectedHomeRunProfile(
                        actualHomeRuns = csvInt(row, "hr_total", "hr", "home_runs") ?: 0,
                        expectedHomeRuns = csvDouble(row, "xhr", "x_hr"),
                        hrMinusExpected = csvDouble(row, "xhr_diff", "hr_minus_xhr"),
                        noDoubters = csvInt(row, "no_doubters", "no_doubter") ?: 0,
                        mostlyGone = csvInt(row, "mostly_gone") ?: 0,
                        doubters = csvInt(row, "doubters") ?: 0,
                        noDoubterPct = csvPct(row, "no_doubter_per", "no_doubter_pct"),
                        source = "Statcast adjusted xHR"
                    )
                }
                .toMap()
        }.getOrDefault(emptyMap())
    }

    suspend fun fetchSavantBatTracking(season: Int): Map<Int, BatTrackingProfile> {
        val url = "$savantBase/leaderboard/bat-tracking?year=$season&csv=true"
        return runCatching {
            parseCsv(getTextCached(url, "text/csv", 45 * MINUTE)).mapNotNull { row ->
                val playerId = csvInt(row, "id", "player_id") ?: return@mapNotNull null
                playerId to BatTrackingProfile(
                    competitiveSwings = csvInt(row, "swings_competitive", "competitive_swings") ?: 0,
                    avgBatSpeed = csvDouble(row, "avg_bat_speed"),
                    fastSwingRate = csvRate(row, "hard_swing_rate", "fast_swing_rate"),
                    squaredUpContactRate = csvRate(row, "squared_up_per_bat_contact"),
                    squaredUpSwingRate = csvRate(row, "squared_up_per_swing"),
                    blastContactRate = csvRate(row, "blast_per_bat_contact"),
                    blastSwingRate = csvRate(row, "blast_per_swing"),
                    swingLength = csvDouble(row, "swing_length"),
                    whiffPerSwing = csvRate(row, "whiff_per_swing")
                )
            }.toMap()
        }.getOrDefault(emptyMap())
    }

    /** Side-specific swing geometry; switch hitters may have one row for each batting side. */
    suspend fun fetchSavantSwingPath(season: Int): Map<Int, List<SwingPathProfile>> {
        val url = "$savantBase/leaderboard/bat-tracking/swing-path-attack-angle?year=$season&csv=true"
        return runCatching {
            parseCsv(getTextCached(url, "text/csv", 45 * MINUTE)).mapNotNull { row ->
                val playerId = csvInt(row, "id", "player_id") ?: return@mapNotNull null
                playerId to SwingPathProfile(
                    side = (row["side"] ?: row["bat_side"])?.trim()?.uppercase()?.takeIf { it.isNotBlank() },
                    competitiveSwings = csvInt(row, "competitive_swings", "swings_competitive") ?: 0,
                    avgBatSpeed = csvDouble(row, "avg_bat_speed"),
                    swingTilt = csvDouble(row, "swing_tilt", "avg_plane_vertical_angle"),
                    attackAngle = csvDouble(row, "attack_angle"),
                    attackDirection = csvDouble(row, "attack_direction"),
                    idealAttackAngleRate = csvRate(row, "ideal_attack_angle_rate", "rate_ideal_attack_angle")
                )
            }.groupBy({ it.first }, { it.second })
        }.getOrDefault(emptyMap())
    }

    /** Exact Statcast pull-air profile; much better than inferring direction from a few Gameday balls. */
    suspend fun fetchSavantBattedBallProfiles(season: Int): Map<Int, BattedBallDirectionProfile> {
        val url = "$savantBase/leaderboard/batted-ball?year=$season&type=batter&min=1&csv=true"
        return runCatching {
            parseCsv(getTextCached(url, "text/csv", 45 * MINUTE)).mapNotNull { row ->
                val playerId = csvInt(row, "id", "player_id") ?: return@mapNotNull null
                playerId to BattedBallDirectionProfile(
                    battedBallEvents = csvInt(row, "bbe") ?: 0,
                    groundBallRate = csvRate(row, "gb_rate"),
                    airRate = csvRate(row, "air_rate"),
                    flyBallRate = csvRate(row, "fb_rate"),
                    pullRate = csvRate(row, "pull_rate"),
                    pullAirRate = csvRate(row, "pull_air_rate")
                )
            }.toMap()
        }.getOrDefault(emptyMap())
    }

    /**
     * Statcast park factors are an embedded-JSON page rather than a CSV export. Parsing is kept
     * optional and defensive; callers retain the legacy park baseline if Savant changes markup.
     */
    suspend fun fetchSavantHomeRunParkFactors(
        season: Int,
        batterSide: String
    ): Map<String, ParkFactorProfile> {
        val safeSide = if (batterSide.equals("L", true)) "L" else "R"
        val url = "$savantBase/leaderboard/statcast-park-factors?type=venue&year=$season&batSide=$safeSide&stat=index_HR&condition=All&rolling=3"
        return runCatching {
            val html = getTextCached(url, "text/html", 3 * HOUR)
            val jsonText = Regex("(?s)\\bdata\\s*=\\s*(\\[.*?\\])\\s*;")
                .find(html)?.groupValues?.getOrNull(1) ?: return@runCatching emptyMap()
            val array = JSONArray(jsonText)
            buildMap {
                for (i in 0 until array.length()) {
                    val row = array.optJSONObject(i) ?: continue
                    val venue = sequenceOf("venue_name", "venueName", "name")
                        .map { row.optString(it) }.firstOrNull { it.isNotBlank() } ?: continue
                    val factor = sequenceOf("index_hr", "index_HR", "hr", "hr_index")
                        .mapNotNull { row.optDoubleOrNull(it) }.firstOrNull()
                        ?: row.optDoubleOrNull(season.toString())
                        ?: continue
                    if (factor.isFinite() && factor in 50.0..170.0) {
                        put(venue.lowercase(), ParkFactorProfile(venue, safeSide, factor))
                    }
                }
            }
        }.getOrDefault(emptyMap())
    }

    /** Team aggregate relief split; used to account for the plate appearances after the starter exits. */
    suspend fun fetchTeamReliefPitchingStats(teamId: Int, season: Int): PitchingStats? {
        val url = "$base/api/v1/teams/$teamId/stats?group=pitching&season=$season&stats=statSplits&sitCodes=rp"
        return runCatching {
            val root = JSONObject(getCached(url, 45 * MINUTE))
            val blocks = root.optJSONArray("stats") ?: return@runCatching null
            for (i in 0 until blocks.length()) {
                val splits = blocks.optJSONObject(i)?.optJSONArray("splits") ?: continue
                for (j in 0 until splits.length()) {
                    val stat = splits.optJSONObject(j)?.optJSONObject("stat") ?: continue
                    val parsed = parsePitchingStats(stat)
                    if (parsed.inningsPitched > 0.0 || parsed.battersFaced > 0) return@runCatching parsed
                }
            }
            null
        }.getOrNull()
    }

    private fun csvInt(row: Map<String, String>, vararg keys: String): Int? = keys.asSequence()
        .mapNotNull { key -> row[key]?.replace(",", "")?.trim()?.takeIf { it.isNotBlank() }?.toDoubleOrNull()?.toInt() }
        .firstOrNull()

    private fun csvDouble(row: Map<String, String>, vararg keys: String): Double? = keys.asSequence()
        .mapNotNull { key -> row[key]?.replace(",", "")?.replace("%", "")?.trim()?.takeIf { it.isNotBlank() }?.toDoubleOrNull() }
        .firstOrNull()

    /** Return a rate as 0..1 whether Savant exported it as 0.24, 24, or 24%. */
    private fun csvRate(row: Map<String, String>, vararg keys: String): Double? = csvDouble(row, *keys)?.let { raw ->
        if (raw > 1.0) (raw / 100.0).coerceIn(0.0, 1.0) else raw.coerceIn(0.0, 1.0)
    }

    /** Return a percentage as 0..100 whether Savant exported it as 0.24 or 24. */
    private fun csvPct(row: Map<String, String>, vararg keys: String): Double? = csvDouble(row, *keys)?.let { raw ->
        if (raw in 0.0..1.0) raw * 100.0 else raw
    }

    fun pitchTypeName(code: String): String = when (code.uppercase()) {
        "FF" -> "4-Seam"
        "SI" -> "Sinker"
        "FC" -> "Cutter"
        "SL" -> "Slider"
        "ST" -> "Sweeper"
        "CU" -> "Curve"
        "KC" -> "Knuckle Curve"
        "CH" -> "Changeup"
        "FS" -> "Splitter"
        "FO" -> "Forkball"
        "SV" -> "Slurve"
        "CS" -> "Slow Curve"
        "SC" -> "Screwball"
        "KN" -> "Knuckleball"
        "EP" -> "Eephus"
        "FA" -> "Other Fastball"
        else -> code.uppercase()
    }

    /**
     * Season hitting splits versus a pitcher handedness for the entire MLB player pool.
     * One league-wide request is much faster than one request per hitter. sitCode `vr` means
     * versus right-handed pitchers and `vl` means versus left-handed pitchers.
     */
    suspend fun fetchLeagueHittingSplitStats(season: Int, sitCode: String): Map<Int, HittingSplitStats> {
        val safeCode = if (sitCode == "vl") "vl" else "vr"
        val url = "$base/api/v1/stats?stats=statSplits&sportId=1&season=$season&group=hitting&playerPool=All&sitCodes=$safeCode&limit=5000"
        return runCatching {
            val root = JSONObject(getCached(url, 30 * MINUTE))
            val blocks = root.optJSONArray("stats") ?: return@runCatching emptyMap()
            val out = mutableMapOf<Int, HittingSplitStats>()
            for (i in 0 until blocks.length()) {
                val splits = blocks.optJSONObject(i)?.optJSONArray("splits") ?: continue
                for (j in 0 until splits.length()) {
                    val split = splits.optJSONObject(j) ?: continue
                    val player = split.optJSONObject("player") ?: split.optJSONObject("person") ?: continue
                    val playerId = player.optInt("id")
                    if (playerId <= 0) continue
                    val stat = split.optJSONObject("stat") ?: continue
                    val parsed = parseHittingSplitStats(stat)
                    val current = out[playerId]
                    if (current == null || parsed.plateAppearances > current.plateAppearances) {
                        out[playerId] = parsed
                    }
                }
            }
            out.toMap()
        }.getOrDefault(emptyMap())
    }

    /**
     * One league-wide date-range request for the previous seven days of offense. This is far
     * cheaper than requesting each hitter individually and powers the Hot tab without adding a
     * large number of network calls.
     */
    suspend fun fetchLeagueHittingDateRangeStats(
        startDate: LocalDate,
        endDate: LocalDate
    ): Map<Int, RecentHittingStats> {
        val url = "$base/api/v1/stats?stats=byDateRange&group=hitting&sportIds=1&gameType=R&season=${startDate.year}&playerPool=All&startDate=$startDate&endDate=$endDate&limit=5000"
        return runCatching {
            val root = JSONObject(getCached(url, 10 * MINUTE))
            val blocks = root.optJSONArray("stats") ?: return@runCatching emptyMap()
            val out = mutableMapOf<Int, RecentHittingStats>()
            for (i in 0 until blocks.length()) {
                val splits = blocks.optJSONObject(i)?.optJSONArray("splits") ?: continue
                for (j in 0 until splits.length()) {
                    val split = splits.optJSONObject(j) ?: continue
                    val player = split.optJSONObject("player") ?: split.optJSONObject("person") ?: continue
                    val playerId = player.optInt("id")
                    if (playerId <= 0) continue
                    val stat = split.optJSONObject("stat") ?: continue
                    val parsed = parseRecentHittingStats(stat)
                    val current = out[playerId]
                    if (current == null || parsed.plateAppearances > current.plateAppearances) {
                        out[playerId] = parsed
                    }
                }
            }
            out.toMap()
        }.getOrDefault(emptyMap())
    }

    /**
     * Triple-A hitting leaderboard from MLB StatsAPI (sportId 11). The same parser is used for
     * season totals and a recent date range so the prospect tab can compare long-term power with
     * what a hitter is doing right now without pulling every individual MiLB game feed.
     */
    suspend fun fetchTripleAHittingStats(
        season: Int,
        startDate: LocalDate? = null,
        endDate: LocalDate? = null
    ): List<MinorLeagueHitterLine> {
        val range = startDate != null && endDate != null
        val url = if (range) {
            "$base/api/v1/stats?stats=byDateRange&group=hitting&sportIds=11&gameType=R&season=$season" +
                "&playerPool=All&startDate=$startDate&endDate=$endDate&hydrate=person,team&limit=5000"
        } else {
            "$base/api/v1/stats?stats=season&group=hitting&sportIds=11&gameType=R&season=$season" +
                "&playerPool=All&hydrate=person,team&limit=5000"
        }
        val ttl = if (range) 12 * MINUTE else 45 * MINUTE
        return runCatching {
            val root = JSONObject(getCached(url, ttl))
            val blocks = root.optJSONArray("stats") ?: return@runCatching emptyList()
            val rows = mutableListOf<MinorLeagueHitterLine>()
            for (i in 0 until blocks.length()) {
                val splits = blocks.optJSONObject(i)?.optJSONArray("splits") ?: continue
                for (j in 0 until splits.length()) {
                    val split = splits.optJSONObject(j) ?: continue
                    val playerObj = split.optJSONObject("player") ?: split.optJSONObject("person") ?: continue
                    val playerId = playerObj.optInt("id")
                    if (playerId <= 0) continue
                    val stat = split.optJSONObject("stat") ?: continue
                    val teamObj = split.optJSONObject("team")
                    val batSide = playerObj.optJSONObject("batSide")?.optString("code")?.takeIf { it.isNotBlank() }
                    val position = playerObj.optJSONObject("primaryPosition")?.let { pos ->
                        pos.optString("abbreviation").takeIf { it.isNotBlank() }
                            ?: pos.optString("name").takeIf { it.isNotBlank() }
                    }
                    rows += MinorLeagueHitterLine(
                        player = PersonRef(
                            id = playerId,
                            name = playerObj.optString("fullName", "Unknown"),
                            batSide = batSide
                        ),
                        team = teamObj?.let(::parseTeam),
                        parentOrgId = teamObj?.optIntOrNull("parentOrgId"),
                        parentOrgName = teamObj?.optString("parentOrgName")?.takeIf { it.isNotBlank() },
                        primaryPosition = position,
                        currentAge = playerObj.optIntOrNull("currentAge"),
                        stats = parseRecentHittingStats(stat)
                    )
                }
            }
            rows.groupBy { it.player.id }.values.map { playerRows ->
                val representative = playerRows.maxByOrNull { it.stats.plateAppearances } ?: playerRows.first()
                representative.copy(stats = aggregateRecentHittingStats(playerRows.map { it.stats }))
            }
        }.getOrDefault(emptyList())
    }

    /**
     * Recent Triple-A schedule used only for the curated prospect contact layer. We intentionally
     * fetch one league schedule window, then Repository selects a small number of relevant games
     * before any live feeds are downloaded.
     */
    suspend fun fetchTripleAScheduleRange(startDate: LocalDate, endDate: LocalDate): List<GameInfo> {
        val url = "$base/api/v1/schedule?sportId=11&startDate=$startDate&endDate=$endDate&gameType=R&hydrate=team"
        val ttl = if (endDate.isBefore(LocalDate.now())) 8 * HOUR else 8 * MINUTE
        return runCatching {
            val root = JSONObject(getCached(url, ttl))
            val dates = root.optJSONArray("dates") ?: return@runCatching emptyList()
            buildList {
                for (d in 0 until dates.length()) {
                    val dateObj = dates.optJSONObject(d) ?: continue
                    val games = dateObj.optJSONArray("games") ?: continue
                    for (i in 0 until games.length()) {
                        val g = games.optJSONObject(i) ?: continue
                        val teams = g.optJSONObject("teams") ?: continue
                        val awayObj = teams.optJSONObject("away") ?: continue
                        val homeObj = teams.optJSONObject("home") ?: continue
                        val awayTeamObj = awayObj.optJSONObject("team") ?: continue
                        val homeTeamObj = homeObj.optJSONObject("team") ?: continue
                        val statusObj = g.optJSONObject("status")
                        val venueObj = g.optJSONObject("venue")
                        add(
                            GameInfo(
                                gamePk = g.optLong("gamePk"),
                                gameDate = parseInstant(g.optString("gameDate")),
                                status = statusObj?.optString("abstractGameState") ?: "Preview",
                                detailedStatus = statusObj?.optString("detailedState") ?: "Scheduled",
                                awayTeam = parseTeam(awayTeamObj),
                                homeTeam = parseTeam(homeTeamObj),
                                venueName = venueObj?.optString("name") ?: "Triple-A park",
                                awayProbablePitcher = null,
                                homeProbablePitcher = null
                            )
                        )
                    }
                }
            }
        }.getOrDefault(emptyList())
    }

    /**
     * Return the pitcher's most recent completed MLB game references. Attack Zone Fit cannot rely
     * on the generic team lookback alone because a starter only appears every 4-6 days; the newest
     * team game is usually a different starter. gameLog gives us the exact gamePk for that pitcher.
     */
    suspend fun fetchRecentPitcherGameRefs(
        playerId: Int,
        season: Int,
        throughDate: LocalDate,
        gameCount: Int = 2
    ): List<Pair<Long, LocalDate>> {
        val safeCount = gameCount.coerceIn(1, 4)
        val url = "$base/api/v1/people/$playerId/stats?stats=gameLog&group=pitching&season=$season&gameType=R"
        return runCatching {
            val root = JSONObject(getCached(url, 30 * MINUTE))
            val blocks = root.optJSONArray("stats") ?: return@runCatching emptyList()
            val rows = mutableListOf<Pair<Long, LocalDate>>()
            for (i in 0 until blocks.length()) {
                val splits = blocks.optJSONObject(i)?.optJSONArray("splits") ?: continue
                for (j in 0 until splits.length()) {
                    val split = splits.optJSONObject(j) ?: continue
                    val splitDate = runCatching { LocalDate.parse(split.optString("date")) }.getOrNull() ?: continue
                    if (splitDate.isAfter(throughDate)) continue
                    val gameObj = split.optJSONObject("game")
                    val gamePk = when {
                        (gameObj?.optLong("gamePk", 0L) ?: 0L) > 0L -> gameObj!!.optLong("gamePk")
                        split.optLong("gamePk", 0L) > 0L -> split.optLong("gamePk")
                        else -> {
                            val link = gameObj?.optString("link").orEmpty()
                            Regex("/game/(\\d+)").find(link)?.groupValues?.getOrNull(1)?.toLongOrNull() ?: 0L
                        }
                    }
                    if (gamePk > 0L) rows += gamePk to splitDate
                }
            }
            rows.distinctBy { it.first }
                .sortedByDescending { it.second }
                .take(safeCount)
        }.getOrDefault(emptyList())
    }

    /**
     * Lightweight play-by-play fetch used to complete recent starter attack maps. This endpoint is
     * much smaller than downloading another full live feed and still contains pitchData coordinates.
     */
    suspend fun fetchGamePitchLocations(gamePk: Long, gameDate: LocalDate): List<PitchLocationSample> {
        val url = "$base/api/v1/game/$gamePk/playByPlay"
        return runCatching {
            val root = JSONObject(getCached(url, 12 * HOUR))
            extractPitchLocations(root, gamePk, gameDate)
        }.getOrDefault(emptyList())
    }

    /**
     * Aggregate the player's last N completed games through a specific date. This powers the
     * Tracked tab without loading full game feeds. The gameLog endpoint returns one split per game;
     * we filter by date, take the newest requested games, and aggregate the counting/rate stats.
     */
    suspend fun fetchPlayerLastGamesStats(
        playerId: Int,
        season: Int,
        throughDate: LocalDate,
        gameCount: Int = 10
    ): RecentHittingStats? {
        val safeCount = gameCount.coerceIn(1, 30)
        val url = "$base/api/v1/people/$playerId/stats?stats=gameLog&group=hitting&season=$season&gameType=R"
        return runCatching {
            val root = JSONObject(getCached(url, 15 * MINUTE))
            val blocks = root.optJSONArray("stats") ?: return@runCatching null
            val datedRows = mutableListOf<Pair<LocalDate, RecentHittingStats>>()
            for (i in 0 until blocks.length()) {
                val splits = blocks.optJSONObject(i)?.optJSONArray("splits") ?: continue
                for (j in 0 until splits.length()) {
                    val split = splits.optJSONObject(j) ?: continue
                    val date = runCatching { LocalDate.parse(split.optString("date")) }.getOrNull() ?: continue
                    if (date.isAfter(throughDate)) continue
                    val stat = split.optJSONObject("stat") ?: continue
                    datedRows += date to parseRecentHittingStats(stat)
                }
            }
            val rows = datedRows
                .sortedByDescending { it.first }
                .take(safeCount)
                .map { it.second }
            if (rows.isEmpty()) null else aggregateRecentHittingStats(rows)
        }.getOrNull()
    }

    /** Fetch a hitter's exact completed-game line for one calendar date. */
    suspend fun fetchPlayerStatsOnDate(
        playerId: Int,
        date: LocalDate
    ): RecentHittingStats? {
        val url = "$base/api/v1/people/$playerId/stats?stats=gameLog&group=hitting&season=${date.year}&gameType=R"
        return runCatching {
            val root = JSONObject(getCached(url, 30 * MINUTE))
            val blocks = root.optJSONArray("stats") ?: return@runCatching null
            val rows = mutableListOf<RecentHittingStats>()
            for (i in 0 until blocks.length()) {
                val splits = blocks.optJSONObject(i)?.optJSONArray("splits") ?: continue
                for (j in 0 until splits.length()) {
                    val split = splits.optJSONObject(j) ?: continue
                    val splitDate = runCatching { LocalDate.parse(split.optString("date")) }.getOrNull() ?: continue
                    if (splitDate != date) continue
                    val stat = split.optJSONObject("stat") ?: continue
                    rows += parseRecentHittingStats(stat)
                }
            }
            if (rows.isEmpty()) null else aggregateRecentHittingStats(rows)
        }.getOrNull()
    }

    private fun aggregateRecentHittingStats(rows: List<RecentHittingStats>): RecentHittingStats {
        val ab = rows.sumOf { it.atBats }
        val pa = rows.sumOf { it.plateAppearances }
        val runs = rows.sumOf { it.runs }
        val hits = rows.sumOf { it.hits }
        val doubles = rows.sumOf { it.doubles }
        val triples = rows.sumOf { it.triples }
        val hrs = rows.sumOf { it.homeRuns }
        val rbi = rows.sumOf { it.rbi }
        val walks = rows.sumOf { it.walks }
        val strikeouts = rows.sumOf { it.strikeouts }
        val hitByPitch = rows.sumOf { it.hitByPitch }
        val sacFlies = rows.sumOf { it.sacFlies }
        val avg = if (ab > 0) hits.toDouble() / ab else null
        val totalBases = hits + doubles + 2 * triples + 3 * hrs
        val slg = if (ab > 0) totalBases.toDouble() / ab else null
        val obpDenom = ab + walks + hitByPitch + sacFlies
        val obp = if (obpDenom > 0) (hits + walks + hitByPitch).toDouble() / obpDenom else null
        val ops = if (obp != null && slg != null) obp + slg else null
        return RecentHittingStats(
            gamesPlayed = rows.size,
            atBats = ab,
            plateAppearances = pa,
            runs = runs,
            hits = hits,
            doubles = doubles,
            triples = triples,
            homeRuns = hrs,
            rbi = rbi,
            walks = walks,
            strikeouts = strikeouts,
            hitByPitch = hitByPitch,
            sacFlies = sacFlies,
            avg = avg,
            obp = obp,
            slg = slg,
            ops = ops
        )
    }

    private fun parseRecentHittingStats(obj: JSONObject): RecentHittingStats = RecentHittingStats(
        gamesPlayed = obj.optIntOrNull("gamesPlayed") ?: obj.optIntOrNull("games") ?: 0,
        atBats = obj.optIntOrNull("atBats") ?: 0,
        plateAppearances = obj.optIntOrNull("plateAppearances") ?: 0,
        runs = obj.optIntOrNull("runs") ?: 0,
        hits = obj.optIntOrNull("hits") ?: 0,
        doubles = obj.optIntOrNull("doubles") ?: 0,
        triples = obj.optIntOrNull("triples") ?: 0,
        homeRuns = obj.optIntOrNull("homeRuns") ?: 0,
        rbi = obj.optIntOrNull("rbi") ?: obj.optIntOrNull("runsBattedIn") ?: 0,
        walks = obj.optIntOrNull("baseOnBalls") ?: obj.optIntOrNull("walks") ?: 0,
        strikeouts = obj.optIntOrNull("strikeOuts") ?: 0,
        hitByPitch = obj.optIntOrNull("hitByPitch") ?: 0,
        sacFlies = obj.optIntOrNull("sacFlies") ?: 0,
        avg = obj.optDoubleOrNull("avg"),
        obp = obj.optDoubleOrNull("obp"),
        slg = obj.optDoubleOrNull("slg"),
        ops = obj.optDoubleOrNull("ops")
    )

    private fun parseHittingSplitStats(obj: JSONObject): HittingSplitStats = HittingSplitStats(
        atBats = obj.optIntOrNull("atBats") ?: 0,
        plateAppearances = obj.optIntOrNull("plateAppearances") ?: 0,
        hits = obj.optIntOrNull("hits") ?: 0,
        doubles = obj.optIntOrNull("doubles") ?: 0,
        triples = obj.optIntOrNull("triples") ?: 0,
        homeRuns = obj.optIntOrNull("homeRuns") ?: 0,
        walks = obj.optIntOrNull("baseOnBalls") ?: obj.optIntOrNull("walks") ?: 0,
        strikeouts = obj.optIntOrNull("strikeOuts") ?: 0,
        avg = obj.optDoubleOrNull("avg"),
        obp = obj.optDoubleOrNull("obp"),
        slg = obj.optDoubleOrNull("slg"),
        ops = obj.optDoubleOrNull("ops")
    )

    /** League-wide pitching totals for a date range. Used by the strikeout model for recent form. */
    suspend fun fetchLeaguePitchingDateRangeStats(
        startDate: LocalDate,
        endDate: LocalDate
    ): Map<Int, PitchingStats> {
        val url = "$base/api/v1/stats?stats=byDateRange&group=pitching&sportIds=1&gameType=R&season=${startDate.year}" +
            "&playerPool=All&startDate=$startDate&endDate=$endDate&limit=5000"
        return runCatching {
            val root = JSONObject(getCached(url, 10 * MINUTE))
            val blocks = root.optJSONArray("stats") ?: return@runCatching emptyMap()
            val out = mutableMapOf<Int, PitchingStats>()
            for (i in 0 until blocks.length()) {
                val splits = blocks.optJSONObject(i)?.optJSONArray("splits") ?: continue
                for (j in 0 until splits.length()) {
                    val split = splits.optJSONObject(j) ?: continue
                    val player = split.optJSONObject("player") ?: split.optJSONObject("person") ?: continue
                    val id = player.optInt("id")
                    if (id <= 0) continue
                    val stat = split.optJSONObject("stat") ?: continue
                    val parsed = parsePitchingStats(stat)
                    val current = out[id]
                    if (current == null || parsed.battersFaced > current.battersFaced) out[id] = parsed
                }
            }
            out.toMap()
        }.getOrDefault(emptyMap())
    }

    /** Season pitching splits versus left- or right-handed batters. */
    suspend fun fetchLeaguePitchingSplitStats(season: Int, sitCode: String): Map<Int, PitchingStats> {
        val safeCode = if (sitCode == "vl") "vl" else "vr"
        val url = "$base/api/v1/stats?stats=statSplits&sportId=1&season=$season&group=pitching&playerPool=All&sitCodes=$safeCode&limit=5000"
        return runCatching {
            val root = JSONObject(getCached(url, 30 * MINUTE))
            val blocks = root.optJSONArray("stats") ?: return@runCatching emptyMap()
            val out = mutableMapOf<Int, PitchingStats>()
            for (i in 0 until blocks.length()) {
                val splits = blocks.optJSONObject(i)?.optJSONArray("splits") ?: continue
                for (j in 0 until splits.length()) {
                    val split = splits.optJSONObject(j) ?: continue
                    val player = split.optJSONObject("player") ?: split.optJSONObject("person") ?: continue
                    val id = player.optInt("id")
                    if (id <= 0) continue
                    val stat = split.optJSONObject("stat") ?: continue
                    val parsed = parsePitchingStats(stat)
                    val current = out[id]
                    if (current == null || parsed.battersFaced > current.battersFaced) out[id] = parsed
                }
            }
            out.toMap()
        }.getOrDefault(emptyMap())
    }

    suspend fun fetchPitchingStats(playerId: Int, season: Int): PitchingStats {
        val url = "$base/api/v1/people/$playerId/stats?stats=season&group=pitching&season=$season"
        return runCatching {
            val root = JSONObject(getCached(url, 30 * MINUTE))
            val stats = root.optJSONArray("stats")?.optJSONObject(0)
                ?.optJSONArray("splits")?.optJSONObject(0)
                ?.optJSONObject("stat")
            parsePitchingStats(stats)
        }.getOrDefault(PitchingStats())
    }

    fun extractTeamLineup(
        snapshot: GameFeedSnapshot,
        side: String,
        team: TeamRef,
        forceProjected: Boolean = false
    ): TeamLineup {
        val ids = if (side == "away") snapshot.awayLineupIds else snapshot.homeLineupIds
        if (ids.isEmpty()) return TeamLineup(team, emptyList(), official = false)

        val boxTeam = snapshot.root.optJSONObject("liveData")
            ?.optJSONObject("boxscore")
            ?.optJSONObject("teams")
            ?.optJSONObject(side)
        val playersObj = boxTeam?.optJSONObject("players")

        val players = ids.mapIndexedNotNull { index, id ->
            val person = extractPerson(snapshot.root, id) ?: run {
                val pObj = playersObj?.optJSONObject("ID$id")?.optJSONObject("person")
                pObj?.let(::parsePerson)
            } ?: return@mapIndexedNotNull null

            val pBox = playersObj?.optJSONObject("ID$id")
            val battingStats = parseHittingStats(
                pBox?.optJSONObject("seasonStats")?.optJSONObject("batting")
            )
            LineupPlayer(
                person = person,
                battingOrder = index + 1,
                seasonStats = battingStats,
                official = !forceProjected,
                sourceGamePk = snapshot.gamePk
            )
        }
        return TeamLineup(team, players, official = !forceProjected)
    }

    fun extractPerson(root: JSONObject, id: Int): PersonRef? {
        val p = root.optJSONObject("gameData")
            ?.optJSONObject("players")
            ?.optJSONObject("ID$id") ?: return null
        return PersonRef(
            id = id,
            name = p.optString("fullName", p.optString("nameFirstLast", "Player $id")),
            batSide = p.optJSONObject("batSide")?.optString("code")?.takeIf { it.isNotBlank() },
            pitchHand = p.optJSONObject("pitchHand")?.optString("code")?.takeIf { it.isNotBlank() }
        )
    }

    fun extractPitchingStatsFromFeed(root: JSONObject, playerId: Int): PitchingStats? {
        val teams = root.optJSONObject("liveData")?.optJSONObject("boxscore")?.optJSONObject("teams") ?: return null
        for (side in listOf("away", "home")) {
            val stats = teams.optJSONObject(side)
                ?.optJSONObject("players")
                ?.optJSONObject("ID$playerId")
                ?.optJSONObject("seasonStats")
                ?.optJSONObject("pitching")
            if (stats != null) return parsePitchingStats(stats)
        }
        return null
    }

    private fun extractBattingOrder(root: JSONObject, side: String): List<Int> {
        val teamObj = root.optJSONObject("liveData")
            ?.optJSONObject("boxscore")
            ?.optJSONObject("teams")
            ?.optJSONObject(side) ?: return emptyList()

        val direct = teamObj.optJSONArray("battingOrder")?.ints().orEmpty()
        if (direct.isNotEmpty()) return direct

        val players = teamObj.optJSONObject("players") ?: return emptyList()
        val ordered = mutableListOf<Pair<Int, Int>>()
        val keys = players.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val player = players.optJSONObject(key) ?: continue
            val personId = player.optJSONObject("person")?.optInt("id") ?: continue
            val orderRaw = when (val raw = player.opt("battingOrder")) {
                is Number -> raw.toInt()
                is String -> raw.toIntOrNull()
                else -> null
            } ?: continue
            if (orderRaw > 0) ordered += orderRaw to personId
        }
        return ordered.sortedBy { it.first }.map { it.second }.distinct().take(9)
    }

    /**
     * Lightweight recent swing-and-miss sample by batter. Recent HR research commonly
     * discuss swing-and-miss alongside barrels/hard contact, so we derive a recent whiff rate
     * directly from MLB Gameday pitch descriptions without adding another network request.
     */
    private fun extractPlateDiscipline(root: JSONObject): Map<Int, PlateDisciplineSample> {
        val plays = root.optJSONObject("liveData")?.optJSONObject("plays")?.optJSONArray("allPlays")
            ?: return emptyMap()
        val out = mutableMapOf<Int, PlateDisciplineSample>()
        for (i in 0 until plays.length()) {
            val play = plays.optJSONObject(i) ?: continue
            val batterId = play.optJSONObject("matchup")?.optJSONObject("batter")?.optInt("id") ?: 0
            if (batterId == 0) continue
            val events = play.optJSONArray("playEvents") ?: continue
            var pitches = 0
            var swings = 0
            var whiffs = 0
            for (e in 0 until events.length()) {
                val event = events.optJSONObject(e) ?: continue
                val details = event.optJSONObject("details") ?: continue
                val isPitch = details.optBoolean("isPitch", false) || event.optBoolean("isPitch", false)
                if (!isPitch) continue
                pitches++
                val description = details.optString("description").lowercase()
                val whiff = description.contains("swinging strike") ||
                    description.contains("missed bunt") ||
                    description.contains("swinging pitchout")
                val swing = whiff ||
                    description.contains("foul") ||
                    description.contains("in play") ||
                    description.contains("hit into play")
                if (swing) swings++
                if (whiff) whiffs++
            }
            if (pitches > 0 || swings > 0) {
                val add = PlateDisciplineSample(totalPitches = pitches, swings = swings, whiffs = whiffs)
                out[batterId] = (out[batterId] ?: PlateDisciplineSample()) + add
            }
        }
        return out
    }

    /**
     * Pitch-location sample derived from the same Gameday feed we already download. This powers
     * Attack Zone Fit without adding one HTTP request per hitter or pitcher. Missing coordinates
     * are skipped rather than estimated.
     */
    private fun extractPitchLocations(
        root: JSONObject,
        gamePk: Long,
        gameDate: LocalDate
    ): List<PitchLocationSample> {
        val plays = root.optJSONArray("allPlays")
            ?: root.optJSONObject("liveData")?.optJSONObject("plays")?.optJSONArray("allPlays")
            ?: return emptyList()
        return buildList {
            for (i in 0 until plays.length()) {
                val play = plays.optJSONObject(i) ?: continue
                val matchup = play.optJSONObject("matchup") ?: continue
                val batterId = matchup.optJSONObject("batter")?.optInt("id") ?: 0
                val pitcherId = matchup.optJSONObject("pitcher")?.optInt("id") ?: 0
                if (batterId == 0 || pitcherId == 0) continue
                val batterSide = matchup.optJSONObject("batSide")?.optString("code")
                    ?.takeIf { it == "R" || it == "L" }
                val events = play.optJSONArray("playEvents") ?: continue
                for (e in 0 until events.length()) {
                    val event = events.optJSONObject(e) ?: continue
                    val details = event.optJSONObject("details") ?: continue
                    if (!(details.optBoolean("isPitch", false) || event.optBoolean("isPitch", false))) continue
                    val pitchData = event.optJSONObject("pitchData") ?: continue
                    val coordinates = pitchData.optJSONObject("coordinates") ?: continue
                    val px = coordinates.optDoubleOrNull("pX") ?: continue
                    val pz = coordinates.optDoubleOrNull("pZ") ?: continue
                    if (!px.isFinite() || !pz.isFinite() || px !in -3.5..3.5 || pz !in -1.0..6.5) continue
                    val description = details.optString("description").takeIf { it.isNotBlank() }
                    val lower = description.orEmpty().lowercase()
                    val whiff = lower.contains("swinging strike") || lower.contains("missed bunt") || lower.contains("swinging pitchout")
                    val inPlay = lower.contains("in play") || lower.contains("hit into play")
                    val swing = whiff || inPlay || lower.contains("foul")
                    add(
                        PitchLocationSample(
                            gamePk = gamePk,
                            gameDate = gameDate,
                            batterId = batterId,
                            pitcherId = pitcherId,
                            batterSide = batterSide,
                            pitchType = details.optJSONObject("type")?.optString("code")
                                ?.takeIf { it.isNotBlank() }?.uppercase(),
                            plateX = px,
                            plateZ = pz,
                            strikeZoneTop = pitchData.optDoubleOrNull("strikeZoneTop"),
                            strikeZoneBottom = pitchData.optDoubleOrNull("strikeZoneBottom"),
                            description = description,
                            isSwing = swing,
                            isWhiff = whiff,
                            isInPlay = inPlay
                        )
                    )
                }
            }
        }
    }

    private fun extractWeather(root: JSONObject): WeatherInfo {
        val gameData = root.optJSONObject("gameData")
        val weather = gameData?.optJSONObject("weather")
        val roof = gameData?.optJSONObject("venue")
            ?.optJSONObject("fieldInfo")
            ?.optString("roofType")
            ?.takeIf { it.isNotBlank() }
        return WeatherInfo(
            temperatureF = weather?.optIntOrNull("temp"),
            wind = weather?.optString("wind")?.takeIf { it.isNotBlank() },
            condition = weather?.optString("condition")?.takeIf { it.isNotBlank() },
            roofType = roof
        )
    }

    private fun extractBattedBalls(root: JSONObject, gamePk: Long, gameDate: LocalDate): List<BattedBall> {
        val plays = root.optJSONObject("liveData")?.optJSONObject("plays")?.optJSONArray("allPlays") ?: return emptyList()
        return buildList {
            for (i in 0 until plays.length()) {
                val play = plays.optJSONObject(i) ?: continue
                val matchup = play.optJSONObject("matchup") ?: continue
                val batterObj = matchup.optJSONObject("batter") ?: continue
                val pitcherObj = matchup.optJSONObject("pitcher") ?: continue
                val batterId = batterObj.optInt("id")
                val pitcherId = pitcherObj.optInt("id")
                if (batterId == 0 || pitcherId == 0) continue
                // matchup.batSide is the side actually used for this plate appearance. This is
                // important for switch hitters, whose roster batSide is "S" and previously made
                // recent pull-direction metrics impossible to classify.
                val batterSide = matchup.optJSONObject("batSide")
                    ?.optString("code")
                    ?.takeIf { it == "R" || it == "L" }
                val result = play.optJSONObject("result")
                val primaryEvent = result?.optString("eventType").orEmpty()
                val fallbackEvent = result?.optString("event").orEmpty()
                val eventType = primaryEvent.ifBlank { fallbackEvent }.ifBlank { "unknown" }
                val resultDescription = result?.optString("description")?.takeIf { it.isNotBlank() }
                val events = play.optJSONArray("playEvents") ?: continue
                var chosen: JSONObject? = null
                for (e in 0 until events.length()) {
                    val event = events.optJSONObject(e) ?: continue
                    if (event.optJSONObject("hitData") != null) chosen = event
                }
                val hitData = chosen?.optJSONObject("hitData") ?: continue
                val coordinates = hitData.optJSONObject("coordinates")
                val fieldLocation = hitData.optString("location")
                    .trim()
                    .toIntOrNull()
                val eventDescription = chosen?.optJSONObject("details")
                    ?.optString("description")
                    ?.takeIf { it.isNotBlank() }
                val description = resultDescription ?: eventDescription
                val isHr = eventType.equals("home_run", true) || eventType.equals("Home Run", true)
                add(
                    BattedBall(
                        gamePk = gamePk,
                        gameDate = gameDate,
                        batterId = batterId,
                        pitcherId = pitcherId,
                        batterName = batterObj.optString("fullName", "Player $batterId"),
                        pitcherName = pitcherObj.optString("fullName", "Pitcher $pitcherId"),
                        batterSide = batterSide,
                        exitVelocity = hitData.optDoubleOrNull("launchSpeed"),
                        launchAngle = hitData.optDoubleOrNull("launchAngle"),
                        distanceFt = hitData.optDoubleOrNull("totalDistance"),
                        trajectory = hitData.optString("trajectory").takeIf { it.isNotBlank() },
                        fieldLocation = fieldLocation,
                        sprayX = coordinates?.optDoubleOrNull("coordX"),
                        sprayY = coordinates?.optDoubleOrNull("coordY"),
                        eventType = eventType,
                        isHomeRun = isHr,
                        isOut = isOutEvent(eventType),
                        description = description,
                        pitchType = chosen?.optJSONObject("details")
                            ?.optJSONObject("type")
                            ?.optString("code")
                            ?.takeIf { it.isNotBlank() }
                            ?.uppercase(),
                        plateX = chosen?.optJSONObject("pitchData")?.optJSONObject("coordinates")?.optDoubleOrNull("pX"),
                        plateZ = chosen?.optJSONObject("pitchData")?.optJSONObject("coordinates")?.optDoubleOrNull("pZ"),
                        strikeZoneTop = chosen?.optJSONObject("pitchData")?.optDoubleOrNull("strikeZoneTop"),
                        strikeZoneBottom = chosen?.optJSONObject("pitchData")?.optDoubleOrNull("strikeZoneBottom")
                    )
                )
            }
        }
    }

    private fun parseTeam(obj: JSONObject): TeamRef {
        val id = obj.optInt("id")
        val name = obj.optString("name", "Unknown Team")
        val abbreviation = obj.optString("abbreviation").takeIf { it.isNotBlank() }
            ?: teamAbbreviation(id)
            ?: obj.optString("teamCode").takeIf { it.isNotBlank() }?.uppercase()
            ?: name.take(3).uppercase()
        return TeamRef(id = id, name = name, abbreviation = abbreviation)
    }

    private fun teamAbbreviation(id: Int): String? = when (id) {
        108 -> "LAA"
        109 -> "ARI"
        110 -> "BAL"
        111 -> "BOS"
        112 -> "CHC"
        113 -> "CIN"
        114 -> "CLE"
        115 -> "COL"
        116 -> "DET"
        117 -> "HOU"
        118 -> "KC"
        119 -> "LAD"
        120 -> "WSH"
        121 -> "NYM"
        133 -> "ATH"
        134 -> "PIT"
        135 -> "SD"
        136 -> "SEA"
        137 -> "SF"
        138 -> "STL"
        139 -> "TB"
        140 -> "TEX"
        141 -> "TOR"
        142 -> "MIN"
        143 -> "PHI"
        144 -> "ATL"
        145 -> "CWS"
        146 -> "MIA"
        147 -> "NYY"
        158 -> "MIL"
        else -> null
    }

    private fun parsePerson(obj: JSONObject): PersonRef = PersonRef(
        id = obj.optInt("id"),
        name = obj.optString("fullName", "Unknown")
    )

    private fun parseHittingStats(obj: JSONObject?): HittingStats {
        if (obj == null) return HittingStats()
        return HittingStats(
            atBats = obj.optIntOrNull("atBats") ?: 0,
            plateAppearances = obj.optIntOrNull("plateAppearances") ?: 0,
            hits = obj.optIntOrNull("hits") ?: 0,
            doubles = obj.optIntOrNull("doubles") ?: 0,
            triples = obj.optIntOrNull("triples") ?: 0,
            homeRuns = obj.optIntOrNull("homeRuns") ?: 0,
            walks = obj.optIntOrNull("baseOnBalls") ?: obj.optIntOrNull("walks") ?: 0,
            strikeouts = obj.optIntOrNull("strikeOuts") ?: 0,
            avg = obj.optDoubleOrNull("avg"),
            slg = obj.optDoubleOrNull("slg"),
            ops = obj.optDoubleOrNull("ops")
        )
    }

    private fun parsePitchingStats(obj: JSONObject?): PitchingStats {
        if (obj == null) return PitchingStats()
        return PitchingStats(
            gamesPlayed = obj.optIntOrNull("gamesPlayed") ?: obj.optIntOrNull("games") ?: 0,
            gamesStarted = obj.optIntOrNull("gamesStarted") ?: 0,
            inningsPitched = parseBaseballInnings(obj.optString("inningsPitched", "0")),
            hitsAllowed = obj.optIntOrNull("hits") ?: 0,
            earnedRuns = obj.optIntOrNull("earnedRuns") ?: 0,
            homeRunsAllowed = obj.optIntOrNull("homeRuns") ?: 0,
            strikeouts = obj.optIntOrNull("strikeOuts") ?: 0,
            walks = obj.optIntOrNull("baseOnBalls") ?: obj.optIntOrNull("walks") ?: 0,
            battersFaced = obj.optIntOrNull("battersFaced") ?: 0,
            pitchesThrown = obj.optIntOrNull("numberOfPitches") ?: obj.optIntOrNull("pitchesThrown") ?: 0,
            strikesThrown = obj.optIntOrNull("strikes") ?: 0,
            era = obj.optDoubleOrNull("era"),
            whip = obj.optDoubleOrNull("whip")
        )
    }

    private fun parseBaseballInnings(raw: String): Double {
        val parts = raw.split('.')
        val full = parts.getOrNull(0)?.toIntOrNull() ?: 0
        val outs = parts.getOrNull(1)?.firstOrNull()?.digitToIntOrNull()?.coerceIn(0, 2) ?: 0
        return full + outs / 3.0
    }

    private fun isOutEvent(event: String): Boolean {
        val e = event.lowercase()
        return e.contains("out") || e.contains("double_play") || e.contains("sac_fly") || e.contains("sac_bunt")
    }

    private fun parseInstant(raw: String): Instant = runCatching { Instant.parse(raw) }.getOrElse { Instant.now() }

    private suspend fun get(url: String): String = getText(url, "application/json")

    private suspend fun getCached(url: String, ttlMs: Long): String =
        getTextCached(url, "application/json", ttlMs)

    /**
     * Small in-memory HTTP cache + per-URL single-flight lock. Rapid refreshes and day switching
     * used to refetch the same 20-30 final game feeds and season leaderboards over and over.
     * Reusing immutable/recent responses removes most of that work while short TTLs keep live
     * lineups and game state fresh.
     */
    private suspend fun getTextCached(url: String, accept: String, ttlMs: Long): String {
        val key = "$accept|$url"
        val now = System.currentTimeMillis()
        responseCache[key]?.takeIf { it.expiresAtMs > now }?.let { return it.value }

        val lock = requestLocks.computeIfAbsent(key) { Mutex() }
        return lock.withLock {
            val checkedAt = System.currentTimeMillis()
            val stale = responseCache[key]
            stale?.takeIf { it.expiresAtMs > checkedAt }?.let { return@withLock it.value }

            val value = try {
                getText(url, accept)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (networkError: Throwable) {
                // Stale-if-error: if this process already loaded a valid copy, prefer slightly stale
                // data over turning a working board blank during a temporary MLB/Savant outage.
                stale?.value ?: throw networkError
            }

            if (ttlMs > 0 && value.isNotBlank()) {
                if (responseCache.size > 72) {
                    responseCache.entries.removeIf { it.value.expiresAtMs <= checkedAt }
                    while (responseCache.size > 64) {
                        val oldestKey = responseCache.entries.minByOrNull { it.value.expiresAtMs }?.key ?: break
                        responseCache.remove(oldestKey)
                    }
                }
                responseCache[key] = CachedText(value, checkedAt + ttlMs)
            }
            value
        }
    }

    private suspend fun getText(url: String, accept: String): String = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 8_000
            conn.readTimeout = if (accept.contains("csv")) 20_000 else 11_000
            conn.requestMethod = "GET"
            conn.useCaches = true
            conn.setRequestProperty("Accept", accept)
            // Savant is fronted separately from StatsAPI and is more reliable with a normal
            // browser-like UA. Native Android HTTP has no CORS restriction.
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) HRChase/0.13.0")
            conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = if (stream != null) {
                BufferedReader(InputStreamReader(stream, StandardCharsets.UTF_8)).use { it.readText() }
            } else {
                ""
            }
            if (code !in 200..299) error("MLB data HTTP $code: ${body.take(180)}")
            body
        } finally {
            conn?.disconnect()
        }
    }

    /** Small RFC-4180 style CSV parser sufficient for Savant exports, including quoted names. */
    private fun parseCsv(body: String): List<Map<String, String>> {
        val lines = body.lineSequence().filter { it.isNotBlank() }.toList()
        if (lines.size < 2) return emptyList()
        val header = parseCsvLine(lines.first()).map { it.trim().removePrefix("\uFEFF") }
        return lines.drop(1).mapNotNull { line ->
            val values = parseCsvLine(line)
            if (values.isEmpty()) null
            else header.indices.associate { idx -> header[idx] to values.getOrElse(idx) { "" } }
        }
    }

    private fun parseCsvLine(line: String): List<String> {
        val out = mutableListOf<String>()
        val current = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> {
                    current.append('"'); i++
                }
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> { out += current.toString(); current.setLength(0) }
                else -> current.append(c)
            }
            i++
        }
        out += current.toString()
        return out
    }
}

data class GameFeedSnapshot(
    val gamePk: Long,
    val officialDate: LocalDate,
    val root: JSONObject,
    val awayLineupIds: List<Int>,
    val homeLineupIds: List<Int>,
    val battedBalls: List<BattedBall>,
    val plateDiscipline: Map<Int, PlateDisciplineSample>,
    val pitchLocations: List<PitchLocationSample>,
    val weather: WeatherInfo
)
