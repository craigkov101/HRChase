package com.ckz.hrchase

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ckz.hrchase.data.AppPreferences
import com.ckz.hrchase.data.AaaSluggerProspect
import com.ckz.hrchase.data.BoardData
import com.ckz.hrchase.data.DailySignalSnapshot
import com.ckz.hrchase.data.HitterSignalSnapshot
import com.ckz.hrchase.data.MetricLearning
import com.ckz.hrchase.data.LearnedPatternRule
import com.ckz.hrchase.data.CommonDenominatorSignal
import com.ckz.hrchase.data.CommonDenominatorCombination
import com.ckz.hrchase.data.MatchupConvergenceProfile
import com.ckz.hrchase.data.NightPatternProfile
import com.ckz.hrchase.data.NightHomerReference
import com.ckz.hrchase.data.SameDayHomerReference
import com.ckz.hrchase.data.SameDayPatternProfile
import com.ckz.hrchase.data.SameDaySharedSignal
import com.ckz.hrchase.data.ModelLearningProfile
import com.ckz.hrchase.data.HitterCandidate
import com.ckz.hrchase.data.MustHaveMetrics
import com.ckz.hrchase.data.PostgameReview
import com.ckz.hrchase.data.PitcherStrikeoutPrediction
import com.ckz.hrchase.data.PitcherStrikeoutSnapshot
import com.ckz.hrchase.data.DailyPitcherStrikeoutSnapshot
import com.ckz.hrchase.data.PitcherStrikeoutCalibrationBucket
import com.ckz.hrchase.data.PitcherStrikeoutLearningProfile
import com.ckz.hrchase.data.PickType
import com.ckz.hrchase.data.RecentHittingStats
import com.ckz.hrchase.data.ResearchLensScore
import com.ckz.hrchase.data.Repository
import com.ckz.hrchase.data.ScoreWeights
import com.ckz.hrchase.data.TrackedPick
import com.ckz.hrchase.model.HrScoringModel
import com.ckz.hrchase.model.PatternLearningEngine
import com.ckz.hrchase.model.PitcherStrikeoutScoringModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.LocalDate
import kotlin.math.absoluteValue
import kotlin.math.roundToInt

enum class SortMode { SCORE, ATTACK, POWER_PRESSURE, RECENT_POWER, MATCHUP }

enum class ParlayFocus {
    BALANCED,
    PURE_POWER,
    HEATING_UP,
    HOT_NOW,
    MATCHUP_EDGE,
    ELITE_ARSENAL
}

data class ParlayEvaluation(
    val rating: Int,
    val label: String,
    val averageLegScore: Int,
    val weakestLegScore: Int,
    val uniqueGames: Int,
    val note: String
)

data class AppUiState(
    val selectedDate: LocalDate = LocalDate.now(),
    val board: BoardData? = null,
    val isLoading: Boolean = false,
    val progress: String = "",
    val error: String? = null,
    val selectedPlayerId: Int? = null,
    val selectedProfileCandidate: HitterCandidate? = null,
    val selectedProfileDate: LocalDate? = null,
    val isProfileLoading: Boolean = false,
    val isProfileBvpLoading: Boolean = false,
    val profileError: String? = null,
    val showRemainingOnly: Boolean = true,
    val officialLineupsOnly: Boolean = false,
    val eliteArsenalOnly: Boolean = false,
    val topZoneOnly: Boolean = false,
    val sortMode: SortMode = SortMode.SCORE,
    val attackStrongOnly: Boolean = false,
    val weights: ScoreWeights = ScoreWeights(),
    val tracked: List<TrackedPick> = emptyList(),
    val trackedLast10: Map<Int, RecentHittingStats> = emptyMap(),
    val trackedLast10Loading: Set<Int> = emptySet(),
    val postgameStats: Map<Int, RecentHittingStats> = emptyMap(),
    val postgameStatsLoading: Set<Int> = emptySet(),
    val learningProfile: ModelLearningProfile = ModelLearningProfile(),
    val pitcherStrikeoutLearningProfile: PitcherStrikeoutLearningProfile = PitcherStrikeoutLearningProfile(),
    val lastNightPattern: NightPatternProfile = NightPatternProfile(),
    val sameDayPattern: SameDayPatternProfile = SameDayPatternProfile(),
    val aaaProspects: List<AaaSluggerProspect> = emptyList(),
    val isAaaLoading: Boolean = false,
    val aaaError: String? = null,
    val aaaLastUpdated: Instant? = null,
    val selectedAaaProspect: AaaSluggerProspect? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = AppPreferences(application)
    private val repository = Repository()
    private val scoringModel = HrScoringModel()
    private val patternLearningEngine = PatternLearningEngine()
    private val pitcherStrikeoutScoringModel = PitcherStrikeoutScoringModel()
    private val mustHaveCache = mutableMapOf<String, MustHaveMetrics>()
    private val heatingMetricsCache = mutableMapOf<String, MustHaveMetrics>()
    private val trackedLast10Cache = mutableMapOf<String, RecentHittingStats?>()
    private val postgameStatsCache = mutableMapOf<String, RecentHittingStats?>()
    private var refreshJob: Job? = null
    private var refreshGeneration: Long = 0L
    private val stateLock = Any()

    // Keep the most recently usable board for each nearby date. This makes date switching
    // instant and, more importantly, prevents a refresh from replacing a good board with an
    // empty schedule-only partial if a downstream MLB/Savant request fails.
    private val boardCache = object : LinkedHashMap<LocalDate, BoardData>(4, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<LocalDate, BoardData>?): Boolean = size > 4
    }

    private val _state = MutableStateFlow(
        AppUiState(
            weights = prefs.loadWeights(),
            tracked = prefs.loadTracked()
        )
    )
    val state: StateFlow<AppUiState> = _state.asStateFlow()

    init {
        refresh()
    }

    fun ensureAaaProspects() {
        if (_state.value.aaaProspects.isEmpty() && !_state.value.isAaaLoading) {
            refreshAaaProspects()
        }
    }

    fun refreshAaaProspects() {
        val date = _state.value.selectedDate
        mutate { it.copy(isAaaLoading = true, aaaError = null) }
        viewModelScope.launch {
            try {
                val prospects = withContext(Dispatchers.IO) { repository.loadAaaSluggerWatch(date) }
                mutate { current ->
                    val keepExisting = prospects.isEmpty() && current.aaaProspects.isNotEmpty()
                    val safeProspects = if (keepExisting) current.aaaProspects else prospects
                    current.copy(
                        aaaProspects = safeProspects,
                        isAaaLoading = false,
                        aaaError = when {
                            keepExisting -> "Triple-A refresh was incomplete. Keeping the last loaded watchlist instead of going blank."
                            prospects.isEmpty() -> "No curated Triple-A watch hitters were found in the current MiLB feed."
                            else -> null
                        },
                        aaaLastUpdated = if (prospects.isNotEmpty()) Instant.now() else current.aaaLastUpdated,
                        selectedAaaProspect = current.selectedAaaProspect?.let { selected ->
                            safeProspects.firstOrNull { it.player.id == selected.player.id } ?: selected
                        }
                    )
                }
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                mutate { current ->
                    current.copy(
                        isAaaLoading = false,
                        aaaError = t.message ?: "Unable to load Triple-A prospect data."
                    )
                }
            }
        }
    }

    fun selectAaaProspect(prospect: AaaSluggerProspect?) {
        mutate { it.copy(selectedAaaProspect = prospect) }
    }

    fun refresh() {
        refreshJob?.cancel()
        val generation = ++refreshGeneration
        val snapshot = _state.value
        val date = snapshot.selectedDate
        val weights = snapshot.weights
        val cached = synchronized(boardCache) { boardCache[date] }

        // Stale-while-revalidate: immediately restore a known-good board when the user jumps
        // between dates, then update it in place. This fixes the "switch back + refresh = no
        // players until restart" failure mode and makes navigation feel instant.
        mutate { current ->
            if (current.selectedDate != date) current
            else current.copy(
                board = cached ?: current.board?.takeIf { it.date == date },
                isLoading = true,
                error = null,
                progress = if (cached?.candidates?.isNotEmpty() == true) "Refreshing in background…" else "Starting…"
            )
        }

        refreshJob = viewModelScope.launch {
            try {
                val board = withContext(Dispatchers.Default) {
                    repository.loadBoard(
                        date = date,
                        weights = weights,
                        onProgress = { message ->
                            if (generation == refreshGeneration) {
                                mutate { s ->
                                    if (s.selectedDate == date) s.copy(progress = message) else s
                                }
                            }
                        },
                        onPartialBoard = { partial ->
                            if (generation != refreshGeneration) return@loadBoard
                            mutate { s ->
                                if (s.selectedDate != partial.date) return@mutate s
                                val existing = s.board?.takeIf { it.date == partial.date }
                                // Never let an early schedule-only partial erase a board that already
                                // has hitters. Preserve the candidates until fresher candidates arrive.
                                val safePartial = if (
                                    partial.candidates.isEmpty() && existing?.candidates?.isNotEmpty() == true
                                ) {
                                    partial.copy(
                                        candidates = existing.candidates,
                                        recentGameCount = maxOf(partial.recentGameCount, existing.recentGameCount),
                                        recentWeekStats = if (partial.recentWeekStats.isNotEmpty()) partial.recentWeekStats else existing.recentWeekStats,
                                        recentThreeDayStats = if (partial.recentThreeDayStats.isNotEmpty()) partial.recentThreeDayStats else existing.recentThreeDayStats,
                                        recentFourteenDayStats = if (partial.recentFourteenDayStats.isNotEmpty()) partial.recentFourteenDayStats else existing.recentFourteenDayStats,
                                        seasonProductionStats = if (partial.seasonProductionStats.isNotEmpty()) partial.seasonProductionStats else existing.seasonProductionStats,
                                        pitcherRecentThirtyDayStats = if (partial.pitcherRecentThirtyDayStats.isNotEmpty()) partial.pitcherRecentThirtyDayStats else existing.pitcherRecentThirtyDayStats,
                                        pitcherRecentFourteenDayStats = if (partial.pitcherRecentFourteenDayStats.isNotEmpty()) partial.pitcherRecentFourteenDayStats else existing.pitcherRecentFourteenDayStats,
                                        pitcherRecentSevenDayStats = if (partial.pitcherRecentSevenDayStats.isNotEmpty()) partial.pitcherRecentSevenDayStats else existing.pitcherRecentSevenDayStats,
                                        pitcherVsLeftStats = if (partial.pitcherVsLeftStats.isNotEmpty()) partial.pitcherVsLeftStats else existing.pitcherVsLeftStats,
                                        pitcherVsRightStats = if (partial.pitcherVsRightStats.isNotEmpty()) partial.pitcherVsRightStats else existing.pitcherVsRightStats
                                    )
                                } else partial
                                if (safePartial.candidates.isNotEmpty()) cacheBoard(safePartial)
                                s.copy(board = safePartial)
                            }
                        }
                    )
                }

                if (generation != refreshGeneration) return@launch
                val learningProfile = withContext(Dispatchers.IO) { updateOutcomeLearning(board) }
                val signalSnapshots = withContext(Dispatchers.IO) { prefs.loadSignalSnapshots() }
                val pitcherStrikeoutLearningProfile = withContext(Dispatchers.IO) { updatePitcherStrikeoutLearning(board) }
                val lastNightPattern = withContext(Dispatchers.Default) {
                    buildLastNightPattern(board, signalSnapshots)
                }
                val sameDayPattern = withContext(Dispatchers.Default) {
                    buildSameDayPattern(board, signalSnapshots)
                }
                if (generation != refreshGeneration) return@launch
                mustHaveCache.clear()
                heatingMetricsCache.clear()
                mutate { current ->
                    if (current.selectedDate != date) current
                    else {
                        val existing = current.board?.takeIf { it.date == date && it.candidates.isNotEmpty() }
                            ?: synchronized(boardCache) { boardCache[date] }
                        val keepExistingPlayers = board.games.isNotEmpty() &&
                            board.candidates.isEmpty() && existing?.candidates?.isNotEmpty() == true
                        val safeBoard = if (keepExistingPlayers) {
                            board.copy(
                                candidates = existing!!.candidates,
                                recentGameCount = maxOf(board.recentGameCount, existing.recentGameCount),
                                recentWeekStats = if (board.recentWeekStats.isNotEmpty()) board.recentWeekStats else existing.recentWeekStats,
                                recentThreeDayStats = if (board.recentThreeDayStats.isNotEmpty()) board.recentThreeDayStats else existing.recentThreeDayStats,
                                recentFourteenDayStats = if (board.recentFourteenDayStats.isNotEmpty()) board.recentFourteenDayStats else existing.recentFourteenDayStats,
                                seasonProductionStats = if (board.seasonProductionStats.isNotEmpty()) board.seasonProductionStats else existing.seasonProductionStats,
                                pitcherRecentThirtyDayStats = if (board.pitcherRecentThirtyDayStats.isNotEmpty()) board.pitcherRecentThirtyDayStats else existing.pitcherRecentThirtyDayStats,
                                pitcherRecentFourteenDayStats = if (board.pitcherRecentFourteenDayStats.isNotEmpty()) board.pitcherRecentFourteenDayStats else existing.pitcherRecentFourteenDayStats,
                                pitcherRecentSevenDayStats = if (board.pitcherRecentSevenDayStats.isNotEmpty()) board.pitcherRecentSevenDayStats else existing.pitcherRecentSevenDayStats,
                                pitcherVsLeftStats = if (board.pitcherVsLeftStats.isNotEmpty()) board.pitcherVsLeftStats else existing.pitcherVsLeftStats,
                                pitcherVsRightStats = if (board.pitcherVsRightStats.isNotEmpty()) board.pitcherVsRightStats else existing.pitcherVsRightStats
                            )
                        } else board
                        cacheBoard(safeBoard)
                        current.copy(
                            board = safeBoard,
                            isLoading = false,
                            progress = "Ready",
                            learningProfile = learningProfile,
                            pitcherStrikeoutLearningProfile = pitcherStrikeoutLearningProfile,
                            lastNightPattern = lastNightPattern,
                            sameDayPattern = sameDayPattern,
                            error = if (keepExistingPlayers) {
                                "The slate refreshed, but player enrichment was incomplete. Keeping the last loaded player board instead of going blank."
                            } else null
                        )
                    }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Throwable) {
                if (generation != refreshGeneration) return@launch
                mutate { current ->
                    if (current.selectedDate != date) current
                    else {
                        val usable = current.board?.takeIf { it.date == date && it.candidates.isNotEmpty() }
                            ?: synchronized(boardCache) { boardCache[date] }
                        current.copy(
                            board = usable ?: current.board?.takeIf { it.date == date },
                            isLoading = false,
                            progress = if (usable != null) "Showing saved data" else "",
                            error = if (usable != null) {
                                "Refresh failed, but your last loaded data is still available. Tap refresh to try again."
                            } else {
                                error.message ?: error::class.java.simpleName
                            }
                        )
                    }
                }
            }
        }
    }

    private suspend fun updateOutcomeLearning(board: BoardData): ModelLearningProfile {
        // Resolve yesterday's saved PRE-GAME signal snapshot against real MLB HR outcomes.
        // Then save today's first full board once, so tomorrow can grade the signals without
        // postgame leakage. This creates a growing local feedback set instead of pretending one
        // night's results are enough to retrain the model.
        board.previousNight?.let { previous ->
            val outcomes = repository.fetchDailyHittingOutcomes(previous.date)
            if (outcomes != null) prefs.resolveHomeRunOutcomes(previous.date, outcomes)
            else prefs.resolveSignalSnapshot(previous.date, previous.homers.map { it.playerId }.toSet())
        }

        // Backfill a few older unresolved days so learning does not depend on opening the app every
        // single day. We deliberately cap this work per refresh to keep startup/network load sane.
        val unresolvedDates = prefs.loadSignalSnapshots()
            .filter { snapshot ->
                snapshot.date.isBefore(LocalDate.now()) &&
                    snapshot.hitters.isNotEmpty() &&
                    snapshot.hitters.any { it.outcomeHomeRun == null }
            }
            .map { it.date }
            .distinct()
            .sortedDescending()
            .take(3)
        unresolvedDates.forEach { date ->
            val outcomes = repository.fetchDailyHittingOutcomes(date)
            if (outcomes != null) prefs.resolveHomeRunOutcomes(date, outcomes)
            else {
                val homerIds = repository.fetchHomeRunHitterIds(date)
                if (homerIds != null) prefs.resolveSignalSnapshot(date, homerIds)
            }
        }

        if (board.date == LocalDate.now() && board.candidates.isNotEmpty()) {
            val hitters = board.candidates.map { candidate ->
                val metrics = scoringModel.mustHaveMetrics(
                    candidate.player, candidate.seasonStats, candidate.recentBattedBalls
                )
                val contactProfile = metrics.score * metrics.confidence +
                    candidate.score.seasonPower * (1.0 - metrics.confidence)
                HitterSignalSnapshot(
                    date = board.date,
                    playerId = candidate.player.id,
                    recentPower = candidate.score.recentPower,
                    powerPressure = candidate.score.powerPressure,
                    pitcherMatchup = candidate.score.pitcherMatchup,
                    environment = candidate.score.environment,
                    seasonPower = candidate.score.seasonPower,
                    platoon = candidate.score.platoon,
                    contactProfile = contactProfile,
                    pitchArsenalFit = candidate.pitchArsenalMatch?.score,
                    pitchArsenalConfidence = candidate.pitchArsenalMatch?.confidence,
                    attackZoneFit = candidate.attackZoneMatch?.score,
                    attackZoneConfidence = candidate.attackZoneMatch?.confidence,
                    statcastPower = officialPowerQualityScore(candidate).takeIf {
                        candidate.statcastContact != null || candidate.expectedStats != null
                    },
                    pullAirPower = pullAirPowerScore(candidate).takeIf { candidate.battedBallDirection != null },
                    advancedPitcher = advancedPitcherVulnerabilityScore(candidate).takeIf {
                        candidate.opponentPitcher?.statcastContact != null || candidate.opponentPitcher?.expectedStats != null
                    },
                    precisionConfidence = precisionDataConfidence(candidate)
                )
            }
            val lockedPlayerIds = board.candidates
                .filter { !it.game.status.equals("Preview", true) || gameIsUnavailable(it.game) }
                .map { it.player.id }
                .toSet()
            prefs.mergePregameSignalSnapshot(
                DailySignalSnapshot(date = board.date, savedAt = Instant.now(), hitters = hitters),
                lockedPlayerIds = lockedPlayerIds
            )
        }

        return buildLearningProfile(prefs.loadSignalSnapshots())
    }

    private fun buildLearningProfile(snapshots: List<DailySignalSnapshot>): ModelLearningProfile =
        patternLearningEngine.build(snapshots)

    private data class PatternSignalDef(
        val key: String,
        val label: String,
        val threshold: Double,
        val getter: (HitterSignalSnapshot) -> Double?
    )

    private val patternSignalDefs = listOf(
        PatternSignalDef("seasonPower", "Season power", 62.0) { it.seasonPower },
        PatternSignalDef("contactProfile", "Contact quality", 60.0) { it.contactProfile },
        PatternSignalDef("recentPower", "Recent power", 60.0) { it.recentPower },
        PatternSignalDef("powerPressure", "Power pressure", 55.0) { it.powerPressure },
        PatternSignalDef("pitcherMatchup", "Pitcher matchup", 58.0) { it.pitcherMatchup },
        PatternSignalDef("pitchArsenalFit", "Pitch arsenal fit", 68.0) { row ->
            val confidence = row.pitchArsenalConfidence ?: 0.30
            row.pitchArsenalFit?.takeIf { confidence >= 0.28 }
        },
        PatternSignalDef("attackZoneFit", "Attack zone fit", 64.0) { row ->
            val confidence = row.attackZoneConfidence ?: 0.0
            row.attackZoneFit?.takeIf { confidence >= 0.28 }
        },
        PatternSignalDef("statcastPower", "Statcast power", 66.0) { row ->
            row.statcastPower?.takeIf { (row.precisionConfidence ?: 0.0) >= 0.30 }
        },
        PatternSignalDef("pullAirPower", "Pull-air power", 65.0) { row ->
            row.pullAirPower?.takeIf { (row.precisionConfidence ?: 0.0) >= 0.30 }
        },
        PatternSignalDef("advancedPitcher", "Starter Statcast vulnerability", 62.0) { row ->
            row.advancedPitcher?.takeIf { (row.precisionConfidence ?: 0.0) >= 0.30 }
        },
        PatternSignalDef("platoon", "Handedness edge", 62.0) { it.platoon },
        PatternSignalDef("environment", "Environment", 58.0) { it.environment }
    )

    private fun patternDefCombinations(size: Int): List<List<PatternSignalDef>> {
        if (size <= 0 || size > patternSignalDefs.size) return emptyList()
        val out = mutableListOf<List<PatternSignalDef>>()
        fun walk(start: Int, current: MutableList<PatternSignalDef>) {
            if (current.size == size) {
                out += current.toList()
                return
            }
            val needed = size - current.size
            for (i in start..patternSignalDefs.size - needed) {
                current += patternSignalDefs[i]
                walk(i + 1, current)
                current.removeAt(current.lastIndex)
            }
        }
        walk(0, mutableListOf())
        return out
    }

    /**
     * Finds the strongest PRE-GAME traits shared by the previous night's actual HR hitters.
     * The comparison is against the full saved slate from that same day, so a trait only rises
     * when it was both common among HR hitters and meaningfully more productive than baseline.
     * This intentionally uses the saved snapshot rather than reconstructing yesterday after the
     * results are known, which avoids postgame leakage.
     */
    private fun buildLastNightPattern(
        board: BoardData,
        snapshots: List<DailySignalSnapshot>
    ): NightPatternProfile {
        val previous = board.previousNight ?: return NightPatternProfile()
        val snapshot = snapshots.lastOrNull { it.date == previous.date }
            ?: return NightPatternProfile(date = previous.date)
        val resolved = snapshot.hitters.filter { it.outcomeHomeRun != null }
        val homers = resolved.filter { it.outcomeHomeRun == true }
        if (resolved.isEmpty() || homers.isEmpty()) {
            return NightPatternProfile(
                date = previous.date,
                gradedHitters = resolved.size,
                homerHitters = homers.size
            )
        }

        val baselineHrRate = homers.size.toDouble() / resolved.size
        val homerSummaryById = previous.homers.associateBy { it.playerId }
        val references = homers.map { row ->
            NightHomerReference(
                playerId = row.playerId,
                playerName = homerSummaryById[row.playerId]?.playerName ?: "Player ${row.playerId}",
                homeRuns = homerSummaryById[row.playerId]?.homeRuns ?: 1,
                seasonPower = row.seasonPower,
                contactProfile = row.contactProfile,
                recentPower = row.recentPower,
                powerPressure = row.powerPressure,
                pitcherMatchup = row.pitcherMatchup,
                pitchArsenalFit = row.pitchArsenalFit?.takeIf { (row.pitchArsenalConfidence ?: 0.30) >= 0.28 },
                attackZoneFit = row.attackZoneFit?.takeIf { (row.attackZoneConfidence ?: 0.0) >= 0.28 },
                platoon = row.platoon,
                environment = row.environment
            )
        }
        val signals = patternSignalDefs.mapNotNull { def ->
            val available = resolved.mapNotNull { row -> def.getter(row)?.let { row to it } }
            val homerAvailable = available.filter { it.first.outcomeHomeRun == true }
            if (available.size < 25 || homerAvailable.size < 3) return@mapNotNull null

            val exposed = available.filter { it.second >= def.threshold }
            val homerExposed = exposed.count { it.first.outcomeHomeRun == true }
            val fieldCount = exposed.size
            if (fieldCount < 8) return@mapNotNull null

            val homerCoverage = homerExposed.toDouble() / homerAvailable.size
            val fieldCoverage = fieldCount.toDouble() / available.size
            val exposedHrRate = homerExposed.toDouble() / fieldCount
            val hrRateLift = if (baselineHrRate > 0.0) exposedHrRate / baselineHrRate else 1.0
            val homerAverage = homerAvailable.map { it.second }.average()
            val fieldAverage = available.map { it.second }.average()
            val averageDelta = homerAverage - fieldAverage

            // Strength rewards broad HR-hitter coverage first, then actual HR-rate lift, then the
            // mean separation from the field. One tiny niche split cannot become the #1 pattern.
            val liftComponent = ((hrRateLift - 1.0) / 1.25).coerceIn(0.0, 1.0)
            val deltaComponent = (averageDelta / 16.0).coerceIn(0.0, 1.0)
            val strength = (homerCoverage * 55.0 + liftComponent * 30.0 + deltaComponent * 15.0)
                .coerceIn(0.0, 100.0)

            val meaningful = (homerCoverage >= .35 && hrRateLift >= 1.05) ||
                (homerCoverage >= .55 && averageDelta >= 3.0)
            if (!meaningful) return@mapNotNull null

            CommonDenominatorSignal(
                key = def.key,
                label = def.label,
                threshold = def.threshold,
                homerCount = homerExposed,
                homerTotal = homerAvailable.size,
                fieldCount = fieldCount,
                fieldTotal = available.size,
                homerCoverage = homerCoverage,
                fieldCoverage = fieldCoverage,
                hrRateLift = hrRateLift.coerceIn(0.25, 4.0),
                homerAverage = homerAverage,
                fieldAverage = fieldAverage,
                strength = strength
            )
        }.sortedByDescending { it.strength }.take(5)

        // Pair/triple common denominators catch interactions that disappear in one-metric averages.
        // In particular, arsenal fit + handedness gets surfaced when actual HR hitters shared both
        // traits at a higher rate than the rest of the slate. It is evidence-driven, not forced.
        val combinations = (2..3).flatMap { size ->
            patternDefCombinations(size).mapNotNull { combo ->
                val available = resolved.filter { row -> combo.all { it.getter(row) != null } }
                val homerAvailable = available.filter { it.outcomeHomeRun == true }
                if (available.size < 25 || homerAvailable.size < 3) return@mapNotNull null
                val exposed = available.filter { row ->
                    combo.all { def -> (def.getter(row) ?: Double.NEGATIVE_INFINITY) >= def.threshold }
                }
                val homerExposed = exposed.count { it.outcomeHomeRun == true }
                if (exposed.size < 7 || homerExposed < 2) return@mapNotNull null
                val baseline = homerAvailable.size.toDouble() / available.size
                val rate = homerExposed.toDouble() / exposed.size
                val lift = if (baseline > 0.0) rate / baseline else 1.0
                val coverage = homerExposed.toDouble() / homerAvailable.size
                val sampleReliability = exposed.size.toDouble() / (exposed.size + if (size == 2) 28.0 else 40.0)
                val strength = (coverage * 58.0 + ((lift - 1.0) / 1.15).coerceIn(0.0, 1.0) * 30.0 + sampleReliability * 12.0)
                    .coerceIn(0.0, 100.0)
                val meaningful = coverage >= .30 && lift >= 1.08
                if (!meaningful) return@mapNotNull null
                CommonDenominatorCombination(
                    key = combo.joinToString("+") { it.key },
                    label = combo.joinToString(" + ") { it.label },
                    homerCount = homerExposed,
                    homerTotal = homerAvailable.size,
                    fieldCount = exposed.size,
                    fieldTotal = available.size,
                    homerCoverage = coverage,
                    hrRateLift = lift.coerceIn(0.25, 4.0),
                    strength = strength
                )
            }
        }.sortedWith(
            compareByDescending<CommonDenominatorCombination> {
                it.strength + when {
                    it.key.contains("pitchArsenalFit") && it.key.contains("platoon") -> 4.0
                    it.key.contains("attackZoneFit") && (it.key.contains("pitchArsenalFit") || it.key.contains("pitcherMatchup")) -> 3.0
                    else -> 0.0
                }
            }.thenByDescending { it.hrRateLift }
        ).take(5)

        fun greenLightCount(row: HitterSignalSnapshot): Int = patternSignalDefs.count { def ->
            val value = def.getter(row)
            value != null && value >= def.threshold
        }
        val homerGreen = homers.map(::greenLightCount).average()
        val fieldGreen = resolved.map(::greenLightCount).average()
        val homerConfidence = (homers.size / 12.0).coerceIn(0.0, 1.0)
        val fieldConfidence = (resolved.size / 160.0).coerceIn(0.0, 1.0)
        val confidence = (homerConfidence * .70 + fieldConfidence * .30).coerceIn(0.0, 1.0)

        return NightPatternProfile(
            date = previous.date,
            gradedHitters = resolved.size,
            homerHitters = homers.size,
            signals = signals,
            combinations = combinations,
            references = references,
            homerGreenLightsAverage = homerGreen,
            fieldGreenLightsAverage = fieldGreen,
            confidence = confidence
        )
    }

    /**
     * Live same-day pattern transfer. References are actual hitters who have already homered today,
     * but their comparison vector comes from the saved PRE-GAME snapshot for this date. That keeps
     * the outcome from leaking back into the profile we are trying to compare against late games.
     */
    private fun buildSameDayPattern(
        board: BoardData,
        snapshots: List<DailySignalSnapshot>
    ): SameDayPatternProfile {
        if (board.date != LocalDate.now()) return SameDayPatternProfile(date = board.date)

        val startedGames = board.games.filter { !it.status.equals("Preview", true) && !gameIsUnavailable(it) }
        val remainingGames = board.games.filter { it.status.equals("Preview", true) && !gameIsUnavailable(it) }
        val startedGameIds = startedGames.map { it.gamePk }.toSet()
        val snapshot = snapshots.lastOrNull { it.date == board.date }
            ?: return SameDayPatternProfile(
                date = board.date,
                startedGames = startedGames.size,
                finalGames = startedGames.count { it.status.equals("Final", true) },
                remainingGames = remainingGames.size
            )
        val snapshotById = snapshot.hitters.associateBy { it.playerId }

        val references = board.candidates
            .asSequence()
            .filter { candidate -> candidate.game.gamePk in startedGameIds }
            .mapNotNull { candidate ->
                val homers = candidate.todayBattedBalls.filter { it.isHomeRun }
                if (homers.isEmpty()) return@mapNotNull null
                val row = snapshotById[candidate.player.id] ?: run {
                    val metrics = scoringModel.mustHaveMetrics(
                        candidate.player, candidate.seasonStats, candidate.recentBattedBalls
                    )
                    val contactProfile = metrics.score * metrics.confidence +
                        candidate.score.seasonPower * (1.0 - metrics.confidence)
                    HitterSignalSnapshot(
                        date = board.date,
                        playerId = candidate.player.id,
                        recentPower = candidate.score.recentPower,
                        powerPressure = candidate.score.powerPressure,
                        pitcherMatchup = candidate.score.pitcherMatchup,
                        environment = candidate.score.environment,
                        seasonPower = candidate.score.seasonPower,
                        platoon = candidate.score.platoon,
                        contactProfile = contactProfile,
                        pitchArsenalFit = candidate.pitchArsenalMatch?.score,
                        pitchArsenalConfidence = candidate.pitchArsenalMatch?.confidence,
                        attackZoneFit = candidate.attackZoneMatch?.score,
                        attackZoneConfidence = candidate.attackZoneMatch?.confidence,
                        statcastPower = officialPowerQualityScore(candidate).takeIf {
                            candidate.statcastContact != null || candidate.expectedStats != null
                        },
                        pullAirPower = pullAirPowerScore(candidate).takeIf { candidate.battedBallDirection != null },
                        advancedPitcher = advancedPitcherVulnerabilityScore(candidate).takeIf {
                            candidate.opponentPitcher?.statcastContact != null || candidate.opponentPitcher?.expectedStats != null
                        },
                        precisionConfidence = precisionDataConfidence(candidate)
                    )
                }
                SameDayHomerReference(
                    playerId = candidate.player.id,
                    playerName = candidate.player.name,
                    team = candidate.team,
                    gamePk = candidate.game.gamePk,
                    homeRuns = homers.size,
                    maxExitVelocity = homers.mapNotNull { it.exitVelocity }.maxOrNull(),
                    longestDistanceFt = homers.mapNotNull { it.distanceFt }.maxOrNull(),
                    pitchTypes = homers.mapNotNull { it.pitchType }.distinct(),
                    seasonPower = row.seasonPower,
                    contactProfile = row.contactProfile,
                    recentPower = row.recentPower,
                    powerPressure = row.powerPressure,
                    pitcherMatchup = row.pitcherMatchup,
                    pitchArsenalFit = row.pitchArsenalFit?.takeIf { (row.pitchArsenalConfidence ?: 0.30) >= 0.28 },
                    attackZoneFit = row.attackZoneFit?.takeIf { (row.attackZoneConfidence ?: 0.0) >= 0.28 },
                    platoon = row.platoon,
                    environment = row.environment
                )
            }
            .toList()

        fun referenceVector(reference: SameDayHomerReference): Map<String, Double?> = mapOf(
            "seasonPower" to reference.seasonPower,
            "contactProfile" to reference.contactProfile,
            "recentPower" to reference.recentPower,
            "powerPressure" to reference.powerPressure,
            "pitcherMatchup" to reference.pitcherMatchup,
            "pitchArsenalFit" to reference.pitchArsenalFit,
            "attackZoneFit" to reference.attackZoneFit,
            "platoon" to reference.platoon,
            "environment" to reference.environment
        )

        val sharedSignals = patternSignalDefs.mapNotNull { def ->
            val values = references.mapNotNull { ref -> referenceVector(ref)[def.key] }
            if (values.isEmpty()) return@mapNotNull null
            val homerCount = values.count { it >= def.threshold }
            val coverage = homerCount.toDouble() / values.size
            val average = values.average()
            if (coverage < .50 || average < def.threshold - 6.0) return@mapNotNull null
            SameDaySharedSignal(
                key = def.key,
                label = def.label,
                threshold = def.threshold,
                homerCount = homerCount,
                homerTotal = values.size,
                coverage = coverage,
                homerAverage = average
            )
        }.sortedWith(
            compareByDescending<SameDaySharedSignal> { it.coverage }
                .thenByDescending { it.homerAverage }
        ).take(5)

        val homerConfidence = (references.size / 6.0).coerceIn(.25, 1.0)
        val slateCoverage = if (board.games.isNotEmpty()) {
            (startedGames.size.toDouble() / board.games.size).coerceIn(0.0, 1.0)
        } else 0.0
        val confidence = if (references.isEmpty()) 0.0
        else (homerConfidence * .78 + slateCoverage * .22).coerceIn(.25, 1.0)

        return SameDayPatternProfile(
            date = board.date,
            startedGames = startedGames.size,
            finalGames = startedGames.count { it.status.equals("Final", true) },
            remainingGames = remainingGames.size,
            totalHomeRuns = references.sumOf { it.homeRuns },
            references = references,
            sharedSignals = sharedSignals,
            confidence = confidence
        )
    }

    private fun patternValues(candidate: HitterCandidate): Map<String, Double?> = mapOf(
        "seasonPower" to candidate.score.seasonPower,
        "contactProfile" to mustHavePowerScore(candidate),
        "recentPower" to candidate.score.recentPower,
        "powerPressure" to candidate.score.powerPressure,
        "pitcherMatchup" to candidate.score.pitcherMatchup,
        "pitchArsenalFit" to candidate.pitchArsenalMatch?.takeIf { it.confidence >= 0.28 }?.score,
        "attackZoneFit" to candidate.attackZoneMatch?.takeIf { it.confidence >= 0.28 }?.score,
        "statcastPower" to officialPowerQualityScore(candidate).takeIf {
            precisionDataConfidence(candidate) >= 0.30 && (candidate.statcastContact != null || candidate.expectedStats != null)
        },
        "pullAirPower" to pullAirPowerScore(candidate).takeIf {
            precisionDataConfidence(candidate) >= 0.30 && candidate.battedBallDirection != null
        },
        "advancedPitcher" to advancedPitcherVulnerabilityScore(candidate).takeIf {
            precisionDataConfidence(candidate) >= 0.30 &&
                (candidate.opponentPitcher?.statcastContact != null || candidate.opponentPitcher?.expectedStats != null)
        },
        "platoon" to candidate.score.platoon,
        "environment" to precisionEnvironmentScore(candidate)
    )

    private fun patternRuleMatches(candidate: HitterCandidate, rule: LearnedPatternRule): Boolean {
        val values = patternValues(candidate)
        val thresholds = patternSignalDefs.associate { it.key to it.threshold }
        return rule.key.split("+").all { key ->
            val value = values[key] ?: return@all false
            value >= (thresholds[key] ?: 65.0)
        }
    }

    /**
     * Pattern Engine v2. Instead of assuming that every good metric adds independent value, this
     * asks whether several signals are converging in combinations that have actually preceded HRs.
     * The learned half uses only pregame snapshots and Bayesian-shrunk pair/triple rules.
     */
    fun patternEngineScore(candidate: HitterCandidate): Double {
        val values = patternValues(candidate)
        val available = patternSignalDefs.filter { values[it.key] != null }
        val green = available.count { def -> (values[def.key] ?: -1.0) >= def.threshold }
        val greenRatio = if (available.isNotEmpty()) green.toDouble() / available.size else 0.0

        var structural = 34.0 + greenRatio * 46.0
        val season = values["seasonPower"] ?: 50.0
        val contact = values["contactProfile"] ?: 50.0
        val recent = values["recentPower"] ?: 50.0
        val pressure = values["powerPressure"] ?: 50.0
        val matchup = values["pitcherMatchup"] ?: 50.0
        val arsenal = values["pitchArsenalFit"]
        val zone = values["attackZoneFit"]
        val statcastPower = values["statcastPower"]
        val pullAir = values["pullAirPower"]
        val advancedPitcher = values["advancedPitcher"]
        val platoon = values["platoon"] ?: 50.0
        val convergence = arsenalHandednessConvergence(candidate)

        // High-value archetypes: these are conjunctions, not additive bonuses for the same signal.
        if (season >= 65.0 && contact >= 62.0 && matchup >= 60.0) structural += 8.0
        if (recent >= 62.0 && pressure >= 62.0 && contact >= 60.0) structural += 6.0
        if (arsenal != null && arsenal >= 68.0 && matchup >= 62.0) structural += 4.0
        if (zone != null && zone >= 64.0 && matchup >= 60.0 && contact >= 58.0) structural += 4.0
        if (zone != null && zone >= 68.0 && arsenal != null && arsenal >= 68.0 && season >= 58.0) structural += 4.0
        if (statcastPower != null && statcastPower >= 68.0 && pullAir != null && pullAir >= 66.0) structural += 7.0
        if (statcastPower != null && statcastPower >= 66.0 && advancedPitcher != null && advancedPitcher >= 64.0) structural += 6.0
        if (statcastPower != null && statcastPower >= 68.0 && arsenal != null && arsenal >= 68.0) structural += 5.0
        if (platoon >= 64.0 && matchup >= 62.0 && season >= 58.0) structural += 3.0
        // This is the interaction the new formula is designed to recognize. It gets more authority
        // than either metric alone, but only when both sides and sample confidence agree.
        if (convergence.isPerfectFit && season >= 58.0 && contact >= 56.0) structural += 10.0
        else if (convergence.isStrongFit && season >= 56.0) structural += 6.0

        // Anti-patterns seen repeatedly in manual review: one loud recent signal without a power
        // foundation, or a mediocre bat trying to overcome a genuinely resistant matchup.
        if (pressure >= 72.0 && season < 52.0 && contact < 58.0) structural -= 10.0
        if (recent >= 70.0 && season < 48.0) structural -= 6.0
        if (matchup < 42.0 && season < 66.0) structural -= 7.0
        structural = structural.coerceIn(18.0, 96.0)

        val learning = _state.value.learningProfile
        if (!learning.isActive || learning.patterns.isEmpty()) return structural

        val matched = learning.patterns.filter { patternRuleMatches(candidate, it) }
        if (matched.isEmpty()) return structural

        var learnedDelta = 0.0
        var evidenceWeight = 0.0
        matched.forEach { rule ->
            // Positive and negative rules both matter. Shrink the effect again at application time
            // so no single historical conjunction can swing a hitter by double digits.
            val interactionPriority = when {
                rule.key.contains("pitchArsenalFit") && rule.key.contains("platoon") -> 1.22
                rule.key.contains("statcastPower") && (rule.key.contains("pullAirPower") || rule.key.contains("advancedPitcher")) -> 1.18
                rule.key.contains("attackZoneFit") && (rule.key.contains("pitchArsenalFit") || rule.key.contains("pitcherMatchup")) -> 1.12
                else -> 1.0
            }
            val weight = (rule.reliability.coerceAtLeast(.08) * interactionPriority).coerceAtMost(1.0)
            val effect = ((rule.posteriorLift - 1.0) * 34.0).coerceIn(-12.0, 14.0)
            learnedDelta += effect * weight
            evidenceWeight += weight
        }
        val learnedScore = (50.0 + if (evidenceWeight > 0.0) learnedDelta / evidenceWeight else 0.0)
            .coerceIn(25.0, 82.0)

        val sampleConfidence = ((learning.resolvedHitterGames - 200) / 1000.0).coerceIn(.10, 1.0)
        val outcomeConfidence = ((learning.homeRuns - 15) / 65.0).coerceIn(.10, 1.0)
        val learnedWeight = (minOf(sampleConfidence, outcomeConfidence) * .55).coerceIn(.08, .55)
        return (structural * (1.0 - learnedWeight) + learnedScore * learnedWeight).coerceIn(0.0, 100.0)
    }

    fun patternEngineReasons(candidate: HitterCandidate): List<String> {
        val learning = _state.value.learningProfile
        val learned = if (learning.isActive) learning.patterns
            .filter { it.isPositive && patternRuleMatches(candidate, it) }
            .sortedWith(
                compareByDescending<LearnedPatternRule> {
                    val arsenalHand = it.key.contains("pitchArsenalFit") && it.key.contains("platoon")
                    (it.posteriorLift - 1.0) * it.reliability + if (arsenalHand) .08 else 0.0
                }
            )
            .take(3)
            .map { rule -> "${rule.label} • ${"%.2f".format(rule.posteriorLift)}x learned lift" }
        else emptyList()
        if (learned.isNotEmpty()) return learned

        val values = patternValues(candidate)
        return buildList {
            val season = values["seasonPower"] ?: 0.0
            val contact = values["contactProfile"] ?: 0.0
            val recent = values["recentPower"] ?: 0.0
            val pressure = values["powerPressure"] ?: 0.0
            val matchup = values["pitcherMatchup"] ?: 0.0
            val arsenal = values["pitchArsenalFit"] ?: 0.0
            val zone = values["attackZoneFit"] ?: 0.0
            val convergence = arsenalHandednessConvergence(candidate)
            if (convergence.isPerfectFit) add("Perfect pitch arsenal + handedness convergence")
            else if (convergence.isStrongFit) add("Strong pitch arsenal + handedness convergence")
            if (season >= 65 && contact >= 62 && matchup >= 60) add("Power + contact + matchup convergence")
            if (recent >= 62 && pressure >= 62 && contact >= 60) add("Recent pressure backed by contact quality")
            if (arsenal >= 68 && matchup >= 62) add("Pitch-mix fit reinforces the matchup")
            if (zone >= 64 && matchup >= 60) add("Attack-zone overlap reinforces the matchup")
            if (zone >= 68 && arsenal >= 68) add("Pitch type + attack zone converge")
            if (isEmpty()) add("No strong multi-signal pattern yet")
        }.take(3)
    }

    fun modelLearningSummary(): List<LearnedPatternRule> = _state.value.learningProfile.patterns
        .filter { it.posteriorLift >= 1.05 }
        .sortedByDescending {
            val interactionPriority = when {
                it.key.contains("pitchArsenalFit") && it.key.contains("platoon") -> .08
                it.key.contains("attackZoneFit") && (it.key.contains("pitchArsenalFit") || it.key.contains("pitcherMatchup")) -> .05
                else -> 0.0
            }
            (it.posteriorLift - 1.0) * it.reliability + interactionPriority
        }
        .take(5)

    private fun referenceValues(reference: NightHomerReference): Map<String, Double?> = mapOf(
        "seasonPower" to reference.seasonPower,
        "contactProfile" to reference.contactProfile,
        "recentPower" to reference.recentPower,
        "powerPressure" to reference.powerPressure,
        "pitcherMatchup" to reference.pitcherMatchup,
        "pitchArsenalFit" to reference.pitchArsenalFit,
        "attackZoneFit" to reference.attackZoneFit,
        "platoon" to reference.platoon,
        "environment" to reference.environment
    )

    private val profileEchoWeights = mapOf(
        "seasonPower" to 1.20,
        "contactProfile" to 1.15,
        "recentPower" to 0.95,
        "powerPressure" to 0.90,
        "pitcherMatchup" to 0.90,
        "pitchArsenalFit" to 1.15,
        "attackZoneFit" to 0.95,
        "platoon" to 0.70,
        "environment" to 0.50
    )

    /**
     * Compares today's full pregame signal vector with an actual hitter who homered last night.
     * This is intentionally a similarity score rather than a "copy yesterday" rule: a player can
     * resemble a different HR archetype (established power, heating contact, arsenal edge, etc.)
     * even when that archetype was not the single most common trait across the entire HR group.
     */
    private fun profileVectorSimilarity(
        currentValues: Map<String, Double?>,
        referenceValues: Map<String, Double?>,
        multiHrBonus: Boolean = false
    ): Double {
        var weighted = 0.0
        var totalWeight = 0.0
        var usable = 0
        profileEchoWeights.forEach { (key, weight) ->
            val current = currentValues[key]
            val prior = referenceValues[key]
            if (current != null && prior != null) {
                val metricSimilarity = (100.0 - (current - prior).absoluteValue * 1.55)
                    .coerceIn(0.0, 100.0)
                weighted += metricSimilarity * weight
                totalWeight += weight
                usable++
            }
        }
        if (usable < 5 || totalWeight <= 0.0) return 0.0
        val base = weighted / totalWeight
        return (base + if (multiHrBonus) 2.5 else 0.0).coerceIn(0.0, 100.0)
    }

    private fun profileEchoSimilarity(
        today: Map<String, Double?>,
        reference: NightHomerReference
    ): Double = profileVectorSimilarity(
        currentValues = today,
        referenceValues = referenceValues(reference),
        multiHrBonus = reference.homeRuns >= 2
    )

    fun lastNightProfileEchoScore(candidate: HitterCandidate): Double {
        val pattern = _state.value.lastNightPattern
        if (pattern.references.size < 4) return 0.0
        val today = patternValues(candidate)
        val matches = pattern.references
            .map { reference -> profileEchoSimilarity(today, reference) }
            .filter { it > 0.0 }
            .sortedDescending()
            .take(3)
        if (matches.isEmpty()) return 0.0
        return when (matches.size) {
            1 -> matches[0]
            2 -> matches[0] * .68 + matches[1] * .32
            else -> matches[0] * .55 + matches[1] * .28 + matches[2] * .17
        }.coerceIn(0.0, 100.0)
    }

    fun lastNightClosestProfiles(candidate: HitterCandidate, limit: Int = 2): List<Pair<String, Int>> {
        val pattern = _state.value.lastNightPattern
        if (pattern.references.isEmpty()) return emptyList()
        val today = patternValues(candidate)
        return pattern.references
            .map { reference -> reference to profileEchoSimilarity(today, reference) }
            .filter { (_, score) -> score >= 58.0 }
            .sortedByDescending { (_, score) -> score }
            .take(limit.coerceIn(1, 3))
            .map { (reference, score) ->
                val label = if (reference.homeRuns >= 2) "${reference.playerName} (${reference.homeRuns} HR)" else reference.playerName
                label to score.roundToInt()
            }
    }

    private fun sameDayReferenceValues(reference: SameDayHomerReference): Map<String, Double?> = mapOf(
        "seasonPower" to reference.seasonPower,
        "contactProfile" to reference.contactProfile,
        "recentPower" to reference.recentPower,
        "powerPressure" to reference.powerPressure,
        "pitcherMatchup" to reference.pitcherMatchup,
        "pitchArsenalFit" to reference.pitchArsenalFit,
        "attackZoneFit" to reference.attackZoneFit,
        "platoon" to reference.platoon,
        "environment" to reference.environment
    )

    private fun sameDayEchoSimilarity(
        current: Map<String, Double?>,
        reference: SameDayHomerReference
    ): Double = profileVectorSimilarity(
        currentValues = current,
        referenceValues = sameDayReferenceValues(reference),
        multiHrBonus = reference.homeRuns >= 2
    )

    /**
     * 0-100 live similarity grade for hitters whose games have not started yet. This is primarily
     * direct profile echo, with a smaller boost when the candidate also carries the strong traits
     * shared by multiple HR hitters from earlier games today.
     */
    fun sameDayPatternScore(candidate: HitterCandidate): Double {
        val pattern = _state.value.sameDayPattern
        if (!pattern.isUsable || !candidate.game.status.equals("Preview", true) || gameIsUnavailable(candidate.game)) return 0.0
        val values = patternValues(candidate)
        val echoMatches = pattern.references
            .map { reference -> sameDayEchoSimilarity(values, reference) }
            .filter { it > 0.0 }
            .sortedDescending()
            .take(3)
        if (echoMatches.isEmpty()) return 0.0
        val echo = when (echoMatches.size) {
            1 -> echoMatches[0]
            2 -> echoMatches[0] * .68 + echoMatches[1] * .32
            else -> echoMatches[0] * .55 + echoMatches[1] * .28 + echoMatches[2] * .17
        }

        val usableSignals = pattern.sharedSignals.mapNotNull { signal ->
            values[signal.key]?.let { value -> signal to value }
        }
        val sharedFit = if (usableSignals.size >= 2) {
            val totalWeight = usableSignals.sumOf { (signal, _) -> 0.5 + signal.coverage }
            usableSignals.sumOf { (signal, value) ->
                val fit = ((value - (signal.threshold - 18.0)) / 36.0 * 100.0).coerceIn(0.0, 100.0)
                fit * (0.5 + signal.coverage)
            } / totalWeight
        } else 0.0

        return if (sharedFit > 0.0) (echo * .78 + sharedFit * .22).coerceIn(0.0, 100.0)
        else echo.coerceIn(0.0, 100.0)
    }

    fun sameDayClosestProfiles(candidate: HitterCandidate, limit: Int = 2): List<Pair<String, Int>> {
        val pattern = _state.value.sameDayPattern
        if (!pattern.isUsable || !candidate.game.status.equals("Preview", true) || gameIsUnavailable(candidate.game)) return emptyList()
        val values = patternValues(candidate)
        return pattern.references
            .map { reference -> reference to sameDayEchoSimilarity(values, reference) }
            .filter { (_, score) -> score >= 58.0 }
            .sortedByDescending { (_, score) -> score }
            .take(limit.coerceIn(1, 3))
            .map { (reference, score) ->
                val label = if (reference.homeRuns >= 2) "${reference.playerName} (${reference.homeRuns} HR)" else reference.playerName
                label to score.roundToInt()
            }
    }

    fun sameDayPatternReasons(candidate: HitterCandidate): List<String> {
        val pattern = _state.value.sameDayPattern
        if (!pattern.isUsable || !candidate.game.status.equals("Preview", true) || gameIsUnavailable(candidate.game)) return emptyList()
        val values = patternValues(candidate)
        return pattern.sharedSignals
            .filter { signal -> (values[signal.key] ?: Double.NEGATIVE_INFINITY) >= signal.threshold }
            .sortedWith(compareByDescending<SameDaySharedSignal> { it.coverage }.thenByDescending { it.homerAverage })
            .take(3)
            .map { it.label }
    }

    private fun sameDayPatternAdjustment(candidate: HitterCandidate): Double {
        val pattern = _state.value.sameDayPattern
        if (!pattern.isUsable || !candidate.game.status.equals("Preview", true) || gameIsUnavailable(candidate.game)) return 0.0
        val score = sameDayPatternScore(candidate)
        val raw = when {
            score >= 90.0 -> 2.0
            score >= 83.0 -> 1.4
            score >= 76.0 -> 0.9
            score >= 68.0 -> 0.4
            else -> 0.0
        }
        // Same-day results are fresh but noisy. This can break close late-slate ties, never replace
        // season power, contact quality, matchup or arsenal fit. One early HR only has low confidence.
        return (raw * pattern.confidence).coerceIn(0.0, 2.0)
    }

    /** 0-100 blend of common-denominator fit and direct profile similarity to last night's HR hitters. */
    fun lastNightPatternScore(candidate: HitterCandidate): Double {
        val pattern = _state.value.lastNightPattern
        if (!pattern.isUsable) return 0.0
        val values = patternValues(candidate)
        val usable = pattern.signals.mapNotNull { signal ->
            values[signal.key]?.let { value -> signal to value }
        }

        val commonScore = if (usable.size >= 2) {
            val totalWeight = usable.sumOf { (signal, _) -> signal.strength.coerceAtLeast(20.0) }
            if (totalWeight <= 0.0) 0.0 else {
                val weightedFit = usable.sumOf { (signal, value) ->
                    val relative = ((value - (signal.threshold - 18.0)) / 36.0 * 100.0).coerceIn(0.0, 100.0)
                    relative * signal.strength.coerceAtLeast(20.0)
                } / totalWeight
                val matchedWeight = usable.filter { (signal, value) -> value >= signal.threshold }
                    .sumOf { (signal, _) -> signal.strength.coerceAtLeast(20.0) }
                val matchedShare = matchedWeight / totalWeight
                (weightedFit * .62 + matchedShare * 100.0 * .38).coerceIn(0.0, 100.0)
            }
        } else 0.0

        val thresholds = patternSignalDefs.associate { it.key to it.threshold }
        val totalComboWeight = pattern.combinations.sumOf { it.strength.coerceAtLeast(20.0) }
        val matchedCombos = pattern.combinations.filter { combo ->
            combo.key.split("+").all { key ->
                (values[key] ?: Double.NEGATIVE_INFINITY) >= (thresholds[key] ?: 65.0)
            }
        }
        val comboScore = if (totalComboWeight > 0.0 && matchedCombos.isNotEmpty()) {
            (matchedCombos.sumOf { it.strength.coerceAtLeast(20.0) } / totalComboWeight * 100.0)
                .coerceIn(0.0, 100.0)
        } else 0.0

        val echoScore = lastNightProfileEchoScore(candidate)
        val pieces = buildList<Pair<Double, Double>> {
            if (commonScore > 0.0) add(commonScore to .48)
            if (echoScore > 0.0) add(echoScore to .32)
            if (comboScore > 0.0) add(comboScore to .20)
        }
        if (pieces.isEmpty()) return 0.0
        val total = pieces.sumOf { it.second }
        return (pieces.sumOf { it.first * it.second } / total).coerceIn(0.0, 100.0)
    }

    fun lastNightPatternReasons(candidate: HitterCandidate): List<String> {
        val pattern = _state.value.lastNightPattern
        if (!pattern.isUsable) return emptyList()
        val values = patternValues(candidate)
        val thresholds = patternSignalDefs.associate { it.key to it.threshold }
        val combos = pattern.combinations
            .filter { combo -> combo.key.split("+").all { key ->
                (values[key] ?: Double.NEGATIVE_INFINITY) >= (thresholds[key] ?: 65.0)
            } }
            .sortedByDescending {
                it.strength + when {
                    it.key.contains("pitchArsenalFit") && it.key.contains("platoon") -> 5.0
                    it.key.contains("attackZoneFit") && (it.key.contains("pitchArsenalFit") || it.key.contains("pitcherMatchup")) -> 4.0
                    else -> 0.0
                }
            }
            .map { it.label }
        val singles = pattern.signals
            .filter { signal -> (values[signal.key] ?: Double.NEGATIVE_INFINITY) >= signal.threshold }
            .sortedByDescending { it.strength }
            .map { it.label }
        return (combos + singles).distinct().take(3)
    }

    private fun lastNightPatternAdjustment(candidate: HitterCandidate): Double {
        val pattern = _state.value.lastNightPattern
        if (!pattern.isUsable) return 0.0
        val score = lastNightPatternScore(candidate)
        val raw = when {
            score >= 88.0 -> 2.4
            score >= 80.0 -> 1.7
            score >= 72.0 -> 1.0
            score >= 64.0 -> 0.45
            else -> 0.0
        }
        // One night is evidence, not a new model. Confidence scales with the number of HR outcomes
        // and the size of yesterday's graded field, and the total effect is intentionally capped.
        return (raw * pattern.confidence).coerceIn(0.0, 2.4)
    }

    private fun outcomeLearningAdjustment(
        candidate: HitterCandidate,
        contactProfile: Double
    ): Double {
        val learning = _state.value.learningProfile
        var adjustment = 0.0

        if (learning.isActive) {
            val signals = mapOf(
                "recentPower" to candidate.score.recentPower,
                "powerPressure" to candidate.score.powerPressure,
                "pitcherMatchup" to candidate.score.pitcherMatchup,
                "environment" to candidate.score.environment,
                "seasonPower" to candidate.score.seasonPower,
                "platoon" to candidate.score.platoon,
                "contactProfile" to contactProfile,
                "pitchArsenalFit" to candidate.pitchArsenalMatch?.score
            )
            signals.forEach { (key, value) ->
                if (value == null || value < 65.0) return@forEach
                val learned = learning.metrics[key] ?: return@forEach
                if (learned.attempts < 20) return@forEach
                val reliability = ((learned.attempts - 20) / 100.0).coerceIn(0.15, 1.0)
                val effect = ((learned.lift - 1.0) * 0.75).coerceIn(-0.45, 0.65)
                adjustment += effect * reliability
            }
        }

        // A homer last night is already represented in recent contact/power. This tiny extra
        // confirmation only breaks close ties and prevents the model from double-counting heat.
        val previous = _state.value.board?.previousNight
        val lastNight = previous?.homers?.firstOrNull { it.playerId == candidate.player.id }
        if (lastNight != null && (candidate.score.powerPressure >= 55.0 || contactProfile >= 60.0)) {
            adjustment += if (lastNight.homeRuns >= 2) 1.1 else 0.6
        }

        return adjustment.coerceIn(-2.0, 2.5)
    }

    private fun cacheBoard(board: BoardData) {
        if (board.candidates.isEmpty()) return
        synchronized(boardCache) { boardCache[board.date] = board }
    }

    private fun switchToDate(next: LocalDate) {
        refreshJob?.cancel()
        ++refreshGeneration
        val cached = synchronized(boardCache) { boardCache[next] }
        mutate {
            it.copy(
                selectedDate = next,
                board = cached,
                isLoading = false,
                progress = if (cached != null) "Showing saved data" else "",
                error = null,
                selectedPlayerId = null,
                selectedProfileCandidate = null,
                selectedProfileDate = null,
                isProfileLoading = false,
                isProfileBvpLoading = false,
                profileError = null,
                trackedLast10 = emptyMap(),
                trackedLast10Loading = emptySet(),
                postgameStats = emptyMap(),
                postgameStatsLoading = emptySet(),
                sameDayPattern = SameDayPatternProfile()
            )
        }
        refresh()
    }

    fun changeDate(days: Long) {
        val current = _state.value.selectedDate
        val minimum = LocalDate.now().minusDays(1)
        val requested = current.plusDays(days)
        val next = if (requested.isBefore(minimum)) minimum else requested
        if (next == current) return
        switchToDate(next)
    }

    fun setDate(date: LocalDate) {
        val minimum = LocalDate.now().minusDays(1)
        val next = if (date.isBefore(minimum)) minimum else date
        if (next == _state.value.selectedDate) return
        switchToDate(next)
    }

    fun toggleRemainingOnly() = mutate { it.copy(showRemainingOnly = !it.showRemainingOnly) }
    fun toggleOfficialOnly() = mutate { it.copy(officialLineupsOnly = !it.officialLineupsOnly) }
    fun toggleEliteArsenalOnly() = mutate { current ->
        val next = !current.eliteArsenalOnly
        current.copy(
            eliteArsenalOnly = next,
            topZoneOnly = if (next) false else current.topZoneOnly
        )
    }

    fun toggleTopZoneOnly() = mutate { current ->
        val next = !current.topZoneOnly
        current.copy(
            topZoneOnly = next,
            eliteArsenalOnly = if (next) false else current.eliteArsenalOnly
        )
    }

    fun setSortMode(mode: SortMode) = mutate { it.copy(sortMode = mode) }
    fun toggleAttackStrongOnly() = mutate { it.copy(attackStrongOnly = !it.attackStrongOnly) }

    /**
     * The v0.3 combo signal. This remains available as a building block, but v0.4 presents it
     * inside a simpler game-first experience instead of exposing many competing sort modes.
     */
    fun attackScore(candidate: HitterCandidate): Double =
        candidate.score.powerPressure * 0.45 +
            candidate.score.pitcherMatchup * 0.45 +
            candidate.score.recentPower * 0.10

    /**
     * A single recommendation score used for game rankings and the parlay generator.
     * It deliberately emphasizes "pressure + matchup", then checks the overall model and
     * environment so a hot hitter in a terrible spot does not automatically rise to the top.
     */
    /**
     * Sample-size-aware BvP adjustment. Strong history matters, but it is intentionally capped so
     * a 2-for-3 matchup cannot overpower current contact quality and the pitcher profile.
     */
    fun bvpAdjustment(candidate: HitterCandidate): Double {
        val bvp = candidate.vsPitcherStats ?: return 0.0
        val pa = bvp.plateAppearances
        if (pa < 5) return 0.0

        var raw = 0.0
        raw += when {
            (bvp.ops ?: 0.0) >= 1.050 -> 5.0
            (bvp.ops ?: 0.0) >= .900 -> 3.0
            (bvp.ops ?: 9.0) < .600 -> -2.0
            else -> 0.0
        }
        raw += when {
            bvp.homeRuns >= 3 -> 4.0
            bvp.homeRuns == 2 -> 3.0
            bvp.homeRuns == 1 -> 1.5
            else -> 0.0
        }
        raw += when {
            (bvp.avg ?: 0.0) >= .350 -> 1.5
            (bvp.avg ?: 0.0) >= .300 -> 0.75
            else -> 0.0
        }

        val reliability = when {
            pa >= 20 -> 1.0
            pa >= 12 -> .85
            pa >= 8 -> .70
            else -> .55
        }
        return (raw * reliability).coerceIn(-4.0, 8.0)
    }

    fun mustHaveMetrics(candidate: HitterCandidate): MustHaveMetrics {
        val key = "${candidate.game.gamePk}:${candidate.player.id}"
        return mustHaveCache.getOrPut(key) {
            scoringModel.mustHaveMetrics(candidate.player, candidate.seasonStats, candidate.recentBattedBalls)
        }
    }

    /**
     * Recent "must-have" power profile blended toward season power when the recent BBE sample is
     * small. This prevents one or two tracked balls from hijacking the daily ranking.
     */
    fun mustHavePowerScore(candidate: HitterCandidate): Double {
        val metrics = mustHaveMetrics(candidate)
        return metrics.score * metrics.confidence +
            candidate.score.seasonPower * (1.0 - metrics.confidence)
    }

    /**
     * Recent swing-and-miss score derived directly from MLB Gameday pitch descriptions.
     * Lower whiff rates are better. Small recent samples are blended back toward season K%.
     */
    fun swingMissScore(candidate: HitterCandidate): Double {
        val sample = candidate.recentPlateDiscipline
        val recent = sample.whiffRate?.let { rate -> inverseScale(rate, .14, .38) }
        val pa = candidate.seasonStats.plateAppearances
        val seasonK = if (pa > 0) candidate.seasonStats.strikeouts.toDouble() / pa else null
        val seasonContact = seasonK?.let { inverseScale(it, .14, .34) } ?: 50.0
        if (recent == null) return seasonContact
        val confidence = (sample.swings / 35.0).coerceIn(.20, 1.0)
        return recent * confidence + seasonContact * (1.0 - confidence)
    }

    fun recentWhiffRate(candidate: HitterCandidate): Double? = candidate.recentPlateDiscipline.whiffRate

    /**
     * Power Pressure now arrives from HrScoringModel already regressed for recent BBE sample size.
     * Keep this helper so ranking/UI code has one semantic place to consume the calibrated signal.
     */
    fun reliablePowerPressure(candidate: HitterCandidate): Double = candidate.score.powerPressure

    /**
     * How closely today's opposing pitcher arsenal matches the pitch types this hitter has
     * homered against this season. Missing/small samples blend back toward a neutral 50.
     */
    fun pitchArsenalFitScore(candidate: HitterCandidate): Double =
        candidate.pitchArsenalMatch?.score ?: 50.0

    /**
     * Arsenal + handedness convergence. This intentionally rewards the INTERACTION rather than
     * counting two green metrics independently. A great pitch-type matchup is most actionable when
     * the hitter also owns the platoon split, and both are backed by enough underlying sample.
     */
    /**
     * A genuinely elite arsenal matchup. We keep this stricter definition for badges/bonuses, but
     * the Top Arsenal filter no longer requires a hitter to clear it. The filter is now relative to
     * that day's slate and always surfaces the best measured matches available.
     */
    fun isEliteArsenalMatch(candidate: HitterCandidate): Boolean {
        val arsenal = candidate.pitchArsenalMatch ?: return false
        val batterEvidence = arsenal.batterPitchSample >= 90 || arsenal.batterHrSample >= 3
        val pitcherEvidence = arsenal.pitcherPitchSample >= 300
        return arsenal.score >= 82.0 &&
            arsenal.confidence >= 0.45 &&
            batterEvidence &&
            pitcherEvidence
    }

    /** Any real arsenal read is eligible for relative ranking; missing data is never fabricated. */
    fun hasUsableArsenalMatch(candidate: HitterCandidate): Boolean {
        val arsenal = candidate.pitchArsenalMatch ?: return false
        val batterEvidence = arsenal.batterPitchSample > 0 || arsenal.batterHrSample > 0
        return arsenal.score.isFinite() && arsenal.confidence.isFinite() &&
            arsenal.pitcherPitchSample > 0 && batterEvidence
    }

    fun eliteArsenalRank(candidate: HitterCandidate): Double {
        val arsenal = candidate.pitchArsenalMatch ?: return 0.0
        // Arsenal score remains the dominant signal. Confidence and overall HR quality only separate
        // similarly rated pitch-type matches instead of imposing a hard pass/fail threshold.
        val confidence = (arsenal.confidence * 100.0).coerceIn(0.0, 100.0)
        return (arsenal.score * .72 + confidence * .16 + targetScore(candidate) * .08 +
            mustHavePowerScore(candidate) * .04).coerceIn(0.0, 100.0)
    }

    private fun topArsenalMatches(
        candidates: List<HitterCandidate>,
        limit: Int = 15
    ): List<HitterCandidate> = candidates
        .asSequence()
        .filter(::hasUsableArsenalMatch)
        .sortedWith(
            compareByDescending<HitterCandidate> { it.pitchArsenalMatch?.score ?: Double.NEGATIVE_INFINITY }
                .thenByDescending { it.pitchArsenalMatch?.confidence ?: 0.0 }
                .thenByDescending(::targetScore)
                .thenByDescending(::mustHavePowerScore)
        )
        .take(limit)
        .toList()

    private fun arsenalCandidateKey(candidate: HitterCandidate): String =
        "${candidate.game.gamePk}:${candidate.player.id}"

    /** A measured attack-zone read. Even low-confidence reads can be ranked, but the UI labels
     * confidence separately so a tiny sample is never presented as equally trustworthy. */
    fun hasUsableAttackZoneMatch(candidate: HitterCandidate): Boolean {
        val zone = candidate.attackZoneMatch ?: return false
        return zone.score.isFinite() && zone.confidence.isFinite() &&
            zone.pitcherPitchSample > 0 && zone.batterContactSample > 0
    }

    fun attackZoneLabel(candidate: HitterCandidate): String {
        val zone = candidate.attackZoneMatch ?: return "NO DATA"
        return when {
            zone.score >= 70.0 -> "GREAT MATCH"
            zone.score >= 62.0 -> "GOOD MATCH"
            zone.score >= 55.0 -> "SLIGHT EDGE"
            zone.score >= 48.0 -> "NEUTRAL"
            else -> "TOUGH FIT"
        }
    }

    fun attackZoneConfidenceLabel(candidate: HitterCandidate): String {
        val confidence = candidate.attackZoneMatch?.confidence ?: return "NO DATA"
        return when {
            confidence >= .60 -> "HIGH"
            confidence >= .35 -> "MEDIUM"
            else -> "LOW"
        }
    }

    fun attackZoneSimpleReason(candidate: HitterCandidate): String {
        val zone = candidate.attackZoneMatch ?: return "No usable pitcher/hitter zone overlap is available yet."
        return when {
            zone.score >= 70.0 -> "The pitcher regularly attacks areas where this hitter has done his best recent damage."
            zone.score >= 62.0 -> "The pitcher's attack pattern overlaps well with this hitter's recent damage zones."
            zone.score >= 55.0 -> "There is some useful overlap, but it is not one of the slate's strongest zone setups."
            zone.score >= 48.0 -> "The attack map is mostly neutral for this hitter."
            else -> "The pitcher tends to work away from this hitter's strongest recent damage zones."
        }
    }

    private fun topAttackZoneMatches(
        candidates: List<HitterCandidate>,
        limit: Int = 15
    ): List<HitterCandidate> = candidates
        .asSequence()
        .filter(::hasUsableAttackZoneMatch)
        .sortedWith(
            compareByDescending<HitterCandidate> { it.attackZoneMatch?.score ?: Double.NEGATIVE_INFINITY }
                .thenByDescending { it.attackZoneMatch?.confidence ?: 0.0 }
                .thenByDescending(::targetScore)
                .thenByDescending(::mustHavePowerScore)
        )
        .take(limit)
        .toList()

    fun bestAttackZoneMatches(
        limit: Int = 15,
        state: AppUiState = _state.value
    ): List<HitterCandidate> {
        val cleanState = state.copy(eliteArsenalOnly = false, topZoneOnly = false)
        return topAttackZoneMatches(pregameCandidates(cleanState), limit)
    }

    fun isTopArsenalMatch(
        candidate: HitterCandidate,
        state: AppUiState = _state.value,
        limit: Int = 15
    ): Boolean {
        val pool = pregameCandidates(state.copy(eliteArsenalOnly = false, topZoneOnly = false))
        if (pool.isEmpty()) return false
        val keys = topArsenalMatches(pool, limit).asSequence().map(::arsenalCandidateKey).toHashSet()
        return arsenalCandidateKey(candidate) in keys
    }

    fun arsenalHandednessConvergence(candidate: HitterCandidate): MatchupConvergenceProfile {
        val arsenal = candidate.pitchArsenalMatch
            ?: return MatchupConvergenceProfile(platoonScore = candidate.score.platoon)
        if (arsenal.confidence < 0.22) {
            return MatchupConvergenceProfile(
                platoonScore = candidate.score.platoon,
                arsenalScore = arsenal.score,
                evidenceConfidence = arsenal.confidence
            )
        }

        val platoon = candidate.score.platoon
        val splitPa = candidate.platoonStats?.plateAppearances ?: 0
        val splitConfidence = (splitPa / 100.0).coerceIn(0.20, 1.0)
        val evidenceConfidence = (arsenal.confidence * .68 + splitConfidence * .32).coerceIn(.20, 1.0)

        // Harmonic-style behavior: the weaker side matters. A 92 arsenal fit with a 42 platoon
        // score is not a "perfect" matchup and should not look like one in the model.
        val weakerSide = minOf(arsenal.score, platoon)
        val weightedMean = arsenal.score * .58 + platoon * .42
        var raw = weakerSide * .58 + weightedMean * .42

        val pairRule = _state.value.learningProfile.patterns.firstOrNull {
            it.key == "pitchArsenalFit+platoon"
        }
        var learnedLift: Double? = null
        var learnedAttempts = 0
        if (pairRule != null && _state.value.learningProfile.isActive) {
            learnedLift = pairRule.posteriorLift
            learnedAttempts = pairRule.attempts
            val learnedDelta = ((pairRule.posteriorLift - 1.0) * 18.0 * pairRule.reliability)
                .coerceIn(-4.0, 6.0)
            raw += learnedDelta
        }

        // Shrink the interaction toward neutral when either pitch-type or split evidence is thin.
        val score = (50.0 + (raw - 50.0) * (0.55 + evidenceConfidence * 0.45))
            .coerceIn(0.0, 100.0)
        val label = when {
            score >= 82.0 && arsenal.score >= 80.0 && platoon >= 70.0 && arsenal.confidence >= .42 -> "PERFECT FIT"
            score >= 74.0 && arsenal.score >= 72.0 && platoon >= 64.0 -> "STRONG FIT"
            score >= 65.0 && arsenal.score >= 66.0 && platoon >= 58.0 -> "GOOD FIT"
            score < 43.0 && arsenal.score < 50.0 && platoon < 50.0 -> "POOR FIT"
            else -> "MIXED"
        }
        return MatchupConvergenceProfile(
            score = score,
            label = label,
            available = true,
            arsenalScore = arsenal.score,
            platoonScore = platoon,
            evidenceConfidence = evidenceConfidence,
            learnedLift = learnedLift,
            learnedAttempts = learnedAttempts
        )
    }

    /**
     * Count teammates at 10%+ recent barrel-proxy rate to create a modest lineup-power context score.
     */
    fun teamBarrelDepthScore(candidate: HitterCandidate, state: AppUiState = _state.value): Double {
        val teammates = state.board?.candidates.orEmpty().filter {
            it.game.gamePk == candidate.game.gamePk && it.team.id == candidate.team.id
        }
        if (teammates.isEmpty()) return 50.0
        val qualified = teammates.count { mate ->
            val m = mustHaveMetrics(mate)
            m.battedBallCount >= 3 && (m.barrelPct ?: 0.0) >= 10.0
        }
        return (35.0 + qualified * 11.0).coerceIn(25.0, 100.0)
    }

    /**
     * Independent HR Chase signal lens: hitter-first recent form, barrels/hard-contact/air-ball quality,
     * swing-and-miss, pitcher resistance, handedness and lineup-wide barrel depth.
     */
    fun signalLensScore(candidate: HitterCandidate, state: AppUiState = _state.value): Double {
        val profile = mustHavePowerScore(candidate)
        val pressure = reliablePowerPressure(candidate)
        val discipline = swingMissScore(candidate)
        val depth = teamBarrelDepthScore(candidate, state)
        val convergence = arsenalHandednessConvergence(candidate)
        val zone = candidate.attackZoneMatch?.takeIf { it.confidence >= .20 }
        val official = officialPowerQualityScore(candidate)
        val advancedPitcher = advancedPitcherVulnerabilityScore(candidate)
        val environment = precisionEnvironmentScore(candidate)

        val pieces = mutableListOf<Pair<Double, Double>>()
        if (candidate.statcastContact != null || candidate.expectedStats != null) {
            pieces += official to .20
        } else {
            pieces += candidate.score.seasonPower to .20
        }
        pieces += profile to .16
        pieces += pressure to .10
        pieces += discipline to .07
        pieces += candidate.score.pitcherMatchup to .10
        if (candidate.opponentPitcher?.statcastContact != null || candidate.opponentPitcher?.expectedStats != null) {
            pieces += advancedPitcher to .10
        }
        if (convergence.available) pieces += convergence.score to .10
        else pieces += candidate.score.platoon to .05
        if (zone != null) pieces += zone.score to .05
        if (candidate.battedBallDirection != null) pieces += pullAirPowerScore(candidate) to .05
        pieces += depth to .04
        pieces += environment to .05

        val weight = pieces.sumOf { it.second }
        val raw = if (weight > 0.0) pieces.sumOf { it.first * it.second } / weight else 50.0
        return (raw + bvpAdjustment(candidate) * .25).coerceIn(0.0, 100.0)
    }

    fun signalTier(candidate: HitterCandidate): String = when {
        signalLensScore(candidate) >= 78.0 -> "TIER 1"
        signalLensScore(candidate) >= 68.0 -> "TIER 2"
        signalLensScore(candidate) >= 58.0 -> "TIER 3"
        else -> "WATCH"
    }

    fun signalReasons(candidate: HitterCandidate): List<String> {
        val metrics = mustHaveMetrics(candidate)
        return buildList {
            if (officialPowerQualityScore(candidate) >= 70.0 &&
                (candidate.statcastContact != null || candidate.expectedStats != null)) add("STATCAST POWER")
            if (pullAirPowerScore(candidate) >= 70.0 && candidate.battedBallDirection != null) add("PULL-AIR")
            if (homeRunPortabilityScore(candidate) >= 70.0 && (candidate.expectedHomeRuns?.actualHomeRuns ?: 0) >= 4) add("PORTABLE HR POWER")
            if (swingMechanicsScore(candidate) >= 70.0 && (candidate.batTracking != null || candidate.swingPath != null)) add("BAT SPEED / BLAST")
            if ((metrics.barrelPct ?: 0.0) >= 12.0) add("BARREL FORM")
            recentWhiffRate(candidate)?.let { if (it <= .22 && candidate.recentPlateDiscipline.swings >= 10) add("LOW WHIFF") }
            if (advancedPitcherVulnerabilityScore(candidate) >= 70.0 &&
                (candidate.opponentPitcher?.statcastContact != null || candidate.opponentPitcher?.expectedStats != null)) add("STARTER VULN")
            if (bullpenVulnerabilityScore(candidate) >= 70.0 && candidate.opponentBullpenStats != null) add("BULLPEN EDGE")
            candidate.attackZoneMatch?.let { if (it.score >= 64.0 && it.confidence >= .28) add("ZONE FIT") }
            val convergence = arsenalHandednessConvergence(candidate)
            if (convergence.isPerfectFit) add("PERFECT ARSENAL + HAND")
            else if (convergence.isStrongFit) add("ARSENAL + HAND")
            else {
                val arsenal = candidate.pitchArsenalMatch
                if (arsenal != null && arsenal.score >= 72.0 && arsenal.confidence >= .35) add("ARSENAL FIT")
                if (candidate.score.platoon >= 70.0) add("PLATOON EDGE")
            }
        }.distinct().take(4)
    }

    /** Stable two-week power form. This is deliberately slower-moving than the 3/7-day heat tabs. */
    fun fourteenDayPowerScore(candidate: HitterCandidate, state: AppUiState = _state.value): Double {
        val stats = state.board?.recentFourteenDayStats?.get(candidate.player.id) ?: return 50.0
        if (stats.plateAppearances <= 0) return 50.0
        val iso = stats.iso?.let { scaleForHot(it, .080, .360) } ?: 48.0
        val ops = stats.ops?.let { scaleForHot(it, .620, 1.050) } ?: 48.0
        val hrRate = stats.hrPerPa?.let { scaleForHot(it, .010, .085) } ?: 45.0
        val contact = stats.strikeoutRate?.let { inverseScale(it, .14, .34) } ?: 50.0
        val raw = iso * .38 + ops * .24 + hrRate * .26 + contact * .12
        val confidence = (stats.plateAppearances / 48.0).coerceIn(.30, 1.0)
        return (50.0 * (1.0 - confidence) + raw * confidence).coerceIn(0.0, 100.0)
    }


    /**
     * v0.18 Precision Foundation. Official season Statcast data is the stable power layer; recent
     * Gameday contact remains valuable for timing, but can no longer overpower a weak season base.
     */
    fun officialPowerQualityScore(candidate: HitterCandidate): Double {
        val contact = candidate.statcastContact
        val expected = candidate.expectedStats
        val parts = mutableListOf<Pair<Double, Double>>()
        contact?.barrelPct?.let { parts += scaleForHot(it, 4.0, 18.0) to .34 }
        expected?.xSlg?.let { parts += scaleForHot(it, .320, .650) to .24 }
        contact?.ev50?.let { parts += scaleForHot(it, 95.0, 108.0) to .15 }
        contact?.hardHitPct?.let { parts += scaleForHot(it, 30.0, 58.0) to .12 }
        contact?.barrelPerPaPct?.let { parts += scaleForHot(it, 2.0, 12.0) to .10 }
        contact?.maxExitVelocity?.let { parts += scaleForHot(it, 103.0, 117.0) to .05 }
        if ((candidate.expectedHomeRuns?.actualHomeRuns ?: 0) >= 4) {
            parts += homeRunPortabilityScore(candidate) to .08
        }
        if (parts.isEmpty()) return candidate.score.seasonPower
        val weight = parts.sumOf { it.second }
        val raw = parts.sumOf { it.first * it.second } / weight
        val bbeConfidence = ((contact?.battedBallEvents ?: 0) / 75.0).coerceIn(.25, 1.0)
        val paConfidence = ((expected?.plateAppearances ?: 0) / 180.0).coerceIn(.25, 1.0)
        val confidence = (bbeConfidence * .65 + paConfidence * .35).coerceIn(.25, 1.0)
        return (candidate.score.seasonPower * (1.0 - confidence) + raw * confidence).coerceIn(0.0, 100.0)
    }

    /**
     * Quality/portability of the home runs a hitter has already produced. Statcast xHR asks how
     * often those trajectories would leave the other MLB parks, while No Doubter% identifies
     * truly portable contact. This is support evidence only because it is conditioned on past HRs.
     */
    fun homeRunPortabilityScore(candidate: HitterCandidate): Double {
        val xhr = candidate.expectedHomeRuns ?: return 50.0
        if (xhr.actualHomeRuns <= 0) return 50.0
        val parts = mutableListOf<Pair<Double, Double>>()
        val ratio = xhr.expectedHomeRuns?.div(xhr.actualHomeRuns.toDouble())
        ratio?.let { parts += scaleForHot(it, .65, 1.08) to .55 }
        xhr.noDoubterPct?.let { parts += scaleForHot(it, 12.0, 62.0) to .45 }
        if (parts.isEmpty()) return 50.0
        val raw = parts.sumOf { it.first * it.second } / parts.sumOf { it.second }
        val confidence = (xhr.actualHomeRuns / 15.0).coerceIn(.18, 1.0)
        return (50.0 * (1.0 - confidence) + raw * confidence).coerceIn(0.0, 100.0)
    }

    /** Bat speed/blast/ideal attack angle are corroboration, not the primary HR signal. */
    fun swingMechanicsScore(candidate: HitterCandidate): Double {
        val bat = candidate.batTracking
        val path = candidate.swingPath
        val parts = mutableListOf<Pair<Double, Double>>()
        bat?.avgBatSpeed?.let { parts += scaleForHot(it, 67.0, 78.0) to .28 }
        bat?.blastContactRate?.let { parts += scaleForHot(it, .07, .30) to .28 }
        bat?.fastSwingRate?.let { parts += scaleForHot(it, .20, .80) to .12 }
        bat?.squaredUpContactRate?.let { parts += scaleForHot(it, .18, .38) to .10 }
        path?.idealAttackAngleRate?.let { parts += scaleForHot(it, .35, .66) to .22 }
        if (parts.isEmpty()) return 50.0
        val weight = parts.sumOf { it.second }
        val raw = parts.sumOf { it.first * it.second } / weight
        val swings = maxOf(bat?.competitiveSwings ?: 0, path?.competitiveSwings ?: 0)
        val confidence = (swings / 300.0).coerceIn(.25, 1.0)
        return (50.0 * (1.0 - confidence) + raw * confidence).coerceIn(0.0, 100.0)
    }

    /** Exact season pull-air shape from Savant. Pulled air is a ceiling signal, not a guarantee. */
    fun pullAirPowerScore(candidate: HitterCandidate): Double {
        val profile = candidate.battedBallDirection ?: return 50.0
        val parts = mutableListOf<Pair<Double, Double>>()
        profile.pullAirRate?.let { parts += scaleForHot(it, .10, .31) to .55 }
        profile.airRate?.let { parts += scaleForHot(it, .42, .72) to .15 }
        profile.flyBallRate?.let { parts += scaleForHot(it, .20, .48) to .15 }
        profile.pullRate?.let { parts += scaleForHot(it, .31, .51) to .15 }
        if (parts.isEmpty()) return 50.0
        val weight = parts.sumOf { it.second }
        val raw = parts.sumOf { it.first * it.second } / weight
        val confidence = (profile.battedBallEvents / 70.0).coerceIn(.25, 1.0)
        return (50.0 * (1.0 - confidence) + raw * confidence).coerceIn(0.0, 100.0)
    }

    /** Stable Statcast contact allowed + expected outcomes for tonight's starter. Higher is better for hitter. */
    fun advancedPitcherVulnerabilityScore(candidate: HitterCandidate): Double {
        val pitcher = candidate.opponentPitcher ?: return candidate.score.pitcherMatchup
        val contact = pitcher.statcastContact
        val expected = pitcher.expectedStats
        val parts = mutableListOf<Pair<Double, Double>>()
        contact?.barrelPct?.let { parts += scaleForHot(it, 4.0, 13.5) to .30 }
        expected?.xSlg?.let { parts += scaleForHot(it, .320, .520) to .27 }
        contact?.hardHitPct?.let { parts += scaleForHot(it, 30.0, 50.0) to .15 }
        expected?.xWoba?.let { parts += scaleForHot(it, .275, .390) to .13 }
        expected?.xEra?.let { parts += scaleForHot(it, 2.70, 5.40) to .10 }
        contact?.avgExitVelocity?.let { parts += scaleForHot(it, 85.0, 92.5) to .05 }
        pitcher.expectedHomeRuns?.takeIf { it.actualHomeRuns >= 4 }?.let { xhr ->
            val portability = xhr.expectedHomeRuns?.div(xhr.actualHomeRuns.toDouble())
            val xHrQuality = listOfNotNull(
                portability?.let { scaleForHot(it, .65, 1.08) },
                xhr.noDoubterPct?.let { scaleForHot(it, 12.0, 62.0) }
            ).average().takeIf { it.isFinite() }
            if (xHrQuality != null) parts += xHrQuality to .08
        }
        if (parts.isEmpty()) return candidate.score.pitcherMatchup
        val weight = parts.sumOf { it.second }
        val raw = parts.sumOf { it.first * it.second } / weight
        val confidence = (((contact?.battedBallEvents ?: 0) / 90.0) * .65 +
            ((expected?.plateAppearances ?: 0) / 220.0) * .35).coerceIn(.25, 1.0)
        return (candidate.score.pitcherMatchup * (1.0 - confidence) + raw * confidence).coerceIn(0.0, 100.0)
    }

    /** HR prop plate appearances continue after the starter leaves, so the opposing bullpen matters. */
    fun bullpenVulnerabilityScore(candidate: HitterCandidate): Double {
        val stats = candidate.opponentBullpenStats ?: return 50.0
        val parts = mutableListOf<Pair<Double, Double>>()
        stats.hrPer9?.let { parts += scaleForHot(it, .75, 1.65) to .36 }
        stats.strikeoutRate?.let { parts += inverseScale(it, .30, .18) to .24 }
        stats.era?.let { parts += scaleForHot(it, 3.00, 5.30) to .18 }
        stats.whip?.let { parts += scaleForHot(it, 1.05, 1.50) to .14 }
        stats.walkRate?.let { parts += scaleForHot(it, .06, .12) to .08 }
        if (parts.isEmpty()) return 50.0
        val weight = parts.sumOf { it.second }
        return (parts.sumOf { it.first * it.second } / weight).coerceIn(0.0, 100.0)
    }

    /** Replace the static park assumption when a handedness-specific Statcast HR factor is available. */
    fun precisionEnvironmentScore(candidate: HitterCandidate): Double {
        val factor = candidate.parkFactor?.homeRunFactor ?: return candidate.score.environment
        val park = scaleForHot(factor, 80.0, 125.0)
        // Existing environment still carries today's temperature/wind/roof signal.
        return (park * .62 + candidate.score.environment * .38).coerceIn(0.0, 100.0)
    }

    /** Evidence strength is shown separately and also mildly shrinks extreme target scores. */
    fun precisionDataConfidence(candidate: HitterCandidate): Double {
        val hitterContact = ((candidate.statcastContact?.battedBallEvents ?: 0) / 80.0).coerceIn(0.0, 1.0)
        val expected = ((candidate.expectedStats?.plateAppearances ?: 0) / 180.0).coerceIn(0.0, 1.0)
        val mechanics = (maxOf(candidate.batTracking?.competitiveSwings ?: 0, candidate.swingPath?.competitiveSwings ?: 0) / 300.0).coerceIn(0.0, 1.0)
        val direction = ((candidate.battedBallDirection?.battedBallEvents ?: 0) / 70.0).coerceIn(0.0, 1.0)
        val pitcherContact = ((candidate.opponentPitcher?.statcastContact?.battedBallEvents ?: 0) / 90.0).coerceIn(0.0, 1.0)
        val pitcherExpected = ((candidate.opponentPitcher?.expectedStats?.plateAppearances ?: 0) / 220.0).coerceIn(0.0, 1.0)
        val arsenal = candidate.pitchArsenalMatch?.confidence?.coerceIn(0.0, 1.0) ?: 0.0
        val zone = candidate.attackZoneMatch?.confidence?.coerceIn(0.0, 1.0) ?: 0.0
        val bullpen = if (candidate.opponentBullpenStats != null) 1.0 else 0.0
        val park = if (candidate.parkFactor?.homeRunFactor != null) 1.0 else 0.0
        val hitterXhr = ((candidate.expectedHomeRuns?.actualHomeRuns ?: 0) / 12.0).coerceIn(0.0, 1.0)
        val pitcherXhr = ((candidate.opponentPitcher?.expectedHomeRuns?.actualHomeRuns ?: 0) / 12.0).coerceIn(0.0, 1.0)
        return (hitterContact * .20 + expected * .12 + mechanics * .08 + direction * .09 +
            pitcherContact * .12 + pitcherExpected * .07 + arsenal * .09 + zone * .05 +
            bullpen * .06 + park * .04 + hitterXhr * .05 + pitcherXhr * .03).coerceIn(0.0, 1.0)
    }

    fun precisionLabel(candidate: HitterCandidate): String = when {
        precisionDataConfidence(candidate) >= .72 -> "HIGH DATA"
        precisionDataConfidence(candidate) >= .48 -> "MED DATA"
        else -> "LOW DATA"
    }

    /**
     * Research Lens: three deliberately separate questions instead of one opaque mega-score.
     * MATCH = today's opponent geometry (pitcher, arsenal+handedness, attack-zone overlap, park).
     * PROCESS TEST = whether the hitter's underlying power/contact/form is trustworthy enough.
     * CEILING = raw one-swing upside. Missing optional data is redistributed, never imputed.
     */
    fun researchLens(candidate: HitterCandidate): ResearchLensScore {
        val convergence = arsenalHandednessConvergence(candidate)
        val zone = candidate.attackZoneMatch?.takeIf { it.confidence >= .18 }
        val advancedPitcher = advancedPitcherVulnerabilityScore(candidate)
        val bullpen = bullpenVulnerabilityScore(candidate)
        val environment = precisionEnvironmentScore(candidate)

        // MATCH explicitly includes likely post-starter plate appearances. Optional components are
        // omitted rather than invented, so a missing endpoint does not create a fake neutral edge.
        val matchPieces = mutableListOf<Pair<Double, Double>>()
        matchPieces += candidate.score.pitcherMatchup to .22
        if (candidate.opponentPitcher?.statcastContact != null || candidate.opponentPitcher?.expectedStats != null) {
            matchPieces += advancedPitcher to .18
        }
        if (convergence.available) matchPieces += convergence.score to .20
        else matchPieces += candidate.score.platoon to .08
        if (zone != null) matchPieces += zone.score to .10
        if (candidate.opponentBullpenStats != null) matchPieces += bullpen to .08
        matchPieces += environment to .12
        matchPieces += candidate.score.lineup to .06
        val matchWeight = matchPieces.sumOf { it.second }
        var match = matchPieces.sumOf { it.first * it.second } / matchWeight
        match += bvpAdjustment(candidate) * .22

        val contact = mustHavePowerScore(candidate)
        val officialPower = officialPowerQualityScore(candidate)
        val mechanics = swingMechanicsScore(candidate)
        val hasOfficial = candidate.statcastContact != null || candidate.expectedStats != null
        val processPieces = mutableListOf<Pair<Double, Double>>()
        if (hasOfficial) processPieces += officialPower to .38
        processPieces += contact to .23
        processPieces += candidate.score.seasonPower to .14
        if (candidate.batTracking != null || candidate.swingPath != null) processPieces += mechanics to .09
        processPieces += swingMissScore(candidate) to .07
        processPieces += fourteenDayPowerScore(candidate) to .05
        processPieces += reliablePowerPressure(candidate) to .04
        val processWeight = processPieces.sumOf { it.second }
        val process = (processPieces.sumOf { it.first * it.second } / processWeight).coerceIn(0.0, 100.0)

        val pullAir = pullAirPowerScore(candidate)
        val ceilingPieces = mutableListOf<Pair<Double, Double>>()
        if (hasOfficial) ceilingPieces += officialPower to .35 else ceilingPieces += candidate.score.seasonPower to .35
        if (candidate.battedBallDirection != null) ceilingPieces += pullAir to .20
        if (candidate.batTracking != null || candidate.swingPath != null) ceilingPieces += mechanics to .13
        if ((candidate.expectedHomeRuns?.actualHomeRuns ?: 0) >= 4) {
            ceilingPieces += homeRunPortabilityScore(candidate) to .10
        }
        ceilingPieces += contact to .12
        ceilingPieces += reliablePowerPressure(candidate) to .10
        ceilingPieces += environment to .07
        ceilingPieces += candidate.score.lineup to .03
        val ceilingWeight = ceilingPieces.sumOf { it.second }
        val ceiling = (ceilingPieces.sumOf { it.first * it.second } / ceilingWeight).coerceIn(0.0, 100.0)
        return ResearchLensScore(match.coerceIn(0.0, 100.0), process, ceiling)
    }

    /**
     * Calibrated Daily Target Score. The old version blended two composites that contained most of
     * the same inputs, accidentally double-counting recent form and matchup. This version uses one
     * transparent composite, then applies small convergence bonuses/penalties.
     *
     * Postmortem lesson from Aug. 24: small-sample recent contact was able to keep light-power bats
     * too high against strong starters, while established power needed more direct weight.
     */
    fun targetScore(candidate: HitterCandidate): Double {
        val metrics = mustHaveMetrics(candidate)
        val contactProfile = mustHavePowerScore(candidate)
        val seasonPower = candidate.score.seasonPower
        val matchup = candidate.score.pitcherMatchup
        val pressure = reliablePowerPressure(candidate)
        val convergence = arsenalHandednessConvergence(candidate)
        val pattern = patternEngineScore(candidate)
        val lens = researchLens(candidate)
        val zone = candidate.attackZoneMatch?.takeIf { it.confidence >= .28 }
        val arsenal = candidate.pitchArsenalMatch?.takeIf { it.confidence >= .28 }

        // v0.17: one transparent base. PROCESS answers whether the hitter is trustworthy, MATCH
        // answers whether tonight fits, CEILING protects one-swing upside, and Pattern Engine is the
        // only historical outcome-learning layer. This avoids repeatedly counting the same inputs.
        var raw = lens.processTest * .36 + pattern * .27 + lens.match * .27 + lens.ceiling * .10

        val strongDimensions = listOf(
            seasonPower >= 62.0,
            contactProfile >= 60.0,
            matchup >= 60.0,
            pressure >= 60.0,
            convergence.score >= 68.0,
            zone?.score?.let { it >= 64.0 } == true
        ).count { it }

        raw += when {
            pattern >= 78.0 && lens.processTest >= 68.0 && strongDimensions >= 4 -> 3.5
            pattern >= 70.0 && lens.processTest >= 63.0 && strongDimensions >= 3 -> 1.8
            pattern < 45.0 && lens.processTest < 58.0 -> -4.5
            strongDimensions <= 1 -> -3.5
            else -> 0.0
        }

        // Public-research lesson: the best reads tend to be convergences, not isolated green cells.
        // Zone overlap therefore gets extra credit only when pitch type and/or handedness agree and
        // the hitter already owns a real power/contact foundation.
        if (zone != null && zone.score >= 68.0 && arsenal != null && arsenal.score >= 68.0 &&
            seasonPower >= 58.0 && contactProfile >= 56.0) raw += 2.0
        if (zone != null && zone.score >= 64.0 && convergence.isStrongFit && seasonPower >= 58.0) raw += 1.2
        if (convergence.isPerfectFit && seasonPower >= 60.0 && contactProfile >= 58.0) raw += 2.5
        else if (convergence.isStrongFit && seasonPower >= 58.0 && contactProfile >= 55.0) raw += 1.2

        val hasOfficialPower = candidate.statcastContact != null || candidate.expectedStats != null
        val officialPower = officialPowerQualityScore(candidate)
        val pullAir = pullAirPowerScore(candidate)
        val advancedStarter = advancedPitcherVulnerabilityScore(candidate)
        if (hasOfficialPower && officialPower >= 72.0 &&
            candidate.battedBallDirection != null && pullAir >= 68.0 &&
            advancedStarter >= 62.0) raw += 2.0
        if (hasOfficialPower && officialPower >= 68.0 &&
            homeRunPortabilityScore(candidate) >= 72.0 &&
            (candidate.expectedHomeRuns?.actualHomeRuns ?: 0) >= 5) raw += .7

        // Vetoes keep loud recent signals from manufacturing a slugger.
        if (matchup < 38.0 && seasonPower < 72.0) raw -= 5.5
        if (seasonPower < 48.0 && contactProfile < 52.0) raw -= 6.5
        if (pressure >= 75.0 && metrics.battedBallCount < 5 && seasonPower < 58.0) raw -= 4.0
        if (hasOfficialPower && officialPower < 44.0 && seasonPower < 58.0) raw -= 4.5
        if (zone != null && zone.score < 42.0 && arsenal != null && arsenal.score < 48.0 && seasonPower < 68.0) raw -= 2.0

        // BvP is already a small input inside MATCH. Single-night transfer remains a tie-breaker.
        raw += lastNightPatternAdjustment(candidate) * .50
        raw += sameDayPatternAdjustment(candidate) * .60

        // Precision shrink: incomplete enrichment is not punished as a bad matchup, but it is not
        // allowed to generate the same extreme confidence as a fully measured hitter/pitcher pair.
        val evidence = precisionDataConfidence(candidate)
        val shrink = 0.78 + evidence * 0.22
        raw = 50.0 + (raw - 50.0) * shrink
        if (evidence < .30 && raw >= 72.0) raw -= 2.0

        return raw.coerceIn(0.0, 100.0)
    }

    fun pickScore(candidate: HitterCandidate): Double = targetScore(candidate)

    /** Rolling seven-day batting line used by the Hot tab. The date-range data comes from one
     * league-wide MLB StatsAPI request, so this does not add one network request per player. */
    fun recentWeekStats(candidate: HitterCandidate, state: AppUiState = _state.value): RecentHittingStats? =
        state.board?.recentWeekStats?.get(candidate.player.id)

    fun recentNearHrCount(candidate: HitterCandidate): Int =
        candidate.recentBattedBalls.count(scoringModel::isNearHomeRun)

    fun recentEliteNearHrCount(candidate: HitterCandidate): Int =
        candidate.recentBattedBalls.count(scoringModel::isEliteNearHomeRun)

    /**
     * Hot Streak Score is deliberately separate from the daily HR Target Score. It answers a
     * different question: who has actually been producing over the last seven days, and is that
     * production supported by contact quality rather than box-score luck alone?
     */
    fun hotStreakScore(candidate: HitterCandidate, state: AppUiState = _state.value): Double {
        val stats = recentWeekStats(candidate, state) ?: return 0.0
        if (stats.plateAppearances < 5) return 0.0
        val metrics = mustHaveMetrics(candidate)

        val ops = stats.ops?.let { scaleForHot(it, .620, 1.250) } ?: 45.0
        val iso = stats.iso?.let { scaleForHot(it, .080, .420) } ?: 45.0
        val avg = stats.avg?.let { scaleForHot(it, .180, .400) } ?: 45.0
        val hrs = scaleForHot(stats.homeRuns.toDouble(), 0.0, 4.0)
        val xbh = scaleForHot(stats.extraBaseHits.toDouble(), 0.0, 7.0)
        val production = scaleForHot((stats.runs + stats.rbi).toDouble(), 1.0, 16.0)
        val contact = stats.strikeoutRate?.let { inverseScale(it, .12, .34) } ?: 50.0
        val profile = mustHavePowerScore(candidate)
        val pressure = candidate.score.powerPressure

        val raw = ops * .20 +
            iso * .18 +
            hrs * .16 +
            avg * .10 +
            xbh * .08 +
            production * .06 +
            contact * .07 +
            profile * .10 +
            pressure * .05

        // Seven-day samples are naturally small. Keep tiny 5-PA cameos from jumping established
        // hot hitters, while allowing regulars with 20-30 PA to express the full score.
        val confidence = ((stats.plateAppearances - 4) / 22.0).coerceIn(.25, 1.0)
        return (50.0 * (1.0 - confidence) + raw * confidence).coerceIn(0.0, 100.0)
    }

    fun hotCandidates(
        limit: Int = 20,
        state: AppUiState = _state.value
    ): List<HitterCandidate> = pregameCandidates(state)
        .filter { (recentWeekStats(it, state)?.plateAppearances ?: 0) >= 5 }
        .sortedWith(
            compareByDescending<HitterCandidate> { hotStreakScore(it, state) }
                .thenByDescending { recentWeekStats(it, state)?.homeRuns ?: 0 }
                .thenByDescending { recentWeekStats(it, state)?.ops ?: 0.0 }
                .thenByDescending(::targetScore)
        )
        .take(limit)

    fun hotStreakReasons(candidate: HitterCandidate, state: AppUiState = _state.value): List<String> {
        val stats = recentWeekStats(candidate, state) ?: return emptyList()
        val metrics = mustHaveMetrics(candidate)
        val near = recentNearHrCount(candidate)
        val eliteNear = recentEliteNearHrCount(candidate)
        return buildList {
            if (stats.homeRuns > 0) add("${stats.homeRuns} HR in the last 7 days")
            stats.ops?.let { if (it >= .850) add("${"%.3f".format(it)} OPS with ${stats.hits} hits") }
            stats.avg?.let { avg -> stats.slg?.let { slg -> if (avg >= .280 || slg >= .500) add("${"%.3f".format(avg)} AVG / ${"%.3f".format(slg)} SLG") } }
            if (stats.extraBaseHits >= 2) add("${stats.extraBaseHits} extra-base hits • ${stats.rbi} RBI")
            if (eliteNear > 0) add("$eliteNear elite near-HR miss${if (eliteNear == 1) "" else "es"} recently")
            else if (near > 0) add("$near recent near-HR miss${if (near == 1) "" else "es"}")
            if ((metrics.barrelPct ?: 0.0) >= 10.0 || (metrics.hardHitPct ?: 0.0) >= 45.0) {
                val parts = buildList {
                    metrics.barrelPct?.let { add("${"%.1f".format(it)}% barrel") }
                    metrics.hardHitPct?.let { add("${"%.1f".format(it)}% hard-hit") }
                }
                if (parts.isNotEmpty()) add(parts.joinToString(" • "))
            }
            metrics.maxExitVelocity?.let { if (it >= 103.0) add("Max EV ${"%.1f".format(it)} mph") }
            stats.strikeoutRate?.let { if (it <= .18 && stats.plateAppearances >= 10) add("Low ${"%.1f".format(it * 100)}% K rate") }
        }.distinct().take(5)
    }


    /** Previous three completed calendar days. This is intentionally separate from the seven-day
     * Hot board: the goal is to catch acceleration before a hitter becomes an obvious hot name. */
    fun recentThreeDayStats(candidate: HitterCandidate, state: AppUiState = _state.value): RecentHittingStats? =
        state.board?.recentThreeDayStats?.get(candidate.player.id)

    fun lastThreeBattedBalls(candidate: HitterCandidate, state: AppUiState = _state.value) =
        candidate.recentBattedBalls.filter { ball ->
            val start = state.selectedDate.minusDays(3)
            val end = state.selectedDate.minusDays(1)
            !ball.gameDate.isBefore(start) && !ball.gameDate.isAfter(end)
        }

    fun heatingMetrics(candidate: HitterCandidate, state: AppUiState = _state.value): MustHaveMetrics {
        val key = "${state.selectedDate}:${candidate.game.gamePk}:${candidate.player.id}"
        return heatingMetricsCache.getOrPut(key) {
            scoringModel.mustHaveMetrics(candidate.player, candidate.seasonStats, lastThreeBattedBalls(candidate, state))
        }
    }

    fun heatingNearHrCount(candidate: HitterCandidate, state: AppUiState = _state.value): Int =
        lastThreeBattedBalls(candidate, state).count(scoringModel::isNearHomeRun)

    fun heatingEliteNearHrCount(candidate: HitterCandidate, state: AppUiState = _state.value): Int =
        lastThreeBattedBalls(candidate, state).count(scoringModel::isEliteNearHomeRun)

    private fun heatingWhiffScore(candidate: HitterCandidate): Double {
        val sample = candidate.last3PlateDiscipline
        val recent = sample.whiffRate?.let { inverseScale(it, .12, .38) } ?: 50.0
        val confidence = (sample.swings / 18.0).coerceIn(.25, 1.0)
        return recent * confidence + 50.0 * (1.0 - confidence)
    }

    fun heatingAcceleration(candidate: HitterCandidate, state: AppUiState = _state.value): Double {
        val three = recentThreeDayStats(candidate, state) ?: return 50.0
        val week = recentWeekStats(candidate, state) ?: return 55.0
        val threeOps = three.ops
        val weekOps = week.ops
        val threeIso = three.iso
        val weekIso = week.iso
        val opsDelta = if (threeOps != null && weekOps != null) threeOps - weekOps else 0.0
        val isoDelta = if (threeIso != null && weekIso != null) threeIso - weekIso else 0.0
        return (scaleForHot(opsDelta, -.12, .38) * .70 + scaleForHot(isoDelta, -.08, .24) * .30)
            .coerceIn(0.0, 100.0)
    }

    /**
     * Three-day Emerging Heat score. It is designed to find hitters whose process is improving
     * before a full seven-day box-score streak makes them obvious. Contact quality and near-HR
     * pressure matter more here than raw HR totals.
     */
    fun heatingScore(candidate: HitterCandidate, state: AppUiState = _state.value): Double {
        val stats = recentThreeDayStats(candidate, state) ?: return 0.0
        if (stats.plateAppearances < 4) return 0.0
        val metrics = heatingMetrics(candidate, state)

        val ops = stats.ops?.let { scaleForHot(it, .560, 1.250) } ?: 42.0
        val avg = stats.avg?.let { scaleForHot(it, .150, .400) } ?: 42.0
        val iso = stats.iso?.let { scaleForHot(it, .040, .420) } ?: 42.0
        val hits = scaleForHot(stats.hits.toDouble(), 0.0, 6.0)
        val xbh = scaleForHot(stats.extraBaseHits.toDouble(), 0.0, 4.0)
        val box = ops * .34 + avg * .18 + iso * .24 + hits * .12 + xbh * .12

        val barrel = metrics.barrelPct?.let { scaleForHot(it, 2.0, 24.0) } ?: 45.0
        val hardHit = metrics.hardHitPct?.let { scaleForHot(it, 30.0, 65.0) } ?: 45.0
        val sweet = metrics.sweetSpotPct?.let { scaleForHot(it, 18.0, 55.0) } ?: 45.0
        val maxEv = metrics.maxExitVelocity?.let { scaleForHot(it, 96.0, 112.0) } ?: 45.0
        val near = when (heatingNearHrCount(candidate, state)) {
            0 -> 40.0
            1 -> 76.0
            2 -> 92.0
            else -> 100.0
        }
        val contactQuality = barrel * .24 + hardHit * .27 + sweet * .14 + maxEv * .19 + near * .16

        val raw = contactQuality * .32 +
            box * .24 +
            candidate.score.powerPressure * .15 +
            heatingWhiffScore(candidate) * .10 +
            heatingAcceleration(candidate, state) * .12 +
            targetScore(candidate) * .07

        val paConfidence = ((stats.plateAppearances - 3) / 10.0).coerceIn(.35, 1.0)
        val bbeConfidence = (metrics.battedBallCount / 5.0).coerceIn(.35, 1.0)
        val confidence = (paConfidence * .60 + bbeConfidence * .40).coerceIn(.35, 1.0)
        return (50.0 * (1.0 - confidence) + raw * confidence).coerceIn(0.0, 100.0)
    }

    fun heatingSignalCount(candidate: HitterCandidate, state: AppUiState = _state.value): Int {
        val stats = recentThreeDayStats(candidate, state) ?: return 0
        val metrics = heatingMetrics(candidate, state)
        var count = 0
        if ((stats.ops ?: 0.0) >= .760 || (stats.avg ?: 0.0) >= .280 || stats.hits >= 3) count++
        if ((metrics.hardHitPct ?: 0.0) >= 45.0) count++
        if ((metrics.barrelPct ?: 0.0) >= 10.0 || (metrics.maxExitVelocity ?: 0.0) >= 103.0) count++
        if (heatingNearHrCount(candidate, state) > 0) count++
        if (candidate.score.powerPressure >= 65.0) count++
        val whiff = candidate.last3PlateDiscipline.whiffRate
        if (whiff != null && whiff <= .24 && candidate.last3PlateDiscipline.swings >= 6) count++
        if (heatingAcceleration(candidate, state) >= 62.0) count++
        return count
    }

    fun heatingCandidates(
        limit: Int = 20,
        state: AppUiState = _state.value
    ): List<HitterCandidate> = pregameCandidates(state)
        .filter { (recentThreeDayStats(it, state)?.plateAppearances ?: 0) >= 4 }
        .filter { heatingSignalCount(it, state) >= 2 }
        .filter { heatingScore(it, state) >= 55.0 }
        // Keep the board focused on emerging heat instead of duplicating obvious established hot streaks.
        .filter {
            val week = recentWeekStats(it, state)
            !(hotStreakScore(it, state) >= 82.0 && (week?.homeRuns ?: 0) >= 2)
        }
        .sortedWith(
            compareByDescending<HitterCandidate> { heatingScore(it, state) }
                .thenByDescending { heatingSignalCount(it, state) }
                .thenByDescending { heatingAcceleration(it, state) }
                .thenByDescending { heatingMetrics(it, state).maxExitVelocity ?: 0.0 }
                .thenByDescending(::targetScore)
        )
        .take(limit)

    fun heatingReasons(candidate: HitterCandidate, state: AppUiState = _state.value): List<String> {
        val stats = recentThreeDayStats(candidate, state) ?: return emptyList()
        val week = recentWeekStats(candidate, state)
        val metrics = heatingMetrics(candidate, state)
        val near = heatingNearHrCount(candidate, state)
        val eliteNear = heatingEliteNearHrCount(candidate, state)
        return buildList {
            stats.ops?.let { ops ->
                val weekOps = week?.ops
                if (weekOps != null && ops - weekOps >= .100) {
                    add("3-day OPS ${"%.3f".format(ops)} • up ${"%.3f".format(ops - weekOps)} versus 7-day form")
                } else if (ops >= .800) {
                    add("3-day OPS ${"%.3f".format(ops)} with ${stats.hits} hits")
                }
                Unit
            }
            stats.avg?.let { if (it >= .280 || stats.hits >= 3) add("${stats.hits}-for-${stats.atBats} (${"%.3f".format(it)}) over the last 3 days") }
            if (stats.extraBaseHits > 0) add("${stats.extraBaseHits} XBH • ${stats.homeRuns} HR • ${stats.rbi} RBI in 3 days")
            if (eliteNear > 0) add("$eliteNear elite near-HR miss${if (eliteNear == 1) "" else "es"} in the 3-day window")
            else if (near > 0) add("$near near-HR miss${if (near == 1) "" else "es"} in the 3-day window")
            val quality = buildList {
                metrics.hardHitPct?.let { if (it >= 40.0) add("${"%.1f".format(it)}% hard-hit") }
                metrics.barrelPct?.let { if (it >= 8.0) add("${"%.1f".format(it)}% barrel") }
                metrics.sweetSpotPct?.let { if (it >= 30.0) add("${"%.1f".format(it)}% sweet spot") }
            }
            if (quality.isNotEmpty()) add(quality.joinToString(" • "))
            metrics.maxExitVelocity?.let { if (it >= 101.0) add("3-day max EV ${"%.1f".format(it)} mph") }
            candidate.last3PlateDiscipline.whiffRate?.let {
                if (it <= .24 && candidate.last3PlateDiscipline.swings >= 6) {
                    add("Only ${"%.1f".format(it * 100)}% whiffs across ${candidate.last3PlateDiscipline.swings} swings")
                }
            }
            if (candidate.score.powerPressure >= 65.0) add("Power Pressure ${candidate.score.powerPressure.roundToInt()} — HR-quality contact is building")
        }.distinct().take(6)
    }

    private fun scaleForHot(value: Double, low: Double, high: Double): Double {
        if (high <= low) return 50.0
        return (((value - low) / (high - low)) * 100.0).coerceIn(0.0, 100.0)
    }

    fun recentFourteenDayStats(candidate: HitterCandidate, state: AppUiState = _state.value): RecentHittingStats? =
        state.board?.recentFourteenDayStats?.get(candidate.player.id)

    fun pitcherStrikeoutPredictions(
        state: AppUiState = _state.value,
        boardOverride: BoardData? = null,
        learningOverride: PitcherStrikeoutLearningProfile? = null
    ): List<PitcherStrikeoutPrediction> {
        val board = boardOverride ?: state.board ?: return emptyList()
        val learning = learningOverride ?: state.pitcherStrikeoutLearningProfile
        val remainingGamePks = board.games.filter { game ->
            if (!state.showRemainingOnly) true else game.status.equals("Preview", true) && !gameIsUnavailable(game)
        }.map { it.gamePk }.toSet()
        return board.games.asSequence()
            .filter { it.gamePk in remainingGamePks }
            .filterNot(::gameIsUnavailable)
            .flatMap { game ->
                val gameHitters = board.candidates.filter { it.game.gamePk == game.gamePk }
                val awayLineup = gameHitters.filter { it.team.id == game.awayTeam.id }
                val homeLineup = gameHitters.filter { it.team.id == game.homeTeam.id }
                sequenceOf(
                    game.awayProbablePitcher?.id?.let { id ->
                        val profile = homeLineup.firstOrNull { it.opponentPitcher?.person?.id == id }?.opponentPitcher
                        profile?.let { pitcher ->
                            pitcherStrikeoutScoringModel.score(
                                pitcher, game.awayTeam, game.homeTeam, game, homeLineup,
                                PitcherStrikeoutScoringModel.Context(
                                    pitcherThirtyDay = board.pitcherRecentThirtyDayStats[id],
                                    pitcherFourteenDay = board.pitcherRecentFourteenDayStats[id],
                                    pitcherSevenDay = board.pitcherRecentSevenDayStats[id],
                                    pitcherVsLeft = board.pitcherVsLeftStats[id],
                                    pitcherVsRight = board.pitcherVsRightStats[id],
                                    seasonHitting = board.seasonProductionStats,
                                    recentFourteenHitting = board.recentFourteenDayStats,
                                    recentSevenHitting = board.recentWeekStats,
                                    recentThreeHitting = board.recentThreeDayStats,
                                    learning = learning
                                )
                            )
                        }
                    },
                    game.homeProbablePitcher?.id?.let { id ->
                        val profile = awayLineup.firstOrNull { it.opponentPitcher?.person?.id == id }?.opponentPitcher
                        profile?.let { pitcher ->
                            pitcherStrikeoutScoringModel.score(
                                pitcher, game.homeTeam, game.awayTeam, game, awayLineup,
                                PitcherStrikeoutScoringModel.Context(
                                    pitcherThirtyDay = board.pitcherRecentThirtyDayStats[id],
                                    pitcherFourteenDay = board.pitcherRecentFourteenDayStats[id],
                                    pitcherSevenDay = board.pitcherRecentSevenDayStats[id],
                                    pitcherVsLeft = board.pitcherVsLeftStats[id],
                                    pitcherVsRight = board.pitcherVsRightStats[id],
                                    seasonHitting = board.seasonProductionStats,
                                    recentFourteenHitting = board.recentFourteenDayStats,
                                    recentSevenHitting = board.recentWeekStats,
                                    recentThreeHitting = board.recentThreeDayStats,
                                    learning = learning
                                )
                            )
                        }
                    }
                ).filterNotNull()
            }
            .filter { it.projectedStrikeouts.isFinite() && it.score.isFinite() }
            .sortedWith(compareByDescending<PitcherStrikeoutPrediction> { it.projectedStrikeouts }.thenByDescending { it.score })
            .toList()
    }

    private suspend fun updatePitcherStrikeoutLearning(board: BoardData): PitcherStrikeoutLearningProfile {
        val today = LocalDate.now()
        val unresolved = prefs.loadPitcherStrikeoutSnapshots()
            .filter { it.date.isBefore(today) && it.pitchers.any { row -> row.outcomeStrikeouts == null } }
            .sortedByDescending { it.date }
            .take(3)
        unresolved.forEach { snapshot ->
            repository.fetchDailyPitchingOutcomes(snapshot.date)?.let { outcomes ->
                prefs.resolvePitcherStrikeoutOutcomes(snapshot.date, outcomes)
            }
        }

        var learning = buildPitcherStrikeoutLearningProfile(prefs.loadPitcherStrikeoutSnapshots())
        if (board.date == today && board.candidates.isNotEmpty()) {
            val predictions = pitcherStrikeoutPredictions(
                state = _state.value.copy(showRemainingOnly = false),
                boardOverride = board,
                learningOverride = learning
            )
            val rows = predictions.map { p ->
                PitcherStrikeoutSnapshot(
                    date = board.date,
                    pitcherId = p.pitcher.id,
                    projectedStrikeouts = p.projectedStrikeouts,
                    score = p.score,
                    opponentStrikeoutRate = p.opponentStrikeoutRate,
                    seasonStrikeoutRate = p.seasonStrikeoutRate,
                    arsenalWhiffScore = p.arsenalWhiffScore,
                    workloadScore = p.workloadScore
                )
            }
            val locked = predictions.filter { !it.game.status.equals("Preview", true) || gameIsUnavailable(it.game) }
                .map { it.pitcher.id }.toSet()
            prefs.mergePregamePitcherStrikeoutSnapshot(
                DailyPitcherStrikeoutSnapshot(board.date, Instant.now(), rows),
                lockedPitcherIds = locked
            )
            learning = buildPitcherStrikeoutLearningProfile(prefs.loadPitcherStrikeoutSnapshots())
        }
        return learning
    }

    private fun buildPitcherStrikeoutLearningProfile(
        snapshots: List<DailyPitcherStrikeoutSnapshot>
    ): PitcherStrikeoutLearningProfile {
        val rows = snapshots.flatMap { it.pitchers }.filter { it.outcomeStrikeouts != null }
        if (rows.isEmpty()) return PitcherStrikeoutLearningProfile()
        val errors = rows.map { it.projectedStrikeouts - (it.outcomeStrikeouts ?: 0) }
        val bucketDefs = listOf(
            Triple("<4.5 K", 0.0, 4.5),
            Triple("4.5–5.4 K", 4.5, 5.5),
            Triple("5.5–6.4 K", 5.5, 6.5),
            Triple("6.5–7.4 K", 6.5, 7.5),
            Triple("7.5+ K", 7.5, 20.0)
        )
        val buckets = bucketDefs.mapNotNull { (label, low, high) ->
            val sample = rows.filter { it.projectedStrikeouts >= low && it.projectedStrikeouts < high }
            if (sample.isEmpty()) return@mapNotNull null
            val actual = sample.map { (it.outcomeStrikeouts ?: 0).toDouble() }
            PitcherStrikeoutCalibrationBucket(
                label = label,
                attempts = sample.size,
                averageProjected = sample.map { it.projectedStrikeouts }.average(),
                averageActual = actual.average(),
                meanAbsoluteError = sample.map { (it.projectedStrikeouts - (it.outcomeStrikeouts ?: 0)).absoluteValue }.average(),
                sixPlusRate = sample.count { (it.outcomeStrikeouts ?: 0) >= 6 }.toDouble() / sample.size
            )
        }
        return PitcherStrikeoutLearningProfile(
            resolvedStarts = rows.size,
            meanAbsoluteError = errors.map { it.absoluteValue }.average(),
            averageBias = errors.average(),
            buckets = buckets
        )
    }

    fun topTargets(
        limit: Int = 15,
        state: AppUiState = _state.value
    ): List<HitterCandidate> = pregameCandidates(state)
        .sortedWith(
            when {
                state.topZoneOnly -> compareByDescending<HitterCandidate> { it.attackZoneMatch?.score ?: 0.0 }
                    .thenByDescending { it.attackZoneMatch?.confidence ?: 0.0 }
                    .thenByDescending(::targetScore)
                    .thenByDescending(::mustHavePowerScore)
                state.eliteArsenalOnly -> compareByDescending<HitterCandidate> { it.pitchArsenalMatch?.score ?: 0.0 }
                    .thenByDescending { it.pitchArsenalMatch?.confidence ?: 0.0 }
                    .thenByDescending(::targetScore)
                    .thenByDescending(::mustHavePowerScore)
                else -> compareByDescending<HitterCandidate>(::targetScore)
                    .thenByDescending(::precisionDataConfidence)
                    .thenByDescending(::signalLensScore)
                    .thenByDescending(::mustHavePowerScore)
                    .thenByDescending { it.score.pitcherMatchup }
                    .thenByDescending { it.score.powerPressure }
            }
        )
        .take(limit)

    fun selectPlayer(id: Int?) {
        if (id == null) {
            mutate {
                it.copy(
                    selectedPlayerId = null,
                    selectedProfileCandidate = null,
                    selectedProfileDate = null,
                    isProfileLoading = false,
                    isProfileBvpLoading = false,
                    profileError = null
                )
            }
            return
        }

        val snapshot = _state.value
        val candidate = snapshot.board?.candidates?.firstOrNull { it.player.id == id }
            ?: synchronized(boardCache) {
                boardCache.values.asSequence()
                    .flatMap { board -> board.candidates.asSequence() }
                    .firstOrNull { it.player.id == id }
            }
        val profileDate = candidate?.let { found ->
            snapshot.board
                ?.takeIf { board -> board.candidates.any { it.player.id == found.player.id } }
                ?.date
                ?: synchronized(boardCache) {
                    boardCache.entries.firstOrNull { (_, board) -> board.candidates.any { it.player.id == id } }?.key
                }
        }

        mutate {
            it.copy(
                selectedPlayerId = id,
                selectedProfileCandidate = candidate,
                selectedProfileDate = profileDate ?: snapshot.selectedDate,
                isProfileLoading = false,
                isProfileBvpLoading = false,
                profileError = if (candidate == null) "Player profile data is not loaded for this date yet." else null
            )
        }
    }

    /**
     * Opens the same full Player Profile from anywhere in HR Chase. Current-slate players open
     * instantly. Historical rows (for example Last Night) fall back to that date's full board so
     * the profile can still show the matchup, signal lens, power metrics, splits, BvP and contact
     * history instead of dead-ending on a name that is not on today's slate.
     */
    fun openPlayerProfile(id: Int, preferredDate: LocalDate? = null) {
        val snapshot = _state.value
        val currentCandidate = snapshot.board?.candidates?.firstOrNull { it.player.id == id }
        if (currentCandidate != null) {
            val profileDate = snapshot.board?.date ?: snapshot.selectedDate
            mutate {
                it.copy(
                    selectedPlayerId = id,
                    selectedProfileCandidate = currentCandidate,
                    selectedProfileDate = profileDate,
                    isProfileLoading = false,
                    isProfileBvpLoading = false,
                    profileError = null
                )
            }
            enrichProfileBvp(currentCandidate, profileDate)
            return
        }

        val cachedMatch = synchronized(boardCache) {
            val orderedDates = buildList {
                preferredDate?.let { add(it) }
                add(snapshot.selectedDate)
                boardCache.keys.filterNot { it in this }.forEach { add(it) }
            }
            orderedDates.firstNotNullOfOrNull { date ->
                boardCache[date]?.candidates?.firstOrNull { it.player.id == id }?.let { date to it }
            }
        }
        if (cachedMatch != null) {
            mutate {
                it.copy(
                    selectedPlayerId = id,
                    selectedProfileCandidate = cachedMatch.second,
                    selectedProfileDate = cachedMatch.first,
                    isProfileLoading = false,
                    isProfileBvpLoading = false,
                    profileError = null
                )
            }
            enrichProfileBvp(cachedMatch.second, cachedMatch.first)
            return
        }

        val fallbackDate = preferredDate ?: snapshot.selectedDate
        mutate {
            it.copy(
                selectedPlayerId = id,
                selectedProfileCandidate = null,
                selectedProfileDate = fallbackDate,
                isProfileLoading = true,
                isProfileBvpLoading = false,
                profileError = null
            )
        }

        viewModelScope.launch {
            val loaded = runCatching {
                repository.loadBoard(
                    date = fallbackDate,
                    weights = snapshot.weights,
                    onProgress = { },
                    onPartialBoard = { }
                )
            }.getOrNull()

            loaded?.takeIf { it.candidates.isNotEmpty() }?.let(::cacheBoard)
            val candidate = loaded?.candidates?.firstOrNull { it.player.id == id }
            val enriched = candidate?.let { repository.enrichPlayerProfile(it) }
            mutate { current ->
                if (current.selectedPlayerId != id) current
                else current.copy(
                    selectedProfileCandidate = enriched,
                    selectedProfileDate = fallbackDate,
                    isProfileLoading = false,
                    isProfileBvpLoading = false,
                    profileError = if (enriched == null) {
                        "A full player profile could not be built for this player on ${fallbackDate}."
                    } else null
                )
            }
        }
    }

    private fun enrichProfileBvp(candidate: HitterCandidate, profileDate: LocalDate) {
        if (candidate.vsPitcherStats != null || candidate.opponentPitcher == null) return
        val id = candidate.player.id
        mutate { current ->
            if (current.selectedPlayerId == id && current.selectedProfileDate == profileDate) {
                current.copy(isProfileBvpLoading = true)
            } else current
        }
        viewModelScope.launch {
            val enriched = repository.enrichPlayerProfile(candidate)
            mutate { current ->
                if (current.selectedPlayerId != id || current.selectedProfileDate != profileDate) current
                else current.copy(
                    selectedProfileCandidate = enriched,
                    isProfileBvpLoading = false
                )
            }
        }
    }

    fun updateWeights(weights: ScoreWeights) {
        prefs.saveWeights(weights)
        synchronized(boardCache) {
            val rescored = boardCache.mapValues { (_, board) -> repository.rescore(board, weights) }
            boardCache.clear()
            boardCache.putAll(rescored)
        }
        mutate { s ->
            val rescored = s.board?.let { repository.rescore(it, weights) }
            s.copy(weights = weights, board = rescored)
        }
    }

    fun resetWeights() = updateWeights(ScoreWeights())

    fun toggleTracked(
        candidate: HitterCandidate,
        date: LocalDate = _state.value.selectedDate,
        pickType: PickType = PickType.HOME_RUN
    ) {
        val existing = _state.value.tracked
        val keyMatch: (TrackedPick) -> Boolean = {
            it.playerId == candidate.player.id && it.date == date
        }
        val next = if (existing.any(keyMatch)) {
            existing.filterNot(keyMatch)
        } else {
            existing + TrackedPick(
                playerId = candidate.player.id,
                playerName = candidate.player.name,
                teamName = candidate.team.name,
                date = date,
                scoreAtTrack = targetScore(candidate),
                trackedAt = Instant.now(),
                pickType = PickType.HOME_RUN
            )
        }
        prefs.saveTracked(next)
        mutate { it.copy(tracked = next) }
    }

    /**
     * Lazily load exact game lines for yesterday's Top 15. This never blocks the main board: the
     * postgame cards fill in as MLB game-log data arrives.
     */
    fun loadPostgameTargetStats() {
        val snapshot = _state.value
        if (snapshot.selectedDate != LocalDate.now().minusDays(1)) return
        val targets = topTargets(15, snapshot)
        if (targets.isEmpty()) return

        viewModelScope.launch {
            for (candidate in targets) {
                val id = candidate.player.id
                val key = "$id:${snapshot.selectedDate}"
                if (postgameStatsCache.containsKey(key)) {
                    val cached = postgameStatsCache[key]
                    if (cached != null) mutate { current ->
                        if (current.selectedDate == snapshot.selectedDate) current.copy(
                            postgameStats = current.postgameStats + (id to cached),
                            postgameStatsLoading = current.postgameStatsLoading - id
                        ) else current
                    }
                    continue
                }
                if (id in _state.value.postgameStatsLoading) continue
                mutate { current -> current.copy(postgameStatsLoading = current.postgameStatsLoading + id) }
                val stats = runCatching { repository.fetchPlayerGameStats(id, snapshot.selectedDate) }.getOrNull()
                postgameStatsCache[key] = stats
                mutate { current ->
                    if (current.selectedDate != snapshot.selectedDate) current
                    else current.copy(
                        postgameStats = if (stats != null) current.postgameStats + (id to stats) else current.postgameStats,
                        postgameStatsLoading = current.postgameStatsLoading - id
                    )
                }
            }
        }
    }

    fun postgameReview(candidate: HitterCandidate, stats: RecentHittingStats?): PostgameReview {
        val balls = candidate.todayBattedBalls
        val measuredHr = maxOf(stats?.homeRuns ?: 0, balls.count { it.isHomeRun })
        val hardest = balls.mapNotNull { it.exitVelocity }.maxOrNull()
        val eliteNear = balls.filter(scoringModel::isEliteNearHomeRun).maxByOrNull { it.distanceFt ?: 0.0 }
        val near = balls.filter(scoringModel::isNearHomeRun).maxByOrNull { it.distanceFt ?: 0.0 }
        val barrels = balls.count(scoringModel::isBarrelProxy)
        val hardHits = balls.count(scoringModel::isHardHit)
        val matchup = candidate.score.pitcherMatchup
        val pitcher = candidate.opponentPitcher

        val resultLine = when {
            stats != null -> buildString {
                append("${stats.hits}-for-${stats.atBats}")
                append(" • ${stats.homeRuns} HR")
                if (stats.extraBaseHits > stats.homeRuns) append(" • ${stats.extraBaseHits} XBH")
                append(" • ${stats.runs} R • ${stats.rbi} RBI • ${stats.strikeouts} K")
                hardest?.let { append(" • ${"%.1f".format(it)} max EV") }
            }
            else -> "${balls.size} tracked BBE${hardest?.let { " • ${"%.1f".format(it)} max EV" } ?: ""}"
        }

        if (measuredHr > 0) return PostgameReview(
            label = "MODEL HIT",
            explanation = "The target converted. The pregame power/matchup signals produced an actual home run.",
            resultLine = resultLine
        )
        if (eliteNear != null) return PostgameReview(
            label = "GOOD READ • JUST MISSED",
            explanation = "He generated elite home-run-quality contact but the ball stayed in the park. ${contactDetail(eliteNear)} This is process-positive and should not be treated like a bad model read.",
            resultLine = resultLine
        )
        if (near != null) return PostgameReview(
            label = "GOOD READ • NEAR-HR",
            explanation = "The hitter produced a legitimate near-home-run contact. ${contactDetail(near)} The HR result missed, but the underlying contact supported the pick.",
            resultLine = resultLine
        )
        if (barrels > 0) return PostgameReview(
            label = "BARREL • NO HR",
            explanation = "He found the barrel ($barrels barrel-proxy contact${if (barrels == 1) "" else "s"}) but did not get the home-run outcome. That is more variance than a complete miss.",
            resultLine = resultLine
        )
        if (stats != null && (stats.hits >= 2 || stats.extraBaseHits > 0 || stats.runs + stats.rbi >= 2)) return PostgameReview(
            label = "GOOD NIGHT • NO HR",
            explanation = "He was productive offensively, so the hitter-form signal was not necessarily wrong; the production simply came without a home run.",
            resultLine = resultLine
        )
        if (matchup < 45.0) {
            val pitcherText = pitcher?.let { p ->
                val details = buildList {
                    p.seasonStats.era?.let { add("${"%.2f".format(it)} ERA") }
                    p.seasonStats.hrPer9?.let { add("${"%.2f".format(it)} HR/9") }
                    p.seasonStats.strikeoutRate?.let { add("${(it * 100).roundToInt()}% K") }
                }.joinToString(" • ")
                "${p.person.name}${if (details.isNotBlank()) " ($details)" else ""}"
            } ?: "the opposing starter"
            return PostgameReview(
                label = "MATCHUP-DRIVEN MISS",
                explanation = "The model already rated the pitcher matchup only ${matchup.roundToInt()}. $pitcherText was a real resistance signal, so this target should have been pushed lower unless the hitter's power signals were exceptional.",
                resultLine = resultLine
            )
        }
        if (stats != null && stats.strikeouts >= 2) return PostgameReview(
            label = "BAD NIGHT • SWING/MISS",
            explanation = "This looks more like a poor individual night than a near miss: ${stats.strikeouts} strikeouts and no HR-quality contact. Swing-and-miss should count against similar profiles when the supporting power signals are only average.",
            resultLine = resultLine
        )
        if (stats != null && stats.hits == 0) return PostgameReview(
            label = "QUIET NIGHT",
            explanation = "He never got going offensively and did not generate a qualifying near-HR/barrel signal. This is a true miss rather than a good process result.",
            resultLine = resultLine
        )
        if (hardHits > 0) return PostgameReview(
            label = "HARD CONTACT • NO HR",
            explanation = "He made $hardHits hard-hit contact${if (hardHits == 1) "" else "s"}, but none reached near-HR quality. The bat was not dead, but the HR-specific read was too optimistic.",
            resultLine = resultLine
        )
        return PostgameReview(
            label = "MODEL MISS",
            explanation = "No home run and no strong contact evidence supported the pick after the game. Treat this as a full miss and use it when calibrating similar profiles.",
            resultLine = resultLine
        )
    }

    private fun contactDetail(ball: com.ckz.hrchase.data.BattedBall): String = buildString {
        ball.exitVelocity?.let { append("${"%.1f".format(it)} mph") }
        ball.launchAngle?.let { if (isNotEmpty()) append(" / "); append("${it.roundToInt()}°") }
        ball.distanceFt?.let { if (isNotEmpty()) append(" / "); append("${it.roundToInt()} ft") }
        if (isNotEmpty()) append(".")
    }

    fun loadTrackedLast10Stats() {
        val snapshot = _state.value
        val picks = snapshot.tracked.filter { it.date == snapshot.selectedDate }
        if (picks.isEmpty()) return

        // Never include an in-progress/future game in the recent-form summary. For today and future
        // boards, use yesterday as the cutoff. When reviewing yesterday, that completed game can be
        // included in the rolling last-10 snapshot.
        val lastCompletedDate = LocalDate.now().minusDays(1)
        val throughDate = minOf(snapshot.selectedDate, lastCompletedDate)

        picks.forEach { pick ->
            val key = "${pick.playerId}:$throughDate"
            if (trackedLast10Cache.containsKey(key)) {
                val cached = trackedLast10Cache[key]
                if (cached != null && snapshot.trackedLast10[pick.playerId] != cached) {
                    mutate { current ->
                        if (current.selectedDate == snapshot.selectedDate) {
                            current.copy(trackedLast10 = current.trackedLast10 + (pick.playerId to cached))
                        } else current
                    }
                }
                return@forEach
            }
            if (pick.playerId in _state.value.trackedLast10Loading) return@forEach

            mutate { current ->
                current.copy(trackedLast10Loading = current.trackedLast10Loading + pick.playerId)
            }
            viewModelScope.launch {
                val stats = runCatching {
                    repository.fetchPlayerLast10Stats(pick.playerId, throughDate)
                }.getOrNull()
                trackedLast10Cache[key] = stats
                mutate { current ->
                    if (current.selectedDate != snapshot.selectedDate) {
                        current.copy(trackedLast10Loading = current.trackedLast10Loading - pick.playerId)
                    } else {
                        current.copy(
                            trackedLast10 = if (stats != null) {
                                current.trackedLast10 + (pick.playerId to stats)
                            } else current.trackedLast10,
                            trackedLast10Loading = current.trackedLast10Loading - pick.playerId
                        )
                    }
                }
            }
        }
    }

    fun clearTrackedForSelectedDate() {
        val date = _state.value.selectedDate
        val next = _state.value.tracked.filterNot { it.date == date }
        prefs.saveTracked(next)
        mutate { it.copy(tracked = next, trackedLast10 = emptyMap(), trackedLast10Loading = emptySet()) }
    }

    private fun inverseScale(value: Double, good: Double, bad: Double): Double {
        if (bad <= good) return 50.0
        return (100.0 - ((value - good) / (bad - good) * 100.0)).coerceIn(0.0, 100.0)
    }

    private fun mutate(block: (AppUiState) -> AppUiState) {
        synchronized(stateLock) {
            _state.value = block(_state.value)
        }
    }

    private fun gameIsUnavailable(game: com.ckz.hrchase.data.GameInfo): Boolean {
        val detail = game.detailedStatus.lowercase()
        return listOf("postponed", "cancelled", "canceled", "suspended", "game over").any { it in detail }
    }

    private fun isPregameCandidate(candidate: HitterCandidate, state: AppUiState = _state.value): Boolean {
        val boardDate = state.board?.date ?: state.selectedDate
        // Historical dates remain fully browsable for review/backtesting. On today's live slate,
        // recommendation surfaces must never suggest a hitter whose game already started.
        if (boardDate != LocalDate.now()) return !gameIsUnavailable(candidate.game)
        return candidate.game.status.equals("Preview", true) && !gameIsUnavailable(candidate.game)
    }

    /** Base candidate set used by the Games screen. Live games may remain visible here. */
    fun eligibleCandidates(state: AppUiState = _state.value): List<HitterCandidate> {
        val board = state.board ?: return emptyList()
        val nowDate = LocalDate.now()
        val base = board.candidates.asSequence()
            .filter { c ->
                if (!state.showRemainingOnly || board.date != nowDate) true
                else !c.game.status.equals("Final", true)
            }
            .filter { c -> !state.officialLineupsOnly || c.lineupOfficial }
            .toList()

        if (!state.eliteArsenalOnly && !state.topZoneOnly) return base

        // Both special filters are relative slate views. Top Arsenal ranks the best measured pitch-
        // type fits; Top Zone ranks the best measured pitcher-attack/hitter-damage overlaps.
        fun applySpecialFilter(pool: List<HitterCandidate>): List<HitterCandidate> = when {
            state.topZoneOnly -> topAttackZoneMatches(pool)
            state.eliteArsenalOnly -> topArsenalMatches(pool)
            else -> pool
        }

        // Preserve a separate live group so started games can still be reviewed without consuming
        // spots from tonight's pregame shortlist.
        if (board.date == nowDate) {
            val pregame = base.filter { it.game.status.equals("Preview", true) && !gameIsUnavailable(it.game) }
            val started = base.filterNot { it.game.status.equals("Preview", true) && !gameIsUnavailable(it.game) }
            return (applySpecialFilter(pregame) + applySpecialFilter(started))
                .distinctBy(::arsenalCandidateKey)
        }
        return applySpecialFilter(base)
    }

    /** Candidates safe for Targets/Hot/Heating/Parlays. Never includes live/final/postponed games today. */
    fun pregameCandidates(state: AppUiState = _state.value): List<HitterCandidate> = eligibleCandidates(state)
        .filter { isPregameCandidate(it, state) }

    fun visibleCandidates(state: AppUiState = _state.value): List<HitterCandidate> {
        return eligibleCandidates(state).asSequence()
            .filter { c ->
                state.sortMode != SortMode.ATTACK ||
                    !state.attackStrongOnly ||
                    (c.score.powerPressure >= 65.0 && c.score.pitcherMatchup >= 65.0)
            }
            .sortedWith(
                if (state.topZoneOnly) {
                    compareByDescending<HitterCandidate> { it.attackZoneMatch?.score ?: 0.0 }
                        .thenByDescending { it.attackZoneMatch?.confidence ?: 0.0 }
                        .thenByDescending(::targetScore)
                } else if (state.eliteArsenalOnly) {
                    compareByDescending<HitterCandidate> { it.pitchArsenalMatch?.score ?: 0.0 }
                        .thenByDescending { it.pitchArsenalMatch?.confidence ?: 0.0 }
                        .thenByDescending(::targetScore)
                } else {
                    when (state.sortMode) {
                        SortMode.SCORE -> compareByDescending<HitterCandidate> { it.score.total }
                        SortMode.ATTACK -> compareByDescending<HitterCandidate> { attackScore(it) }
                            .thenByDescending { it.score.total }
                        SortMode.POWER_PRESSURE -> compareByDescending<HitterCandidate> { it.score.powerPressure }
                        SortMode.RECENT_POWER -> compareByDescending<HitterCandidate> { it.score.recentPower }
                        SortMode.MATCHUP -> compareByDescending<HitterCandidate> { it.score.pitcherMatchup }
                    }
                }
            )
            .toList()
    }

    fun topHittersForGame(
        gamePk: Long,
        limit: Int = 4,
        state: AppUiState = _state.value
    ): List<HitterCandidate> = eligibleCandidates(state)
        .filter { it.game.gamePk == gamePk }
        .sortedWith(
            if (state.eliteArsenalOnly) {
                compareByDescending<HitterCandidate> { it.pitchArsenalMatch?.score ?: 0.0 }
                    .thenByDescending { it.pitchArsenalMatch?.confidence ?: 0.0 }
                    .thenByDescending(::pickScore)
            } else {
                compareByDescending<HitterCandidate>(::pickScore)
            }
        )
        .take(limit)

    /**
     * Balanced parlay score used by the default generator profile. This still starts from the
     * calibrated Daily Target Score, then adds a small convergence bonus for pressure, matchup,
     * signal quality and plate discipline.
     */
    fun parlayScore(candidate: HitterCandidate): Double {
        var score = pickScore(candidate)
        val pressure = candidate.score.powerPressure
        val matchup = candidate.score.pitcherMatchup

        score += when {
            pressure >= 70.0 && matchup >= 70.0 -> 7.0
            pressure >= 60.0 && matchup >= 60.0 -> 4.0
            pressure >= 52.0 && matchup >= 52.0 -> 2.0
            else -> 0.0
        }

        val signal = signalLensScore(candidate)
        score += when {
            signal >= 78.0 -> 4.0
            signal >= 68.0 -> 2.0
            else -> 0.0
        }
        recentWhiffRate(candidate)?.let {
            if (it <= .22 && candidate.recentPlateDiscipline.swings >= 10) score += 1.5
        }

        if (candidate.score.environment < 35.0) score -= 8.0
        if (matchup < 35.0) score -= 6.0
        return score.coerceIn(0.0, 100.0)
    }

    /**
     * Profile-specific generator score. Each focus answers a different betting question instead
     * of sending every generator request through the same top-target ranking.
     */
    fun parlayFocusScore(
        candidate: HitterCandidate,
        focus: ParlayFocus,
        state: AppUiState = _state.value
    ): Double {
        val metrics = mustHaveMetrics(candidate)
        val profile = mustHavePowerScore(candidate)
        val arsenal = candidate.pitchArsenalMatch?.score
        val arsenalValue = arsenal ?: 50.0
        val matchup = candidate.score.pitcherMatchup
        val environment = candidate.score.environment

        val raw = when (focus) {
            ParlayFocus.BALANCED -> parlayScore(candidate)

            ParlayFocus.PURE_POWER -> {
                // Established HR skill + current batted-ball shape lead this mode. Recent form and
                // matchup still matter enough to keep pure-power cards from becoming name-only slips.
                candidate.score.seasonPower * .30 +
                    profile * .28 +
                    candidate.score.recentPower * .12 +
                    reliablePowerPressure(candidate) * .10 +
                    arsenalValue * .08 +
                    matchup * .07 +
                    environment * .05
            }

            ParlayFocus.HEATING_UP -> {
                val heat = heatingScore(candidate, state)
                heat * .43 +
                    targetScore(candidate) * .20 +
                    reliablePowerPressure(candidate) * .13 +
                    candidate.score.recentPower * .09 +
                    matchup * .07 +
                    arsenalValue * .05 +
                    swingMissScore(candidate) * .03
            }

            ParlayFocus.HOT_NOW -> {
                val hot = hotStreakScore(candidate, state)
                hot * .43 +
                    targetScore(candidate) * .20 +
                    candidate.score.seasonPower * .14 +
                    profile * .08 +
                    matchup * .07 +
                    arsenalValue * .05 +
                    environment * .03
            }

            ParlayFocus.MATCHUP_EDGE -> {
                val convergence = arsenalHandednessConvergence(candidate)
                matchup * .28 +
                    convergence.score * .28 +
                    targetScore(candidate) * .17 +
                    environment * .08 +
                    candidate.score.seasonPower * .07 +
                    signalLensScore(candidate, state) * .07 +
                    candidate.score.platoon * .05
            }

            ParlayFocus.ELITE_ARSENAL -> {
                val elite = candidate.pitchArsenalMatch
                val fit = elite?.score ?: 0.0
                val confidence = ((elite?.confidence ?: 0.0) * 100.0).coerceIn(0.0, 100.0)
                fit * .58 +
                    confidence * .14 +
                    targetScore(candidate) * .12 +
                    mustHavePowerScore(candidate) * .08 +
                    matchup * .05 +
                    candidate.score.platoon * .03
            }
        }

        var adjusted = raw
        // Give BvP a small capped tie-breaker in every profile without letting a tiny career sample
        // dominate the generator.
        adjusted += bvpAdjustment(candidate) * .25

        if (focus == ParlayFocus.PURE_POWER) {
            if ((metrics.barrelPct ?: 0.0) >= 14.0) adjusted += 2.0
            if ((metrics.maxExitVelocity ?: 0.0) >= 108.0) adjusted += 1.5
        }
        if (focus == ParlayFocus.HEATING_UP && heatingSignalCount(candidate, state) >= 5) adjusted += 2.0
        if (focus == ParlayFocus.HOT_NOW && (recentWeekStats(candidate, state)?.homeRuns ?: 0) >= 2) adjusted += 2.0
        if (focus == ParlayFocus.MATCHUP_EDGE) {
            val convergence = arsenalHandednessConvergence(candidate)
            if (convergence.isPerfectFit) adjusted += 3.0
            else if (convergence.isStrongFit) adjusted += 1.5
        }
        if (focus == ParlayFocus.ELITE_ARSENAL && isEliteArsenalMatch(candidate)) adjusted += 3.0

        if (environment < 30.0) adjusted -= 5.0
        if (matchup < 30.0 && focus != ParlayFocus.PURE_POWER) adjusted -= 4.0
        return adjusted.coerceIn(0.0, 100.0)
    }

    fun parlayFocusLabel(focus: ParlayFocus): String = when (focus) {
        ParlayFocus.BALANCED -> "Balanced"
        ParlayFocus.PURE_POWER -> "Pure Power"
        ParlayFocus.HEATING_UP -> "Heating Up"
        ParlayFocus.HOT_NOW -> "Hot Now"
        ParlayFocus.MATCHUP_EDGE -> "Matchup Edge"
        ParlayFocus.ELITE_ARSENAL -> "Top Arsenal"
    }

    fun parlayFocusDescription(focus: ParlayFocus): String = when (focus) {
        ParlayFocus.BALANCED -> "Blends the full HR Chase model with matchup, form, power and pitch fit."
        ParlayFocus.PURE_POWER -> "Prioritizes proven HR skill, barrels, hard contact, EV and power shape."
        ParlayFocus.HEATING_UP -> "Targets 3-day acceleration, improving contact and emerging HR-quality swings."
        ParlayFocus.HOT_NOW -> "Leans into hitters already producing over the last 7 days with support underneath."
        ParlayFocus.MATCHUP_EDGE -> "Prioritizes pitcher vulnerability plus arsenal + handedness convergence, then environment and power support."
        ParlayFocus.ELITE_ARSENAL -> "Shows the strongest available pitch-arsenal matches on the slate with no hard score cutoff; arsenal fit ranks first, then confidence and HR quality."
    }

    fun parlayLegReason(
        candidate: HitterCandidate,
        focus: ParlayFocus,
        state: AppUiState = _state.value
    ): String {
        val metrics = mustHaveMetrics(candidate)
        return when (focus) {
            ParlayFocus.BALANCED -> {
                val arsenal = candidate.pitchArsenalMatch?.score?.roundToInt()?.let { " • Arsenal $it" }.orEmpty()
                "Target ${targetScore(candidate).roundToInt()} • Pressure ${candidate.score.powerPressure.roundToInt()} • Matchup ${candidate.score.pitcherMatchup.roundToInt()}$arsenal"
            }
            ParlayFocus.PURE_POWER -> {
                val barrel = metrics.barrelPct?.let { "${"%.1f".format(it)}% barrel" } ?: "power profile ${profileText(mustHavePowerScore(candidate))}"
                "Season power ${candidate.score.seasonPower.roundToInt()} • $barrel • Max EV ${metrics.maxExitVelocity?.let { "%.1f".format(it) } ?: "—"}"
            }
            ParlayFocus.HEATING_UP -> {
                val three = recentThreeDayStats(candidate, state)
                val line = three?.ops?.let { " • 3D OPS ${"%.3f".format(it)}" }.orEmpty()
                "Heat ${heatingScore(candidate, state).roundToInt()} • ${heatingSignalCount(candidate, state)} signals • Pressure ${candidate.score.powerPressure.roundToInt()}$line"
            }
            ParlayFocus.HOT_NOW -> {
                val week = recentWeekStats(candidate, state)
                val ops = week?.ops?.let { "${"%.3f".format(it)} OPS" } ?: "7-day form"
                "Hot ${hotStreakScore(candidate, state).roundToInt()} • $ops • ${week?.homeRuns ?: 0} HR / ${week?.extraBaseHits ?: 0} XBH"
            }
            ParlayFocus.MATCHUP_EDGE -> {
                val convergence = arsenalHandednessConvergence(candidate)
                val arsenal = candidate.pitchArsenalMatch?.score?.roundToInt()?.toString() ?: "N/A"
                "Matchup ${candidate.score.pitcherMatchup.roundToInt()} • A+H ${convergence.score.roundToInt()} ${convergence.label} • Arsenal $arsenal • Platoon ${candidate.score.platoon.roundToInt()}"
            }
            ParlayFocus.ELITE_ARSENAL -> {
                val arsenal = candidate.pitchArsenalMatch
                val score = arsenal?.score?.roundToInt() ?: 0
                val confidence = ((arsenal?.confidence ?: 0.0) * 100.0).roundToInt()
                "Arsenal $score • confidence $confidence% • Target ${targetScore(candidate).roundToInt()} • Power ${mustHavePowerScore(candidate).roundToInt()}"
            }
        }
    }

    /**
     * Multi-focus generator support. Every selected specialized lens is treated as an AND filter,
     * while the combined score rewards both the average quality and the weakest selected lens.
     * Balanced can be stacked with another lens when the user wants the core model to remain part
     * of the ranking.
     */
    private fun normalizedParlayFocuses(focuses: Set<ParlayFocus>): List<ParlayFocus> =
        (if (focuses.isEmpty()) setOf(ParlayFocus.BALANCED) else focuses).sortedBy { it.ordinal }

    private fun passesParlayFocus(
        candidate: HitterCandidate,
        focus: ParlayFocus,
        state: AppUiState
    ): Boolean = when (focus) {
        ParlayFocus.BALANCED -> true
        ParlayFocus.PURE_POWER ->
            candidate.score.seasonPower >= 44.0 || mustHavePowerScore(candidate) >= 58.0
        ParlayFocus.HEATING_UP ->
            (recentThreeDayStats(candidate, state)?.plateAppearances ?: 0) >= 4 &&
                heatingSignalCount(candidate, state) >= 2
        ParlayFocus.HOT_NOW ->
            (recentWeekStats(candidate, state)?.plateAppearances ?: 0) >= 5 &&
                hotStreakScore(candidate, state) >= 52.0
        ParlayFocus.MATCHUP_EDGE -> {
            val convergence = arsenalHandednessConvergence(candidate)
            candidate.score.pitcherMatchup >= 48.0 || convergence.score >= 62.0
        }
        ParlayFocus.ELITE_ARSENAL -> isTopArsenalMatch(candidate, state)
    }

    fun parlayCombinedScore(
        candidate: HitterCandidate,
        focuses: Set<ParlayFocus>,
        state: AppUiState = _state.value
    ): Double {
        val selected = normalizedParlayFocuses(focuses)
        if (selected.size == 1) return parlayFocusScore(candidate, selected.first(), state)

        val scores = selected.map { parlayFocusScore(candidate, it, state) }
        val average = scores.average()
        val floor = scores.minOrNull() ?: average
        val strongAcross = scores.count { it >= 65.0 }
        val synergy = ((strongAcross - 1).coerceAtLeast(0) * 1.15).coerceAtMost(4.0)

        // A weak selected lens matters: stacking filters should find overlap, not merely average away
        // a bad matchup or cold-form signal.
        return (average * .72 + floor * .28 + synergy).coerceIn(0.0, 100.0)
    }

    fun parlayCombinedLabel(focuses: Set<ParlayFocus>): String {
        val selected = normalizedParlayFocuses(focuses)
        if (selected.size == 1) return parlayFocusLabel(selected.first())
        return selected.joinToString(" + ") {
            when (it) {
                ParlayFocus.BALANCED -> "Balanced"
                ParlayFocus.PURE_POWER -> "Power"
                ParlayFocus.HEATING_UP -> "Heating"
                ParlayFocus.HOT_NOW -> "Hot"
                ParlayFocus.MATCHUP_EDGE -> "Matchup"
                ParlayFocus.ELITE_ARSENAL -> "Arsenal"
            }
        }
    }

    fun parlayCombinedDescription(focuses: Set<ParlayFocus>): String {
        val selected = normalizedParlayFocuses(focuses)
        if (selected.size == 1) return parlayFocusDescription(selected.first())
        val fullLabels = selected.joinToString(" + ") { parlayFocusLabel(it) }
        return "AND mode: hitters must qualify for every selected lens ($fullLabels). Ranking rewards strength across the entire stack, and one weak selected lens pulls the score down."
    }

    fun parlayCombinedLegReason(
        candidate: HitterCandidate,
        focuses: Set<ParlayFocus>,
        state: AppUiState = _state.value
    ): String {
        val selected = normalizedParlayFocuses(focuses)
        if (selected.size == 1) return parlayLegReason(candidate, selected.first(), state)
        return selected.joinToString(" • ") { focus ->
            val short = when (focus) {
                ParlayFocus.BALANCED -> "Bal"
                ParlayFocus.PURE_POWER -> "Power"
                ParlayFocus.HEATING_UP -> "Heat"
                ParlayFocus.HOT_NOW -> "Hot"
                ParlayFocus.MATCHUP_EDGE -> "Matchup"
                ParlayFocus.ELITE_ARSENAL -> "Arsenal"
            }
            "$short ${parlayFocusScore(candidate, focus, state).roundToInt()}"
        }
    }

    private fun parlayCombinedCandidatePool(
        focuses: Set<ParlayFocus>,
        state: AppUiState
    ): List<HitterCandidate> {
        val selected = normalizedParlayFocuses(focuses)
        val eligible = pregameCandidates(state.copy(eliteArsenalOnly = false)).filter { it.score.total >= 36.0 }
        if (eligible.isEmpty()) return emptyList()

        // Strict intersection: when the user stacks Hot + Matchup, every returned hitter must pass
        // both qualification rules. We intentionally do not silently fall back to unfiltered names.
        val focused = eligible.filter { candidate ->
            selected.all { focus -> passesParlayFocus(candidate, focus, state) }
        }
        if (focused.isEmpty()) return emptyList()

        val ranked = focused.sortedWith(
            compareByDescending<HitterCandidate> { parlayCombinedScore(it, focuses, state) }
                .thenByDescending(::targetScore)
                .thenByDescending { it.score.seasonPower }
        )
        val best = parlayCombinedScore(ranked.first(), focuses, state)
        val qualityWindow = ranked.filter { parlayCombinedScore(it, focuses, state) >= best - 23.0 }.take(48)
        return if (qualityWindow.size >= 5 || ranked.size < 5) qualityWindow else ranked.take(48)
    }

    fun straightCombinedCandidates(
        focuses: Set<ParlayFocus>,
        state: AppUiState = _state.value
    ): List<HitterCandidate> {
        val base = parlayCombinedCandidatePool(focuses, state)
        if (base.isEmpty()) return emptyList()
        val best = parlayCombinedScore(base.first(), focuses, state)
        val window = base.filter { parlayCombinedScore(it, focuses, state) >= best - 16.0 }.take(18)
        return if (window.isNotEmpty()) window else base.take(18)
    }

    fun parlayCombinedRotationOffset(focuses: Set<ParlayFocus>): Int =
        normalizedParlayFocuses(focuses).sumOf { (it.ordinal + 1) * 3 }

    private fun combinedRotationBonus(
        candidate: HitterCandidate,
        variant: Int,
        slot: Int,
        focuses: Set<ParlayFocus>
    ): Double {
        if (variant == 0) return 0.0
        var x = candidate.player.id.toLong() * 1_103_515_245L
        x += variant.toLong() * 12_345L
        x += slot.toLong() * 97_531L
        x += parlayCombinedRotationOffset(focuses).toLong() * 7_919L
        x = x xor (x ushr 16)
        val unit = ((x and 0x7fffffffL) % 1000L) / 1000.0
        return unit * 7.5
    }

    fun generateCombinedParlay(
        legs: Int,
        variant: Int = 0,
        focuses: Set<ParlayFocus> = setOf(ParlayFocus.BALANCED),
        state: AppUiState = _state.value
    ): List<HitterCandidate> {
        val targetLegs = legs.coerceIn(1, 5)
        val selected = normalizedParlayFocuses(focuses)
        val base = parlayCombinedCandidatePool(focuses, state)
        if (base.size < targetLegs) return emptyList()

        if (targetLegs == 1) {
            val straights = straightCombinedCandidates(focuses, state)
            if (straights.isEmpty()) return emptyList()
            val offset = parlayCombinedRotationOffset(focuses)
            val index = if (variant == 0) 0 else Math.floorMod(variant * 5 + offset, straights.size)
            return listOf(straights[index])
        }

        val chosen = mutableListOf<HitterCandidate>()
        val usedGames = mutableSetOf<Long>()
        val usedTeams = mutableSetOf<Int>()
        val offset = parlayCombinedRotationOffset(focuses)

        val anchorPoolSize = minOf(18, base.size)
        val anchorIndex = if (variant == 0) 0 else Math.floorMod(variant * 5 + offset, anchorPoolSize)
        val anchor = base[anchorIndex]
        chosen += anchor
        usedGames += anchor.game.gamePk
        usedTeams += anchor.team.id

        for (slot in 1 until targetLegs) {
            val options = base.asSequence()
                .filter { candidate -> chosen.none { it.player.id == candidate.player.id } }
                .map { candidate ->
                    var adjusted = parlayCombinedScore(candidate, focuses, state)
                    if (candidate.game.gamePk in usedGames) adjusted -= 17.0
                    if (candidate.team.id in usedTeams) adjusted -= 8.0
                    if (candidate.score.environment < 35.0) adjusted -= 5.0

                    val purePowerOnly = selected.size == 1 && selected.first() == ParlayFocus.PURE_POWER
                    if (candidate.score.pitcherMatchup < 35.0 && !purePowerOnly) adjusted -= 5.0
                    adjusted += combinedRotationBonus(candidate, variant, slot, focuses)
                    candidate to adjusted
                }
                .sortedByDescending { it.second }
                .take(10)
                .toList()

            if (options.isEmpty()) break
            val bestAdjusted = options.first().second
            val competitive = options.filter { it.second >= bestAdjusted - 7.5 }.take(6)
            val optionIndex = if (variant == 0 || competitive.size == 1) 0
            else Math.floorMod(variant + slot * 2 + offset, competitive.size)
            val next = competitive[optionIndex].first

            chosen += next
            usedGames += next.game.gamePk
            usedTeams += next.team.id
        }

        return if (chosen.size == targetLegs) chosen else emptyList()
    }

    fun evaluateCombinedParlay(
        parlay: List<HitterCandidate>,
        focuses: Set<ParlayFocus> = setOf(ParlayFocus.BALANCED),
        state: AppUiState = _state.value
    ): ParlayEvaluation {
        if (parlay.isEmpty()) {
            return ParlayEvaluation(0, "NO CARD", 0, 0, 0, "Not enough hitters qualify for every selected filter. Remove a filter or wait for more data.")
        }

        val scores = parlay.map { parlayCombinedScore(it, focuses, state).coerceIn(0.0, 100.0) }
        val average = scores.average()
        val weakest = scores.minOrNull() ?: 0.0
        val uniqueGames = parlay.map { it.game.gamePk }.distinct().size
        val diversityBonus = if (parlay.size <= 1) 0.0 else (uniqueGames.toDouble() / parlay.size) * 3.0
        val legPenalty = when (parlay.size) {
            1 -> 0.0
            2 -> 10.0
            3 -> 21.0
            4 -> 33.0
            else -> 44.0
        }
        val stackedBonus = ((normalizedParlayFocuses(focuses).size - 1) * 0.8).coerceAtMost(2.4)

        val rating = (average * .58 + weakest * .42 + diversityBonus + stackedBonus - legPenalty)
            .roundToInt()
            .coerceIn(1, 99)
        val label = when {
            rating >= 76 -> "HIGHER"
            rating >= 63 -> "STRONG"
            rating >= 49 -> "MODERATE"
            rating >= 35 -> "LOWER"
            else -> "LONG SHOT"
        }
        val filterNote = if (normalizedParlayFocuses(focuses).size > 1) {
            " Every leg passed all ${normalizedParlayFocuses(focuses).size} selected filters."
        } else ""
        val note = when {
            parlay.size == 1 -> "Strongest comparison is against other straight HR candidates in this filter set.$filterNote"
            uniqueGames == parlay.size -> "All legs come from different games, reducing avoidable same-game dependence.$filterNote"
            uniqueGames >= parlay.size - 1 -> "Mostly diversified across games with one shared-game exposure.$filterNote"
            else -> "Multiple legs share games, so the card carries more correlation and slate-specific risk.$filterNote"
        }

        return ParlayEvaluation(
            rating = rating,
            label = label,
            averageLegScore = average.roundToInt(),
            weakestLegScore = weakest.roundToInt(),
            uniqueGames = uniqueGames,
            note = note
        )
    }

    private fun profileText(score: Double): String = when {
        score >= 80.0 -> "elite"
        score >= 68.0 -> "strong"
        score >= 56.0 -> "solid"
        else -> "developing"
    }

    private fun parlayCandidatePool(
        focus: ParlayFocus,
        state: AppUiState
    ): List<HitterCandidate> {
        val eligible = pregameCandidates(state.copy(eliteArsenalOnly = false)).filter { it.score.total >= 36.0 }
        if (eligible.isEmpty()) return emptyList()

        val focused = eligible.filter { candidate ->
            when (focus) {
                ParlayFocus.BALANCED -> true
                ParlayFocus.PURE_POWER ->
                    candidate.score.seasonPower >= 44.0 || mustHavePowerScore(candidate) >= 58.0
                ParlayFocus.HEATING_UP ->
                    (recentThreeDayStats(candidate, state)?.plateAppearances ?: 0) >= 4 &&
                        heatingSignalCount(candidate, state) >= 2
                ParlayFocus.HOT_NOW ->
                    (recentWeekStats(candidate, state)?.plateAppearances ?: 0) >= 5 &&
                        hotStreakScore(candidate, state) >= 52.0
                ParlayFocus.MATCHUP_EDGE ->
                    candidate.score.pitcherMatchup >= 44.0 || (candidate.pitchArsenalMatch?.score ?: 0.0) >= 58.0
                ParlayFocus.ELITE_ARSENAL -> isTopArsenalMatch(candidate, state)
            }
        }

        // Specialized modes are strict. Returning unrelated hitters makes a working generator look
        // trustworthy while violating the selected filter, which is worse than an honest empty state.
        val source = if (focus == ParlayFocus.BALANCED) eligible else focused
        val ranked = source.sortedWith(
            compareByDescending<HitterCandidate> { parlayFocusScore(it, focus, state) }
                .thenByDescending(::targetScore)
                .thenByDescending { it.score.seasonPower }
        )
        if (ranked.isEmpty()) return emptyList()

        val best = parlayFocusScore(ranked.first(), focus, state)
        // A wider but still controlled quality window gives Generate Again room to breathe.
        return ranked.filter { parlayFocusScore(it, focus, state) >= best - 23.0 }.take(48)
    }

    fun straightCandidates(
        focus: ParlayFocus = ParlayFocus.BALANCED,
        state: AppUiState = _state.value
    ): List<HitterCandidate> {
        val base = parlayCandidatePool(focus, state)
        if (base.isEmpty()) return emptyList()
        val best = parlayFocusScore(base.first(), focus, state)
        val window = base.filter { parlayFocusScore(it, focus, state) >= best - 16.0 }.take(18)
        return if (window.isNotEmpty()) window else base.take(18)
    }

    private fun rotationBonus(
        candidate: HitterCandidate,
        variant: Int,
        slot: Int,
        focus: ParlayFocus
    ): Double {
        if (variant == 0) return 0.0
        var x = candidate.player.id.toLong() * 1_103_515_245L
        x += variant.toLong() * 12_345L
        x += slot.toLong() * 97_531L
        x += focus.ordinal.toLong() * 7_919L
        x = x xor (x ushr 16)
        val unit = ((x and 0x7fffffffL) % 1000L) / 1000.0
        return unit * 7.5
    }

    /**
     * Generates a profile-aware, quality-controlled HR card with substantially more rotation.
     * Variant zero remains the strongest pure model card. Later variants deliberately rotate the
     * anchor through a deeper quality band and add a small deterministic diversity bonus, while
     * still penalizing repeated games/teams and weak legs.
     */
    fun generateParlay(
        legs: Int,
        variant: Int = 0,
        focus: ParlayFocus = ParlayFocus.BALANCED,
        state: AppUiState = _state.value
    ): List<HitterCandidate> {
        val targetLegs = legs.coerceIn(1, 5)
        val base = parlayCandidatePool(focus, state)
        if (base.isEmpty()) return emptyList()

        if (targetLegs == 1) {
            val straights = straightCandidates(focus, state)
            if (straights.isEmpty()) return emptyList()
            // A stride of five walks the ranked pool instead of simply cycling adjacent names.
            val index = if (variant == 0) 0 else Math.floorMod(variant * 5 + focus.ordinal * 3, straights.size)
            return listOf(straights[index])
        }

        val chosen = mutableListOf<HitterCandidate>()
        val usedGames = mutableSetOf<Long>()
        val usedTeams = mutableSetOf<Int>()

        val anchorPoolSize = minOf(18, base.size)
        val anchorIndex = if (variant == 0) 0 else Math.floorMod(variant * 5 + focus.ordinal * 3, anchorPoolSize)
        val anchor = base[anchorIndex]
        chosen += anchor
        usedGames += anchor.game.gamePk
        usedTeams += anchor.team.id

        for (slot in 1 until targetLegs) {
            val options = base.asSequence()
                .filter { candidate -> chosen.none { it.player.id == candidate.player.id } }
                .map { candidate ->
                    var adjusted = parlayFocusScore(candidate, focus, state)

                    // Prefer independent games and teams, especially for longer cards.
                    if (candidate.game.gamePk in usedGames) adjusted -= 17.0
                    if (candidate.team.id in usedTeams) adjusted -= 8.0
                    if (candidate.score.environment < 35.0) adjusted -= 5.0
                    if (candidate.score.pitcherMatchup < 35.0 && focus != ParlayFocus.PURE_POWER) adjusted -= 5.0

                    // Later generations get a small deterministic rotation boost. It is large enough
                    // to change comparable options, but not enough to promote a clearly weak hitter.
                    adjusted += rotationBonus(candidate, variant, slot, focus)
                    candidate to adjusted
                }
                .sortedByDescending { it.second }
                .take(10)
                .toList()

            if (options.isEmpty()) break

            val bestAdjusted = options.first().second
            val competitive = options.filter { it.second >= bestAdjusted - 7.5 }.take(6)
            val optionIndex = if (variant == 0 || competitive.size == 1) 0
            else Math.floorMod(variant + slot * 2 + focus.ordinal, competitive.size)
            val next = competitive[optionIndex].first

            chosen += next
            usedGames += next.game.gamePk
            usedTeams += next.team.id
        }

        return chosen.take(targetLegs)
    }

    /**
     * Relative card rating, not a calibrated probability. It intentionally penalizes leg count
     * because even excellent HR legs become much harder to combine as a parlay grows. The weakest
     * leg matters heavily so a single reach can drag down the entire card grade.
     */
    fun evaluateParlay(
        parlay: List<HitterCandidate>,
        focus: ParlayFocus = ParlayFocus.BALANCED,
        state: AppUiState = _state.value
    ): ParlayEvaluation {
        if (parlay.isEmpty()) {
            return ParlayEvaluation(0, "NO CARD", 0, 0, 0, "Waiting for enough qualified hitters.")
        }

        val scores = parlay.map { parlayFocusScore(it, focus, state).coerceIn(0.0, 100.0) }
        val average = scores.average()
        val weakest = scores.minOrNull() ?: 0.0
        val uniqueGames = parlay.map { it.game.gamePk }.distinct().size
        val diversityBonus = if (parlay.size <= 1) 0.0 else (uniqueGames.toDouble() / parlay.size) * 3.0
        val legPenalty = when (parlay.size) {
            1 -> 0.0
            2 -> 10.0
            3 -> 21.0
            4 -> 33.0
            else -> 44.0
        }

        val rating = (average * .58 + weakest * .42 + diversityBonus - legPenalty)
            .roundToInt()
            .coerceIn(1, 99)
        val label = when {
            rating >= 76 -> "HIGHER"
            rating >= 63 -> "STRONG"
            rating >= 49 -> "MODERATE"
            rating >= 35 -> "LOWER"
            else -> "LONG SHOT"
        }
        val note = when {
            parlay.size == 1 -> "Strongest comparison is against other straight HR candidates in this focus."
            uniqueGames == parlay.size -> "All legs come from different games, reducing avoidable same-game dependence."
            uniqueGames >= parlay.size - 1 -> "Mostly diversified across games with one shared-game exposure."
            else -> "Multiple legs share games, so the card carries more correlation and slate-specific risk."
        }

        return ParlayEvaluation(
            rating = rating,
            label = label,
            averageLegScore = average.roundToInt(),
            weakestLegScore = weakest.roundToInt(),
            uniqueGames = uniqueGames,
            note = note
        )
    }

}
