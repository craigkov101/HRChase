package com.ckz.hrchase.model

import com.ckz.hrchase.data.BattedBall
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class HrScoringModelTest {
    private val model = HrScoringModel()

    @Test
    fun eliteNearHrDetectsBohmStyleContact() {
        val ball = BattedBall(
            gamePk = 1,
            gameDate = LocalDate.of(2026, 8, 20),
            batterId = 1,
            pitcherId = 2,
            batterName = "Test Hitter",
            pitcherName = "Test Pitcher",
            exitVelocity = 106.4,
            launchAngle = 29.0,
            distanceFt = 397.0,
            eventType = "field_out",
            isHomeRun = false,
            isOut = true
        )
        assertTrue(model.isNearHomeRun(ball))
        assertTrue(model.isEliteNearHomeRun(ball))
    }

    @Test
    fun actualHomeRunIsNotNearHr() {
        val ball = BattedBall(
            gamePk = 1,
            gameDate = LocalDate.of(2026, 8, 20),
            batterId = 1,
            pitcherId = 2,
            batterName = "Test Hitter",
            pitcherName = "Test Pitcher",
            exitVelocity = 108.0,
            launchAngle = 28.0,
            distanceFt = 420.0,
            eventType = "home_run",
            isHomeRun = true,
            isOut = false
        )
        assertFalse(model.isNearHomeRun(ball))
    }
}
