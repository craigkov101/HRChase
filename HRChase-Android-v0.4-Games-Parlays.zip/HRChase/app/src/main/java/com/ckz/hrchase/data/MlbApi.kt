package com.ckz.hrchase.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

class MlbApi {
    private val base = "https://statsapi.mlb.com"

    suspend fun fetchSchedule(date: LocalDate): List<GameInfo> {
        val url = "$base/api/v1/schedule?sportId=1&date=$date&hydrate=probablePitcher,team,linescore"
        val root = JSONObject(get(url))
        val dates = root.optJSONArray("dates") ?: return emptyList()
        if (dates.length() == 0) return emptyList()
        val games = dates.optJSONObject(0)?.optJSONArray("games") ?: return emptyList()
        return buildList {
            for (i in 0 until games.length()) {
                val g = games.optJSONObject(i) ?: continue
                val teams = g.optJSONObject("teams") ?: continue
                val awayObj = teams.optJSONObject("away") ?: continue
                val homeObj = teams.optJSONObject("home") ?: continue
                val awayTeamObj = awayObj.optJSONObject("team") ?: continue
                val homeTeamObj = homeObj.optJSONObject("team") ?: continue
                val statusObj = g.optJSONObject("status")
                val venueObj = g.optJSONObject("venue")

                add(
                    GameInfo(
                        gamePk = g.optLong("gamePk"),
                        gameDate = parseInstant(g.optString("gameDate")),
                        status = statusObj?.optString("abstractGameState") ?: "Preview",
                        detailedStatus = statusObj?.optString("detailedState") ?: "Scheduled",
                        awayTeam = parseTeam(awayTeamObj),
                        homeTeam = parseTeam(homeTeamObj),
                        venueName = venueObj?.optString("name") ?: "Unknown park",
                        awayProbablePitcher = awayObj.optJSONObject("probablePitcher")?.let(::parsePerson),
                        homeProbablePitcher = homeObj.optJSONObject("probablePitcher")?.let(::parsePerson)
                    )
                )
            }
        }
    }

    suspend fun fetchScheduleRange(startDate: LocalDate, endDate: LocalDate): List<GameInfo> {
        val url = "$base/api/v1/schedule?sportId=1&startDate=$startDate&endDate=$endDate&gameType=R&hydrate=probablePitcher,team"
        val root = JSONObject(get(url))
        val dates = root.optJSONArray("dates") ?: return emptyList()
        return buildList {
            for (d in 0 until dates.length()) {
                val dateObj = dates.optJSONObject(d) ?: continue
                val games = dateObj.optJSONArray("games") ?: continue
                for (i in 0 until games.length()) {
                    val g = games.optJSONObject(i) ?: continue
                    val teams = g.optJSONObject("teams") ?: continue
                    val awayObj = teams.optJSONObject("away") ?: continue
                    val homeObj = teams.optJSONObject("home") ?: continue
                    val awayTeamObj = awayObj.optJSONObject("team") ?: continue
                    val homeTeamObj = homeObj.optJSONObject("team") ?: continue
                    val statusObj = g.optJSONObject("status")
                    val venueObj = g.optJSONObject("venue")
                    add(
                        GameInfo(
                            gamePk = g.optLong("gamePk"),
                            gameDate = parseInstant(g.optString("gameDate")),
                            status = statusObj?.optString("abstractGameState") ?: "Preview",
                            detailedStatus = statusObj?.optString("detailedState") ?: "Scheduled",
                            awayTeam = parseTeam(awayTeamObj),
                            homeTeam = parseTeam(homeTeamObj),
                            venueName = venueObj?.optString("name") ?: "Unknown park",
                            awayProbablePitcher = awayObj.optJSONObject("probablePitcher")?.let(::parsePerson),
                            homeProbablePitcher = homeObj.optJSONObject("probablePitcher")?.let(::parsePerson)
                        )
                    )
                }
            }
        }
    }

    suspend fun fetchGameFeed(gamePk: Long): GameFeedSnapshot {
        val root = JSONObject(get("$base/api/v1.1/game/$gamePk/feed/live"))
        val officialDate = root.optJSONObject("gameData")
            ?.optJSONObject("datetime")
            ?.optString("officialDate")
            ?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            ?: Instant.now().atZone(ZoneOffset.UTC).toLocalDate()

        return GameFeedSnapshot(
            gamePk = gamePk,
            officialDate = officialDate,
            root = root,
            awayLineupIds = extractBattingOrder(root, "away"),
            homeLineupIds = extractBattingOrder(root, "home"),
            battedBalls = extractBattedBalls(root, gamePk, officialDate),
            weather = extractWeather(root)
        )
    }

    suspend fun fetchPitchingStats(playerId: Int, season: Int): PitchingStats {
        val url = "$base/api/v1/people/$playerId/stats?stats=season&group=pitching&season=$season"
        return runCatching {
            val root = JSONObject(get(url))
            val stats = root.optJSONArray("stats")?.optJSONObject(0)
                ?.optJSONArray("splits")?.optJSONObject(0)
                ?.optJSONObject("stat")
            parsePitchingStats(stats)
        }.getOrDefault(PitchingStats())
    }

    fun extractTeamLineup(
        snapshot: GameFeedSnapshot,
        side: String,
        team: TeamRef,
        forceProjected: Boolean = false
    ): TeamLineup {
        val ids = if (side == "away") snapshot.awayLineupIds else snapshot.homeLineupIds
        if (ids.isEmpty()) return TeamLineup(team, emptyList(), official = false)

        val boxTeam = snapshot.root.optJSONObject("liveData")
            ?.optJSONObject("boxscore")
            ?.optJSONObject("teams")
            ?.optJSONObject(side)
        val playersObj = boxTeam?.optJSONObject("players")

        val players = ids.mapIndexedNotNull { index, id ->
            val person = extractPerson(snapshot.root, id) ?: run {
                val pObj = playersObj?.optJSONObject("ID$id")?.optJSONObject("person")
                pObj?.let(::parsePerson)
            } ?: return@mapIndexedNotNull null

            val pBox = playersObj?.optJSONObject("ID$id")
            val battingStats = parseHittingStats(
                pBox?.optJSONObject("seasonStats")?.optJSONObject("batting")
            )
            LineupPlayer(
                person = person,
                battingOrder = index + 1,
                seasonStats = battingStats,
                official = !forceProjected,
                sourceGamePk = snapshot.gamePk
            )
        }
        return TeamLineup(team, players, official = !forceProjected)
    }

    fun extractPerson(root: JSONObject, id: Int): PersonRef? {
        val p = root.optJSONObject("gameData")
            ?.optJSONObject("players")
            ?.optJSONObject("ID$id") ?: return null
        return PersonRef(
            id = id,
            name = p.optString("fullName", p.optString("nameFirstLast", "Player $id")),
            batSide = p.optJSONObject("batSide")?.optString("code")?.takeIf { it.isNotBlank() },
            pitchHand = p.optJSONObject("pitchHand")?.optString("code")?.takeIf { it.isNotBlank() }
        )
    }

    fun extractPitchingStatsFromFeed(root: JSONObject, playerId: Int): PitchingStats? {
        val teams = root.optJSONObject("liveData")?.optJSONObject("boxscore")?.optJSONObject("teams") ?: return null
        for (side in listOf("away", "home")) {
            val stats = teams.optJSONObject(side)
                ?.optJSONObject("players")
                ?.optJSONObject("ID$playerId")
                ?.optJSONObject("seasonStats")
                ?.optJSONObject("pitching")
            if (stats != null) return parsePitchingStats(stats)
        }
        return null
    }

    private fun extractBattingOrder(root: JSONObject, side: String): List<Int> {
        val teamObj = root.optJSONObject("liveData")
            ?.optJSONObject("boxscore")
            ?.optJSONObject("teams")
            ?.optJSONObject(side) ?: return emptyList()

        val direct = teamObj.optJSONArray("battingOrder")?.ints().orEmpty()
        if (direct.isNotEmpty()) return direct

        val players = teamObj.optJSONObject("players") ?: return emptyList()
        val ordered = mutableListOf<Pair<Int, Int>>()
        val keys = players.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val player = players.optJSONObject(key) ?: continue
            val personId = player.optJSONObject("person")?.optInt("id") ?: continue
            val orderRaw = when (val raw = player.opt("battingOrder")) {
                is Number -> raw.toInt()
                is String -> raw.toIntOrNull()
                else -> null
            } ?: continue
            if (orderRaw > 0) ordered += orderRaw to personId
        }
        return ordered.sortedBy { it.first }.map { it.second }.distinct().take(9)
    }

    private fun extractWeather(root: JSONObject): WeatherInfo {
        val gameData = root.optJSONObject("gameData")
        val weather = gameData?.optJSONObject("weather")
        val roof = gameData?.optJSONObject("venue")
            ?.optJSONObject("fieldInfo")
            ?.optString("roofType")
            ?.takeIf { it.isNotBlank() }
        return WeatherInfo(
            temperatureF = weather?.optIntOrNull("temp"),
            wind = weather?.optString("wind")?.takeIf { it.isNotBlank() },
            condition = weather?.optString("condition")?.takeIf { it.isNotBlank() },
            roofType = roof
        )
    }

    private fun extractBattedBalls(root: JSONObject, gamePk: Long, gameDate: LocalDate): List<BattedBall> {
        val plays = root.optJSONObject("liveData")?.optJSONObject("plays")?.optJSONArray("allPlays") ?: return emptyList()
        return buildList {
            for (i in 0 until plays.length()) {
                val play = plays.optJSONObject(i) ?: continue
                val matchup = play.optJSONObject("matchup") ?: continue
                val batterObj = matchup.optJSONObject("batter") ?: continue
                val pitcherObj = matchup.optJSONObject("pitcher") ?: continue
                val batterId = batterObj.optInt("id")
                val pitcherId = pitcherObj.optInt("id")
                if (batterId == 0 || pitcherId == 0) continue
                val result = play.optJSONObject("result")
                val primaryEvent = result?.optString("eventType").orEmpty()
                val fallbackEvent = result?.optString("event").orEmpty()
                val eventType = primaryEvent.ifBlank { fallbackEvent }.ifBlank { "unknown" }
                val description = result?.optString("description")?.takeIf { it.isNotBlank() }
                val events = play.optJSONArray("playEvents") ?: continue
                var chosen: JSONObject? = null
                for (e in 0 until events.length()) {
                    val event = events.optJSONObject(e) ?: continue
                    if (event.optJSONObject("hitData") != null) chosen = event
                }
                val hitData = chosen?.optJSONObject("hitData") ?: continue
                val isHr = eventType.equals("home_run", true) || eventType.equals("Home Run", true)
                add(
                    BattedBall(
                        gamePk = gamePk,
                        gameDate = gameDate,
                        batterId = batterId,
                        pitcherId = pitcherId,
                        batterName = batterObj.optString("fullName", "Player $batterId"),
                        pitcherName = pitcherObj.optString("fullName", "Pitcher $pitcherId"),
                        exitVelocity = hitData.optDoubleOrNull("launchSpeed"),
                        launchAngle = hitData.optDoubleOrNull("launchAngle"),
                        distanceFt = hitData.optDoubleOrNull("totalDistance"),
                        eventType = eventType,
                        isHomeRun = isHr,
                        isOut = isOutEvent(eventType),
                        description = description
                    )
                )
            }
        }
    }

    private fun parseTeam(obj: JSONObject): TeamRef {
        val id = obj.optInt("id")
        val name = obj.optString("name", "Unknown Team")
        val abbreviation = obj.optString("abbreviation").takeIf { it.isNotBlank() }
            ?: teamAbbreviation(id)
            ?: obj.optString("teamCode").takeIf { it.isNotBlank() }?.uppercase()
            ?: name.take(3).uppercase()
        return TeamRef(id = id, name = name, abbreviation = abbreviation)
    }

    private fun teamAbbreviation(id: Int): String? = when (id) {
        108 -> "LAA"
        109 -> "ARI"
        110 -> "BAL"
        111 -> "BOS"
        112 -> "CHC"
        113 -> "CIN"
        114 -> "CLE"
        115 -> "COL"
        116 -> "DET"
        117 -> "HOU"
        118 -> "KC"
        119 -> "LAD"
        120 -> "WSH"
        121 -> "NYM"
        133 -> "ATH"
        134 -> "PIT"
        135 -> "SD"
        136 -> "SEA"
        137 -> "SF"
        138 -> "STL"
        139 -> "TB"
        140 -> "TEX"
        141 -> "TOR"
        142 -> "MIN"
        143 -> "PHI"
        144 -> "ATL"
        145 -> "CWS"
        146 -> "MIA"
        147 -> "NYY"
        158 -> "MIL"
        else -> null
    }

    private fun parsePerson(obj: JSONObject): PersonRef = PersonRef(
        id = obj.optInt("id"),
        name = obj.optString("fullName", "Unknown")
    )

    private fun parseHittingStats(obj: JSONObject?): HittingStats {
        if (obj == null) return HittingStats()
        return HittingStats(
            atBats = obj.optIntOrNull("atBats") ?: 0,
            plateAppearances = obj.optIntOrNull("plateAppearances") ?: 0,
            hits = obj.optIntOrNull("hits") ?: 0,
            doubles = obj.optIntOrNull("doubles") ?: 0,
            triples = obj.optIntOrNull("triples") ?: 0,
            homeRuns = obj.optIntOrNull("homeRuns") ?: 0,
            avg = obj.optDoubleOrNull("avg"),
            slg = obj.optDoubleOrNull("slg"),
            ops = obj.optDoubleOrNull("ops")
        )
    }

    private fun parsePitchingStats(obj: JSONObject?): PitchingStats {
        if (obj == null) return PitchingStats()
        return PitchingStats(
            inningsPitched = parseBaseballInnings(obj.optString("inningsPitched", "0")),
            homeRunsAllowed = obj.optIntOrNull("homeRuns") ?: 0,
            era = obj.optDoubleOrNull("era"),
            whip = obj.optDoubleOrNull("whip")
        )
    }

    private fun parseBaseballInnings(raw: String): Double {
        val parts = raw.split('.')
        val full = parts.getOrNull(0)?.toIntOrNull() ?: 0
        val outs = parts.getOrNull(1)?.firstOrNull()?.digitToIntOrNull()?.coerceIn(0, 2) ?: 0
        return full + outs / 3.0
    }

    private fun isOutEvent(event: String): Boolean {
        val e = event.lowercase()
        return e.contains("out") || e.contains("double_play") || e.contains("sac_fly") || e.contains("sac_bunt")
    }

    private fun parseInstant(raw: String): Instant = runCatching { Instant.parse(raw) }.getOrElse { Instant.now() }

    private suspend fun get(url: String): String = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 12_000
            conn.readTimeout = 20_000
            conn.requestMethod = "GET"
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("User-Agent", "HRChase/0.1 Android")
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = BufferedReader(InputStreamReader(stream, StandardCharsets.UTF_8)).use { it.readText() }
            if (code !in 200..299) error("MLB API HTTP $code: ${body.take(180)}")
            body
        } finally {
            conn?.disconnect()
        }
    }
}

data class GameFeedSnapshot(
    val gamePk: Long,
    val officialDate: LocalDate,
    val root: JSONObject,
    val awayLineupIds: List<Int>,
    val homeLineupIds: List<Int>,
    val battedBalls: List<BattedBall>,
    val weather: WeatherInfo
)
