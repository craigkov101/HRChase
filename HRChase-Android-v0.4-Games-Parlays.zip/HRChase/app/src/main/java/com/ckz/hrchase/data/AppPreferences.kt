package com.ckz.hrchase.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate

class AppPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("hr_chase_prefs", Context.MODE_PRIVATE)

    fun loadWeights(): ScoreWeights = ScoreWeights(
        recentPower = prefs.getFloat("w_recent", 25f),
        powerPressure = prefs.getFloat("w_pressure", 20f),
        pitcherMatchup = prefs.getFloat("w_matchup", 25f),
        environment = prefs.getFloat("w_environment", 10f),
        seasonPower = prefs.getFloat("w_season", 15f),
        lineup = prefs.getFloat("w_lineup", 5f)
    )

    fun saveWeights(w: ScoreWeights) {
        prefs.edit()
            .putFloat("w_recent", w.recentPower)
            .putFloat("w_pressure", w.powerPressure)
            .putFloat("w_matchup", w.pitcherMatchup)
            .putFloat("w_environment", w.environment)
            .putFloat("w_season", w.seasonPower)
            .putFloat("w_lineup", w.lineup)
            .apply()
    }

    fun loadTracked(): List<TrackedPick> {
        val raw = prefs.getString("tracked", null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val o = array.optJSONObject(i) ?: continue
                    add(
                        TrackedPick(
                            playerId = o.optInt("playerId"),
                            playerName = o.optString("playerName"),
                            teamName = o.optString("teamName"),
                            date = LocalDate.parse(o.optString("date")),
                            scoreAtTrack = o.optDouble("scoreAtTrack"),
                            trackedAt = Instant.parse(o.optString("trackedAt"))
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun saveTracked(picks: List<TrackedPick>) {
        val array = JSONArray()
        picks.forEach { p ->
            array.put(
                JSONObject()
                    .put("playerId", p.playerId)
                    .put("playerName", p.playerName)
                    .put("teamName", p.teamName)
                    .put("date", p.date.toString())
                    .put("scoreAtTrack", p.scoreAtTrack)
                    .put("trackedAt", p.trackedAt.toString())
            )
        }
        prefs.edit().putString("tracked", array.toString()).apply()
    }
}
