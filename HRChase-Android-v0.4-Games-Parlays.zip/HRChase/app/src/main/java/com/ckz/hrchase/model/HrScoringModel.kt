package com.ckz.hrchase.model

import com.ckz.hrchase.data.BattedBall
import com.ckz.hrchase.data.GameInfo
import com.ckz.hrchase.data.HittingStats
import com.ckz.hrchase.data.PersonRef
import com.ckz.hrchase.data.PitcherProfile
import com.ckz.hrchase.data.ScoreBreakdown
import com.ckz.hrchase.data.ScoreWeights
import kotlin.math.max
import kotlin.math.min

class HrScoringModel {
    fun score(
        player: PersonRef,
        battingOrder: Int,
        lineupOfficial: Boolean,
        seasonStats: HittingStats,
        recentBattedBalls: List<BattedBall>,
        opponentPitcher: PitcherProfile?,
        game: GameInfo,
        weights: ScoreWeights
    ): ScoreBreakdown {
        val recentPower = recentPowerScore(recentBattedBalls)
        val pressure = powerPressureScore(recentBattedBalls)
        val matchup = pitcherMatchupScore(player, opponentPitcher)
        val environment = environmentScore(game)
        val seasonPower = seasonPowerScore(seasonStats)
        val lineup = lineupScore(battingOrder, lineupOfficial)

        val safeTotal = weights.total.takeIf { it > 0f } ?: 100f
        val total = (
            recentPower * weights.recentPower +
                pressure * weights.powerPressure +
                matchup * weights.pitcherMatchup +
                environment * weights.environment +
                seasonPower * weights.seasonPower +
                lineup * weights.lineup
            ) / safeTotal

        val tags = buildTags(recentBattedBalls, pressure, recentPower, matchup, environment, lineupOfficial)
        val notes = buildNotes(player, recentBattedBalls, opponentPitcher, game, battingOrder, lineupOfficial)

        return ScoreBreakdown(
            recentPower = recentPower,
            powerPressure = pressure,
            pitcherMatchup = matchup,
            environment = environment,
            seasonPower = seasonPower,
            lineup = lineup,
            total = total.coerceIn(0.0, 100.0),
            tags = tags,
            notes = notes
        )
    }

    fun isHardHit(ball: BattedBall): Boolean = (ball.exitVelocity ?: 0.0) >= 95.0

    fun isBarrelProxy(ball: BattedBall): Boolean {
        val ev = ball.exitVelocity ?: return false
        val la = ball.launchAngle ?: return false
        if (ev < 98.0) return false
        val mphOver = ev - 98.0
        val lower = max(8.0, 26.0 - mphOver * 1.5)
        val upper = min(50.0, 30.0 + mphOver)
        return la in lower..upper
    }

    fun isNearHomeRun(ball: BattedBall): Boolean {
        if (ball.isHomeRun) return false
        val ev = ball.exitVelocity ?: return false
        val la = ball.launchAngle ?: return false
        val dist = ball.distanceFt
        val direct = ev >= 100.0 && la in 20.0..36.0 && (dist == null || dist >= 350.0)
        val barrelish = isBarrelProxy(ball) && (dist == null || dist >= 340.0)
        return direct || barrelish
    }

    fun isEliteNearHomeRun(ball: BattedBall): Boolean {
        if (ball.isHomeRun) return false
        val ev = ball.exitVelocity ?: return false
        val la = ball.launchAngle ?: return false
        val dist = ball.distanceFt ?: 0.0
        return ev >= 105.0 && la in 20.0..35.0 && dist >= 370.0
    }

    private fun recentPowerScore(balls: List<BattedBall>): Double {
        val tracked = balls.filter { it.exitVelocity != null && it.launchAngle != null }
        if (tracked.isEmpty()) return 35.0
        val hardHitPct = tracked.count(::isHardHit).toDouble() / tracked.size
        val barrelPct = tracked.count(::isBarrelProxy).toDouble() / tracked.size
        val avgEv = tracked.mapNotNull { it.exitVelocity }.average()
        val maxEv = tracked.mapNotNull { it.exitVelocity }.maxOrNull() ?: 0.0
        val hrRate = tracked.count { it.isHomeRun }.toDouble() / tracked.size

        val hard = scale(hardHitPct, 0.20, 0.60)
        val barrels = scale(barrelPct, 0.02, 0.20)
        val avg = scale(avgEv, 84.0, 95.0)
        val max = scale(maxEv, 98.0, 114.0)
        val hr = scale(hrRate, 0.0, 0.16)
        return weighted(hard to .25, barrels to .25, avg to .20, max to .20, hr to .10)
    }

    private fun powerPressureScore(balls: List<BattedBall>): Double {
        val tracked = balls.filter { it.exitVelocity != null && it.launchAngle != null }
        if (tracked.isEmpty()) return 20.0
        val near = tracked.count(::isNearHomeRun)
        val elite = tracked.count(::isEliteNearHomeRun)
        val unrewardedBarrels = tracked.count { isBarrelProxy(it) && !it.isHomeRun }

        val mostRecentDate = tracked.maxOfOrNull { it.gameDate }
        val recentGameBalls = if (mostRecentDate != null) tracked.filter { it.gameDate == mostRecentDate } else emptyList()
        val recentGameSignal = when {
            recentGameBalls.any(::isEliteNearHomeRun) -> 100.0
            recentGameBalls.any(::isNearHomeRun) -> 85.0
            recentGameBalls.any { isBarrelProxy(it) && !it.isHomeRun } -> 70.0
            recentGameBalls.any(::isHardHit) -> 45.0
            else -> 20.0
        }

        val chronological = tracked.sortedWith(compareBy<BattedBall> { it.gameDate }.thenBy { it.gamePk })
        val lastFive = chronological.takeLast(5).mapNotNull { it.exitVelocity }
        val priorFive = chronological.dropLast(lastFive.size).takeLast(5).mapNotNull { it.exitVelocity }
        val evTrend = if (lastFive.isNotEmpty() && priorFive.isNotEmpty()) lastFive.average() - priorFive.average() else 0.0

        val nearScore = scale(near.toDouble(), 0.0, 2.0)
        val eliteScore = scale(elite.toDouble(), 0.0, 1.0)
        val unrewardedScore = scale(unrewardedBarrels.toDouble(), 0.0, 2.0)
        val trendScore = scale(evTrend, -4.0, 5.0)

        return weighted(
            recentGameSignal to .35,
            nearScore to .25,
            eliteScore to .15,
            unrewardedScore to .15,
            trendScore to .10
        )
    }

    private fun pitcherMatchupScore(player: PersonRef, pitcher: PitcherProfile?): Double {
        if (pitcher == null) return 45.0
        val stats = pitcher.seasonStats
        val recent = pitcher.recentBattedBallsAllowed.filter { it.exitVelocity != null && it.launchAngle != null }

        val hr9 = stats.hrPer9?.let { scale(it, 0.55, 1.85) } ?: 50.0
        val era = stats.era?.let { scale(it, 2.50, 6.00) } ?: 50.0
        val recentHard = if (recent.isNotEmpty()) {
            scale(recent.count(::isHardHit).toDouble() / recent.size, .28, .58)
        } else 50.0
        val recentBarrel = if (recent.isNotEmpty()) {
            scale(recent.count(::isBarrelProxy).toDouble() / recent.size, .04, .20)
        } else 50.0

        val batterSide = player.batSide
        val pitcherHand = pitcher.person.pitchHand
        val platoon = when {
            batterSide == "S" -> 65.0
            batterSide == null || pitcherHand == null -> 50.0
            batterSide != pitcherHand -> 70.0
            else -> 40.0
        }

        return weighted(hr9 to .35, era to .20, recentHard to .20, recentBarrel to .15, platoon to .10)
    }

    private fun environmentScore(game: GameInfo): Double {
        val park = parkScore(game.venueName)
        val weather = game.weather
        val roofClosed = weather.roofType?.contains("closed", true) == true ||
            weather.condition?.contains("dome", true) == true
        val temp = if (roofClosed) 50.0 else weather.temperatureF?.let { scale(it.toDouble(), 55.0, 92.0) } ?: 50.0
        val wind = if (roofClosed) 50.0 else windScore(weather.wind)
        return weighted(park to .50, temp to .30, wind to .20)
    }

    private fun seasonPowerScore(stats: HittingStats): Double {
        if (stats.atBats <= 0) return 40.0
        val hrRate = stats.homeRuns.toDouble() / stats.atBats
        val hr = scale(hrRate, .015, .075)
        val slg = stats.slg?.let { scale(it, .330, .600) } ?: 45.0
        val ops = stats.ops?.let { scale(it, .620, 1.000) } ?: 45.0
        return weighted(hr to .50, slg to .30, ops to .20)
    }

    private fun lineupScore(order: Int, official: Boolean): Double {
        val base = when (order) {
            1, 2, 3, 4 -> 100.0
            5 -> 88.0
            6 -> 78.0
            7 -> 65.0
            8 -> 55.0
            9 -> 45.0
            else -> 50.0
        }
        return (base - if (official) 0.0 else 7.0).coerceAtLeast(0.0)
    }

    private fun buildTags(
        balls: List<BattedBall>,
        pressure: Double,
        recentPower: Double,
        matchup: Double,
        environment: Double,
        official: Boolean
    ): List<String> = buildList {
        val latestDate = balls.maxOfOrNull { it.gameDate }
        val latest = latestDate?.let { d -> balls.filter { it.gameDate == d } }.orEmpty()
        if (latest.any(::isEliteNearHomeRun)) add("NEAR-HR+")
        else if (latest.any(::isNearHomeRun)) add("NEAR-HR")
        if (pressure >= 75) add("POWER PRESSURE")
        if (recentPower >= 75) add("HOT CONTACT")
        if (matchup >= 75) add("PITCHER TARGET")
        if (environment >= 75) add("PARK/WEATHER")
        if (!official) add("PROJECTED LINEUP")
    }.distinct().take(4)

    private fun buildNotes(
        player: PersonRef,
        balls: List<BattedBall>,
        pitcher: PitcherProfile?,
        game: GameInfo,
        battingOrder: Int,
        official: Boolean
    ): List<String> = buildList {
        val tracked = balls.filter { it.exitVelocity != null }
        val hardest = tracked.maxByOrNull { it.exitVelocity ?: 0.0 }
        val near = tracked.filter(::isNearHomeRun)
        val barrels = tracked.count(::isBarrelProxy)
        val hardHits = tracked.count(::isHardHit)

        hardest?.let {
            val la = it.launchAngle?.let { a -> " / ${"%.0f".format(a)}°" } ?: ""
            val dist = it.distanceFt?.let { d -> " / ${"%.0f".format(d)} ft" } ?: ""
            add("Recent max EV ${"%.1f".format(it.exitVelocity)} mph$la$dist")
        }
        if (near.isNotEmpty()) add("${near.size} recent HR-quality near miss${if (near.size == 1) "" else "es"}")
        if (tracked.isNotEmpty()) add("$hardHits hard-hit balls and $barrels barrel-proxy contacts in ${tracked.size} tracked balls")
        pitcher?.let {
            val hr9 = it.seasonStats.hrPer9
            val era = it.seasonStats.era
            if (hr9 != null || era != null) {
                val bits = buildList {
                    hr9?.let { v -> add("${"%.2f".format(v)} HR/9") }
                    era?.let { v -> add("${"%.2f".format(v)} ERA") }
                }
                add("Faces ${it.person.name}: ${bits.joinToString(" • ")}")
            } else add("Faces ${it.person.name}")
        }
        val weatherText = listOfNotNull(
            game.weather.temperatureF?.let { "$it°F" },
            game.weather.wind,
            game.weather.condition
        ).joinToString(" • ")
        if (weatherText.isNotBlank()) add("${game.venueName}: $weatherText")
        add("Batting #$battingOrder${if (official) " (official lineup)" else " (projected from most recent lineup)"}")
    }

    private fun windScore(raw: String?): Double {
        if (raw.isNullOrBlank()) return 50.0
        val lower = raw.lowercase()
        val mph = Regex("(\\d+)\\s*mph").find(lower)?.groupValues?.getOrNull(1)?.toDoubleOrNull() ?: 0.0
        val direction = when {
            "out" in lower -> 70.0 + min(30.0, mph * 2.0)
            "in" in lower -> 35.0 - min(25.0, mph * 1.5)
            else -> 50.0
        }
        return direction.coerceIn(0.0, 100.0)
    }

    private fun parkScore(venue: String): Double {
        val v = venue.lowercase()
        return when {
            "coors" in v -> 100.0
            "great american" in v -> 92.0
            "yankee" in v -> 88.0
            "citizens bank" in v -> 86.0
            "fenway" in v -> 80.0
            "camden" in v -> 77.0
            "sutter health" in v -> 75.0
            "globe life" in v -> 73.0
            "rogers centre" in v || "rogers center" in v -> 70.0
            "rate field" in v || "guaranteed rate" in v -> 69.0
            "dodger" in v -> 67.0
            "truist" in v -> 66.0
            "daikin" in v || "minute maid" in v -> 65.0
            "wrigley" in v -> 65.0
            "american family" in v -> 64.0
            "chase field" in v -> 63.0
            "angel stadium" in v -> 62.0
            "target field" in v -> 60.0
            "nationals park" in v -> 58.0
            "progressive" in v -> 58.0
            "busch" in v -> 56.0
            "citi field" in v -> 52.0
            "loanDepot".lowercase() in v -> 48.0
            "kauffman" in v -> 47.0
            "pnc park" in v -> 47.0
            "comerica" in v -> 45.0
            "petco" in v -> 42.0
            "t-mobile" in v -> 40.0
            "oracle" in v -> 38.0
            else -> 55.0
        }
    }

    private fun scale(value: Double, low: Double, high: Double): Double {
        if (high <= low) return 50.0
        return (((value - low) / (high - low)) * 100.0).coerceIn(0.0, 100.0)
    }

    private fun weighted(vararg values: Pair<Double, Double>): Double {
        val totalWeight = values.sumOf { it.second }
        if (totalWeight <= 0) return 0.0
        return values.sumOf { it.first * it.second } / totalWeight
    }
}
