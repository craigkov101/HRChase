package com.ckz.hrchase

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ckz.hrchase.data.AppPreferences
import com.ckz.hrchase.data.BoardData
import com.ckz.hrchase.data.HitterCandidate
import com.ckz.hrchase.data.Repository
import com.ckz.hrchase.data.ScoreWeights
import com.ckz.hrchase.data.TrackedPick
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import kotlin.math.absoluteValue

enum class SortMode { SCORE, ATTACK, POWER_PRESSURE, RECENT_POWER, MATCHUP }

data class AppUiState(
    val selectedDate: LocalDate = LocalDate.now(),
    val board: BoardData? = null,
    val isLoading: Boolean = false,
    val progress: String = "",
    val error: String? = null,
    val selectedPlayerId: Int? = null,
    val showRemainingOnly: Boolean = true,
    val officialLineupsOnly: Boolean = false,
    val sortMode: SortMode = SortMode.SCORE,
    val attackStrongOnly: Boolean = false,
    val weights: ScoreWeights = ScoreWeights(),
    val tracked: List<TrackedPick> = emptyList()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = AppPreferences(application)
    private val repository = Repository()
    private var refreshJob: Job? = null

    private val _state = MutableStateFlow(
        AppUiState(
            weights = prefs.loadWeights(),
            tracked = prefs.loadTracked()
        )
    )
    val state: StateFlow<AppUiState> = _state.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            val date = _state.value.selectedDate
            val weights = _state.value.weights
            mutate { it.copy(isLoading = true, error = null, progress = "Starting…") }
            runCatching {
                repository.loadBoard(date, weights) { message ->
                    mutate { s -> s.copy(progress = message) }
                }
            }.onSuccess { board ->
                mutate { it.copy(board = board, isLoading = false, progress = "Ready", error = null) }
            }.onFailure { error ->
                mutate {
                    it.copy(
                        isLoading = false,
                        progress = "",
                        error = error.message ?: error::class.java.simpleName
                    )
                }
            }
        }
    }

    fun changeDate(days: Long) {
        mutate { it.copy(selectedDate = it.selectedDate.plusDays(days), selectedPlayerId = null) }
        refresh()
    }

    fun setDate(date: LocalDate) {
        mutate { it.copy(selectedDate = date, selectedPlayerId = null) }
        refresh()
    }

    fun toggleRemainingOnly() = mutate { it.copy(showRemainingOnly = !it.showRemainingOnly) }
    fun toggleOfficialOnly() = mutate { it.copy(officialLineupsOnly = !it.officialLineupsOnly) }
    fun setSortMode(mode: SortMode) = mutate { it.copy(sortMode = mode) }
    fun toggleAttackStrongOnly() = mutate { it.copy(attackStrongOnly = !it.attackStrongOnly) }

    /**
     * The v0.3 combo signal. This remains available as a building block, but v0.4 presents it
     * inside a simpler game-first experience instead of exposing many competing sort modes.
     */
    fun attackScore(candidate: HitterCandidate): Double =
        candidate.score.powerPressure * 0.45 +
            candidate.score.pitcherMatchup * 0.45 +
            candidate.score.recentPower * 0.10

    /**
     * A single recommendation score used for game rankings and the parlay generator.
     * It deliberately emphasizes "pressure + matchup", then checks the overall model and
     * environment so a hot hitter in a terrible spot does not automatically rise to the top.
     */
    fun pickScore(candidate: HitterCandidate): Double =
        attackScore(candidate) * 0.55 +
            candidate.score.total * 0.30 +
            candidate.score.environment * 0.10 +
            candidate.score.lineup * 0.05

    fun selectPlayer(id: Int?) = mutate { it.copy(selectedPlayerId = id) }

    fun updateWeights(weights: ScoreWeights) {
        prefs.saveWeights(weights)
        mutate { s ->
            val rescored = s.board?.let { repository.rescore(it, weights) }
            s.copy(weights = weights, board = rescored)
        }
    }

    fun resetWeights() = updateWeights(ScoreWeights())

    fun toggleTracked(candidate: HitterCandidate) {
        val date = _state.value.selectedDate
        val existing = _state.value.tracked
        val keyMatch: (TrackedPick) -> Boolean = { it.playerId == candidate.player.id && it.date == date }
        val next = if (existing.any(keyMatch)) {
            existing.filterNot(keyMatch)
        } else {
            existing + TrackedPick(
                playerId = candidate.player.id,
                playerName = candidate.player.name,
                teamName = candidate.team.name,
                date = date,
                scoreAtTrack = candidate.score.total,
                trackedAt = Instant.now()
            )
        }
        prefs.saveTracked(next)
        mutate { it.copy(tracked = next) }
    }

    fun clearTrackedForSelectedDate() {
        val date = _state.value.selectedDate
        val next = _state.value.tracked.filterNot { it.date == date }
        prefs.saveTracked(next)
        mutate { it.copy(tracked = next) }
    }

    private fun mutate(block: (AppUiState) -> AppUiState) {
        _state.value = block(_state.value)
    }

    /** Base candidate set shared by Games and Parlays. */
    fun eligibleCandidates(state: AppUiState = _state.value): List<HitterCandidate> {
        val board = state.board ?: return emptyList()
        val nowDate = LocalDate.now()
        return board.candidates.asSequence()
            .filter { c ->
                if (!state.showRemainingOnly || board.date != nowDate) true
                else !c.game.status.equals("Final", true)
            }
            .filter { c -> !state.officialLineupsOnly || c.lineupOfficial }
            .toList()
    }

    fun visibleCandidates(state: AppUiState = _state.value): List<HitterCandidate> {
        return eligibleCandidates(state).asSequence()
            .filter { c ->
                state.sortMode != SortMode.ATTACK ||
                    !state.attackStrongOnly ||
                    (c.score.powerPressure >= 65.0 && c.score.pitcherMatchup >= 65.0)
            }
            .sortedWith(
                when (state.sortMode) {
                    SortMode.SCORE -> compareByDescending<HitterCandidate> { it.score.total }
                    SortMode.ATTACK -> compareByDescending<HitterCandidate> { attackScore(it) }
                        .thenByDescending { it.score.total }
                    SortMode.POWER_PRESSURE -> compareByDescending<HitterCandidate> { it.score.powerPressure }
                    SortMode.RECENT_POWER -> compareByDescending<HitterCandidate> { it.score.recentPower }
                    SortMode.MATCHUP -> compareByDescending<HitterCandidate> { it.score.pitcherMatchup }
                }
            )
            .toList()
    }

    fun topHittersForGame(
        gamePk: Long,
        limit: Int = 4,
        state: AppUiState = _state.value
    ): List<HitterCandidate> = eligibleCandidates(state)
        .filter { it.game.gamePk == gamePk }
        .sortedByDescending(::pickScore)
        .take(limit)

    /**
     * Generates a quality-first parlay while avoiding needless correlation. The generator tries
     * to use one hitter per game and one hitter per team before it repeats either. `variant` adds
     * a small deterministic shuffle inside the strongest part of the board so Generate Again can
     * produce a different slip without turning into a random long-shot picker.
     */
    fun generateParlay(
        legs: Int,
        variant: Int = 0,
        state: AppUiState = _state.value
    ): List<HitterCandidate> {
        val targetLegs = legs.coerceIn(1, 5)
        val base = eligibleCandidates(state)
            .filter { it.score.total >= 42.0 }
            .sortedByDescending(::pickScore)
            .take(36)

        if (base.isEmpty()) return emptyList()
        if (targetLegs == 1) return listOf(base.maxBy(::pickScore))

        val chosen = mutableListOf<HitterCandidate>()
        val usedGames = mutableSetOf<Long>()
        val usedTeams = mutableSetOf<Int>()

        repeat(targetLegs) { slot ->
            val best = base.asSequence()
                .filter { candidate -> chosen.none { it.player.id == candidate.player.id } }
                .maxByOrNull { candidate ->
                    var adjusted = pickScore(candidate)

                    // Prefer independent games and teams in a multi-leg slip.
                    if (candidate.game.gamePk in usedGames) adjusted -= 16.0
                    if (candidate.team.id in usedTeams) adjusted -= 8.0

                    // Very poor weather/environment should not sneak into an otherwise strong slip.
                    if (candidate.score.environment < 35.0) adjusted -= 8.0

                    // Small stable variation, capped so the model remains quality-first.
                    val noiseKey = (candidate.player.id * 31 + variant * 97 + slot * 17).absoluteValue
                    val noise = ((noiseKey % 100) / 100.0 - 0.5) * 5.0
                    adjusted + noise
                } ?: return@repeat

            chosen += best
            usedGames += best.game.gamePk
            usedTeams += best.team.id
        }

        return chosen
    }
}
