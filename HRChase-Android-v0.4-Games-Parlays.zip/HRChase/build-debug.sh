#!/usr/bin/env sh
set -eu
./gradlew assembleDebug
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
