@echo off
setlocal
set VERSION=8.10.2
set CACHE=%USERPROFILE%\.gradle\hrchase-bootstrap
set GH=%CACHE%\gradle-%VERSION%
set ZIP=%CACHE%\gradle-%VERSION%-bin.zip
if not exist "%GH%\bin\gradle.bat" (
  if not exist "%CACHE%" mkdir "%CACHE%"
  if not exist "%ZIP%" (
    echo Downloading Gradle %VERSION%...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%ZIP%'"
    if errorlevel 1 exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%ZIP%' -DestinationPath '%CACHE%' -Force"
  if errorlevel 1 exit /b 1
)
call "%GH%\bin\gradle.bat" %*
endlocal
