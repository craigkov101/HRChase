# HR Chase v0.14.1 — Arsenal + Handedness Convergence

## Goal
Move the model away from treating pitch arsenal fit and handedness as two unrelated green metrics. The important signal is whether both line up at the same time, and whether that interaction has actually appeared disproportionately among home-run outcomes.

## Formula changes
- Pitch Arsenal Fit enters learned pattern analysis only when pitch-type confidence is credible. Legacy saved scores remain usable with a conservative confidence assumption.
- Pattern thresholds are now 68 for Arsenal Fit and 62 for Handedness Edge.
- The long-term learning engine explicitly retains Arsenal + Handedness pair/triple rules, even when the learned lift is neutral or negative. This makes the hypothesis testable instead of forcing a positive conclusion.
- Arsenal + Handedness rules receive a modest priority in Pattern Engine application, but Bayesian shrinkage and reliability still control the effect.
- A new Arsenal + Handedness Convergence score is limited by the weaker side, then shrunk by pitch-type and split sample confidence.
- A `PERFECT FIT` requires approximately: Arsenal >= 80, Handedness >= 70, Arsenal confidence >= 42%, and a combined convergence grade >= 82.
- Perfect/strong convergence only earns a Target Score bonus when season power and contact foundation are also credible. Matchup geometry cannot manufacture a slugger.
- The Matchup Edge parlay focus now centers on the combined convergence score instead of independently stacking Arsenal Fit + Platoon.

## Common-denominator learning
- Last Night Learning now calculates 2-signal and 3-signal combinations, not only single metrics.
- Combination strength uses HR-hitter coverage, HR-rate lift vs the same slate, and sample reliability.
- Arsenal + Handedness combinations are visually flagged as `A+H` when they were actually shared by HR hitters.
- Last-night pattern matching now gives combination matches their own portion of the next-day echo score.

## UI
- Targets can show a `PERFECT FIT` badge.
- A dedicated `PERFECT ARSENAL + HAND FITS` panel appears when qualifying hitters exist.
- Target cards show the combined A+H score and learned historical lift when enough data exists.
- Player Profiles include a full Arsenal + Handedness Convergence section.
- Pattern Engine displays the historical Arsenal + Handedness pair result directly.

## Guardrails
A high arsenal score alone is not considered perfect. A high handedness split alone is not considered perfect. Missing arsenal data is not replaced with a fake 50. The interaction is confidence-shrunk and still depends on a real power/contact foundation.
