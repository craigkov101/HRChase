# HR Chase v0.14.0 — Pattern Engine v2

This release changes the daily ranking philosophy from an additive metric stack to a pattern-first model.

## Why the redesign
The old Target Score could reward a player because several correlated metrics were all high at once, even when the combination itself had not demonstrated useful HR lift. It also froze the first daily learning snapshot too early, which could preserve projected lineups, TBD pitchers, or missing arsenal data as if they were the final pregame state.

## Pattern Engine v2
- Learns **pair and triple signal combinations** from saved pregame hitter profiles and actual HR outcomes.
- Signals currently eligible for learned combinations: season power, contact quality, recent power, power pressure, pitcher matchup, pitch-arsenal fit, handedness edge, and environment.
- Every learned rule is **Bayesian-shrunk toward the slate baseline HR rate**.
- Rule influence is reliability-weighted by both sample size and HR outcomes.
- Small samples cannot create large ranking swings.
- Positive and negative learned conjunctions can both affect the Pattern score.

## Structural pattern archetypes
Before the historical sample is mature, the engine still recognizes transparent multi-signal archetypes:
- established power + contact quality + matchup,
- recent power + pressure + contact support,
- arsenal fit + pitcher matchup,
- platoon edge + matchup + power floor.

It also recognizes anti-patterns such as a huge recent-pressure score with weak season power and weak contact support.

## New Target Score
The daily Target Score is now organized into four layers:
1. **Foundation (50%)** — season power, contact profile, pitcher matchup, platoon context, discipline, and pitch mix.
2. **Pattern Engine (28%)** — multi-signal convergence plus learned historical combinations.
3. **Tonight Trigger (15%)** — recent power/pressure/discipline with sample-size regression.
4. **Context (7%)** — park/weather and lineup opportunity.

BvP, Last Night Pattern Transfer, and Live Day Echo remain small tie-breakers rather than primary drivers.

## Cleaner outcome learning
- Today's snapshot is no longer permanently frozen at the first morning refresh.
- Pregame rows keep improving as official lineups, probable pitchers, and arsenal data arrive.
- Each player's row freezes once that player's game starts, preventing result leakage.
- Up to three older unresolved saved dates can be backfilled from completed MLB game feeds on refresh, so learning does not require opening the app every single day.

## UI
The Targets tab now shows:
- Pattern Engine sample size and HR outcome count,
- the strongest learned positive combinations when enough data exists,
- a PATTERN score on every target card,
- a plain-English explanation of the strongest pattern match.

## Important interpretation
Pattern lift is not a guaranteed home-run probability. It is a shrunk historical association in HR Chase's own saved pregame sample. The model deliberately increases its reliance on learned patterns only as the sample becomes larger and more stable.

## Recommendation honesty
- The top three are no longer automatically labeled ELITE.
- A target receives the **CORE** badge only when its absolute Target score, Pattern score, and power-profile floor are all strong.
- Weak slates are allowed to have zero CORE plays.
