package com.ckz.hrchase.model

import com.ckz.hrchase.data.DailySignalSnapshot
import com.ckz.hrchase.data.HitterSignalSnapshot
import java.time.Instant
import java.time.LocalDate
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PatternLearningEngineTest {
    @Test
    fun arsenalAndHandednessPairLearnsPositiveLiftWhenOutcomesSupportIt() {
        val date = LocalDate.of(2026, 9, 1)
        val rows = (1..500).map { i ->
            val convergence = i <= 100
            val homer = if (convergence) i % 8 == 0 else i % 30 == 0
            HitterSignalSnapshot(
                date = date,
                playerId = i,
                recentPower = 55.0,
                powerPressure = 55.0,
                pitcherMatchup = 60.0,
                environment = 55.0,
                seasonPower = 65.0,
                platoon = if (convergence) 75.0 else 50.0,
                contactProfile = 62.0,
                pitchArsenalFit = if (convergence) 82.0 else 55.0,
                pitchArsenalConfidence = .70,
                outcomeHomeRun = homer
            )
        }
        val profile = PatternLearningEngine().build(
            listOf(DailySignalSnapshot(date, Instant.parse("2026-09-01T12:00:00Z"), rows))
        )
        val pair = profile.patterns.firstOrNull { it.key == "pitchArsenalFit+platoon" }
        assertNotNull(pair)
        assertTrue(pair!!.posteriorLift > 1.0)
    }

    @Test
    fun unreliableArsenalDataDoesNotBecomeAConvergenceRule() {
        val date = LocalDate.of(2026, 9, 1)
        val rows = (1..300).map { i ->
            HitterSignalSnapshot(
                date = date,
                playerId = i,
                recentPower = 55.0,
                powerPressure = 55.0,
                pitcherMatchup = 60.0,
                environment = 55.0,
                seasonPower = 65.0,
                platoon = 75.0,
                contactProfile = 62.0,
                pitchArsenalFit = 90.0,
                pitchArsenalConfidence = .10,
                outcomeHomeRun = i % 20 == 0
            )
        }
        val profile = PatternLearningEngine().build(
            listOf(DailySignalSnapshot(date, Instant.parse("2026-09-01T12:00:00Z"), rows))
        )
        assertTrue(profile.patterns.none { it.key.contains("pitchArsenalFit") })
    }
}
