package com.ckz.hrchase.data

import java.time.Instant
import java.time.LocalDate


data class TeamRef(
    val id: Int,
    val name: String,
    val abbreviation: String = name.take(3).uppercase()
)

data class PersonRef(
    val id: Int,
    val name: String,
    val batSide: String? = null,
    val pitchHand: String? = null
)

data class WeatherInfo(
    val temperatureF: Int? = null,
    val wind: String? = null,
    val condition: String? = null,
    val roofType: String? = null
)

data class GameInfo(
    val gamePk: Long,
    val gameDate: Instant,
    val status: String,
    val detailedStatus: String,
    val awayTeam: TeamRef,
    val homeTeam: TeamRef,
    val venueName: String,
    val awayProbablePitcher: PersonRef? = null,
    val homeProbablePitcher: PersonRef? = null,
    val weather: WeatherInfo = WeatherInfo()
)

data class HittingStats(
    val atBats: Int = 0,
    val plateAppearances: Int = 0,
    val hits: Int = 0,
    val doubles: Int = 0,
    val triples: Int = 0,
    val homeRuns: Int = 0,
    val walks: Int = 0,
    val strikeouts: Int = 0,
    val avg: Double? = null,
    val slg: Double? = null,
    val ops: Double? = null
)

data class HittingSplitStats(
    val atBats: Int = 0,
    val plateAppearances: Int = 0,
    val hits: Int = 0,
    val doubles: Int = 0,
    val triples: Int = 0,
    val homeRuns: Int = 0,
    val walks: Int = 0,
    val strikeouts: Int = 0,
    val avg: Double? = null,
    val obp: Double? = null,
    val slg: Double? = null,
    val ops: Double? = null
) {
    val iso: Double?
        get() = if (slg != null && avg != null) (slg - avg).coerceAtLeast(0.0) else null
    val hrPerPa: Double?
        get() = if (plateAppearances > 0) homeRuns.toDouble() / plateAppearances else null
    val strikeoutRate: Double?
        get() = if (plateAppearances > 0) strikeouts.toDouble() / plateAppearances else null
}



data class RecentHittingStats(
    val gamesPlayed: Int = 0,
    val atBats: Int = 0,
    val plateAppearances: Int = 0,
    val runs: Int = 0,
    val hits: Int = 0,
    val doubles: Int = 0,
    val triples: Int = 0,
    val homeRuns: Int = 0,
    val rbi: Int = 0,
    val walks: Int = 0,
    val strikeouts: Int = 0,
    val hitByPitch: Int = 0,
    val sacFlies: Int = 0,
    val avg: Double? = null,
    val obp: Double? = null,
    val slg: Double? = null,
    val ops: Double? = null
) {
    val extraBaseHits: Int get() = doubles + triples + homeRuns
    val iso: Double?
        get() = if (slg != null && avg != null) (slg - avg).coerceAtLeast(0.0) else null
    val hrPerPa: Double?
        get() = if (plateAppearances > 0) homeRuns.toDouble() / plateAppearances else null
    val strikeoutRate: Double?
        get() = if (plateAppearances > 0) strikeouts.toDouble() / plateAppearances else null
    val walkRate: Double?
        get() = if (plateAppearances > 0) walks.toDouble() / plateAppearances else null
}

data class BatterVsPitcherStats(
    val atBats: Int = 0,
    val plateAppearances: Int = 0,
    val hits: Int = 0,
    val doubles: Int = 0,
    val triples: Int = 0,
    val homeRuns: Int = 0,
    val walks: Int = 0,
    val strikeouts: Int = 0,
    val hitByPitch: Int = 0,
    val sacFlies: Int = 0,
    val avg: Double? = null,
    val obp: Double? = null,
    val slg: Double? = null,
    val ops: Double? = null
)

data class PitchingStats(
    val inningsPitched: Double = 0.0,
    val homeRunsAllowed: Int = 0,
    val strikeouts: Int = 0,
    val walks: Int = 0,
    val battersFaced: Int = 0,
    val era: Double? = null,
    val whip: Double? = null
) {
    val hrPer9: Double?
        get() = if (inningsPitched > 0.0) homeRunsAllowed * 9.0 / inningsPitched else null
    val strikeoutRate: Double?
        get() = if (battersFaced > 0) strikeouts.toDouble() / battersFaced else null
    val walkRate: Double?
        get() = if (battersFaced > 0) walks.toDouble() / battersFaced else null
}


data class PlateDisciplineSample(
    val totalPitches: Int = 0,
    val swings: Int = 0,
    val whiffs: Int = 0
) {
    val whiffRate: Double?
        get() = if (swings > 0) whiffs.toDouble() / swings else null
    val swingRate: Double?
        get() = if (totalPitches > 0) swings.toDouble() / totalPitches else null

    operator fun plus(other: PlateDisciplineSample): PlateDisciplineSample = PlateDisciplineSample(
        totalPitches = totalPitches + other.totalPitches,
        swings = swings + other.swings,
        whiffs = whiffs + other.whiffs
    )
}

data class BattedBall(
    val gamePk: Long,
    val gameDate: LocalDate,
    val batterId: Int,
    val pitcherId: Int,
    val batterName: String,
    val pitcherName: String,
    val batterSide: String? = null,
    val exitVelocity: Double?,
    val launchAngle: Double?,
    val distanceFt: Double?,
    val trajectory: String? = null,
    val fieldLocation: Int? = null,
    val sprayX: Double? = null,
    val sprayY: Double? = null,
    val eventType: String,
    val isHomeRun: Boolean,
    val isOut: Boolean,
    val description: String? = null,
    val pitchType: String? = null
)

data class MustHaveMetrics(
    val barrelPct: Double? = null,
    val pullBarrelPct: Double? = null,
    val pullAirPct: Double? = null,
    val hardHitPct: Double? = null,
    val avgDistanceFt: Double? = null,
    val avgExitVelocity: Double? = null,
    val iso: Double? = null,
    val flyBallPct: Double? = null,
    val pullPct: Double? = null,
    val blastPct: Double? = null,
    val sweetSpotPct: Double? = null,
    val maxExitVelocity: Double? = null,
    val battedBallCount: Int = 0,
    val directionalBattedBallCount: Int = 0,
    val score: Double = 50.0,
    val confidence: Double = 0.0
)

data class LineupPlayer(
    val person: PersonRef,
    val battingOrder: Int,
    val seasonStats: HittingStats,
    val official: Boolean,
    val sourceGamePk: Long
)

data class TeamLineup(
    val team: TeamRef,
    val players: List<LineupPlayer>,
    val official: Boolean
)



data class PitchTypeUsage(
    val code: String,
    val name: String,
    val count: Int,
    val share: Double = 0.0
)

data class PitchHrTendency(
    val code: String,
    val name: String,
    val homeRuns: Int,
    val share: Double,
    val opposingPitcherUsage: Double,
    val batterSlg: Double? = null,
    val batterXslg: Double? = null,
    val batterHardHitPct: Double? = null,
    val pitcherXslgAllowed: Double? = null
)

/** Per-pitch-type Statcast leaderboard row from Baseball Savant. */
data class SavantPitchArsenalRow(
    val playerId: Int,
    val code: String,
    val name: String,
    val pitches: Int,
    val usagePct: Double? = null,
    val plateAppearances: Int = 0,
    val slg: Double? = null,
    val xslg: Double? = null,
    val woba: Double? = null,
    val xwoba: Double? = null,
    val hardHitPct: Double? = null
)

data class PitchArsenalMatch(
    val score: Double = 50.0,
    val confidence: Double = 0.0,
    val batterHrSample: Int = 0,
    val batterPitchSample: Int = 0,
    val pitcherPitchSample: Int = 0,
    val feastPitches: List<PitchHrTendency> = emptyList(),
    val pitcherArsenal: List<PitchTypeUsage> = emptyList(),
    val source: String = "MLB Statcast"
)
data class PitcherProfile(
    val person: PersonRef,
    val seasonStats: PitchingStats,
    val recentBattedBallsAllowed: List<BattedBall>,
    val seasonPitchArsenal: List<PitchTypeUsage> = emptyList()
)

data class ScoreWeights(
    val recentPower: Float = 20f,
    val powerPressure: Float = 15f,
    val pitcherMatchup: Float = 28f,
    val environment: Float = 8f,
    val seasonPower: Float = 24f,
    val lineup: Float = 5f
) {
    val total: Float get() = recentPower + powerPressure + pitcherMatchup + environment + seasonPower + lineup
}

data class ScoreBreakdown(
    val recentPower: Double,
    val powerPressure: Double,
    val pitcherMatchup: Double,
    val environment: Double,
    val seasonPower: Double,
    val lineup: Double,
    val total: Double,
    val tags: List<String>,
    val notes: List<String>,
    val platoon: Double = 50.0
)

data class HitterCandidate(
    val player: PersonRef,
    val team: TeamRef,
    val opponent: TeamRef,
    val game: GameInfo,
    val battingOrder: Int,
    val lineupOfficial: Boolean,
    val seasonStats: HittingStats,
    val opponentPitcher: PitcherProfile?,
    val recentBattedBalls: List<BattedBall>,
    val todayBattedBalls: List<BattedBall>,
    val recentPlateDiscipline: PlateDisciplineSample = PlateDisciplineSample(),
    val last3PlateDiscipline: PlateDisciplineSample = PlateDisciplineSample(),
    val score: ScoreBreakdown,
    val vsPitcherStats: BatterVsPitcherStats? = null,
    val platoonStats: HittingSplitStats? = null,
    val pitchArsenalMatch: PitchArsenalMatch? = null
)

data class BoardData(
    val date: LocalDate,
    val candidates: List<HitterCandidate>,
    val games: List<GameInfo>,
    val lastUpdated: Instant,
    val recentGameCount: Int,
    val recentWeekStats: Map<Int, RecentHittingStats> = emptyMap(),
    val recentThreeDayStats: Map<Int, RecentHittingStats> = emptyMap()
)

data class TrackedPick(
    val playerId: Int,
    val playerName: String,
    val teamName: String,
    val date: LocalDate,
    val scoreAtTrack: Double,
    val trackedAt: Instant
)

/** A concise postgame diagnosis for a target that was on the board. */
data class PostgameReview(
    val label: String,
    val explanation: String,
    val resultLine: String
)
