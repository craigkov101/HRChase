package com.ckz.hrchase

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ckz.hrchase.data.AppPreferences
import com.ckz.hrchase.data.BoardData
import com.ckz.hrchase.data.HitterCandidate
import com.ckz.hrchase.data.MustHaveMetrics
import com.ckz.hrchase.data.PostgameReview
import com.ckz.hrchase.data.RecentHittingStats
import com.ckz.hrchase.data.Repository
import com.ckz.hrchase.data.ScoreWeights
import com.ckz.hrchase.data.TrackedPick
import com.ckz.hrchase.model.HrScoringModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.LocalDate
import kotlin.math.absoluteValue
import kotlin.math.roundToInt

enum class SortMode { SCORE, ATTACK, POWER_PRESSURE, RECENT_POWER, MATCHUP }

data class AppUiState(
    val selectedDate: LocalDate = LocalDate.now(),
    val board: BoardData? = null,
    val isLoading: Boolean = false,
    val progress: String = "",
    val error: String? = null,
    val selectedPlayerId: Int? = null,
    val showRemainingOnly: Boolean = true,
    val officialLineupsOnly: Boolean = false,
    val sortMode: SortMode = SortMode.SCORE,
    val attackStrongOnly: Boolean = false,
    val weights: ScoreWeights = ScoreWeights(),
    val tracked: List<TrackedPick> = emptyList(),
    val trackedLast10: Map<Int, RecentHittingStats> = emptyMap(),
    val trackedLast10Loading: Set<Int> = emptySet(),
    val postgameStats: Map<Int, RecentHittingStats> = emptyMap(),
    val postgameStatsLoading: Set<Int> = emptySet()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = AppPreferences(application)
    private val repository = Repository()
    private val scoringModel = HrScoringModel()
    private val mustHaveCache = mutableMapOf<String, MustHaveMetrics>()
    private val heatingMetricsCache = mutableMapOf<String, MustHaveMetrics>()
    private val trackedLast10Cache = mutableMapOf<String, RecentHittingStats?>()
    private val postgameStatsCache = mutableMapOf<String, RecentHittingStats?>()
    private var refreshJob: Job? = null
    private var refreshGeneration: Long = 0L
    private val stateLock = Any()

    // Keep the most recently usable board for each nearby date. This makes date switching
    // instant and, more importantly, prevents a refresh from replacing a good board with an
    // empty schedule-only partial if a downstream MLB/Savant request fails.
    private val boardCache = object : LinkedHashMap<LocalDate, BoardData>(4, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<LocalDate, BoardData>?): Boolean = size > 4
    }

    private val _state = MutableStateFlow(
        AppUiState(
            weights = prefs.loadWeights(),
            tracked = prefs.loadTracked()
        )
    )
    val state: StateFlow<AppUiState> = _state.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        refreshJob?.cancel()
        val generation = ++refreshGeneration
        val snapshot = _state.value
        val date = snapshot.selectedDate
        val weights = snapshot.weights
        val cached = synchronized(boardCache) { boardCache[date] }

        // Stale-while-revalidate: immediately restore a known-good board when the user jumps
        // between dates, then update it in place. This fixes the "switch back + refresh = no
        // players until restart" failure mode and makes navigation feel instant.
        mutate { current ->
            if (current.selectedDate != date) current
            else current.copy(
                board = cached ?: current.board?.takeIf { it.date == date },
                isLoading = true,
                error = null,
                progress = if (cached?.candidates?.isNotEmpty() == true) "Refreshing in background…" else "Starting…"
            )
        }

        refreshJob = viewModelScope.launch {
            try {
                val board = withContext(Dispatchers.Default) {
                    repository.loadBoard(
                        date = date,
                        weights = weights,
                        onProgress = { message ->
                            if (generation == refreshGeneration) {
                                mutate { s ->
                                    if (s.selectedDate == date) s.copy(progress = message) else s
                                }
                            }
                        },
                        onPartialBoard = { partial ->
                            if (generation != refreshGeneration) return@loadBoard
                            mutate { s ->
                                if (s.selectedDate != partial.date) return@mutate s
                                val existing = s.board?.takeIf { it.date == partial.date }
                                // Never let an early schedule-only partial erase a board that already
                                // has hitters. Preserve the candidates until fresher candidates arrive.
                                val safePartial = if (
                                    partial.candidates.isEmpty() && existing?.candidates?.isNotEmpty() == true
                                ) {
                                    partial.copy(
                                        candidates = existing.candidates,
                                        recentGameCount = maxOf(partial.recentGameCount, existing.recentGameCount),
                                        recentWeekStats = if (partial.recentWeekStats.isNotEmpty()) partial.recentWeekStats else existing.recentWeekStats,
                                        recentThreeDayStats = if (partial.recentThreeDayStats.isNotEmpty()) partial.recentThreeDayStats else existing.recentThreeDayStats
                                    )
                                } else partial
                                if (safePartial.candidates.isNotEmpty()) cacheBoard(safePartial)
                                s.copy(board = safePartial)
                            }
                        }
                    )
                }

                if (generation != refreshGeneration) return@launch
                mustHaveCache.clear()
                heatingMetricsCache.clear()
                mutate { current ->
                    if (current.selectedDate != date) current
                    else {
                        val existing = current.board?.takeIf { it.date == date && it.candidates.isNotEmpty() }
                            ?: synchronized(boardCache) { boardCache[date] }
                        val keepExistingPlayers = board.games.isNotEmpty() &&
                            board.candidates.isEmpty() && existing?.candidates?.isNotEmpty() == true
                        val safeBoard = if (keepExistingPlayers) {
                            board.copy(
                                candidates = existing!!.candidates,
                                recentGameCount = maxOf(board.recentGameCount, existing.recentGameCount),
                                recentWeekStats = if (board.recentWeekStats.isNotEmpty()) board.recentWeekStats else existing.recentWeekStats,
                                recentThreeDayStats = if (board.recentThreeDayStats.isNotEmpty()) board.recentThreeDayStats else existing.recentThreeDayStats
                            )
                        } else board
                        cacheBoard(safeBoard)
                        current.copy(
                            board = safeBoard,
                            isLoading = false,
                            progress = "Ready",
                            error = if (keepExistingPlayers) {
                                "The slate refreshed, but player enrichment was incomplete. Keeping the last loaded player board instead of going blank."
                            } else null
                        )
                    }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Throwable) {
                if (generation != refreshGeneration) return@launch
                mutate { current ->
                    if (current.selectedDate != date) current
                    else {
                        val usable = current.board?.takeIf { it.date == date && it.candidates.isNotEmpty() }
                            ?: synchronized(boardCache) { boardCache[date] }
                        current.copy(
                            board = usable ?: current.board?.takeIf { it.date == date },
                            isLoading = false,
                            progress = if (usable != null) "Showing saved data" else "",
                            error = if (usable != null) {
                                "Refresh failed, but your last loaded data is still available. Tap refresh to try again."
                            } else {
                                error.message ?: error::class.java.simpleName
                            }
                        )
                    }
                }
            }
        }
    }

    private fun cacheBoard(board: BoardData) {
        if (board.candidates.isEmpty()) return
        synchronized(boardCache) { boardCache[board.date] = board }
    }

    private fun switchToDate(next: LocalDate) {
        refreshJob?.cancel()
        ++refreshGeneration
        val cached = synchronized(boardCache) { boardCache[next] }
        mutate {
            it.copy(
                selectedDate = next,
                board = cached,
                isLoading = false,
                progress = if (cached != null) "Showing saved data" else "",
                error = null,
                selectedPlayerId = null,
                trackedLast10 = emptyMap(),
                trackedLast10Loading = emptySet(),
                postgameStats = emptyMap(),
                postgameStatsLoading = emptySet()
            )
        }
        refresh()
    }

    fun changeDate(days: Long) {
        val current = _state.value.selectedDate
        val minimum = LocalDate.now().minusDays(1)
        val requested = current.plusDays(days)
        val next = if (requested.isBefore(minimum)) minimum else requested
        if (next == current) return
        switchToDate(next)
    }

    fun setDate(date: LocalDate) {
        val minimum = LocalDate.now().minusDays(1)
        val next = if (date.isBefore(minimum)) minimum else date
        if (next == _state.value.selectedDate) return
        switchToDate(next)
    }

    fun toggleRemainingOnly() = mutate { it.copy(showRemainingOnly = !it.showRemainingOnly) }
    fun toggleOfficialOnly() = mutate { it.copy(officialLineupsOnly = !it.officialLineupsOnly) }
    fun setSortMode(mode: SortMode) = mutate { it.copy(sortMode = mode) }
    fun toggleAttackStrongOnly() = mutate { it.copy(attackStrongOnly = !it.attackStrongOnly) }

    /**
     * The v0.3 combo signal. This remains available as a building block, but v0.4 presents it
     * inside a simpler game-first experience instead of exposing many competing sort modes.
     */
    fun attackScore(candidate: HitterCandidate): Double =
        candidate.score.powerPressure * 0.45 +
            candidate.score.pitcherMatchup * 0.45 +
            candidate.score.recentPower * 0.10

    /**
     * A single recommendation score used for game rankings and the parlay generator.
     * It deliberately emphasizes "pressure + matchup", then checks the overall model and
     * environment so a hot hitter in a terrible spot does not automatically rise to the top.
     */
    /**
     * Sample-size-aware BvP adjustment. Strong history matters, but it is intentionally capped so
     * a 2-for-3 matchup cannot overpower current contact quality and the pitcher profile.
     */
    fun bvpAdjustment(candidate: HitterCandidate): Double {
        val bvp = candidate.vsPitcherStats ?: return 0.0
        val pa = bvp.plateAppearances
        if (pa < 5) return 0.0

        var raw = 0.0
        raw += when {
            (bvp.ops ?: 0.0) >= 1.050 -> 5.0
            (bvp.ops ?: 0.0) >= .900 -> 3.0
            (bvp.ops ?: 9.0) < .600 -> -2.0
            else -> 0.0
        }
        raw += when {
            bvp.homeRuns >= 3 -> 4.0
            bvp.homeRuns == 2 -> 3.0
            bvp.homeRuns == 1 -> 1.5
            else -> 0.0
        }
        raw += when {
            (bvp.avg ?: 0.0) >= .350 -> 1.5
            (bvp.avg ?: 0.0) >= .300 -> 0.75
            else -> 0.0
        }

        val reliability = when {
            pa >= 20 -> 1.0
            pa >= 12 -> .85
            pa >= 8 -> .70
            else -> .55
        }
        return (raw * reliability).coerceIn(-4.0, 8.0)
    }

    fun mustHaveMetrics(candidate: HitterCandidate): MustHaveMetrics {
        val key = "${candidate.game.gamePk}:${candidate.player.id}"
        return mustHaveCache.getOrPut(key) {
            scoringModel.mustHaveMetrics(candidate.player, candidate.seasonStats, candidate.recentBattedBalls)
        }
    }

    /**
     * Recent "must-have" power profile blended toward season power when the recent BBE sample is
     * small. This prevents one or two tracked balls from hijacking the daily ranking.
     */
    fun mustHavePowerScore(candidate: HitterCandidate): Double {
        val metrics = mustHaveMetrics(candidate)
        return metrics.score * metrics.confidence +
            candidate.score.seasonPower * (1.0 - metrics.confidence)
    }

    /**
     * Recent swing-and-miss score derived directly from MLB Gameday pitch descriptions.
     * Lower whiff rates are better. Small recent samples are blended back toward season K%.
     */
    fun swingMissScore(candidate: HitterCandidate): Double {
        val sample = candidate.recentPlateDiscipline
        val recent = sample.whiffRate?.let { rate -> inverseScale(rate, .14, .38) }
        val pa = candidate.seasonStats.plateAppearances
        val seasonK = if (pa > 0) candidate.seasonStats.strikeouts.toDouble() / pa else null
        val seasonContact = seasonK?.let { inverseScale(it, .14, .34) } ?: 50.0
        if (recent == null) return seasonContact
        val confidence = (sample.swings / 35.0).coerceIn(.20, 1.0)
        return recent * confidence + seasonContact * (1.0 - confidence)
    }

    fun recentWhiffRate(candidate: HitterCandidate): Double? = candidate.recentPlateDiscipline.whiffRate

    /**
     * Power Pressure now arrives from HrScoringModel already regressed for recent BBE sample size.
     * Keep this helper so ranking/UI code has one semantic place to consume the calibrated signal.
     */
    fun reliablePowerPressure(candidate: HitterCandidate): Double = candidate.score.powerPressure

    /**
     * How closely today's opposing pitcher arsenal matches the pitch types this hitter has
     * homered against this season. Missing/small samples blend back toward a neutral 50.
     */
    fun pitchArsenalFitScore(candidate: HitterCandidate): Double =
        candidate.pitchArsenalMatch?.score ?: 50.0

    /**
     * Count teammates at 10%+ recent barrel-proxy rate to create a modest lineup-power context score.
     */
    fun teamBarrelDepthScore(candidate: HitterCandidate, state: AppUiState = _state.value): Double {
        val teammates = state.board?.candidates.orEmpty().filter {
            it.game.gamePk == candidate.game.gamePk && it.team.id == candidate.team.id
        }
        if (teammates.isEmpty()) return 50.0
        val qualified = teammates.count { mate ->
            val m = mustHaveMetrics(mate)
            m.battedBallCount >= 3 && (m.barrelPct ?: 0.0) >= 10.0
        }
        return (35.0 + qualified * 11.0).coerceIn(25.0, 100.0)
    }

    /**
     * Independent HR Chase signal lens: hitter-first recent form, barrels/hard-contact/air-ball quality,
     * swing-and-miss, pitcher resistance, handedness and lineup-wide barrel depth.
     */
    fun signalLensScore(candidate: HitterCandidate, state: AppUiState = _state.value): Double {
        val profile = mustHavePowerScore(candidate)
        val seasonPower = candidate.score.seasonPower
        val pressure = reliablePowerPressure(candidate)
        val discipline = swingMissScore(candidate)
        val matchup = candidate.score.pitcherMatchup
        val platoon = candidate.score.platoon
        val depth = teamBarrelDepthScore(candidate, state)
        val environment = candidate.score.environment
        val arsenalFit = candidate.pitchArsenalMatch?.score

        val baseWithoutArsenal = profile * .22 +
            seasonPower * .13 +
            pressure * .13 +
            discipline * .08 +
            matchup * .16 +
            platoon * .07 +
            depth * .06 +
            environment * .05
        // Arsenal Fit v2 is now a real Statcast matchup input rather than an often-missing
        // enrichment, so it receives a meaningful 10% of this signal lens. Missing data still
        // redistributes the weight rather than fabricating a neutral observation.
        val raw = if (arsenalFit != null) baseWithoutArsenal + arsenalFit * .10
            else baseWithoutArsenal / .90
        return (raw + bvpAdjustment(candidate) * .40).coerceIn(0.0, 100.0)
    }

    fun signalTier(candidate: HitterCandidate): String = when {
        signalLensScore(candidate) >= 78.0 -> "TIER 1"
        signalLensScore(candidate) >= 68.0 -> "TIER 2"
        signalLensScore(candidate) >= 58.0 -> "TIER 3"
        else -> "WATCH"
    }

    fun signalReasons(candidate: HitterCandidate): List<String> {
        val metrics = mustHaveMetrics(candidate)
        return buildList {
            if ((metrics.barrelPct ?: 0.0) >= 12.0) add("BARREL FORM")
            if ((metrics.hardHitPct ?: 0.0) >= 48.0) add("HARD HIT")
            if ((metrics.flyBallPct ?: 0.0) >= 35.0) add("AIR BALL")
            recentWhiffRate(candidate)?.let { if (it <= .22 && candidate.recentPlateDiscipline.swings >= 10) add("LOW WHIFF") }
            if (reliablePowerPressure(candidate) >= 70.0) add("RECENT PRESSURE")
            if (candidate.score.pitcherMatchup >= 70.0) add("PITCHER EDGE")
            val arsenal = candidate.pitchArsenalMatch
            if (arsenal != null && arsenal.score >= 70.0 && arsenal.confidence >= .30) add("ARSENAL FIT")
            if (candidate.score.platoon >= 70.0) add("PLATOON EDGE")
            if (teamBarrelDepthScore(candidate) >= 68.0) add("LINEUP POWER")
        }.take(4)
    }

    /**
     * Calibrated Daily Target Score. The old version blended two composites that contained most of
     * the same inputs, accidentally double-counting recent form and matchup. This version uses one
     * transparent composite, then applies small convergence bonuses/penalties.
     *
     * Postmortem lesson from Aug. 24: small-sample recent contact was able to keep light-power bats
     * too high against strong starters, while established power needed more direct weight.
     */
    fun targetScore(candidate: HitterCandidate): Double {
        val metrics = mustHaveMetrics(candidate)
        val profile = mustHavePowerScore(candidate)
        val seasonPower = candidate.score.seasonPower
        val pressure = reliablePowerPressure(candidate)
        val matchup = candidate.score.pitcherMatchup
        val platoon = candidate.score.platoon
        val discipline = swingMissScore(candidate)
        val depth = teamBarrelDepthScore(candidate)
        val environment = candidate.score.environment
        val lineup = candidate.score.lineup
        val arsenal = candidate.pitchArsenalMatch

        val baseWithoutArsenal = profile * .22 +
            seasonPower * .15 +
            pressure * .11 +
            matchup * .14 +
            platoon * .07 +
            discipline * .06 +
            depth * .04 +
            environment * .05 +
            lineup * .04
        // Arsenal Fit is now 12% of the daily ranking when measured. The v2 score already
        // regresses small samples toward neutral, so this is meaningful without letting one
        // pitch-type split dominate the entire target board.
        var raw = if (arsenal != null) baseWithoutArsenal + arsenal.score * .12
            else baseWithoutArsenal / .88

        // Reward convergence instead of one giant signal. This is intentionally small so it cannot
        // manufacture a play; it only separates hitters with several independent green lights.
        val greenLights = listOfNotNull(
            seasonPower.takeIf { it >= 65.0 },
            profile.takeIf { it >= 65.0 },
            matchup.takeIf { it >= 62.0 },
            platoon.takeIf { it >= 62.0 },
            arsenal?.score?.takeIf { arsenal.confidence >= .35 && it >= 65.0 }
        ).size
        raw += when {
            greenLights >= 4 -> 3.0
            greenLights == 3 -> 1.5
            else -> 0.0
        }

        // High-confidence pitch-type mismatches should actually move the ranking. A hitter who
        // crushes the pitch mix this starter lives on gets a small bonus; a severe mismatch gets
        // a symmetric penalty. This happens after the 12% base weight and is intentionally capped.
        if (arsenal != null && arsenal.confidence >= .45) {
            raw += when {
                arsenal.score >= 78.0 -> 2.5
                arsenal.score >= 70.0 -> 1.0
                arsenal.score <= 34.0 -> -2.5
                arsenal.score <= 42.0 -> -1.0
                else -> 0.0
            }
        }

        // Strong-starter resistance: a weak season-power bat should not remain a top target merely
        // because 3-5 recent BBE looked hot. Established sluggers and well-supported recent profiles
        // are allowed to survive this penalty because elite hitters can beat good pitching.
        val supportedRecentBreakout = metrics.battedBallCount >= 8 && profile >= 68.0
        if (!supportedRecentBreakout) {
            raw -= when {
                matchup < 40.0 && seasonPower < 62.0 -> 7.0
                matchup < 47.0 && seasonPower < 55.0 -> 4.0
                else -> 0.0
            }
            if (platoon < 35.0 && seasonPower < 62.0) raw -= 2.0
        }

        // Tiny-sample spike protection. A very high pressure number with fewer than six tracked BBE
        // now needs a credible season power floor to stay near the top of the slate.
        if (metrics.battedBallCount < 6 && candidate.score.powerPressure >= 72.0 && seasonPower < 55.0) {
            raw -= 3.0
        }

        // Established power gets a modest tie-breaker. This specifically prevents elite HR bats from
        // being buried by a short cold stretch without turning season totals into the whole model.
        raw += when {
            seasonPower >= 85.0 -> 3.0
            seasonPower >= 75.0 -> 1.5
            else -> 0.0
        }

        raw += bvpAdjustment(candidate) * .40
        return raw.coerceIn(0.0, 100.0)
    }

    fun pickScore(candidate: HitterCandidate): Double = targetScore(candidate)

    /** Rolling seven-day batting line used by the Hot tab. The date-range data comes from one
     * league-wide MLB StatsAPI request, so this does not add one network request per player. */
    fun recentWeekStats(candidate: HitterCandidate, state: AppUiState = _state.value): RecentHittingStats? =
        state.board?.recentWeekStats?.get(candidate.player.id)

    fun recentNearHrCount(candidate: HitterCandidate): Int =
        candidate.recentBattedBalls.count(scoringModel::isNearHomeRun)

    fun recentEliteNearHrCount(candidate: HitterCandidate): Int =
        candidate.recentBattedBalls.count(scoringModel::isEliteNearHomeRun)

    /**
     * Hot Streak Score is deliberately separate from the daily HR Target Score. It answers a
     * different question: who has actually been producing over the last seven days, and is that
     * production supported by contact quality rather than box-score luck alone?
     */
    fun hotStreakScore(candidate: HitterCandidate, state: AppUiState = _state.value): Double {
        val stats = recentWeekStats(candidate, state) ?: return 0.0
        if (stats.plateAppearances < 5) return 0.0
        val metrics = mustHaveMetrics(candidate)

        val ops = stats.ops?.let { scaleForHot(it, .620, 1.250) } ?: 45.0
        val iso = stats.iso?.let { scaleForHot(it, .080, .420) } ?: 45.0
        val avg = stats.avg?.let { scaleForHot(it, .180, .400) } ?: 45.0
        val hrs = scaleForHot(stats.homeRuns.toDouble(), 0.0, 4.0)
        val xbh = scaleForHot(stats.extraBaseHits.toDouble(), 0.0, 7.0)
        val production = scaleForHot((stats.runs + stats.rbi).toDouble(), 1.0, 16.0)
        val contact = stats.strikeoutRate?.let { inverseScale(it, .12, .34) } ?: 50.0
        val profile = mustHavePowerScore(candidate)
        val pressure = candidate.score.powerPressure

        val raw = ops * .20 +
            iso * .18 +
            hrs * .16 +
            avg * .10 +
            xbh * .08 +
            production * .06 +
            contact * .07 +
            profile * .10 +
            pressure * .05

        // Seven-day samples are naturally small. Keep tiny 5-PA cameos from jumping established
        // hot hitters, while allowing regulars with 20-30 PA to express the full score.
        val confidence = ((stats.plateAppearances - 4) / 22.0).coerceIn(.25, 1.0)
        return (50.0 * (1.0 - confidence) + raw * confidence).coerceIn(0.0, 100.0)
    }

    fun hotCandidates(
        limit: Int = 20,
        state: AppUiState = _state.value
    ): List<HitterCandidate> = eligibleCandidates(state)
        .filter { (recentWeekStats(it, state)?.plateAppearances ?: 0) >= 5 }
        .sortedWith(
            compareByDescending<HitterCandidate> { hotStreakScore(it, state) }
                .thenByDescending { recentWeekStats(it, state)?.homeRuns ?: 0 }
                .thenByDescending { recentWeekStats(it, state)?.ops ?: 0.0 }
                .thenByDescending(::targetScore)
        )
        .take(limit)

    fun hotStreakReasons(candidate: HitterCandidate, state: AppUiState = _state.value): List<String> {
        val stats = recentWeekStats(candidate, state) ?: return emptyList()
        val metrics = mustHaveMetrics(candidate)
        val near = recentNearHrCount(candidate)
        val eliteNear = recentEliteNearHrCount(candidate)
        return buildList {
            if (stats.homeRuns > 0) add("${stats.homeRuns} HR in the last 7 days")
            stats.ops?.let { if (it >= .850) add("${"%.3f".format(it)} OPS with ${stats.hits} hits") }
            stats.avg?.let { avg -> stats.slg?.let { slg -> if (avg >= .280 || slg >= .500) add("${"%.3f".format(avg)} AVG / ${"%.3f".format(slg)} SLG") } }
            if (stats.extraBaseHits >= 2) add("${stats.extraBaseHits} extra-base hits • ${stats.rbi} RBI")
            if (eliteNear > 0) add("$eliteNear elite near-HR miss${if (eliteNear == 1) "" else "es"} recently")
            else if (near > 0) add("$near recent near-HR miss${if (near == 1) "" else "es"}")
            if ((metrics.barrelPct ?: 0.0) >= 10.0 || (metrics.hardHitPct ?: 0.0) >= 45.0) {
                val parts = buildList {
                    metrics.barrelPct?.let { add("${"%.1f".format(it)}% barrel") }
                    metrics.hardHitPct?.let { add("${"%.1f".format(it)}% hard-hit") }
                }
                if (parts.isNotEmpty()) add(parts.joinToString(" • "))
            }
            metrics.maxExitVelocity?.let { if (it >= 103.0) add("Max EV ${"%.1f".format(it)} mph") }
            stats.strikeoutRate?.let { if (it <= .18 && stats.plateAppearances >= 10) add("Low ${"%.1f".format(it * 100)}% K rate") }
        }.distinct().take(5)
    }


    /** Previous three completed calendar days. This is intentionally separate from the seven-day
     * Hot board: the goal is to catch acceleration before a hitter becomes an obvious hot name. */
    fun recentThreeDayStats(candidate: HitterCandidate, state: AppUiState = _state.value): RecentHittingStats? =
        state.board?.recentThreeDayStats?.get(candidate.player.id)

    fun lastThreeBattedBalls(candidate: HitterCandidate, state: AppUiState = _state.value) =
        candidate.recentBattedBalls.filter { ball ->
            val start = state.selectedDate.minusDays(3)
            val end = state.selectedDate.minusDays(1)
            !ball.gameDate.isBefore(start) && !ball.gameDate.isAfter(end)
        }

    fun heatingMetrics(candidate: HitterCandidate, state: AppUiState = _state.value): MustHaveMetrics {
        val key = "${state.selectedDate}:${candidate.game.gamePk}:${candidate.player.id}"
        return heatingMetricsCache.getOrPut(key) {
            scoringModel.mustHaveMetrics(candidate.player, candidate.seasonStats, lastThreeBattedBalls(candidate, state))
        }
    }

    fun heatingNearHrCount(candidate: HitterCandidate, state: AppUiState = _state.value): Int =
        lastThreeBattedBalls(candidate, state).count(scoringModel::isNearHomeRun)

    fun heatingEliteNearHrCount(candidate: HitterCandidate, state: AppUiState = _state.value): Int =
        lastThreeBattedBalls(candidate, state).count(scoringModel::isEliteNearHomeRun)

    private fun heatingWhiffScore(candidate: HitterCandidate): Double {
        val sample = candidate.last3PlateDiscipline
        val recent = sample.whiffRate?.let { inverseScale(it, .12, .38) } ?: 50.0
        val confidence = (sample.swings / 18.0).coerceIn(.25, 1.0)
        return recent * confidence + 50.0 * (1.0 - confidence)
    }

    fun heatingAcceleration(candidate: HitterCandidate, state: AppUiState = _state.value): Double {
        val three = recentThreeDayStats(candidate, state) ?: return 50.0
        val week = recentWeekStats(candidate, state) ?: return 55.0
        val threeOps = three.ops
        val weekOps = week.ops
        val threeIso = three.iso
        val weekIso = week.iso
        val opsDelta = if (threeOps != null && weekOps != null) threeOps - weekOps else 0.0
        val isoDelta = if (threeIso != null && weekIso != null) threeIso - weekIso else 0.0
        return (scaleForHot(opsDelta, -.12, .38) * .70 + scaleForHot(isoDelta, -.08, .24) * .30)
            .coerceIn(0.0, 100.0)
    }

    /**
     * Three-day Emerging Heat score. It is designed to find hitters whose process is improving
     * before a full seven-day box-score streak makes them obvious. Contact quality and near-HR
     * pressure matter more here than raw HR totals.
     */
    fun heatingScore(candidate: HitterCandidate, state: AppUiState = _state.value): Double {
        val stats = recentThreeDayStats(candidate, state) ?: return 0.0
        if (stats.plateAppearances < 4) return 0.0
        val metrics = heatingMetrics(candidate, state)

        val ops = stats.ops?.let { scaleForHot(it, .560, 1.250) } ?: 42.0
        val avg = stats.avg?.let { scaleForHot(it, .150, .400) } ?: 42.0
        val iso = stats.iso?.let { scaleForHot(it, .040, .420) } ?: 42.0
        val hits = scaleForHot(stats.hits.toDouble(), 0.0, 6.0)
        val xbh = scaleForHot(stats.extraBaseHits.toDouble(), 0.0, 4.0)
        val box = ops * .34 + avg * .18 + iso * .24 + hits * .12 + xbh * .12

        val barrel = metrics.barrelPct?.let { scaleForHot(it, 2.0, 24.0) } ?: 45.0
        val hardHit = metrics.hardHitPct?.let { scaleForHot(it, 30.0, 65.0) } ?: 45.0
        val sweet = metrics.sweetSpotPct?.let { scaleForHot(it, 18.0, 55.0) } ?: 45.0
        val maxEv = metrics.maxExitVelocity?.let { scaleForHot(it, 96.0, 112.0) } ?: 45.0
        val near = when (heatingNearHrCount(candidate, state)) {
            0 -> 40.0
            1 -> 76.0
            2 -> 92.0
            else -> 100.0
        }
        val contactQuality = barrel * .24 + hardHit * .27 + sweet * .14 + maxEv * .19 + near * .16

        val raw = contactQuality * .32 +
            box * .24 +
            candidate.score.powerPressure * .15 +
            heatingWhiffScore(candidate) * .10 +
            heatingAcceleration(candidate, state) * .12 +
            targetScore(candidate) * .07

        val paConfidence = ((stats.plateAppearances - 3) / 10.0).coerceIn(.35, 1.0)
        val bbeConfidence = (metrics.battedBallCount / 5.0).coerceIn(.35, 1.0)
        val confidence = (paConfidence * .60 + bbeConfidence * .40).coerceIn(.35, 1.0)
        return (50.0 * (1.0 - confidence) + raw * confidence).coerceIn(0.0, 100.0)
    }

    fun heatingSignalCount(candidate: HitterCandidate, state: AppUiState = _state.value): Int {
        val stats = recentThreeDayStats(candidate, state) ?: return 0
        val metrics = heatingMetrics(candidate, state)
        var count = 0
        if ((stats.ops ?: 0.0) >= .760 || (stats.avg ?: 0.0) >= .280 || stats.hits >= 3) count++
        if ((metrics.hardHitPct ?: 0.0) >= 45.0) count++
        if ((metrics.barrelPct ?: 0.0) >= 10.0 || (metrics.maxExitVelocity ?: 0.0) >= 103.0) count++
        if (heatingNearHrCount(candidate, state) > 0) count++
        if (candidate.score.powerPressure >= 65.0) count++
        val whiff = candidate.last3PlateDiscipline.whiffRate
        if (whiff != null && whiff <= .24 && candidate.last3PlateDiscipline.swings >= 6) count++
        if (heatingAcceleration(candidate, state) >= 62.0) count++
        return count
    }

    fun heatingCandidates(
        limit: Int = 20,
        state: AppUiState = _state.value
    ): List<HitterCandidate> = eligibleCandidates(state)
        .filter { (recentThreeDayStats(it, state)?.plateAppearances ?: 0) >= 4 }
        .filter { heatingSignalCount(it, state) >= 2 }
        .filter { heatingScore(it, state) >= 55.0 }
        // Keep the board focused on emerging heat instead of duplicating obvious established hot streaks.
        .filter {
            val week = recentWeekStats(it, state)
            !(hotStreakScore(it, state) >= 82.0 && (week?.homeRuns ?: 0) >= 2)
        }
        .sortedWith(
            compareByDescending<HitterCandidate> { heatingScore(it, state) }
                .thenByDescending { heatingSignalCount(it, state) }
                .thenByDescending { heatingAcceleration(it, state) }
                .thenByDescending { heatingMetrics(it, state).maxExitVelocity ?: 0.0 }
                .thenByDescending(::targetScore)
        )
        .take(limit)

    fun heatingReasons(candidate: HitterCandidate, state: AppUiState = _state.value): List<String> {
        val stats = recentThreeDayStats(candidate, state) ?: return emptyList()
        val week = recentWeekStats(candidate, state)
        val metrics = heatingMetrics(candidate, state)
        val near = heatingNearHrCount(candidate, state)
        val eliteNear = heatingEliteNearHrCount(candidate, state)
        return buildList {
            stats.ops?.let { ops ->
                val weekOps = week?.ops
                if (weekOps != null && ops - weekOps >= .100) {
                    add("3-day OPS ${"%.3f".format(ops)} • up ${"%.3f".format(ops - weekOps)} versus 7-day form")
                } else if (ops >= .800) {
                    add("3-day OPS ${"%.3f".format(ops)} with ${stats.hits} hits")
                }
                Unit
            }
            stats.avg?.let { if (it >= .280 || stats.hits >= 3) add("${stats.hits}-for-${stats.atBats} (${"%.3f".format(it)}) over the last 3 days") }
            if (stats.extraBaseHits > 0) add("${stats.extraBaseHits} XBH • ${stats.homeRuns} HR • ${stats.rbi} RBI in 3 days")
            if (eliteNear > 0) add("$eliteNear elite near-HR miss${if (eliteNear == 1) "" else "es"} in the 3-day window")
            else if (near > 0) add("$near near-HR miss${if (near == 1) "" else "es"} in the 3-day window")
            val quality = buildList {
                metrics.hardHitPct?.let { if (it >= 40.0) add("${"%.1f".format(it)}% hard-hit") }
                metrics.barrelPct?.let { if (it >= 8.0) add("${"%.1f".format(it)}% barrel") }
                metrics.sweetSpotPct?.let { if (it >= 30.0) add("${"%.1f".format(it)}% sweet spot") }
            }
            if (quality.isNotEmpty()) add(quality.joinToString(" • "))
            metrics.maxExitVelocity?.let { if (it >= 101.0) add("3-day max EV ${"%.1f".format(it)} mph") }
            candidate.last3PlateDiscipline.whiffRate?.let {
                if (it <= .24 && candidate.last3PlateDiscipline.swings >= 6) {
                    add("Only ${"%.1f".format(it * 100)}% whiffs across ${candidate.last3PlateDiscipline.swings} swings")
                }
            }
            if (candidate.score.powerPressure >= 65.0) add("Power Pressure ${candidate.score.powerPressure.roundToInt()} — HR-quality contact is building")
        }.distinct().take(6)
    }

    private fun scaleForHot(value: Double, low: Double, high: Double): Double {
        if (high <= low) return 50.0
        return (((value - low) / (high - low)) * 100.0).coerceIn(0.0, 100.0)
    }

    fun topTargets(
        limit: Int = 15,
        state: AppUiState = _state.value
    ): List<HitterCandidate> = eligibleCandidates(state)
        .sortedWith(
            compareByDescending<HitterCandidate>(::targetScore)
                .thenByDescending(::signalLensScore)
                .thenByDescending(::mustHavePowerScore)
                .thenByDescending { it.score.pitcherMatchup }
                .thenByDescending { it.score.powerPressure }
        )
        .take(limit)

    fun selectPlayer(id: Int?) = mutate { it.copy(selectedPlayerId = id) }

    fun updateWeights(weights: ScoreWeights) {
        prefs.saveWeights(weights)
        synchronized(boardCache) {
            val rescored = boardCache.mapValues { (_, board) -> repository.rescore(board, weights) }
            boardCache.clear()
            boardCache.putAll(rescored)
        }
        mutate { s ->
            val rescored = s.board?.let { repository.rescore(it, weights) }
            s.copy(weights = weights, board = rescored)
        }
    }

    fun resetWeights() = updateWeights(ScoreWeights())

    fun toggleTracked(candidate: HitterCandidate) {
        val date = _state.value.selectedDate
        val existing = _state.value.tracked
        val keyMatch: (TrackedPick) -> Boolean = { it.playerId == candidate.player.id && it.date == date }
        val next = if (existing.any(keyMatch)) {
            existing.filterNot(keyMatch)
        } else {
            existing + TrackedPick(
                playerId = candidate.player.id,
                playerName = candidate.player.name,
                teamName = candidate.team.name,
                date = date,
                scoreAtTrack = candidate.score.total,
                trackedAt = Instant.now()
            )
        }
        prefs.saveTracked(next)
        mutate { it.copy(tracked = next) }
    }

    /**
     * Lazily load exact game lines for yesterday's Top 15. This never blocks the main board: the
     * postgame cards fill in as MLB game-log data arrives.
     */
    fun loadPostgameTargetStats() {
        val snapshot = _state.value
        if (snapshot.selectedDate != LocalDate.now().minusDays(1)) return
        val targets = topTargets(15, snapshot)
        if (targets.isEmpty()) return

        viewModelScope.launch {
            for (candidate in targets) {
                val id = candidate.player.id
                val key = "$id:${snapshot.selectedDate}"
                if (postgameStatsCache.containsKey(key)) {
                    val cached = postgameStatsCache[key]
                    if (cached != null) mutate { current ->
                        if (current.selectedDate == snapshot.selectedDate) current.copy(
                            postgameStats = current.postgameStats + (id to cached),
                            postgameStatsLoading = current.postgameStatsLoading - id
                        ) else current
                    }
                    continue
                }
                if (id in _state.value.postgameStatsLoading) continue
                mutate { current -> current.copy(postgameStatsLoading = current.postgameStatsLoading + id) }
                val stats = runCatching { repository.fetchPlayerGameStats(id, snapshot.selectedDate) }.getOrNull()
                postgameStatsCache[key] = stats
                mutate { current ->
                    if (current.selectedDate != snapshot.selectedDate) current
                    else current.copy(
                        postgameStats = if (stats != null) current.postgameStats + (id to stats) else current.postgameStats,
                        postgameStatsLoading = current.postgameStatsLoading - id
                    )
                }
            }
        }
    }

    fun postgameReview(candidate: HitterCandidate, stats: RecentHittingStats?): PostgameReview {
        val balls = candidate.todayBattedBalls
        val measuredHr = maxOf(stats?.homeRuns ?: 0, balls.count { it.isHomeRun })
        val hardest = balls.mapNotNull { it.exitVelocity }.maxOrNull()
        val eliteNear = balls.filter(scoringModel::isEliteNearHomeRun).maxByOrNull { it.distanceFt ?: 0.0 }
        val near = balls.filter(scoringModel::isNearHomeRun).maxByOrNull { it.distanceFt ?: 0.0 }
        val barrels = balls.count(scoringModel::isBarrelProxy)
        val hardHits = balls.count(scoringModel::isHardHit)
        val matchup = candidate.score.pitcherMatchup
        val pitcher = candidate.opponentPitcher

        val resultLine = when {
            stats != null -> buildString {
                append("${stats.hits}-for-${stats.atBats}")
                append(" • ${stats.homeRuns} HR")
                if (stats.extraBaseHits > stats.homeRuns) append(" • ${stats.extraBaseHits} XBH")
                append(" • ${stats.runs} R • ${stats.rbi} RBI • ${stats.strikeouts} K")
                hardest?.let { append(" • ${"%.1f".format(it)} max EV") }
            }
            else -> "${balls.size} tracked BBE${hardest?.let { " • ${"%.1f".format(it)} max EV" } ?: ""}"
        }

        if (measuredHr > 0) return PostgameReview(
            label = "MODEL HIT",
            explanation = "The target converted. The pregame power/matchup signals produced an actual home run.",
            resultLine = resultLine
        )
        if (eliteNear != null) return PostgameReview(
            label = "GOOD READ • JUST MISSED",
            explanation = "He generated elite home-run-quality contact but the ball stayed in the park. ${contactDetail(eliteNear)} This is process-positive and should not be treated like a bad model read.",
            resultLine = resultLine
        )
        if (near != null) return PostgameReview(
            label = "GOOD READ • NEAR-HR",
            explanation = "The hitter produced a legitimate near-home-run contact. ${contactDetail(near)} The HR result missed, but the underlying contact supported the pick.",
            resultLine = resultLine
        )
        if (barrels > 0) return PostgameReview(
            label = "BARREL • NO HR",
            explanation = "He found the barrel ($barrels barrel-proxy contact${if (barrels == 1) "" else "s"}) but did not get the home-run outcome. That is more variance than a complete miss.",
            resultLine = resultLine
        )
        if (stats != null && (stats.hits >= 2 || stats.extraBaseHits > 0 || stats.runs + stats.rbi >= 2)) return PostgameReview(
            label = "GOOD NIGHT • NO HR",
            explanation = "He was productive offensively, so the hitter-form signal was not necessarily wrong; the production simply came without a home run.",
            resultLine = resultLine
        )
        if (matchup < 45.0) {
            val pitcherText = pitcher?.let { p ->
                val details = buildList {
                    p.seasonStats.era?.let { add("${"%.2f".format(it)} ERA") }
                    p.seasonStats.hrPer9?.let { add("${"%.2f".format(it)} HR/9") }
                    p.seasonStats.strikeoutRate?.let { add("${(it * 100).roundToInt()}% K") }
                }.joinToString(" • ")
                "${p.person.name}${if (details.isNotBlank()) " ($details)" else ""}"
            } ?: "the opposing starter"
            return PostgameReview(
                label = "MATCHUP-DRIVEN MISS",
                explanation = "The model already rated the pitcher matchup only ${matchup.roundToInt()}. $pitcherText was a real resistance signal, so this target should have been pushed lower unless the hitter's power signals were exceptional.",
                resultLine = resultLine
            )
        }
        if (stats != null && stats.strikeouts >= 2) return PostgameReview(
            label = "BAD NIGHT • SWING/MISS",
            explanation = "This looks more like a poor individual night than a near miss: ${stats.strikeouts} strikeouts and no HR-quality contact. Swing-and-miss should count against similar profiles when the supporting power signals are only average.",
            resultLine = resultLine
        )
        if (stats != null && stats.hits == 0) return PostgameReview(
            label = "QUIET NIGHT",
            explanation = "He never got going offensively and did not generate a qualifying near-HR/barrel signal. This is a true miss rather than a good process result.",
            resultLine = resultLine
        )
        if (hardHits > 0) return PostgameReview(
            label = "HARD CONTACT • NO HR",
            explanation = "He made $hardHits hard-hit contact${if (hardHits == 1) "" else "s"}, but none reached near-HR quality. The bat was not dead, but the HR-specific read was too optimistic.",
            resultLine = resultLine
        )
        return PostgameReview(
            label = "MODEL MISS",
            explanation = "No home run and no strong contact evidence supported the pick after the game. Treat this as a full miss and use it when calibrating similar profiles.",
            resultLine = resultLine
        )
    }

    private fun contactDetail(ball: com.ckz.hrchase.data.BattedBall): String = buildString {
        ball.exitVelocity?.let { append("${"%.1f".format(it)} mph") }
        ball.launchAngle?.let { if (isNotEmpty()) append(" / "); append("${it.roundToInt()}°") }
        ball.distanceFt?.let { if (isNotEmpty()) append(" / "); append("${it.roundToInt()} ft") }
        if (isNotEmpty()) append(".")
    }

    fun loadTrackedLast10Stats() {
        val snapshot = _state.value
        val picks = snapshot.tracked.filter { it.date == snapshot.selectedDate }
        if (picks.isEmpty()) return

        // Never include an in-progress/future game in the recent-form summary. For today and future
        // boards, use yesterday as the cutoff. When reviewing yesterday, that completed game can be
        // included in the rolling last-10 snapshot.
        val lastCompletedDate = LocalDate.now().minusDays(1)
        val throughDate = minOf(snapshot.selectedDate, lastCompletedDate)

        picks.forEach { pick ->
            val key = "${pick.playerId}:$throughDate"
            if (trackedLast10Cache.containsKey(key)) {
                val cached = trackedLast10Cache[key]
                if (cached != null && snapshot.trackedLast10[pick.playerId] != cached) {
                    mutate { current ->
                        if (current.selectedDate == snapshot.selectedDate) {
                            current.copy(trackedLast10 = current.trackedLast10 + (pick.playerId to cached))
                        } else current
                    }
                }
                return@forEach
            }
            if (pick.playerId in _state.value.trackedLast10Loading) return@forEach

            mutate { current ->
                current.copy(trackedLast10Loading = current.trackedLast10Loading + pick.playerId)
            }
            viewModelScope.launch {
                val stats = runCatching {
                    repository.fetchPlayerLast10Stats(pick.playerId, throughDate)
                }.getOrNull()
                trackedLast10Cache[key] = stats
                mutate { current ->
                    if (current.selectedDate != snapshot.selectedDate) {
                        current.copy(trackedLast10Loading = current.trackedLast10Loading - pick.playerId)
                    } else {
                        current.copy(
                            trackedLast10 = if (stats != null) {
                                current.trackedLast10 + (pick.playerId to stats)
                            } else current.trackedLast10,
                            trackedLast10Loading = current.trackedLast10Loading - pick.playerId
                        )
                    }
                }
            }
        }
    }

    fun clearTrackedForSelectedDate() {
        val date = _state.value.selectedDate
        val next = _state.value.tracked.filterNot { it.date == date }
        prefs.saveTracked(next)
        mutate { it.copy(tracked = next, trackedLast10 = emptyMap(), trackedLast10Loading = emptySet()) }
    }

    private fun inverseScale(value: Double, good: Double, bad: Double): Double {
        if (bad <= good) return 50.0
        return (100.0 - ((value - good) / (bad - good) * 100.0)).coerceIn(0.0, 100.0)
    }

    private fun mutate(block: (AppUiState) -> AppUiState) {
        synchronized(stateLock) {
            _state.value = block(_state.value)
        }
    }

    /** Base candidate set shared by Games and Parlays. */
    fun eligibleCandidates(state: AppUiState = _state.value): List<HitterCandidate> {
        val board = state.board ?: return emptyList()
        val nowDate = LocalDate.now()
        return board.candidates.asSequence()
            .filter { c ->
                if (!state.showRemainingOnly || board.date != nowDate) true
                else !c.game.status.equals("Final", true)
            }
            .filter { c -> !state.officialLineupsOnly || c.lineupOfficial }
            .toList()
    }

    fun visibleCandidates(state: AppUiState = _state.value): List<HitterCandidate> {
        return eligibleCandidates(state).asSequence()
            .filter { c ->
                state.sortMode != SortMode.ATTACK ||
                    !state.attackStrongOnly ||
                    (c.score.powerPressure >= 65.0 && c.score.pitcherMatchup >= 65.0)
            }
            .sortedWith(
                when (state.sortMode) {
                    SortMode.SCORE -> compareByDescending<HitterCandidate> { it.score.total }
                    SortMode.ATTACK -> compareByDescending<HitterCandidate> { attackScore(it) }
                        .thenByDescending { it.score.total }
                    SortMode.POWER_PRESSURE -> compareByDescending<HitterCandidate> { it.score.powerPressure }
                    SortMode.RECENT_POWER -> compareByDescending<HitterCandidate> { it.score.recentPower }
                    SortMode.MATCHUP -> compareByDescending<HitterCandidate> { it.score.pitcherMatchup }
                }
            )
            .toList()
    }

    fun topHittersForGame(
        gamePk: Long,
        limit: Int = 4,
        state: AppUiState = _state.value
    ): List<HitterCandidate> = eligibleCandidates(state)
        .filter { it.game.gamePk == gamePk }
        .sortedByDescending(::pickScore)
        .take(limit)

    /**
     * Parlay-specific quality score. It rewards hitters who are strong in BOTH Power Pressure and
     * Matchup, then penalizes weak environments or genuinely poor pitcher matchups. This prevents
     * the generator from simply copying the overall board ranking.
     */
    fun parlayScore(candidate: HitterCandidate): Double {
        var score = pickScore(candidate)
        val pressure = candidate.score.powerPressure
        val matchup = candidate.score.pitcherMatchup

        score += when {
            pressure >= 70.0 && matchup >= 70.0 -> 7.0
            pressure >= 60.0 && matchup >= 60.0 -> 4.0
            pressure >= 52.0 && matchup >= 52.0 -> 2.0
            else -> 0.0
        }

        val signal = signalLensScore(candidate)
        score += when {
            signal >= 78.0 -> 4.0
            signal >= 68.0 -> 2.0
            else -> 0.0
        }
        recentWhiffRate(candidate)?.let { if (it <= .22 && candidate.recentPlateDiscipline.swings >= 10) score += 1.5 }

        if (candidate.score.environment < 35.0) score -= 8.0
        if (matchup < 35.0) score -= 6.0
        return score
    }

    private fun parlayCandidatePool(state: AppUiState): List<HitterCandidate> {
        val ranked = eligibleCandidates(state)
            .filter { it.score.total >= 40.0 }
            .sortedWith(
                compareByDescending<HitterCandidate>(::parlayScore)
                    .thenByDescending { it.score.powerPressure }
                    .thenByDescending { it.score.pitcherMatchup }
            )

        if (ranked.isEmpty()) return emptyList()

        // Keep the generator in a competitive quality window rather than letting "Generate again"
        // drift into weak long shots just for the sake of being different.
        val best = parlayScore(ranked.first())
        return ranked.filter { parlayScore(it) >= best - 18.0 }.take(40)
    }

    /**
     * Straight-bet rotation pool. Generate Another cycles through these players in ranked order,
     * so a 1-leg request no longer returns the same hitter forever.
     */
    fun straightCandidates(state: AppUiState = _state.value): List<HitterCandidate> {
        val base = parlayCandidatePool(state)
        if (base.isEmpty()) return emptyList()
        val best = parlayScore(base.first())
        val tightWindow = base.filter { parlayScore(it) >= best - 11.0 }.take(12)
        return if (tightWindow.isNotEmpty()) tightWindow else base.take(12)
    }

    /**
     * Generates a quality-first parlay while avoiding needless correlation.
     *
     * v0.5 behavior:
     * - 1-leg: cycles through a ranked pool of strong straight HR choices.
     * - 2-5 legs: rotates the anchor hitter and then builds around that anchor from the best
     *   remaining players, preferring different games and teams.
     * - Generate Another changes the slip without abandoning the strongest part of the board.
     */
    fun generateParlay(
        legs: Int,
        variant: Int = 0,
        state: AppUiState = _state.value
    ): List<HitterCandidate> {
        val targetLegs = legs.coerceIn(1, 5)
        val base = parlayCandidatePool(state)
        if (base.isEmpty()) return emptyList()

        if (targetLegs == 1) {
            val straights = straightCandidates(state)
            if (straights.isEmpty()) return emptyList()
            return listOf(straights[Math.floorMod(variant, straights.size)])
        }

        val chosen = mutableListOf<HitterCandidate>()
        val usedGames = mutableSetOf<Long>()
        val usedTeams = mutableSetOf<Int>()

        // Rotate the anchor among the best competitive candidates. This guarantees that a new
        // variant actually produces a different parlay while keeping the first leg high quality.
        val anchorPoolSize = minOf(10, base.size)
        val anchor = base[Math.floorMod(variant, anchorPoolSize)]
        chosen += anchor
        usedGames += anchor.game.gamePk
        usedTeams += anchor.team.id

        for (slot in 1 until targetLegs) {
            val options = base.asSequence()
                .filter { candidate -> chosen.none { it.player.id == candidate.player.id } }
                .map { candidate ->
                    var adjusted = parlayScore(candidate)

                    // Prefer independent games and teams before repeating either.
                    if (candidate.game.gamePk in usedGames) adjusted -= 16.0
                    if (candidate.team.id in usedTeams) adjusted -= 8.0

                    // Extra protection against obviously weak individual legs.
                    if (candidate.score.environment < 35.0) adjusted -= 6.0
                    if (candidate.score.pitcherMatchup < 35.0) adjusted -= 5.0

                    candidate to adjusted
                }
                .sortedByDescending { it.second }
                .take(5)
                .toList()

            if (options.isEmpty()) break

            // Variant zero is the pure best-score slip. Later variants can use the 2nd/3rd-best
            // option in a slot, but never wander farther than the top three adjusted choices.
            val depth = minOf(3, options.size)
            val optionIndex = if (variant == 0) 0 else Math.floorMod(variant + slot - 1, depth)
            val best = options[optionIndex].first

            chosen += best
            usedGames += best.game.gamePk
            usedTeams += best.team.id
        }

        return chosen.take(targetLegs)
    }

}
