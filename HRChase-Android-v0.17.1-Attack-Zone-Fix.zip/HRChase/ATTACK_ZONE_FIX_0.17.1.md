# HR Chase v0.17.1 — Attack Zone Fit Reliability Fix

## Root cause
v0.17.0 built each opponent starter's attack map only from the compact recent **team** feed budget. That works for hitter contact, but it is unreliable for starting pitchers because the newest team game usually features a different starter. As a result, many current probable pitchers had zero recent pitch-location rows and Attack Zone Fit stayed unavailable.

The original score was also being sample-regressed twice: once inside each zone cell and then a second time by total confidence. That compressed even legitimate overlaps back toward 50.

## Fix
- Each current probable starter now gets his actual most recent start resolved from the previous eight days of MLB schedule data.
- Only if that historical schedule cannot identify the starter do we fall back to his individual pitching game log.
- HR Chase downloads the lightweight MLB play-by-play payload for that start and extracts real `pX` / `pZ` pitch coordinates.
- This enrichment happens **after** the fast base board is published, so fixing Zone Fit does not hold the whole slate behind extra network calls.
- Existing recent pitch samples are reused; duplicate games are skipped.
- The play-by-play parser now supports both the full live-feed structure and the standalone `/playByPlay` structure.

## Scoring correction
- Empty hitter evidence in a zone is now treated as **unknown/neutral**, not slightly negative.
- One normal starter outing is enough to produce a usable attack map; a second outing mainly adds stability.
- Zone matchup quality and Zone confidence are now separate. Cell damage is already sample-regressed, so the final Zone score is no longer shrunk toward 50 a second time.
- Confidence still controls whether Zone Fit is allowed into the Research Lens, target model and Pattern Engine.

## Validation
A synthetic smoke test using the same hitter contact map against two different pitcher attack maps produced:
- strong overlap: Zone 70.65, confidence 0.62
- poor overlap: Zone 54.85, confidence 0.51

The strong-overlap case correctly outranked the poor-overlap case. The modified MlbApi, Repository, models and HR scoring layer compile successfully with a standalone Kotlin/JVM check. The full Android Gradle build still requires GitHub Actions because this environment cannot resolve `services.gradle.org`.
