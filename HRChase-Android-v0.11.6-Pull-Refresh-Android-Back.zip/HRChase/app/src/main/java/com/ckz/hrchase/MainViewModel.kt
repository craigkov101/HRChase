package com.ckz.hrchase

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ckz.hrchase.data.AppPreferences
import com.ckz.hrchase.data.BoardData
import com.ckz.hrchase.data.DailySignalSnapshot
import com.ckz.hrchase.data.HitterSignalSnapshot
import com.ckz.hrchase.data.MetricLearning
import com.ckz.hrchase.data.CommonDenominatorSignal
import com.ckz.hrchase.data.NightPatternProfile
import com.ckz.hrchase.data.NightHomerReference
import com.ckz.hrchase.data.ModelLearningProfile
import com.ckz.hrchase.data.HitterCandidate
import com.ckz.hrchase.data.MustHaveMetrics
import com.ckz.hrchase.data.PostgameReview
import com.ckz.hrchase.data.RecentHittingStats
import com.ckz.hrchase.data.Repository
import com.ckz.hrchase.data.ScoreWeights
import com.ckz.hrchase.data.TrackedPick
import com.ckz.hrchase.model.HrScoringModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.LocalDate
import kotlin.math.absoluteValue
import kotlin.math.roundToInt

enum class SortMode { SCORE, ATTACK, POWER_PRESSURE, RECENT_POWER, MATCHUP }

enum class ParlayFocus {
    BALANCED,
    PURE_POWER,
    HEATING_UP,
    HOT_NOW,
    MATCHUP_EDGE
}

data class ParlayEvaluation(
    val rating: Int,
    val label: String,
    val averageLegScore: Int,
    val weakestLegScore: Int,
    val uniqueGames: Int,
    val note: String
)

data class AppUiState(
    val selectedDate: LocalDate = LocalDate.now(),
    val board: BoardData? = null,
    val isLoading: Boolean = false,
    val progress: String = "",
    val error: String? = null,
    val selectedPlayerId: Int? = null,
    val showRemainingOnly: Boolean = true,
    val officialLineupsOnly: Boolean = false,
    val sortMode: SortMode = SortMode.SCORE,
    val attackStrongOnly: Boolean = false,
    val weights: ScoreWeights = ScoreWeights(),
    val tracked: List<TrackedPick> = emptyList(),
    val trackedLast10: Map<Int, RecentHittingStats> = emptyMap(),
    val trackedLast10Loading: Set<Int> = emptySet(),
    val postgameStats: Map<Int, RecentHittingStats> = emptyMap(),
    val postgameStatsLoading: Set<Int> = emptySet(),
    val learningProfile: ModelLearningProfile = ModelLearningProfile(),
    val lastNightPattern: NightPatternProfile = NightPatternProfile()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = AppPreferences(application)
    private val repository = Repository()
    private val scoringModel = HrScoringModel()
    private val mustHaveCache = mutableMapOf<String, MustHaveMetrics>()
    private val heatingMetricsCache = mutableMapOf<String, MustHaveMetrics>()
    private val trackedLast10Cache = mutableMapOf<String, RecentHittingStats?>()
    private val postgameStatsCache = mutableMapOf<String, RecentHittingStats?>()
    private var refreshJob: Job? = null
    private var refreshGeneration: Long = 0L
    private val stateLock = Any()

    // Keep the most recently usable board for each nearby date. This makes date switching
    // instant and, more importantly, prevents a refresh from replacing a good board with an
    // empty schedule-only partial if a downstream MLB/Savant request fails.
    private val boardCache = object : LinkedHashMap<LocalDate, BoardData>(4, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<LocalDate, BoardData>?): Boolean = size > 4
    }

    private val _state = MutableStateFlow(
        AppUiState(
            weights = prefs.loadWeights(),
            tracked = prefs.loadTracked()
        )
    )
    val state: StateFlow<AppUiState> = _state.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        refreshJob?.cancel()
        val generation = ++refreshGeneration
        val snapshot = _state.value
        val date = snapshot.selectedDate
        val weights = snapshot.weights
        val cached = synchronized(boardCache) { boardCache[date] }

        // Stale-while-revalidate: immediately restore a known-good board when the user jumps
        // between dates, then update it in place. This fixes the "switch back + refresh = no
        // players until restart" failure mode and makes navigation feel instant.
        mutate { current ->
            if (current.selectedDate != date) current
            else current.copy(
                board = cached ?: current.board?.takeIf { it.date == date },
                isLoading = true,
                error = null,
                progress = if (cached?.candidates?.isNotEmpty() == true) "Refreshing in background…" else "Starting…"
            )
        }

        refreshJob = viewModelScope.launch {
            try {
                val board = withContext(Dispatchers.Default) {
                    repository.loadBoard(
                        date = date,
                        weights = weights,
                        onProgress = { message ->
                            if (generation == refreshGeneration) {
                                mutate { s ->
                                    if (s.selectedDate == date) s.copy(progress = message) else s
                                }
                            }
                        },
                        onPartialBoard = { partial ->
                            if (generation != refreshGeneration) return@loadBoard
                            mutate { s ->
                                if (s.selectedDate != partial.date) return@mutate s
                                val existing = s.board?.takeIf { it.date == partial.date }
                                // Never let an early schedule-only partial erase a board that already
                                // has hitters. Preserve the candidates until fresher candidates arrive.
                                val safePartial = if (
                                    partial.candidates.isEmpty() && existing?.candidates?.isNotEmpty() == true
                                ) {
                                    partial.copy(
                                        candidates = existing.candidates,
                                        recentGameCount = maxOf(partial.recentGameCount, existing.recentGameCount),
                                        recentWeekStats = if (partial.recentWeekStats.isNotEmpty()) partial.recentWeekStats else existing.recentWeekStats,
                                        recentThreeDayStats = if (partial.recentThreeDayStats.isNotEmpty()) partial.recentThreeDayStats else existing.recentThreeDayStats
                                    )
                                } else partial
                                if (safePartial.candidates.isNotEmpty()) cacheBoard(safePartial)
                                s.copy(board = safePartial)
                            }
                        }
                    )
                }

                if (generation != refreshGeneration) return@launch
                val learningProfile = withContext(Dispatchers.IO) { updateOutcomeLearning(board) }
                val lastNightPattern = withContext(Dispatchers.Default) {
                    buildLastNightPattern(board, prefs.loadSignalSnapshots())
                }
                if (generation != refreshGeneration) return@launch
                mustHaveCache.clear()
                heatingMetricsCache.clear()
                mutate { current ->
                    if (current.selectedDate != date) current
                    else {
                        val existing = current.board?.takeIf { it.date == date && it.candidates.isNotEmpty() }
                            ?: synchronized(boardCache) { boardCache[date] }
                        val keepExistingPlayers = board.games.isNotEmpty() &&
                            board.candidates.isEmpty() && existing?.candidates?.isNotEmpty() == true
                        val safeBoard = if (keepExistingPlayers) {
                            board.copy(
                                candidates = existing!!.candidates,
                                recentGameCount = maxOf(board.recentGameCount, existing.recentGameCount),
                                recentWeekStats = if (board.recentWeekStats.isNotEmpty()) board.recentWeekStats else existing.recentWeekStats,
                                recentThreeDayStats = if (board.recentThreeDayStats.isNotEmpty()) board.recentThreeDayStats else existing.recentThreeDayStats
                            )
                        } else board
                        cacheBoard(safeBoard)
                        current.copy(
                            board = safeBoard,
                            isLoading = false,
                            progress = "Ready",
                            learningProfile = learningProfile,
                            lastNightPattern = lastNightPattern,
                            error = if (keepExistingPlayers) {
                                "The slate refreshed, but player enrichment was incomplete. Keeping the last loaded player board instead of going blank."
                            } else null
                        )
                    }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Throwable) {
                if (generation != refreshGeneration) return@launch
                mutate { current ->
                    if (current.selectedDate != date) current
                    else {
                        val usable = current.board?.takeIf { it.date == date && it.candidates.isNotEmpty() }
                            ?: synchronized(boardCache) { boardCache[date] }
                        current.copy(
                            board = usable ?: current.board?.takeIf { it.date == date },
                            isLoading = false,
                            progress = if (usable != null) "Showing saved data" else "",
                            error = if (usable != null) {
                                "Refresh failed, but your last loaded data is still available. Tap refresh to try again."
                            } else {
                                error.message ?: error::class.java.simpleName
                            }
                        )
                    }
                }
            }
        }
    }

    private fun updateOutcomeLearning(board: BoardData): ModelLearningProfile {
        // Resolve yesterday's saved PRE-GAME signal snapshot against real MLB HR outcomes.
        // Then save today's first full board once, so tomorrow can grade the signals without
        // postgame leakage. This creates a growing local feedback set instead of pretending one
        // night's results are enough to retrain the model.
        board.previousNight?.let { previous ->
            prefs.resolveSignalSnapshot(previous.date, previous.homers.map { it.playerId }.toSet())
        }

        if (board.date == LocalDate.now() && board.candidates.isNotEmpty()) {
            val hitters = board.candidates.map { candidate ->
                val metrics = scoringModel.mustHaveMetrics(
                    candidate.player, candidate.seasonStats, candidate.recentBattedBalls
                )
                val contactProfile = metrics.score * metrics.confidence +
                    candidate.score.seasonPower * (1.0 - metrics.confidence)
                HitterSignalSnapshot(
                    date = board.date,
                    playerId = candidate.player.id,
                    recentPower = candidate.score.recentPower,
                    powerPressure = candidate.score.powerPressure,
                    pitcherMatchup = candidate.score.pitcherMatchup,
                    environment = candidate.score.environment,
                    seasonPower = candidate.score.seasonPower,
                    platoon = candidate.score.platoon,
                    contactProfile = contactProfile,
                    pitchArsenalFit = candidate.pitchArsenalMatch?.score
                )
            }
            prefs.saveSignalSnapshotIfAbsent(
                DailySignalSnapshot(date = board.date, savedAt = Instant.now(), hitters = hitters)
            )
        }

        return buildLearningProfile(prefs.loadSignalSnapshots())
    }

    private fun buildLearningProfile(snapshots: List<DailySignalSnapshot>): ModelLearningProfile {
        val resolved = snapshots
            .flatMap { it.hitters }
            .filter { it.outcomeHomeRun != null }
        if (resolved.isEmpty()) return ModelLearningProfile()

        val homeRuns = resolved.count { it.outcomeHomeRun == true }
        val baseline = homeRuns.toDouble() / resolved.size
        fun metric(getter: (HitterSignalSnapshot) -> Double?): MetricLearning {
            val exposed = resolved.mapNotNull { row -> getter(row)?.let { value -> row to value } }
                .filter { (_, value) -> value >= 65.0 }
                .map { it.first }
            val wins = exposed.count { it.outcomeHomeRun == true }
            val rate = if (exposed.isNotEmpty()) wins.toDouble() / exposed.size else 0.0
            val lift = if (baseline > 0.0 && exposed.isNotEmpty()) rate / baseline else 1.0
            return MetricLearning(exposed.size, wins, rate, lift.coerceIn(0.25, 3.0))
        }

        return ModelLearningProfile(
            resolvedHitterGames = resolved.size,
            homeRuns = homeRuns,
            baselineRate = baseline,
            metrics = mapOf(
                "recentPower" to metric { it.recentPower },
                "powerPressure" to metric { it.powerPressure },
                "pitcherMatchup" to metric { it.pitcherMatchup },
                "environment" to metric { it.environment },
                "seasonPower" to metric { it.seasonPower },
                "platoon" to metric { it.platoon },
                "contactProfile" to metric { it.contactProfile },
                "pitchArsenalFit" to metric { it.pitchArsenalFit }
            )
        )
    }

    private data class PatternSignalDef(
        val key: String,
        val label: String,
        val threshold: Double,
        val getter: (HitterSignalSnapshot) -> Double?
    )

    private val patternSignalDefs = listOf(
        PatternSignalDef("seasonPower", "Season power", 62.0) { it.seasonPower },
        PatternSignalDef("contactProfile", "Contact quality", 60.0) { it.contactProfile },
        PatternSignalDef("recentPower", "Recent power", 60.0) { it.recentPower },
        PatternSignalDef("powerPressure", "Power pressure", 55.0) { it.powerPressure },
        PatternSignalDef("pitcherMatchup", "Pitcher matchup", 58.0) { it.pitcherMatchup },
        PatternSignalDef("pitchArsenalFit", "Pitch arsenal fit", 62.0) { it.pitchArsenalFit },
        PatternSignalDef("platoon", "Handedness edge", 58.0) { it.platoon },
        PatternSignalDef("environment", "Environment", 58.0) { it.environment }
    )

    /**
     * Finds the strongest PRE-GAME traits shared by the previous night's actual HR hitters.
     * The comparison is against the full saved slate from that same day, so a trait only rises
     * when it was both common among HR hitters and meaningfully more productive than baseline.
     * This intentionally uses the saved snapshot rather than reconstructing yesterday after the
     * results are known, which avoids postgame leakage.
     */
    private fun buildLastNightPattern(
        board: BoardData,
        snapshots: List<DailySignalSnapshot>
    ): NightPatternProfile {
        val previous = board.previousNight ?: return NightPatternProfile()
        val snapshot = snapshots.lastOrNull { it.date == previous.date }
            ?: return NightPatternProfile(date = previous.date)
        val resolved = snapshot.hitters.filter { it.outcomeHomeRun != null }
        val homers = resolved.filter { it.outcomeHomeRun == true }
        if (resolved.isEmpty() || homers.isEmpty()) {
            return NightPatternProfile(
                date = previous.date,
                gradedHitters = resolved.size,
                homerHitters = homers.size
            )
        }

        val baselineHrRate = homers.size.toDouble() / resolved.size
        val homerSummaryById = previous.homers.associateBy { it.playerId }
        val references = homers.map { row ->
            NightHomerReference(
                playerId = row.playerId,
                playerName = homerSummaryById[row.playerId]?.playerName ?: "Player ${row.playerId}",
                homeRuns = homerSummaryById[row.playerId]?.homeRuns ?: 1,
                seasonPower = row.seasonPower,
                contactProfile = row.contactProfile,
                recentPower = row.recentPower,
                powerPressure = row.powerPressure,
                pitcherMatchup = row.pitcherMatchup,
                pitchArsenalFit = row.pitchArsenalFit,
                platoon = row.platoon,
                environment = row.environment
            )
        }
        val signals = patternSignalDefs.mapNotNull { def ->
            val available = resolved.mapNotNull { row -> def.getter(row)?.let { row to it } }
            val homerAvailable = available.filter { it.first.outcomeHomeRun == true }
            if (available.size < 25 || homerAvailable.size < 3) return@mapNotNull null

            val exposed = available.filter { it.second >= def.threshold }
            val homerExposed = exposed.count { it.first.outcomeHomeRun == true }
            val fieldCount = exposed.size
            if (fieldCount < 8) return@mapNotNull null

            val homerCoverage = homerExposed.toDouble() / homerAvailable.size
            val fieldCoverage = fieldCount.toDouble() / available.size
            val exposedHrRate = homerExposed.toDouble() / fieldCount
            val hrRateLift = if (baselineHrRate > 0.0) exposedHrRate / baselineHrRate else 1.0
            val homerAverage = homerAvailable.map { it.second }.average()
            val fieldAverage = available.map { it.second }.average()
            val averageDelta = homerAverage - fieldAverage

            // Strength rewards broad HR-hitter coverage first, then actual HR-rate lift, then the
            // mean separation from the field. One tiny niche split cannot become the #1 pattern.
            val liftComponent = ((hrRateLift - 1.0) / 1.25).coerceIn(0.0, 1.0)
            val deltaComponent = (averageDelta / 16.0).coerceIn(0.0, 1.0)
            val strength = (homerCoverage * 55.0 + liftComponent * 30.0 + deltaComponent * 15.0)
                .coerceIn(0.0, 100.0)

            val meaningful = (homerCoverage >= .35 && hrRateLift >= 1.05) ||
                (homerCoverage >= .55 && averageDelta >= 3.0)
            if (!meaningful) return@mapNotNull null

            CommonDenominatorSignal(
                key = def.key,
                label = def.label,
                threshold = def.threshold,
                homerCount = homerExposed,
                homerTotal = homerAvailable.size,
                fieldCount = fieldCount,
                fieldTotal = available.size,
                homerCoverage = homerCoverage,
                fieldCoverage = fieldCoverage,
                hrRateLift = hrRateLift.coerceIn(0.25, 4.0),
                homerAverage = homerAverage,
                fieldAverage = fieldAverage,
                strength = strength
            )
        }.sortedByDescending { it.strength }.take(5)

        fun greenLightCount(row: HitterSignalSnapshot): Int = patternSignalDefs.count { def ->
            val value = def.getter(row)
            value != null && value >= def.threshold
        }
        val homerGreen = homers.map(::greenLightCount).average()
        val fieldGreen = resolved.map(::greenLightCount).average()
        val homerConfidence = (homers.size / 12.0).coerceIn(0.0, 1.0)
        val fieldConfidence = (resolved.size / 160.0).coerceIn(0.0, 1.0)
        val confidence = (homerConfidence * .70 + fieldConfidence * .30).coerceIn(0.0, 1.0)

        return NightPatternProfile(
            date = previous.date,
            gradedHitters = resolved.size,
            homerHitters = homers.size,
            signals = signals,
            references = references,
            homerGreenLightsAverage = homerGreen,
            fieldGreenLightsAverage = fieldGreen,
            confidence = confidence
        )
    }

    private fun patternValues(candidate: HitterCandidate): Map<String, Double?> = mapOf(
        "seasonPower" to candidate.score.seasonPower,
        "contactProfile" to mustHavePowerScore(candidate),
        "recentPower" to candidate.score.recentPower,
        "powerPressure" to candidate.score.powerPressure,
        "pitcherMatchup" to candidate.score.pitcherMatchup,
        "pitchArsenalFit" to candidate.pitchArsenalMatch?.score,
        "platoon" to candidate.score.platoon,
        "environment" to candidate.score.environment
    )

    private fun referenceValues(reference: NightHomerReference): Map<String, Double?> = mapOf(
        "seasonPower" to reference.seasonPower,
        "contactProfile" to reference.contactProfile,
        "recentPower" to reference.recentPower,
        "powerPressure" to reference.powerPressure,
        "pitcherMatchup" to reference.pitcherMatchup,
        "pitchArsenalFit" to reference.pitchArsenalFit,
        "platoon" to reference.platoon,
        "environment" to reference.environment
    )

    private val profileEchoWeights = mapOf(
        "seasonPower" to 1.20,
        "contactProfile" to 1.15,
        "recentPower" to 0.95,
        "powerPressure" to 0.90,
        "pitcherMatchup" to 0.90,
        "pitchArsenalFit" to 1.15,
        "platoon" to 0.70,
        "environment" to 0.50
    )

    /**
     * Compares today's full pregame signal vector with an actual hitter who homered last night.
     * This is intentionally a similarity score rather than a "copy yesterday" rule: a player can
     * resemble a different HR archetype (established power, heating contact, arsenal edge, etc.)
     * even when that archetype was not the single most common trait across the entire HR group.
     */
    private fun profileEchoSimilarity(
        today: Map<String, Double?>,
        reference: NightHomerReference
    ): Double {
        val yesterday = referenceValues(reference)
        var weighted = 0.0
        var totalWeight = 0.0
        var usable = 0
        profileEchoWeights.forEach { (key, weight) ->
            val current = today[key]
            val prior = yesterday[key]
            if (current != null && prior != null) {
                val metricSimilarity = (100.0 - (current - prior).absoluteValue * 1.55)
                    .coerceIn(0.0, 100.0)
                weighted += metricSimilarity * weight
                totalWeight += weight
                usable++
            }
        }
        if (usable < 5 || totalWeight <= 0.0) return 0.0
        val base = weighted / totalWeight
        // A multi-HR night is a slightly stronger reference, but never enough to dominate the model.
        return (base + if (reference.homeRuns >= 2) 2.5 else 0.0).coerceIn(0.0, 100.0)
    }

    fun lastNightProfileEchoScore(candidate: HitterCandidate): Double {
        val pattern = _state.value.lastNightPattern
        if (pattern.references.size < 4) return 0.0
        val today = patternValues(candidate)
        val matches = pattern.references
            .map { reference -> profileEchoSimilarity(today, reference) }
            .filter { it > 0.0 }
            .sortedDescending()
            .take(3)
        if (matches.isEmpty()) return 0.0
        return when (matches.size) {
            1 -> matches[0]
            2 -> matches[0] * .68 + matches[1] * .32
            else -> matches[0] * .55 + matches[1] * .28 + matches[2] * .17
        }.coerceIn(0.0, 100.0)
    }

    fun lastNightClosestProfiles(candidate: HitterCandidate, limit: Int = 2): List<Pair<String, Int>> {
        val pattern = _state.value.lastNightPattern
        if (pattern.references.isEmpty()) return emptyList()
        val today = patternValues(candidate)
        return pattern.references
            .map { reference -> reference to profileEchoSimilarity(today, reference) }
            .filter { (_, score) -> score >= 58.0 }
            .sortedByDescending { (_, score) -> score }
            .take(limit.coerceIn(1, 3))
            .map { (reference, score) ->
                val label = if (reference.homeRuns >= 2) "${reference.playerName} (${reference.homeRuns} HR)" else reference.playerName
                label to score.roundToInt()
            }
    }

    /** 0-100 blend of common-denominator fit and direct profile similarity to last night's HR hitters. */
    fun lastNightPatternScore(candidate: HitterCandidate): Double {
        val pattern = _state.value.lastNightPattern
        if (!pattern.isUsable) return 0.0
        val values = patternValues(candidate)
        val usable = pattern.signals.mapNotNull { signal ->
            values[signal.key]?.let { value -> signal to value }
        }

        val commonScore = if (usable.size >= 2) {
            val totalWeight = usable.sumOf { (signal, _) -> signal.strength.coerceAtLeast(20.0) }
            if (totalWeight <= 0.0) 0.0 else {
                val weightedFit = usable.sumOf { (signal, value) ->
                    val relative = ((value - (signal.threshold - 18.0)) / 36.0 * 100.0).coerceIn(0.0, 100.0)
                    relative * signal.strength.coerceAtLeast(20.0)
                } / totalWeight
                val matchedWeight = usable.filter { (signal, value) -> value >= signal.threshold }
                    .sumOf { (signal, _) -> signal.strength.coerceAtLeast(20.0) }
                val matchedShare = matchedWeight / totalWeight
                (weightedFit * .62 + matchedShare * 100.0 * .38).coerceIn(0.0, 100.0)
            }
        } else 0.0

        val echoScore = lastNightProfileEchoScore(candidate)
        return when {
            commonScore > 0.0 && echoScore > 0.0 -> commonScore * .62 + echoScore * .38
            commonScore > 0.0 -> commonScore
            else -> echoScore
        }.coerceIn(0.0, 100.0)
    }

    fun lastNightPatternReasons(candidate: HitterCandidate): List<String> {
        val pattern = _state.value.lastNightPattern
        if (!pattern.isUsable) return emptyList()
        val values = patternValues(candidate)
        return pattern.signals
            .filter { signal -> (values[signal.key] ?: Double.NEGATIVE_INFINITY) >= signal.threshold }
            .sortedByDescending { it.strength }
            .take(3)
            .map { it.label }
    }

    private fun lastNightPatternAdjustment(candidate: HitterCandidate): Double {
        val pattern = _state.value.lastNightPattern
        if (!pattern.isUsable) return 0.0
        val score = lastNightPatternScore(candidate)
        val raw = when {
            score >= 88.0 -> 2.4
            score >= 80.0 -> 1.7
            score >= 72.0 -> 1.0
            score >= 64.0 -> 0.45
            else -> 0.0
        }
        // One night is evidence, not a new model. Confidence scales with the number of HR outcomes
        // and the size of yesterday's graded field, and the total effect is intentionally capped.
        return (raw * pattern.confidence).coerceIn(0.0, 2.4)
    }

    private fun outcomeLearningAdjustment(
        candidate: HitterCandidate,
        contactProfile: Double
    ): Double {
        val learning = _state.value.learningProfile
        var adjustment = 0.0

        if (learning.isActive) {
            val signals = mapOf(
                "recentPower" to candidate.score.recentPower,
                "powerPressure" to candidate.score.powerPressure,
                "pitcherMatchup" to candidate.score.pitcherMatchup,
                "environment" to candidate.score.environment,
                "seasonPower" to candidate.score.seasonPower,
                "platoon" to candidate.score.platoon,
                "contactProfile" to contactProfile,
                "pitchArsenalFit" to candidate.pitchArsenalMatch?.score
            )
            signals.forEach { (key, value) ->
                if (value == null || value < 65.0) return@forEach
                val learned = learning.metrics[key] ?: return@forEach
                if (learned.attempts < 20) return@forEach
                val reliability = ((learned.attempts - 20) / 100.0).coerceIn(0.15, 1.0)
                val effect = ((learned.lift - 1.0) * 0.75).coerceIn(-0.45, 0.65)
                adjustment += effect * reliability
            }
        }

        // A homer last night is already represented in recent contact/power. This tiny extra
        // confirmation only breaks close ties and prevents the model from double-counting heat.
        val previous = _state.value.board?.previousNight
        val lastNight = previous?.homers?.firstOrNull { it.playerId == candidate.player.id }
        if (lastNight != null && (candidate.score.powerPressure >= 55.0 || contactProfile >= 60.0)) {
            adjustment += if (lastNight.homeRuns >= 2) 1.1 else 0.6
        }

        return adjustment.coerceIn(-2.0, 2.5)
    }

    private fun cacheBoard(board: BoardData) {
        if (board.candidates.isEmpty()) return
        synchronized(boardCache) { boardCache[board.date] = board }
    }

    private fun switchToDate(next: LocalDate) {
        refreshJob?.cancel()
        ++refreshGeneration
        val cached = synchronized(boardCache) { boardCache[next] }
        mutate {
            it.copy(
                selectedDate = next,
                board = cached,
                isLoading = false,
                progress = if (cached != null) "Showing saved data" else "",
                error = null,
                selectedPlayerId = null,
                trackedLast10 = emptyMap(),
                trackedLast10Loading = emptySet(),
                postgameStats = emptyMap(),
                postgameStatsLoading = emptySet()
            )
        }
        refresh()
    }

    fun changeDate(days: Long) {
        val current = _state.value.selectedDate
        val minimum = LocalDate.now().minusDays(1)
        val requested = current.plusDays(days)
        val next = if (requested.isBefore(minimum)) minimum else requested
        if (next == current) return
        switchToDate(next)
    }

    fun setDate(date: LocalDate) {
        val minimum = LocalDate.now().minusDays(1)
        val next = if (date.isBefore(minimum)) minimum else date
        if (next == _state.value.selectedDate) return
        switchToDate(next)
    }

    fun toggleRemainingOnly() = mutate { it.copy(showRemainingOnly = !it.showRemainingOnly) }
    fun toggleOfficialOnly() = mutate { it.copy(officialLineupsOnly = !it.officialLineupsOnly) }
    fun setSortMode(mode: SortMode) = mutate { it.copy(sortMode = mode) }
    fun toggleAttackStrongOnly() = mutate { it.copy(attackStrongOnly = !it.attackStrongOnly) }

    /**
     * The v0.3 combo signal. This remains available as a building block, but v0.4 presents it
     * inside a simpler game-first experience instead of exposing many competing sort modes.
     */
    fun attackScore(candidate: HitterCandidate): Double =
        candidate.score.powerPressure * 0.45 +
            candidate.score.pitcherMatchup * 0.45 +
            candidate.score.recentPower * 0.10

    /**
     * A single recommendation score used for game rankings and the parlay generator.
     * It deliberately emphasizes "pressure + matchup", then checks the overall model and
     * environment so a hot hitter in a terrible spot does not automatically rise to the top.
     */
    /**
     * Sample-size-aware BvP adjustment. Strong history matters, but it is intentionally capped so
     * a 2-for-3 matchup cannot overpower current contact quality and the pitcher profile.
     */
    fun bvpAdjustment(candidate: HitterCandidate): Double {
        val bvp = candidate.vsPitcherStats ?: return 0.0
        val pa = bvp.plateAppearances
        if (pa < 5) return 0.0

        var raw = 0.0
        raw += when {
            (bvp.ops ?: 0.0) >= 1.050 -> 5.0
            (bvp.ops ?: 0.0) >= .900 -> 3.0
            (bvp.ops ?: 9.0) < .600 -> -2.0
            else -> 0.0
        }
        raw += when {
            bvp.homeRuns >= 3 -> 4.0
            bvp.homeRuns == 2 -> 3.0
            bvp.homeRuns == 1 -> 1.5
            else -> 0.0
        }
        raw += when {
            (bvp.avg ?: 0.0) >= .350 -> 1.5
            (bvp.avg ?: 0.0) >= .300 -> 0.75
            else -> 0.0
        }

        val reliability = when {
            pa >= 20 -> 1.0
            pa >= 12 -> .85
            pa >= 8 -> .70
            else -> .55
        }
        return (raw * reliability).coerceIn(-4.0, 8.0)
    }

    fun mustHaveMetrics(candidate: HitterCandidate): MustHaveMetrics {
        val key = "${candidate.game.gamePk}:${candidate.player.id}"
        return mustHaveCache.getOrPut(key) {
            scoringModel.mustHaveMetrics(candidate.player, candidate.seasonStats, candidate.recentBattedBalls)
        }
    }

    /**
     * Recent "must-have" power profile blended toward season power when the recent BBE sample is
     * small. This prevents one or two tracked balls from hijacking the daily ranking.
     */
    fun mustHavePowerScore(candidate: HitterCandidate): Double {
        val metrics = mustHaveMetrics(candidate)
        return metrics.score * metrics.confidence +
            candidate.score.seasonPower * (1.0 - metrics.confidence)
    }

    /**
     * Recent swing-and-miss score derived directly from MLB Gameday pitch descriptions.
     * Lower whiff rates are better. Small recent samples are blended back toward season K%.
     */
    fun swingMissScore(candidate: HitterCandidate): Double {
        val sample = candidate.recentPlateDiscipline
        val recent = sample.whiffRate?.let { rate -> inverseScale(rate, .14, .38) }
        val pa = candidate.seasonStats.plateAppearances
        val seasonK = if (pa > 0) candidate.seasonStats.strikeouts.toDouble() / pa else null
        val seasonContact = seasonK?.let { inverseScale(it, .14, .34) } ?: 50.0
        if (recent == null) return seasonContact
        val confidence = (sample.swings / 35.0).coerceIn(.20, 1.0)
        return recent * confidence + seasonContact * (1.0 - confidence)
    }

    fun recentWhiffRate(candidate: HitterCandidate): Double? = candidate.recentPlateDiscipline.whiffRate

    /**
     * Power Pressure now arrives from HrScoringModel already regressed for recent BBE sample size.
     * Keep this helper so ranking/UI code has one semantic place to consume the calibrated signal.
     */
    fun reliablePowerPressure(candidate: HitterCandidate): Double = candidate.score.powerPressure

    /**
     * How closely today's opposing pitcher arsenal matches the pitch types this hitter has
     * homered against this season. Missing/small samples blend back toward a neutral 50.
     */
    fun pitchArsenalFitScore(candidate: HitterCandidate): Double =
        candidate.pitchArsenalMatch?.score ?: 50.0

    /**
     * Count teammates at 10%+ recent barrel-proxy rate to create a modest lineup-power context score.
     */
    fun teamBarrelDepthScore(candidate: HitterCandidate, state: AppUiState = _state.value): Double {
        val teammates = state.board?.candidates.orEmpty().filter {
            it.game.gamePk == candidate.game.gamePk && it.team.id == candidate.team.id
        }
        if (teammates.isEmpty()) return 50.0
        val qualified = teammates.count { mate ->
            val m = mustHaveMetrics(mate)
            m.battedBallCount >= 3 && (m.barrelPct ?: 0.0) >= 10.0
        }
        return (35.0 + qualified * 11.0).coerceIn(25.0, 100.0)
    }

    /**
     * Independent HR Chase signal lens: hitter-first recent form, barrels/hard-contact/air-ball quality,
     * swing-and-miss, pitcher resistance, handedness and lineup-wide barrel depth.
     */
    fun signalLensScore(candidate: HitterCandidate, state: AppUiState = _state.value): Double {
        val profile = mustHavePowerScore(candidate)
        val seasonPower = candidate.score.seasonPower
        val pressure = reliablePowerPressure(candidate)
        val discipline = swingMissScore(candidate)
        val matchup = candidate.score.pitcherMatchup
        val platoon = candidate.score.platoon
        val depth = teamBarrelDepthScore(candidate, state)
        val environment = candidate.score.environment
        val arsenalFit = candidate.pitchArsenalMatch?.score

        val baseWithoutArsenal = profile * .22 +
            seasonPower * .13 +
            pressure * .13 +
            discipline * .08 +
            matchup * .16 +
            platoon * .07 +
            depth * .06 +
            environment * .05
        // Arsenal Fit v2 is now a real Statcast matchup input rather than an often-missing
        // enrichment, so it receives a meaningful 10% of this signal lens. Missing data still
        // redistributes the weight rather than fabricating a neutral observation.
        val raw = if (arsenalFit != null) baseWithoutArsenal + arsenalFit * .10
            else baseWithoutArsenal / .90
        return (raw + bvpAdjustment(candidate) * .40).coerceIn(0.0, 100.0)
    }

    fun signalTier(candidate: HitterCandidate): String = when {
        signalLensScore(candidate) >= 78.0 -> "TIER 1"
        signalLensScore(candidate) >= 68.0 -> "TIER 2"
        signalLensScore(candidate) >= 58.0 -> "TIER 3"
        else -> "WATCH"
    }

    fun signalReasons(candidate: HitterCandidate): List<String> {
        val metrics = mustHaveMetrics(candidate)
        return buildList {
            if ((metrics.barrelPct ?: 0.0) >= 12.0) add("BARREL FORM")
            if ((metrics.hardHitPct ?: 0.0) >= 48.0) add("HARD HIT")
            if ((metrics.flyBallPct ?: 0.0) >= 35.0) add("AIR BALL")
            recentWhiffRate(candidate)?.let { if (it <= .22 && candidate.recentPlateDiscipline.swings >= 10) add("LOW WHIFF") }
            if (reliablePowerPressure(candidate) >= 70.0) add("RECENT PRESSURE")
            if (candidate.score.pitcherMatchup >= 70.0) add("PITCHER EDGE")
            val arsenal = candidate.pitchArsenalMatch
            if (arsenal != null && arsenal.score >= 70.0 && arsenal.confidence >= .30) add("ARSENAL FIT")
            if (candidate.score.platoon >= 70.0) add("PLATOON EDGE")
            if (teamBarrelDepthScore(candidate) >= 68.0) add("LINEUP POWER")
        }.take(4)
    }

    /**
     * Calibrated Daily Target Score. The old version blended two composites that contained most of
     * the same inputs, accidentally double-counting recent form and matchup. This version uses one
     * transparent composite, then applies small convergence bonuses/penalties.
     *
     * Postmortem lesson from Aug. 24: small-sample recent contact was able to keep light-power bats
     * too high against strong starters, while established power needed more direct weight.
     */
    fun targetScore(candidate: HitterCandidate): Double {
        val metrics = mustHaveMetrics(candidate)
        val profile = mustHavePowerScore(candidate)
        val seasonPower = candidate.score.seasonPower
        val pressure = reliablePowerPressure(candidate)
        val matchup = candidate.score.pitcherMatchup
        val platoon = candidate.score.platoon
        val discipline = swingMissScore(candidate)
        val depth = teamBarrelDepthScore(candidate)
        val environment = candidate.score.environment
        val lineup = candidate.score.lineup
        val arsenal = candidate.pitchArsenalMatch

        val baseWithoutArsenal = profile * .22 +
            seasonPower * .15 +
            pressure * .11 +
            matchup * .14 +
            platoon * .07 +
            discipline * .06 +
            depth * .04 +
            environment * .05 +
            lineup * .04
        // Arsenal Fit is now 12% of the daily ranking when measured. The v2 score already
        // regresses small samples toward neutral, so this is meaningful without letting one
        // pitch-type split dominate the entire target board.
        var raw = if (arsenal != null) baseWithoutArsenal + arsenal.score * .12
            else baseWithoutArsenal / .88

        // Reward convergence instead of one giant signal. This is intentionally small so it cannot
        // manufacture a play; it only separates hitters with several independent green lights.
        val greenLights = listOfNotNull(
            seasonPower.takeIf { it >= 65.0 },
            profile.takeIf { it >= 65.0 },
            matchup.takeIf { it >= 62.0 },
            platoon.takeIf { it >= 62.0 },
            arsenal?.score?.takeIf { arsenal.confidence >= .35 && it >= 65.0 }
        ).size
        raw += when {
            greenLights >= 4 -> 3.0
            greenLights == 3 -> 1.5
            else -> 0.0
        }

        // High-confidence pitch-type mismatches should actually move the ranking. A hitter who
        // crushes the pitch mix this starter lives on gets a small bonus; a severe mismatch gets
        // a symmetric penalty. This happens after the 12% base weight and is intentionally capped.
        if (arsenal != null && arsenal.confidence >= .45) {
            raw += when {
                arsenal.score >= 78.0 -> 2.5
                arsenal.score >= 70.0 -> 1.0
                arsenal.score <= 34.0 -> -2.5
                arsenal.score <= 42.0 -> -1.0
                else -> 0.0
            }
        }

        // Strong-starter resistance: a weak season-power bat should not remain a top target merely
        // because 3-5 recent BBE looked hot. Established sluggers and well-supported recent profiles
        // are allowed to survive this penalty because elite hitters can beat good pitching.
        val supportedRecentBreakout = metrics.battedBallCount >= 8 && profile >= 68.0
        if (!supportedRecentBreakout) {
            raw -= when {
                matchup < 40.0 && seasonPower < 62.0 -> 7.0
                matchup < 47.0 && seasonPower < 55.0 -> 4.0
                else -> 0.0
            }
            if (platoon < 35.0 && seasonPower < 62.0) raw -= 2.0
        }

        // Tiny-sample spike protection. A very high pressure number with fewer than six tracked BBE
        // now needs a credible season power floor to stay near the top of the slate.
        if (metrics.battedBallCount < 6 && candidate.score.powerPressure >= 72.0 && seasonPower < 55.0) {
            raw -= 3.0
        }

        // Established power gets a modest tie-breaker. This specifically prevents elite HR bats from
        // being buried by a short cold stretch without turning season totals into the whole model.
        raw += when {
            seasonPower >= 85.0 -> 3.0
            seasonPower >= 75.0 -> 1.5
            else -> 0.0
        }

        raw += bvpAdjustment(candidate) * .40
        raw += outcomeLearningAdjustment(candidate, profile)
        raw += lastNightPatternAdjustment(candidate)
        return raw.coerceIn(0.0, 100.0)
    }

    fun pickScore(candidate: HitterCandidate): Double = targetScore(candidate)

    /** Rolling seven-day batting line used by the Hot tab. The date-range data comes from one
     * league-wide MLB StatsAPI request, so this does not add one network request per player. */
    fun recentWeekStats(candidate: HitterCandidate, state: AppUiState = _state.value): RecentHittingStats? =
        state.board?.recentWeekStats?.get(candidate.player.id)

    fun recentNearHrCount(candidate: HitterCandidate): Int =
        candidate.recentBattedBalls.count(scoringModel::isNearHomeRun)

    fun recentEliteNearHrCount(candidate: HitterCandidate): Int =
        candidate.recentBattedBalls.count(scoringModel::isEliteNearHomeRun)

    /**
     * Hot Streak Score is deliberately separate from the daily HR Target Score. It answers a
     * different question: who has actually been producing over the last seven days, and is that
     * production supported by contact quality rather than box-score luck alone?
     */
    fun hotStreakScore(candidate: HitterCandidate, state: AppUiState = _state.value): Double {
        val stats = recentWeekStats(candidate, state) ?: return 0.0
        if (stats.plateAppearances < 5) return 0.0
        val metrics = mustHaveMetrics(candidate)

        val ops = stats.ops?.let { scaleForHot(it, .620, 1.250) } ?: 45.0
        val iso = stats.iso?.let { scaleForHot(it, .080, .420) } ?: 45.0
        val avg = stats.avg?.let { scaleForHot(it, .180, .400) } ?: 45.0
        val hrs = scaleForHot(stats.homeRuns.toDouble(), 0.0, 4.0)
        val xbh = scaleForHot(stats.extraBaseHits.toDouble(), 0.0, 7.0)
        val production = scaleForHot((stats.runs + stats.rbi).toDouble(), 1.0, 16.0)
        val contact = stats.strikeoutRate?.let { inverseScale(it, .12, .34) } ?: 50.0
        val profile = mustHavePowerScore(candidate)
        val pressure = candidate.score.powerPressure

        val raw = ops * .20 +
            iso * .18 +
            hrs * .16 +
            avg * .10 +
            xbh * .08 +
            production * .06 +
            contact * .07 +
            profile * .10 +
            pressure * .05

        // Seven-day samples are naturally small. Keep tiny 5-PA cameos from jumping established
        // hot hitters, while allowing regulars with 20-30 PA to express the full score.
        val confidence = ((stats.plateAppearances - 4) / 22.0).coerceIn(.25, 1.0)
        return (50.0 * (1.0 - confidence) + raw * confidence).coerceIn(0.0, 100.0)
    }

    fun hotCandidates(
        limit: Int = 20,
        state: AppUiState = _state.value
    ): List<HitterCandidate> = eligibleCandidates(state)
        .filter { (recentWeekStats(it, state)?.plateAppearances ?: 0) >= 5 }
        .sortedWith(
            compareByDescending<HitterCandidate> { hotStreakScore(it, state) }
                .thenByDescending { recentWeekStats(it, state)?.homeRuns ?: 0 }
                .thenByDescending { recentWeekStats(it, state)?.ops ?: 0.0 }
                .thenByDescending(::targetScore)
        )
        .take(limit)

    fun hotStreakReasons(candidate: HitterCandidate, state: AppUiState = _state.value): List<String> {
        val stats = recentWeekStats(candidate, state) ?: return emptyList()
        val metrics = mustHaveMetrics(candidate)
        val near = recentNearHrCount(candidate)
        val eliteNear = recentEliteNearHrCount(candidate)
        return buildList {
            if (stats.homeRuns > 0) add("${stats.homeRuns} HR in the last 7 days")
            stats.ops?.let { if (it >= .850) add("${"%.3f".format(it)} OPS with ${stats.hits} hits") }
            stats.avg?.let { avg -> stats.slg?.let { slg -> if (avg >= .280 || slg >= .500) add("${"%.3f".format(avg)} AVG / ${"%.3f".format(slg)} SLG") } }
            if (stats.extraBaseHits >= 2) add("${stats.extraBaseHits} extra-base hits • ${stats.rbi} RBI")
            if (eliteNear > 0) add("$eliteNear elite near-HR miss${if (eliteNear == 1) "" else "es"} recently")
            else if (near > 0) add("$near recent near-HR miss${if (near == 1) "" else "es"}")
            if ((metrics.barrelPct ?: 0.0) >= 10.0 || (metrics.hardHitPct ?: 0.0) >= 45.0) {
                val parts = buildList {
                    metrics.barrelPct?.let { add("${"%.1f".format(it)}% barrel") }
                    metrics.hardHitPct?.let { add("${"%.1f".format(it)}% hard-hit") }
                }
                if (parts.isNotEmpty()) add(parts.joinToString(" • "))
            }
            metrics.maxExitVelocity?.let { if (it >= 103.0) add("Max EV ${"%.1f".format(it)} mph") }
            stats.strikeoutRate?.let { if (it <= .18 && stats.plateAppearances >= 10) add("Low ${"%.1f".format(it * 100)}% K rate") }
        }.distinct().take(5)
    }


    /** Previous three completed calendar days. This is intentionally separate from the seven-day
     * Hot board: the goal is to catch acceleration before a hitter becomes an obvious hot name. */
    fun recentThreeDayStats(candidate: HitterCandidate, state: AppUiState = _state.value): RecentHittingStats? =
        state.board?.recentThreeDayStats?.get(candidate.player.id)

    fun lastThreeBattedBalls(candidate: HitterCandidate, state: AppUiState = _state.value) =
        candidate.recentBattedBalls.filter { ball ->
            val start = state.selectedDate.minusDays(3)
            val end = state.selectedDate.minusDays(1)
            !ball.gameDate.isBefore(start) && !ball.gameDate.isAfter(end)
        }

    fun heatingMetrics(candidate: HitterCandidate, state: AppUiState = _state.value): MustHaveMetrics {
        val key = "${state.selectedDate}:${candidate.game.gamePk}:${candidate.player.id}"
        return heatingMetricsCache.getOrPut(key) {
            scoringModel.mustHaveMetrics(candidate.player, candidate.seasonStats, lastThreeBattedBalls(candidate, state))
        }
    }

    fun heatingNearHrCount(candidate: HitterCandidate, state: AppUiState = _state.value): Int =
        lastThreeBattedBalls(candidate, state).count(scoringModel::isNearHomeRun)

    fun heatingEliteNearHrCount(candidate: HitterCandidate, state: AppUiState = _state.value): Int =
        lastThreeBattedBalls(candidate, state).count(scoringModel::isEliteNearHomeRun)

    private fun heatingWhiffScore(candidate: HitterCandidate): Double {
        val sample = candidate.last3PlateDiscipline
        val recent = sample.whiffRate?.let { inverseScale(it, .12, .38) } ?: 50.0
        val confidence = (sample.swings / 18.0).coerceIn(.25, 1.0)
        return recent * confidence + 50.0 * (1.0 - confidence)
    }

    fun heatingAcceleration(candidate: HitterCandidate, state: AppUiState = _state.value): Double {
        val three = recentThreeDayStats(candidate, state) ?: return 50.0
        val week = recentWeekStats(candidate, state) ?: return 55.0
        val threeOps = three.ops
        val weekOps = week.ops
        val threeIso = three.iso
        val weekIso = week.iso
        val opsDelta = if (threeOps != null && weekOps != null) threeOps - weekOps else 0.0
        val isoDelta = if (threeIso != null && weekIso != null) threeIso - weekIso else 0.0
        return (scaleForHot(opsDelta, -.12, .38) * .70 + scaleForHot(isoDelta, -.08, .24) * .30)
            .coerceIn(0.0, 100.0)
    }

    /**
     * Three-day Emerging Heat score. It is designed to find hitters whose process is improving
     * before a full seven-day box-score streak makes them obvious. Contact quality and near-HR
     * pressure matter more here than raw HR totals.
     */
    fun heatingScore(candidate: HitterCandidate, state: AppUiState = _state.value): Double {
        val stats = recentThreeDayStats(candidate, state) ?: return 0.0
        if (stats.plateAppearances < 4) return 0.0
        val metrics = heatingMetrics(candidate, state)

        val ops = stats.ops?.let { scaleForHot(it, .560, 1.250) } ?: 42.0
        val avg = stats.avg?.let { scaleForHot(it, .150, .400) } ?: 42.0
        val iso = stats.iso?.let { scaleForHot(it, .040, .420) } ?: 42.0
        val hits = scaleForHot(stats.hits.toDouble(), 0.0, 6.0)
        val xbh = scaleForHot(stats.extraBaseHits.toDouble(), 0.0, 4.0)
        val box = ops * .34 + avg * .18 + iso * .24 + hits * .12 + xbh * .12

        val barrel = metrics.barrelPct?.let { scaleForHot(it, 2.0, 24.0) } ?: 45.0
        val hardHit = metrics.hardHitPct?.let { scaleForHot(it, 30.0, 65.0) } ?: 45.0
        val sweet = metrics.sweetSpotPct?.let { scaleForHot(it, 18.0, 55.0) } ?: 45.0
        val maxEv = metrics.maxExitVelocity?.let { scaleForHot(it, 96.0, 112.0) } ?: 45.0
        val near = when (heatingNearHrCount(candidate, state)) {
            0 -> 40.0
            1 -> 76.0
            2 -> 92.0
            else -> 100.0
        }
        val contactQuality = barrel * .24 + hardHit * .27 + sweet * .14 + maxEv * .19 + near * .16

        val raw = contactQuality * .32 +
            box * .24 +
            candidate.score.powerPressure * .15 +
            heatingWhiffScore(candidate) * .10 +
            heatingAcceleration(candidate, state) * .12 +
            targetScore(candidate) * .07

        val paConfidence = ((stats.plateAppearances - 3) / 10.0).coerceIn(.35, 1.0)
        val bbeConfidence = (metrics.battedBallCount / 5.0).coerceIn(.35, 1.0)
        val confidence = (paConfidence * .60 + bbeConfidence * .40).coerceIn(.35, 1.0)
        return (50.0 * (1.0 - confidence) + raw * confidence).coerceIn(0.0, 100.0)
    }

    fun heatingSignalCount(candidate: HitterCandidate, state: AppUiState = _state.value): Int {
        val stats = recentThreeDayStats(candidate, state) ?: return 0
        val metrics = heatingMetrics(candidate, state)
        var count = 0
        if ((stats.ops ?: 0.0) >= .760 || (stats.avg ?: 0.0) >= .280 || stats.hits >= 3) count++
        if ((metrics.hardHitPct ?: 0.0) >= 45.0) count++
        if ((metrics.barrelPct ?: 0.0) >= 10.0 || (metrics.maxExitVelocity ?: 0.0) >= 103.0) count++
        if (heatingNearHrCount(candidate, state) > 0) count++
        if (candidate.score.powerPressure >= 65.0) count++
        val whiff = candidate.last3PlateDiscipline.whiffRate
        if (whiff != null && whiff <= .24 && candidate.last3PlateDiscipline.swings >= 6) count++
        if (heatingAcceleration(candidate, state) >= 62.0) count++
        return count
    }

    fun heatingCandidates(
        limit: Int = 20,
        state: AppUiState = _state.value
    ): List<HitterCandidate> = eligibleCandidates(state)
        .filter { (recentThreeDayStats(it, state)?.plateAppearances ?: 0) >= 4 }
        .filter { heatingSignalCount(it, state) >= 2 }
        .filter { heatingScore(it, state) >= 55.0 }
        // Keep the board focused on emerging heat instead of duplicating obvious established hot streaks.
        .filter {
            val week = recentWeekStats(it, state)
            !(hotStreakScore(it, state) >= 82.0 && (week?.homeRuns ?: 0) >= 2)
        }
        .sortedWith(
            compareByDescending<HitterCandidate> { heatingScore(it, state) }
                .thenByDescending { heatingSignalCount(it, state) }
                .thenByDescending { heatingAcceleration(it, state) }
                .thenByDescending { heatingMetrics(it, state).maxExitVelocity ?: 0.0 }
                .thenByDescending(::targetScore)
        )
        .take(limit)

    fun heatingReasons(candidate: HitterCandidate, state: AppUiState = _state.value): List<String> {
        val stats = recentThreeDayStats(candidate, state) ?: return emptyList()
        val week = recentWeekStats(candidate, state)
        val metrics = heatingMetrics(candidate, state)
        val near = heatingNearHrCount(candidate, state)
        val eliteNear = heatingEliteNearHrCount(candidate, state)
        return buildList {
            stats.ops?.let { ops ->
                val weekOps = week?.ops
                if (weekOps != null && ops - weekOps >= .100) {
                    add("3-day OPS ${"%.3f".format(ops)} • up ${"%.3f".format(ops - weekOps)} versus 7-day form")
                } else if (ops >= .800) {
                    add("3-day OPS ${"%.3f".format(ops)} with ${stats.hits} hits")
                }
                Unit
            }
            stats.avg?.let { if (it >= .280 || stats.hits >= 3) add("${stats.hits}-for-${stats.atBats} (${"%.3f".format(it)}) over the last 3 days") }
            if (stats.extraBaseHits > 0) add("${stats.extraBaseHits} XBH • ${stats.homeRuns} HR • ${stats.rbi} RBI in 3 days")
            if (eliteNear > 0) add("$eliteNear elite near-HR miss${if (eliteNear == 1) "" else "es"} in the 3-day window")
            else if (near > 0) add("$near near-HR miss${if (near == 1) "" else "es"} in the 3-day window")
            val quality = buildList {
                metrics.hardHitPct?.let { if (it >= 40.0) add("${"%.1f".format(it)}% hard-hit") }
                metrics.barrelPct?.let { if (it >= 8.0) add("${"%.1f".format(it)}% barrel") }
                metrics.sweetSpotPct?.let { if (it >= 30.0) add("${"%.1f".format(it)}% sweet spot") }
            }
            if (quality.isNotEmpty()) add(quality.joinToString(" • "))
            metrics.maxExitVelocity?.let { if (it >= 101.0) add("3-day max EV ${"%.1f".format(it)} mph") }
            candidate.last3PlateDiscipline.whiffRate?.let {
                if (it <= .24 && candidate.last3PlateDiscipline.swings >= 6) {
                    add("Only ${"%.1f".format(it * 100)}% whiffs across ${candidate.last3PlateDiscipline.swings} swings")
                }
            }
            if (candidate.score.powerPressure >= 65.0) add("Power Pressure ${candidate.score.powerPressure.roundToInt()} — HR-quality contact is building")
        }.distinct().take(6)
    }

    private fun scaleForHot(value: Double, low: Double, high: Double): Double {
        if (high <= low) return 50.0
        return (((value - low) / (high - low)) * 100.0).coerceIn(0.0, 100.0)
    }

    fun topTargets(
        limit: Int = 15,
        state: AppUiState = _state.value
    ): List<HitterCandidate> = eligibleCandidates(state)
        .sortedWith(
            compareByDescending<HitterCandidate>(::targetScore)
                .thenByDescending(::signalLensScore)
                .thenByDescending(::mustHavePowerScore)
                .thenByDescending { it.score.pitcherMatchup }
                .thenByDescending { it.score.powerPressure }
        )
        .take(limit)

    fun selectPlayer(id: Int?) = mutate { it.copy(selectedPlayerId = id) }

    fun updateWeights(weights: ScoreWeights) {
        prefs.saveWeights(weights)
        synchronized(boardCache) {
            val rescored = boardCache.mapValues { (_, board) -> repository.rescore(board, weights) }
            boardCache.clear()
            boardCache.putAll(rescored)
        }
        mutate { s ->
            val rescored = s.board?.let { repository.rescore(it, weights) }
            s.copy(weights = weights, board = rescored)
        }
    }

    fun resetWeights() = updateWeights(ScoreWeights())

    fun toggleTracked(candidate: HitterCandidate) {
        val date = _state.value.selectedDate
        val existing = _state.value.tracked
        val keyMatch: (TrackedPick) -> Boolean = { it.playerId == candidate.player.id && it.date == date }
        val next = if (existing.any(keyMatch)) {
            existing.filterNot(keyMatch)
        } else {
            existing + TrackedPick(
                playerId = candidate.player.id,
                playerName = candidate.player.name,
                teamName = candidate.team.name,
                date = date,
                scoreAtTrack = candidate.score.total,
                trackedAt = Instant.now()
            )
        }
        prefs.saveTracked(next)
        mutate { it.copy(tracked = next) }
    }

    /**
     * Lazily load exact game lines for yesterday's Top 15. This never blocks the main board: the
     * postgame cards fill in as MLB game-log data arrives.
     */
    fun loadPostgameTargetStats() {
        val snapshot = _state.value
        if (snapshot.selectedDate != LocalDate.now().minusDays(1)) return
        val targets = topTargets(15, snapshot)
        if (targets.isEmpty()) return

        viewModelScope.launch {
            for (candidate in targets) {
                val id = candidate.player.id
                val key = "$id:${snapshot.selectedDate}"
                if (postgameStatsCache.containsKey(key)) {
                    val cached = postgameStatsCache[key]
                    if (cached != null) mutate { current ->
                        if (current.selectedDate == snapshot.selectedDate) current.copy(
                            postgameStats = current.postgameStats + (id to cached),
                            postgameStatsLoading = current.postgameStatsLoading - id
                        ) else current
                    }
                    continue
                }
                if (id in _state.value.postgameStatsLoading) continue
                mutate { current -> current.copy(postgameStatsLoading = current.postgameStatsLoading + id) }
                val stats = runCatching { repository.fetchPlayerGameStats(id, snapshot.selectedDate) }.getOrNull()
                postgameStatsCache[key] = stats
                mutate { current ->
                    if (current.selectedDate != snapshot.selectedDate) current
                    else current.copy(
                        postgameStats = if (stats != null) current.postgameStats + (id to stats) else current.postgameStats,
                        postgameStatsLoading = current.postgameStatsLoading - id
                    )
                }
            }
        }
    }

    fun postgameReview(candidate: HitterCandidate, stats: RecentHittingStats?): PostgameReview {
        val balls = candidate.todayBattedBalls
        val measuredHr = maxOf(stats?.homeRuns ?: 0, balls.count { it.isHomeRun })
        val hardest = balls.mapNotNull { it.exitVelocity }.maxOrNull()
        val eliteNear = balls.filter(scoringModel::isEliteNearHomeRun).maxByOrNull { it.distanceFt ?: 0.0 }
        val near = balls.filter(scoringModel::isNearHomeRun).maxByOrNull { it.distanceFt ?: 0.0 }
        val barrels = balls.count(scoringModel::isBarrelProxy)
        val hardHits = balls.count(scoringModel::isHardHit)
        val matchup = candidate.score.pitcherMatchup
        val pitcher = candidate.opponentPitcher

        val resultLine = when {
            stats != null -> buildString {
                append("${stats.hits}-for-${stats.atBats}")
                append(" • ${stats.homeRuns} HR")
                if (stats.extraBaseHits > stats.homeRuns) append(" • ${stats.extraBaseHits} XBH")
                append(" • ${stats.runs} R • ${stats.rbi} RBI • ${stats.strikeouts} K")
                hardest?.let { append(" • ${"%.1f".format(it)} max EV") }
            }
            else -> "${balls.size} tracked BBE${hardest?.let { " • ${"%.1f".format(it)} max EV" } ?: ""}"
        }

        if (measuredHr > 0) return PostgameReview(
            label = "MODEL HIT",
            explanation = "The target converted. The pregame power/matchup signals produced an actual home run.",
            resultLine = resultLine
        )
        if (eliteNear != null) return PostgameReview(
            label = "GOOD READ • JUST MISSED",
            explanation = "He generated elite home-run-quality contact but the ball stayed in the park. ${contactDetail(eliteNear)} This is process-positive and should not be treated like a bad model read.",
            resultLine = resultLine
        )
        if (near != null) return PostgameReview(
            label = "GOOD READ • NEAR-HR",
            explanation = "The hitter produced a legitimate near-home-run contact. ${contactDetail(near)} The HR result missed, but the underlying contact supported the pick.",
            resultLine = resultLine
        )
        if (barrels > 0) return PostgameReview(
            label = "BARREL • NO HR",
            explanation = "He found the barrel ($barrels barrel-proxy contact${if (barrels == 1) "" else "s"}) but did not get the home-run outcome. That is more variance than a complete miss.",
            resultLine = resultLine
        )
        if (stats != null && (stats.hits >= 2 || stats.extraBaseHits > 0 || stats.runs + stats.rbi >= 2)) return PostgameReview(
            label = "GOOD NIGHT • NO HR",
            explanation = "He was productive offensively, so the hitter-form signal was not necessarily wrong; the production simply came without a home run.",
            resultLine = resultLine
        )
        if (matchup < 45.0) {
            val pitcherText = pitcher?.let { p ->
                val details = buildList {
                    p.seasonStats.era?.let { add("${"%.2f".format(it)} ERA") }
                    p.seasonStats.hrPer9?.let { add("${"%.2f".format(it)} HR/9") }
                    p.seasonStats.strikeoutRate?.let { add("${(it * 100).roundToInt()}% K") }
                }.joinToString(" • ")
                "${p.person.name}${if (details.isNotBlank()) " ($details)" else ""}"
            } ?: "the opposing starter"
            return PostgameReview(
                label = "MATCHUP-DRIVEN MISS",
                explanation = "The model already rated the pitcher matchup only ${matchup.roundToInt()}. $pitcherText was a real resistance signal, so this target should have been pushed lower unless the hitter's power signals were exceptional.",
                resultLine = resultLine
            )
        }
        if (stats != null && stats.strikeouts >= 2) return PostgameReview(
            label = "BAD NIGHT • SWING/MISS",
            explanation = "This looks more like a poor individual night than a near miss: ${stats.strikeouts} strikeouts and no HR-quality contact. Swing-and-miss should count against similar profiles when the supporting power signals are only average.",
            resultLine = resultLine
        )
        if (stats != null && stats.hits == 0) return PostgameReview(
            label = "QUIET NIGHT",
            explanation = "He never got going offensively and did not generate a qualifying near-HR/barrel signal. This is a true miss rather than a good process result.",
            resultLine = resultLine
        )
        if (hardHits > 0) return PostgameReview(
            label = "HARD CONTACT • NO HR",
            explanation = "He made $hardHits hard-hit contact${if (hardHits == 1) "" else "s"}, but none reached near-HR quality. The bat was not dead, but the HR-specific read was too optimistic.",
            resultLine = resultLine
        )
        return PostgameReview(
            label = "MODEL MISS",
            explanation = "No home run and no strong contact evidence supported the pick after the game. Treat this as a full miss and use it when calibrating similar profiles.",
            resultLine = resultLine
        )
    }

    private fun contactDetail(ball: com.ckz.hrchase.data.BattedBall): String = buildString {
        ball.exitVelocity?.let { append("${"%.1f".format(it)} mph") }
        ball.launchAngle?.let { if (isNotEmpty()) append(" / "); append("${it.roundToInt()}°") }
        ball.distanceFt?.let { if (isNotEmpty()) append(" / "); append("${it.roundToInt()} ft") }
        if (isNotEmpty()) append(".")
    }

    fun loadTrackedLast10Stats() {
        val snapshot = _state.value
        val picks = snapshot.tracked.filter { it.date == snapshot.selectedDate }
        if (picks.isEmpty()) return

        // Never include an in-progress/future game in the recent-form summary. For today and future
        // boards, use yesterday as the cutoff. When reviewing yesterday, that completed game can be
        // included in the rolling last-10 snapshot.
        val lastCompletedDate = LocalDate.now().minusDays(1)
        val throughDate = minOf(snapshot.selectedDate, lastCompletedDate)

        picks.forEach { pick ->
            val key = "${pick.playerId}:$throughDate"
            if (trackedLast10Cache.containsKey(key)) {
                val cached = trackedLast10Cache[key]
                if (cached != null && snapshot.trackedLast10[pick.playerId] != cached) {
                    mutate { current ->
                        if (current.selectedDate == snapshot.selectedDate) {
                            current.copy(trackedLast10 = current.trackedLast10 + (pick.playerId to cached))
                        } else current
                    }
                }
                return@forEach
            }
            if (pick.playerId in _state.value.trackedLast10Loading) return@forEach

            mutate { current ->
                current.copy(trackedLast10Loading = current.trackedLast10Loading + pick.playerId)
            }
            viewModelScope.launch {
                val stats = runCatching {
                    repository.fetchPlayerLast10Stats(pick.playerId, throughDate)
                }.getOrNull()
                trackedLast10Cache[key] = stats
                mutate { current ->
                    if (current.selectedDate != snapshot.selectedDate) {
                        current.copy(trackedLast10Loading = current.trackedLast10Loading - pick.playerId)
                    } else {
                        current.copy(
                            trackedLast10 = if (stats != null) {
                                current.trackedLast10 + (pick.playerId to stats)
                            } else current.trackedLast10,
                            trackedLast10Loading = current.trackedLast10Loading - pick.playerId
                        )
                    }
                }
            }
        }
    }

    fun clearTrackedForSelectedDate() {
        val date = _state.value.selectedDate
        val next = _state.value.tracked.filterNot { it.date == date }
        prefs.saveTracked(next)
        mutate { it.copy(tracked = next, trackedLast10 = emptyMap(), trackedLast10Loading = emptySet()) }
    }

    private fun inverseScale(value: Double, good: Double, bad: Double): Double {
        if (bad <= good) return 50.0
        return (100.0 - ((value - good) / (bad - good) * 100.0)).coerceIn(0.0, 100.0)
    }

    private fun mutate(block: (AppUiState) -> AppUiState) {
        synchronized(stateLock) {
            _state.value = block(_state.value)
        }
    }

    /** Base candidate set shared by Games and Parlays. */
    fun eligibleCandidates(state: AppUiState = _state.value): List<HitterCandidate> {
        val board = state.board ?: return emptyList()
        val nowDate = LocalDate.now()
        return board.candidates.asSequence()
            .filter { c ->
                if (!state.showRemainingOnly || board.date != nowDate) true
                else !c.game.status.equals("Final", true)
            }
            .filter { c -> !state.officialLineupsOnly || c.lineupOfficial }
            .toList()
    }

    fun visibleCandidates(state: AppUiState = _state.value): List<HitterCandidate> {
        return eligibleCandidates(state).asSequence()
            .filter { c ->
                state.sortMode != SortMode.ATTACK ||
                    !state.attackStrongOnly ||
                    (c.score.powerPressure >= 65.0 && c.score.pitcherMatchup >= 65.0)
            }
            .sortedWith(
                when (state.sortMode) {
                    SortMode.SCORE -> compareByDescending<HitterCandidate> { it.score.total }
                    SortMode.ATTACK -> compareByDescending<HitterCandidate> { attackScore(it) }
                        .thenByDescending { it.score.total }
                    SortMode.POWER_PRESSURE -> compareByDescending<HitterCandidate> { it.score.powerPressure }
                    SortMode.RECENT_POWER -> compareByDescending<HitterCandidate> { it.score.recentPower }
                    SortMode.MATCHUP -> compareByDescending<HitterCandidate> { it.score.pitcherMatchup }
                }
            )
            .toList()
    }

    fun topHittersForGame(
        gamePk: Long,
        limit: Int = 4,
        state: AppUiState = _state.value
    ): List<HitterCandidate> = eligibleCandidates(state)
        .filter { it.game.gamePk == gamePk }
        .sortedByDescending(::pickScore)
        .take(limit)

    /**
     * Balanced parlay score used by the default generator profile. This still starts from the
     * calibrated Daily Target Score, then adds a small convergence bonus for pressure, matchup,
     * signal quality and plate discipline.
     */
    fun parlayScore(candidate: HitterCandidate): Double {
        var score = pickScore(candidate)
        val pressure = candidate.score.powerPressure
        val matchup = candidate.score.pitcherMatchup

        score += when {
            pressure >= 70.0 && matchup >= 70.0 -> 7.0
            pressure >= 60.0 && matchup >= 60.0 -> 4.0
            pressure >= 52.0 && matchup >= 52.0 -> 2.0
            else -> 0.0
        }

        val signal = signalLensScore(candidate)
        score += when {
            signal >= 78.0 -> 4.0
            signal >= 68.0 -> 2.0
            else -> 0.0
        }
        recentWhiffRate(candidate)?.let {
            if (it <= .22 && candidate.recentPlateDiscipline.swings >= 10) score += 1.5
        }

        if (candidate.score.environment < 35.0) score -= 8.0
        if (matchup < 35.0) score -= 6.0
        return score.coerceIn(0.0, 100.0)
    }

    /**
     * Profile-specific generator score. Each focus answers a different betting question instead
     * of sending every generator request through the same top-target ranking.
     */
    fun parlayFocusScore(
        candidate: HitterCandidate,
        focus: ParlayFocus,
        state: AppUiState = _state.value
    ): Double {
        val metrics = mustHaveMetrics(candidate)
        val profile = mustHavePowerScore(candidate)
        val arsenal = candidate.pitchArsenalMatch?.score
        val arsenalValue = arsenal ?: 50.0
        val matchup = candidate.score.pitcherMatchup
        val environment = candidate.score.environment

        val raw = when (focus) {
            ParlayFocus.BALANCED -> parlayScore(candidate)

            ParlayFocus.PURE_POWER -> {
                // Established HR skill + current batted-ball shape lead this mode. Recent form and
                // matchup still matter enough to keep pure-power cards from becoming name-only slips.
                candidate.score.seasonPower * .30 +
                    profile * .28 +
                    candidate.score.recentPower * .12 +
                    reliablePowerPressure(candidate) * .10 +
                    arsenalValue * .08 +
                    matchup * .07 +
                    environment * .05
            }

            ParlayFocus.HEATING_UP -> {
                val heat = heatingScore(candidate, state)
                heat * .43 +
                    targetScore(candidate) * .20 +
                    reliablePowerPressure(candidate) * .13 +
                    candidate.score.recentPower * .09 +
                    matchup * .07 +
                    arsenalValue * .05 +
                    swingMissScore(candidate) * .03
            }

            ParlayFocus.HOT_NOW -> {
                val hot = hotStreakScore(candidate, state)
                hot * .43 +
                    targetScore(candidate) * .20 +
                    candidate.score.seasonPower * .14 +
                    profile * .08 +
                    matchup * .07 +
                    arsenalValue * .05 +
                    environment * .03
            }

            ParlayFocus.MATCHUP_EDGE -> {
                matchup * .28 +
                    arsenalValue * .22 +
                    candidate.score.platoon * .14 +
                    targetScore(candidate) * .17 +
                    environment * .08 +
                    candidate.score.seasonPower * .06 +
                    signalLensScore(candidate, state) * .05
            }
        }

        var adjusted = raw
        // Give BvP a small capped tie-breaker in every profile without letting a tiny career sample
        // dominate the generator.
        adjusted += bvpAdjustment(candidate) * .25

        if (focus == ParlayFocus.PURE_POWER) {
            if ((metrics.barrelPct ?: 0.0) >= 14.0) adjusted += 2.0
            if ((metrics.maxExitVelocity ?: 0.0) >= 108.0) adjusted += 1.5
        }
        if (focus == ParlayFocus.HEATING_UP && heatingSignalCount(candidate, state) >= 5) adjusted += 2.0
        if (focus == ParlayFocus.HOT_NOW && (recentWeekStats(candidate, state)?.homeRuns ?: 0) >= 2) adjusted += 2.0
        if (focus == ParlayFocus.MATCHUP_EDGE && arsenal != null && arsenal >= 75.0) adjusted += 2.0

        if (environment < 30.0) adjusted -= 5.0
        if (matchup < 30.0 && focus != ParlayFocus.PURE_POWER) adjusted -= 4.0
        return adjusted.coerceIn(0.0, 100.0)
    }

    fun parlayFocusLabel(focus: ParlayFocus): String = when (focus) {
        ParlayFocus.BALANCED -> "Balanced"
        ParlayFocus.PURE_POWER -> "Pure Power"
        ParlayFocus.HEATING_UP -> "Heating Up"
        ParlayFocus.HOT_NOW -> "Hot Now"
        ParlayFocus.MATCHUP_EDGE -> "Matchup Edge"
    }

    fun parlayFocusDescription(focus: ParlayFocus): String = when (focus) {
        ParlayFocus.BALANCED -> "Blends the full HR Chase model with matchup, form, power and pitch fit."
        ParlayFocus.PURE_POWER -> "Prioritizes proven HR skill, barrels, hard contact, EV and power shape."
        ParlayFocus.HEATING_UP -> "Targets 3-day acceleration, improving contact and emerging HR-quality swings."
        ParlayFocus.HOT_NOW -> "Leans into hitters already producing over the last 7 days with support underneath."
        ParlayFocus.MATCHUP_EDGE -> "Prioritizes pitcher vulnerability, pitch-arsenal fit, platoon edge and environment."
    }

    fun parlayLegReason(
        candidate: HitterCandidate,
        focus: ParlayFocus,
        state: AppUiState = _state.value
    ): String {
        val metrics = mustHaveMetrics(candidate)
        return when (focus) {
            ParlayFocus.BALANCED -> {
                val arsenal = candidate.pitchArsenalMatch?.score?.roundToInt()?.let { " • Arsenal $it" }.orEmpty()
                "Target ${targetScore(candidate).roundToInt()} • Pressure ${candidate.score.powerPressure.roundToInt()} • Matchup ${candidate.score.pitcherMatchup.roundToInt()}$arsenal"
            }
            ParlayFocus.PURE_POWER -> {
                val barrel = metrics.barrelPct?.let { "${"%.1f".format(it)}% barrel" } ?: "power profile ${profileText(mustHavePowerScore(candidate))}"
                "Season power ${candidate.score.seasonPower.roundToInt()} • $barrel • Max EV ${metrics.maxExitVelocity?.let { "%.1f".format(it) } ?: "—"}"
            }
            ParlayFocus.HEATING_UP -> {
                val three = recentThreeDayStats(candidate, state)
                val line = three?.ops?.let { " • 3D OPS ${"%.3f".format(it)}" }.orEmpty()
                "Heat ${heatingScore(candidate, state).roundToInt()} • ${heatingSignalCount(candidate, state)} signals • Pressure ${candidate.score.powerPressure.roundToInt()}$line"
            }
            ParlayFocus.HOT_NOW -> {
                val week = recentWeekStats(candidate, state)
                val ops = week?.ops?.let { "${"%.3f".format(it)} OPS" } ?: "7-day form"
                "Hot ${hotStreakScore(candidate, state).roundToInt()} • $ops • ${week?.homeRuns ?: 0} HR / ${week?.extraBaseHits ?: 0} XBH"
            }
            ParlayFocus.MATCHUP_EDGE -> {
                val arsenal = candidate.pitchArsenalMatch?.score?.roundToInt()?.toString() ?: "N/A"
                "Matchup ${candidate.score.pitcherMatchup.roundToInt()} • Arsenal $arsenal • Platoon ${candidate.score.platoon.roundToInt()} • Env ${candidate.score.environment.roundToInt()}"
            }
        }
    }

    /**
     * Multi-focus generator support. Every selected specialized lens is treated as an AND filter,
     * while the combined score rewards both the average quality and the weakest selected lens.
     * Balanced can be stacked with another lens when the user wants the core model to remain part
     * of the ranking.
     */
    private fun normalizedParlayFocuses(focuses: Set<ParlayFocus>): List<ParlayFocus> =
        (if (focuses.isEmpty()) setOf(ParlayFocus.BALANCED) else focuses).sortedBy { it.ordinal }

    private fun passesParlayFocus(
        candidate: HitterCandidate,
        focus: ParlayFocus,
        state: AppUiState
    ): Boolean = when (focus) {
        ParlayFocus.BALANCED -> true
        ParlayFocus.PURE_POWER ->
            candidate.score.seasonPower >= 44.0 || mustHavePowerScore(candidate) >= 58.0
        ParlayFocus.HEATING_UP ->
            (recentThreeDayStats(candidate, state)?.plateAppearances ?: 0) >= 4 &&
                heatingSignalCount(candidate, state) >= 2
        ParlayFocus.HOT_NOW ->
            (recentWeekStats(candidate, state)?.plateAppearances ?: 0) >= 5 &&
                hotStreakScore(candidate, state) >= 52.0
        ParlayFocus.MATCHUP_EDGE ->
            candidate.score.pitcherMatchup >= 44.0 || (candidate.pitchArsenalMatch?.score ?: 0.0) >= 58.0
    }

    fun parlayCombinedScore(
        candidate: HitterCandidate,
        focuses: Set<ParlayFocus>,
        state: AppUiState = _state.value
    ): Double {
        val selected = normalizedParlayFocuses(focuses)
        if (selected.size == 1) return parlayFocusScore(candidate, selected.first(), state)

        val scores = selected.map { parlayFocusScore(candidate, it, state) }
        val average = scores.average()
        val floor = scores.minOrNull() ?: average
        val strongAcross = scores.count { it >= 65.0 }
        val synergy = ((strongAcross - 1).coerceAtLeast(0) * 1.15).coerceAtMost(4.0)

        // A weak selected lens matters: stacking filters should find overlap, not merely average away
        // a bad matchup or cold-form signal.
        return (average * .72 + floor * .28 + synergy).coerceIn(0.0, 100.0)
    }

    fun parlayCombinedLabel(focuses: Set<ParlayFocus>): String {
        val selected = normalizedParlayFocuses(focuses)
        if (selected.size == 1) return parlayFocusLabel(selected.first())
        return selected.joinToString(" + ") {
            when (it) {
                ParlayFocus.BALANCED -> "Balanced"
                ParlayFocus.PURE_POWER -> "Power"
                ParlayFocus.HEATING_UP -> "Heating"
                ParlayFocus.HOT_NOW -> "Hot"
                ParlayFocus.MATCHUP_EDGE -> "Matchup"
            }
        }
    }

    fun parlayCombinedDescription(focuses: Set<ParlayFocus>): String {
        val selected = normalizedParlayFocuses(focuses)
        if (selected.size == 1) return parlayFocusDescription(selected.first())
        val fullLabels = selected.joinToString(" + ") { parlayFocusLabel(it) }
        return "AND mode: hitters must qualify for every selected lens ($fullLabels). Ranking rewards strength across the entire stack, and one weak selected lens pulls the score down."
    }

    fun parlayCombinedLegReason(
        candidate: HitterCandidate,
        focuses: Set<ParlayFocus>,
        state: AppUiState = _state.value
    ): String {
        val selected = normalizedParlayFocuses(focuses)
        if (selected.size == 1) return parlayLegReason(candidate, selected.first(), state)
        return selected.joinToString(" • ") { focus ->
            val short = when (focus) {
                ParlayFocus.BALANCED -> "Bal"
                ParlayFocus.PURE_POWER -> "Power"
                ParlayFocus.HEATING_UP -> "Heat"
                ParlayFocus.HOT_NOW -> "Hot"
                ParlayFocus.MATCHUP_EDGE -> "Matchup"
            }
            "$short ${parlayFocusScore(candidate, focus, state).roundToInt()}"
        }
    }

    private fun parlayCombinedCandidatePool(
        focuses: Set<ParlayFocus>,
        state: AppUiState
    ): List<HitterCandidate> {
        val selected = normalizedParlayFocuses(focuses)
        val eligible = eligibleCandidates(state).filter { it.score.total >= 36.0 }
        if (eligible.isEmpty()) return emptyList()

        // Strict intersection: when the user stacks Hot + Matchup, every returned hitter must pass
        // both qualification rules. We intentionally do not silently fall back to unfiltered names.
        val focused = eligible.filter { candidate ->
            selected.all { focus -> passesParlayFocus(candidate, focus, state) }
        }
        if (focused.isEmpty()) return emptyList()

        val ranked = focused.sortedWith(
            compareByDescending<HitterCandidate> { parlayCombinedScore(it, focuses, state) }
                .thenByDescending(::targetScore)
                .thenByDescending { it.score.seasonPower }
        )
        val best = parlayCombinedScore(ranked.first(), focuses, state)
        val qualityWindow = ranked.filter { parlayCombinedScore(it, focuses, state) >= best - 23.0 }.take(48)
        return if (qualityWindow.size >= 5 || ranked.size < 5) qualityWindow else ranked.take(48)
    }

    fun straightCombinedCandidates(
        focuses: Set<ParlayFocus>,
        state: AppUiState = _state.value
    ): List<HitterCandidate> {
        val base = parlayCombinedCandidatePool(focuses, state)
        if (base.isEmpty()) return emptyList()
        val best = parlayCombinedScore(base.first(), focuses, state)
        val window = base.filter { parlayCombinedScore(it, focuses, state) >= best - 16.0 }.take(18)
        return if (window.isNotEmpty()) window else base.take(18)
    }

    fun parlayCombinedRotationOffset(focuses: Set<ParlayFocus>): Int =
        normalizedParlayFocuses(focuses).sumOf { (it.ordinal + 1) * 3 }

    private fun combinedRotationBonus(
        candidate: HitterCandidate,
        variant: Int,
        slot: Int,
        focuses: Set<ParlayFocus>
    ): Double {
        if (variant == 0) return 0.0
        var x = candidate.player.id.toLong() * 1_103_515_245L
        x += variant.toLong() * 12_345L
        x += slot.toLong() * 97_531L
        x += parlayCombinedRotationOffset(focuses).toLong() * 7_919L
        x = x xor (x ushr 16)
        val unit = ((x and 0x7fffffffL) % 1000L) / 1000.0
        return unit * 7.5
    }

    fun generateCombinedParlay(
        legs: Int,
        variant: Int = 0,
        focuses: Set<ParlayFocus> = setOf(ParlayFocus.BALANCED),
        state: AppUiState = _state.value
    ): List<HitterCandidate> {
        val targetLegs = legs.coerceIn(1, 5)
        val selected = normalizedParlayFocuses(focuses)
        val base = parlayCombinedCandidatePool(focuses, state)
        if (base.size < targetLegs) return emptyList()

        if (targetLegs == 1) {
            val straights = straightCombinedCandidates(focuses, state)
            if (straights.isEmpty()) return emptyList()
            val offset = parlayCombinedRotationOffset(focuses)
            val index = if (variant == 0) 0 else Math.floorMod(variant * 5 + offset, straights.size)
            return listOf(straights[index])
        }

        val chosen = mutableListOf<HitterCandidate>()
        val usedGames = mutableSetOf<Long>()
        val usedTeams = mutableSetOf<Int>()
        val offset = parlayCombinedRotationOffset(focuses)

        val anchorPoolSize = minOf(18, base.size)
        val anchorIndex = if (variant == 0) 0 else Math.floorMod(variant * 5 + offset, anchorPoolSize)
        val anchor = base[anchorIndex]
        chosen += anchor
        usedGames += anchor.game.gamePk
        usedTeams += anchor.team.id

        for (slot in 1 until targetLegs) {
            val options = base.asSequence()
                .filter { candidate -> chosen.none { it.player.id == candidate.player.id } }
                .map { candidate ->
                    var adjusted = parlayCombinedScore(candidate, focuses, state)
                    if (candidate.game.gamePk in usedGames) adjusted -= 17.0
                    if (candidate.team.id in usedTeams) adjusted -= 8.0
                    if (candidate.score.environment < 35.0) adjusted -= 5.0

                    val purePowerOnly = selected.size == 1 && selected.first() == ParlayFocus.PURE_POWER
                    if (candidate.score.pitcherMatchup < 35.0 && !purePowerOnly) adjusted -= 5.0
                    adjusted += combinedRotationBonus(candidate, variant, slot, focuses)
                    candidate to adjusted
                }
                .sortedByDescending { it.second }
                .take(10)
                .toList()

            if (options.isEmpty()) break
            val bestAdjusted = options.first().second
            val competitive = options.filter { it.second >= bestAdjusted - 7.5 }.take(6)
            val optionIndex = if (variant == 0 || competitive.size == 1) 0
            else Math.floorMod(variant + slot * 2 + offset, competitive.size)
            val next = competitive[optionIndex].first

            chosen += next
            usedGames += next.game.gamePk
            usedTeams += next.team.id
        }

        return if (chosen.size == targetLegs) chosen else emptyList()
    }

    fun evaluateCombinedParlay(
        parlay: List<HitterCandidate>,
        focuses: Set<ParlayFocus> = setOf(ParlayFocus.BALANCED),
        state: AppUiState = _state.value
    ): ParlayEvaluation {
        if (parlay.isEmpty()) {
            return ParlayEvaluation(0, "NO CARD", 0, 0, 0, "Not enough hitters qualify for every selected filter. Remove a filter or wait for more data.")
        }

        val scores = parlay.map { parlayCombinedScore(it, focuses, state).coerceIn(0.0, 100.0) }
        val average = scores.average()
        val weakest = scores.minOrNull() ?: 0.0
        val uniqueGames = parlay.map { it.game.gamePk }.distinct().size
        val diversityBonus = if (parlay.size <= 1) 0.0 else (uniqueGames.toDouble() / parlay.size) * 3.0
        val legPenalty = when (parlay.size) {
            1 -> 0.0
            2 -> 10.0
            3 -> 21.0
            4 -> 33.0
            else -> 44.0
        }
        val stackedBonus = ((normalizedParlayFocuses(focuses).size - 1) * 0.8).coerceAtMost(2.4)

        val rating = (average * .58 + weakest * .42 + diversityBonus + stackedBonus - legPenalty)
            .roundToInt()
            .coerceIn(1, 99)
        val label = when {
            rating >= 76 -> "HIGHER"
            rating >= 63 -> "STRONG"
            rating >= 49 -> "MODERATE"
            rating >= 35 -> "LOWER"
            else -> "LONG SHOT"
        }
        val filterNote = if (normalizedParlayFocuses(focuses).size > 1) {
            " Every leg passed all ${normalizedParlayFocuses(focuses).size} selected filters."
        } else ""
        val note = when {
            parlay.size == 1 -> "Strongest comparison is against other straight HR candidates in this filter set.$filterNote"
            uniqueGames == parlay.size -> "All legs come from different games, reducing avoidable same-game dependence.$filterNote"
            uniqueGames >= parlay.size - 1 -> "Mostly diversified across games with one shared-game exposure.$filterNote"
            else -> "Multiple legs share games, so the card carries more correlation and slate-specific risk.$filterNote"
        }

        return ParlayEvaluation(
            rating = rating,
            label = label,
            averageLegScore = average.roundToInt(),
            weakestLegScore = weakest.roundToInt(),
            uniqueGames = uniqueGames,
            note = note
        )
    }

    private fun profileText(score: Double): String = when {
        score >= 80.0 -> "elite"
        score >= 68.0 -> "strong"
        score >= 56.0 -> "solid"
        else -> "developing"
    }

    private fun parlayCandidatePool(
        focus: ParlayFocus,
        state: AppUiState
    ): List<HitterCandidate> {
        val eligible = eligibleCandidates(state).filter { it.score.total >= 36.0 }
        if (eligible.isEmpty()) return emptyList()

        val focused = eligible.filter { candidate ->
            when (focus) {
                ParlayFocus.BALANCED -> true
                ParlayFocus.PURE_POWER ->
                    candidate.score.seasonPower >= 44.0 || mustHavePowerScore(candidate) >= 58.0
                ParlayFocus.HEATING_UP ->
                    (recentThreeDayStats(candidate, state)?.plateAppearances ?: 0) >= 4 &&
                        heatingSignalCount(candidate, state) >= 2
                ParlayFocus.HOT_NOW ->
                    (recentWeekStats(candidate, state)?.plateAppearances ?: 0) >= 5 &&
                        hotStreakScore(candidate, state) >= 52.0
                ParlayFocus.MATCHUP_EDGE ->
                    candidate.score.pitcherMatchup >= 44.0 || (candidate.pitchArsenalMatch?.score ?: 0.0) >= 58.0
            }
        }

        // If a specialized data feed is still loading, gracefully fall back to the full eligible
        // board rather than making the generator look broken. The mode score still controls rank.
        val source = if (focused.size >= 6 || focus == ParlayFocus.BALANCED) focused else eligible
        val ranked = source.sortedWith(
            compareByDescending<HitterCandidate> { parlayFocusScore(it, focus, state) }
                .thenByDescending(::targetScore)
                .thenByDescending { it.score.seasonPower }
        )
        if (ranked.isEmpty()) return emptyList()

        val best = parlayFocusScore(ranked.first(), focus, state)
        // A wider but still controlled quality window gives Generate Again room to breathe.
        return ranked.filter { parlayFocusScore(it, focus, state) >= best - 23.0 }.take(48)
    }

    fun straightCandidates(
        focus: ParlayFocus = ParlayFocus.BALANCED,
        state: AppUiState = _state.value
    ): List<HitterCandidate> {
        val base = parlayCandidatePool(focus, state)
        if (base.isEmpty()) return emptyList()
        val best = parlayFocusScore(base.first(), focus, state)
        val window = base.filter { parlayFocusScore(it, focus, state) >= best - 16.0 }.take(18)
        return if (window.isNotEmpty()) window else base.take(18)
    }

    private fun rotationBonus(
        candidate: HitterCandidate,
        variant: Int,
        slot: Int,
        focus: ParlayFocus
    ): Double {
        if (variant == 0) return 0.0
        var x = candidate.player.id.toLong() * 1_103_515_245L
        x += variant.toLong() * 12_345L
        x += slot.toLong() * 97_531L
        x += focus.ordinal.toLong() * 7_919L
        x = x xor (x ushr 16)
        val unit = ((x and 0x7fffffffL) % 1000L) / 1000.0
        return unit * 7.5
    }

    /**
     * Generates a profile-aware, quality-controlled HR card with substantially more rotation.
     * Variant zero remains the strongest pure model card. Later variants deliberately rotate the
     * anchor through a deeper quality band and add a small deterministic diversity bonus, while
     * still penalizing repeated games/teams and weak legs.
     */
    fun generateParlay(
        legs: Int,
        variant: Int = 0,
        focus: ParlayFocus = ParlayFocus.BALANCED,
        state: AppUiState = _state.value
    ): List<HitterCandidate> {
        val targetLegs = legs.coerceIn(1, 5)
        val base = parlayCandidatePool(focus, state)
        if (base.isEmpty()) return emptyList()

        if (targetLegs == 1) {
            val straights = straightCandidates(focus, state)
            if (straights.isEmpty()) return emptyList()
            // A stride of five walks the ranked pool instead of simply cycling adjacent names.
            val index = if (variant == 0) 0 else Math.floorMod(variant * 5 + focus.ordinal * 3, straights.size)
            return listOf(straights[index])
        }

        val chosen = mutableListOf<HitterCandidate>()
        val usedGames = mutableSetOf<Long>()
        val usedTeams = mutableSetOf<Int>()

        val anchorPoolSize = minOf(18, base.size)
        val anchorIndex = if (variant == 0) 0 else Math.floorMod(variant * 5 + focus.ordinal * 3, anchorPoolSize)
        val anchor = base[anchorIndex]
        chosen += anchor
        usedGames += anchor.game.gamePk
        usedTeams += anchor.team.id

        for (slot in 1 until targetLegs) {
            val options = base.asSequence()
                .filter { candidate -> chosen.none { it.player.id == candidate.player.id } }
                .map { candidate ->
                    var adjusted = parlayFocusScore(candidate, focus, state)

                    // Prefer independent games and teams, especially for longer cards.
                    if (candidate.game.gamePk in usedGames) adjusted -= 17.0
                    if (candidate.team.id in usedTeams) adjusted -= 8.0
                    if (candidate.score.environment < 35.0) adjusted -= 5.0
                    if (candidate.score.pitcherMatchup < 35.0 && focus != ParlayFocus.PURE_POWER) adjusted -= 5.0

                    // Later generations get a small deterministic rotation boost. It is large enough
                    // to change comparable options, but not enough to promote a clearly weak hitter.
                    adjusted += rotationBonus(candidate, variant, slot, focus)
                    candidate to adjusted
                }
                .sortedByDescending { it.second }
                .take(10)
                .toList()

            if (options.isEmpty()) break

            val bestAdjusted = options.first().second
            val competitive = options.filter { it.second >= bestAdjusted - 7.5 }.take(6)
            val optionIndex = if (variant == 0 || competitive.size == 1) 0
            else Math.floorMod(variant + slot * 2 + focus.ordinal, competitive.size)
            val next = competitive[optionIndex].first

            chosen += next
            usedGames += next.game.gamePk
            usedTeams += next.team.id
        }

        return chosen.take(targetLegs)
    }

    /**
     * Relative card rating, not a calibrated probability. It intentionally penalizes leg count
     * because even excellent HR legs become much harder to combine as a parlay grows. The weakest
     * leg matters heavily so a single reach can drag down the entire card grade.
     */
    fun evaluateParlay(
        parlay: List<HitterCandidate>,
        focus: ParlayFocus = ParlayFocus.BALANCED,
        state: AppUiState = _state.value
    ): ParlayEvaluation {
        if (parlay.isEmpty()) {
            return ParlayEvaluation(0, "NO CARD", 0, 0, 0, "Waiting for enough qualified hitters.")
        }

        val scores = parlay.map { parlayFocusScore(it, focus, state).coerceIn(0.0, 100.0) }
        val average = scores.average()
        val weakest = scores.minOrNull() ?: 0.0
        val uniqueGames = parlay.map { it.game.gamePk }.distinct().size
        val diversityBonus = if (parlay.size <= 1) 0.0 else (uniqueGames.toDouble() / parlay.size) * 3.0
        val legPenalty = when (parlay.size) {
            1 -> 0.0
            2 -> 10.0
            3 -> 21.0
            4 -> 33.0
            else -> 44.0
        }

        val rating = (average * .58 + weakest * .42 + diversityBonus - legPenalty)
            .roundToInt()
            .coerceIn(1, 99)
        val label = when {
            rating >= 76 -> "HIGHER"
            rating >= 63 -> "STRONG"
            rating >= 49 -> "MODERATE"
            rating >= 35 -> "LOWER"
            else -> "LONG SHOT"
        }
        val note = when {
            parlay.size == 1 -> "Strongest comparison is against other straight HR candidates in this focus."
            uniqueGames == parlay.size -> "All legs come from different games, reducing avoidable same-game dependence."
            uniqueGames >= parlay.size - 1 -> "Mostly diversified across games with one shared-game exposure."
            else -> "Multiple legs share games, so the card carries more correlation and slate-specific risk."
        }

        return ParlayEvaluation(
            rating = rating,
            label = label,
            averageLegScore = average.roundToInt(),
            weakestLegScore = weakest.roundToInt(),
            uniqueGames = uniqueGames,
            note = note
        )
    }

}
