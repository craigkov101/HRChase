# HR Chase v0.19.6

Compile-fix release for the all-teams projected hitter fallback.

- Defines the season before active-roster fallback requests.
- Converts date-range RecentHittingStats into the HittingStats type required by LineupPlayer.
- Retains the v0.19.5 team-by-team active roster fallback so both clubs can populate independently.
- Version bumped to 0.19.6 (versionCode 54).
