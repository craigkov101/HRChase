# HR Chase 0.19.3 — Projected Playoff Hitters + Launcher Logo

- Fixed projected-lineup fallback during the postseason by allowing the recent schedule lookup to include postseason game types, rather than regular-season games only.
- Games remain visible even when official lineups have not posted.
- Recent postseason batting orders can now seed projected hitters and HR rankings until official lineups replace them.
- Added a new HR Chase launcher icon derived from the new HR Chase visual identity.
- Version bumped to 0.19.3 (versionCode 51).
