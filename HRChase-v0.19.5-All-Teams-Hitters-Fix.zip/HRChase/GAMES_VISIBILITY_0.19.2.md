# HR Chase v0.19.2 — Games visibility fix

Fixes the Games tab briefly showing scheduled playoff games and then hiding them after player-data enrichment finishes.

The Games tab now treats the MLB schedule as authoritative: scheduled games remain visible even when projected/official lineups or hitter candidates are not available yet. Filters still affect candidate/player rows rather than deleting the scheduled game itself.
