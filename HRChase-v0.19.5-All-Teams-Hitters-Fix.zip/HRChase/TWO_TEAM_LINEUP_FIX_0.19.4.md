# HR Chase v0.19.4 — Two-Team Projected Lineup Fix

- Fixes projected games where only one club supplied hitters.
- Collects up to three recent lineup sources independently for every team on the slate.
- Prefers a complete nine-hitter lineup for each club, then the most complete/recent fallback.
- Away and home fallbacks are resolved independently before candidates are merged and ranked.
- Preserves v0.19.2 game visibility and v0.19.3 postseason projected-hitter support.
