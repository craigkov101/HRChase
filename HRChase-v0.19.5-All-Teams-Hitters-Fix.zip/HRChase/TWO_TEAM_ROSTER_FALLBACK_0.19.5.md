# HR Chase v0.19.5

Fixes projected postseason hitter coverage when MLB recent-game feeds only expose one club's batting order.

- Recent lineup fallback remains first choice for each team independently.
- If a team still lacks a usable recent lineup, HR Chase now loads that team's active position-player roster.
- The nine hitters with the most season plate appearances become a projected lineup until an official/recent lineup is available.
- Away and home fallbacks are resolved independently so one team's data can never suppress its opponent.
- Preserves v0.19.2-v0.19.4 schedule visibility and postseason support.
