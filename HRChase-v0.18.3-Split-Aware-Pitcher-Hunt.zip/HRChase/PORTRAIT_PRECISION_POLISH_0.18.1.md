# HR Chase v0.18.1 — Portrait + Precision Polish

## Orientation fix
- Locks the main Android activity to portrait in `AndroidManifest.xml`.
- Adds a second portrait lock in `MainActivity` so device sensor state cannot leave the app sideways on normal phone layouts.

## More selective HR reads
- Adds an **independent-agreement gate**: very high Target Scores now need PROCESS, MATCH, Pattern Engine and CEILING to agree instead of allowing one correlated signal family to carry the pick.
- Tightens the top-end convergence bonus so strong Pattern scores also need a usable matchup read.
- Adds **pregame readiness gates**:
  - projected lineups remain visible, but cannot be treated exactly like confirmed lineups;
  - a TBD opposing pitcher caps the recommendation until the matchup is known;
  - LOW DATA candidates have explicit score ceilings so missing enrichment cannot create an extreme pick.
- CORE status now requires a confirmed lineup, known opposing pitcher, usable evidence, Pattern support and a power foundation.
- Balanced Parlay scoring is re-anchored to the calibrated Target Score instead of stacking large additive bonuses from correlated green metrics; all parlay focus modes now respect the same readiness/evidence caps.
- The Picks screen can explicitly say **NO CONFIRMED CORE YET** on a thin/unfinished slate rather than forcing a top-play label.

## Smoother app behavior
- Adds bounded in-memory caches for expensive derived model calculations (Target Score, Research Lens, Pattern Engine score and Precision confidence). Sorting and Compose recomposition no longer recalculate the same deep score tree over and over for the same hitter snapshot.
- Reduces simultaneous starter attack-map requests from 8 to 4.
- Limits optional Statcast precision-enrichment leaderboards to four concurrent requests. The fast/base board still appears first; advanced data fills in afterward with less mobile-network thrashing.
- Existing stale-while-revalidate board loading and HTTP cache remain intact.

## UI polish
- Header badge now reads **PRECISION**.
- Pick cards show a plain-language readiness state such as **CONFIRMED READ**, **SOLID READ**, **PROJECTED LINEUP**, **PITCHER TBD**, or **LIMITED DATA**, plus a readiness percentage.
- Adds a compact **SLATE READ** banner showing whether confirmed CORE plays actually exist.
- Keeps the existing Match / Process / Ceiling, Precision, Attack Zone and Arsenal + Handedness visual hierarchy without adding another cluttered tab.
