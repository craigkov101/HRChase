# HR Chase v0.18.0 — Precision Foundation

This release is a model-quality upgrade rather than a simple metric dump. The goal is to make daily HR picks more evidence-driven, reduce overreaction to tiny hot streaks, and make the app explicit about how much data supports each read.

## New official Statcast layers

The app now optionally enriches each hitter/pitcher pair with league-wide Baseball Savant data after the fast board has loaded:

- Expected statistics: xBA, xSLG, xwOBA; pitchers also use xERA.
- Stable contact quality: Barrel%, Barrel/PA, Hard-Hit%, EV50, average/max EV, sweet-spot rate.
- Exact batted-ball direction: Pull%, AIR%, Fly Ball%, and Pull AIR%.
- Bat tracking: average bat speed, fast-swing rate, squared-up rate, Blast rate, swing length.
- Swing path: attack angle and Ideal Attack Angle rate, with switch hitters using the side they are expected to hit from.
- Adjusted xHR / No-Doubter information as a supporting home-run-trajectory quality signal.
- Handedness-specific Statcast home-run park factors, with the old environment model retained as fallback.
- Opposing team relief-pitching profile so later plate appearances are not modeled as if the starter pitches all nine innings.
- Starter Statcast contact allowed and expected outcomes.

All optional enrichments use timeouts/fallbacks. Missing data lowers evidence coverage; it is never turned into a fake neutral observation and can never blank the slate.

## Formula architecture

### PROCESS
Stable season skill now leads the process score. Official Statcast power receives more authority than a short recent contact sample. Bat speed/Blast/attack angle are corroboration rather than primary power signals.

### MATCH
Tonight-specific fit now combines conventional pitcher matchup, Statcast starter vulnerability, Arsenal + Handedness convergence, Attack Zone Match, bullpen vulnerability, handedness-specific park factor, weather/roof, lineup position, and a small BvP tie-breaker.

### CEILING
Ceiling emphasizes stable power, exact Pull AIR%, bat mechanics, recent contact quality, adjusted xHR trajectory quality, Power Pressure, and environment.

Daily Target weighting is now:
- PROCESS 36%
- learned Pattern Engine 27%
- MATCH 27%
- CEILING 10%

The model also applies evidence shrink to extreme scores when advanced coverage is thin.

## Precision confidence

Every candidate now has a separate Precision Evidence score based on sample coverage for hitter contact, expected stats, swing mechanics, batted-ball direction, starter contact allowed, starter expected stats, pitch arsenal, Attack Zone, bullpen, park factor, and xHR evidence.

Labels:
- HIGH DATA
- MED DATA
- LOW DATA

A CORE badge now requires at least medium Precision evidence in addition to strong Target, Pattern and power grades.

## Outcome learning

Pregame snapshots now also save:
- Statcast Power composite
- Pull-Air Power composite
- Advanced Starter Vulnerability
- Precision Evidence confidence

Pattern Engine can therefore test interactions such as:
- Statcast Power + Pull-Air Power
- Statcast Power + Starter Vulnerability
- Pitch Arsenal Fit + Statcast Power
- Statcast Power + Pull-Air + Starter Vulnerability

The new metrics only enter the learned layer when Precision evidence is credible. Positive lift is not assumed; outcomes determine direction and Bayesian shrink limits small-sample authority.

## UI

Target cards now show:
- Precision evidence percentage + HIGH/MED/LOW DATA
- xSLG when available
- Barrel%, EV50, Pull AIR%, xHR compact detail
- Official Power / Pull-Air / Starter grades

Player Profile adds a full Precision Foundation section showing the component grades and available raw Statcast values.

## Model safeguards

- Bat-tracking mechanics remain secondary to Barrel/xSLG/contact-quality evidence.
- Adjusted xHR is treated as trajectory-quality evidence, not as a standalone future-HR prediction.
- Missing advanced endpoints do not penalize a player as if the matchup were bad.
- Short hot streaks still matter, but are regressed and cannot manufacture a top pick without a power foundation.
- Low-data extreme Target Scores are shrunk toward neutral.
- Strong recent pressure cannot overcome a clearly weak stable power profile without supporting evidence.

## Validation

- `Models.kt` + `PatternLearningEngine.kt` compile with `kotlinc`.
- A synthetic pregame/outcome smoke test correctly learned a strong positive Statcast Power + Pull-Air interaction when outcomes supported it (1.973x Bayesian-shrunk learned lift in the test dataset).
- Kotlin parser checks found no syntax-parser errors in edited UI/MainViewModel/API files; unresolved Android/Compose references are expected without the Gradle classpath.
- Full local Gradle build could not run because the environment cannot resolve `services.gradle.org`; GitHub Actions remains the final Android compilation check.
