# HR Chase v0.18.3 — Split-Aware Pitcher Hunt

This release hardens the v0.18.2 game-first Pitcher Hunt by making starter vulnerability hitter-specific.

## What changed
- Uses the already-downloaded season pitcher-vs-LHB and pitcher-vs-RHB stats in the HR vulnerability profile.
- Resolves switch hitters to the side they will use against the probable starter's throwing hand.
- Adds split HR/9 and HR per batter faced with sample-size regression; small handedness samples cannot dominate the score.
- Rebalances the vulnerability weights so overall season HR history remains the anchor, handedness carries meaningful matchup value, recent windows add form, and Statcast contact quality confirms the underlying damage profile.
- Target Pitchers and STARTER HR RISK cards display the relevant `vs LHB` / `vs RHB` HR/9 when available.
- Pattern Engine automatically learns the improved split-aware HR-prone starter score because the saved `hrPronePitcher` pregame signal now contains this matchup-specific information.

## Guardrails
A vulnerable split does not manufacture a home-run pick. Pitcher Hunt bonuses remain gated by hitter Season Power, Process Test, Statcast power/contact evidence, and normal readiness/data-quality caps.
