package com.ckz.hrchase.model

import com.ckz.hrchase.data.DailySignalSnapshot
import com.ckz.hrchase.data.HitterSignalSnapshot
import java.time.Instant
import java.time.LocalDate
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PatternLearningEngineTest {
    @Test
    fun arsenalAndHandednessPairLearnsPositiveLiftWhenOutcomesSupportIt() {
        val date = LocalDate.of(2026, 9, 1)
        val rows = (1..500).map { i ->
            val convergence = i <= 100
            val homer = if (convergence) i % 8 == 0 else i % 30 == 0
            HitterSignalSnapshot(
                date = date,
                playerId = i,
                recentPower = 55.0,
                powerPressure = 55.0,
                pitcherMatchup = 60.0,
                environment = 55.0,
                seasonPower = 65.0,
                platoon = if (convergence) 75.0 else 50.0,
                contactProfile = 62.0,
                pitchArsenalFit = if (convergence) 82.0 else 55.0,
                pitchArsenalConfidence = .70,
                outcomeHomeRun = homer
            )
        }
        val profile = PatternLearningEngine().build(
            listOf(DailySignalSnapshot(date, Instant.parse("2026-09-01T12:00:00Z"), rows))
        )
        val pair = profile.patterns.firstOrNull { it.key == "pitchArsenalFit+platoon" }
        assertNotNull(pair)
        assertTrue(pair!!.posteriorLift > 1.0)
    }

    @Test
    fun unreliableArsenalDataDoesNotBecomeAConvergenceRule() {
        val date = LocalDate.of(2026, 9, 1)
        val rows = (1..300).map { i ->
            HitterSignalSnapshot(
                date = date,
                playerId = i,
                recentPower = 55.0,
                powerPressure = 55.0,
                pitcherMatchup = 60.0,
                environment = 55.0,
                seasonPower = 65.0,
                platoon = 75.0,
                contactProfile = 62.0,
                pitchArsenalFit = 90.0,
                pitchArsenalConfidence = .10,
                outcomeHomeRun = i % 20 == 0
            )
        }
        val profile = PatternLearningEngine().build(
            listOf(DailySignalSnapshot(date, Instant.parse("2026-09-01T12:00:00Z"), rows))
        )
        assertTrue(profile.patterns.none { it.key.contains("pitchArsenalFit") })
    }
    @Test
    fun statcastPowerAndPullAirLearnOnlyWhenPregameOutcomesSupportThem() {
        val date = LocalDate.of(2026, 9, 2)
        val rows = (1..520).map { i ->
            val precisionGroup = i <= 120
            val homer = if (precisionGroup) i % 7 == 0 else i % 34 == 0
            HitterSignalSnapshot(
                date = date,
                playerId = i,
                recentPower = 55.0,
                powerPressure = 55.0,
                pitcherMatchup = 58.0,
                environment = 55.0,
                seasonPower = 60.0,
                platoon = 55.0,
                contactProfile = 58.0,
                statcastPower = if (precisionGroup) 78.0 else 54.0,
                pullAirPower = if (precisionGroup) 76.0 else 52.0,
                advancedPitcher = if (precisionGroup) 69.0 else 52.0,
                precisionConfidence = .78,
                outcomeHomeRun = homer
            )
        }
        val profile = PatternLearningEngine().build(
            listOf(DailySignalSnapshot(date, Instant.parse("2026-09-02T12:00:00Z"), rows))
        )
        val rule = profile.patterns.firstOrNull { it.key == "statcastPower+pullAirPower" }
        assertNotNull(rule)
        assertTrue(rule!!.posteriorLift > 1.0)
    }

    @Test
    fun lowConfidencePrecisionDataDoesNotBecomeALearnedRule() {
        val date = LocalDate.of(2026, 9, 3)
        val rows = (1..320).map { i ->
            HitterSignalSnapshot(
                date = date,
                playerId = i,
                recentPower = 55.0,
                powerPressure = 55.0,
                pitcherMatchup = 58.0,
                environment = 55.0,
                seasonPower = 60.0,
                platoon = 55.0,
                contactProfile = 58.0,
                statcastPower = 88.0,
                pullAirPower = 84.0,
                advancedPitcher = 78.0,
                precisionConfidence = .12,
                outcomeHomeRun = i % 18 == 0
            )
        }
        val profile = PatternLearningEngine().build(
            listOf(DailySignalSnapshot(date, Instant.parse("2026-09-03T12:00:00Z"), rows))
        )
        assertTrue(profile.patterns.none { it.key.contains("statcastPower") || it.key.contains("pullAirPower") || it.key.contains("advancedPitcher") })
    }

    @Test
    fun hrProneStarterAndRealPowerLearnPositiveLiftWhenOutcomesSupportIt() {
        val date = LocalDate.of(2026, 9, 4)
        val rows = (1..560).map { i ->
            val attackGroup = i <= 140
            val homer = if (attackGroup) i % 7 == 0 else i % 31 == 0
            HitterSignalSnapshot(
                date = date,
                playerId = i,
                recentPower = 55.0,
                powerPressure = 55.0,
                pitcherMatchup = if (attackGroup) 67.0 else 51.0,
                environment = 55.0,
                seasonPower = if (attackGroup) 70.0 else 54.0,
                platoon = 55.0,
                contactProfile = if (attackGroup) 65.0 else 54.0,
                hrPronePitcher = if (attackGroup) 80.0 else 48.0,
                precisionConfidence = .74,
                outcomeHomeRun = homer
            )
        }
        val profile = PatternLearningEngine().build(
            listOf(DailySignalSnapshot(date, Instant.parse("2026-09-04T12:00:00Z"), rows))
        )
        val rule = profile.patterns.firstOrNull { it.key == "seasonPower+hrPronePitcher" }
        assertNotNull(rule)
        assertTrue(rule!!.posteriorLift > 1.0)
    }

}
