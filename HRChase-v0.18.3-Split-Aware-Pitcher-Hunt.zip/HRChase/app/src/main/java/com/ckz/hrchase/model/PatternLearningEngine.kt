package com.ckz.hrchase.model

import com.ckz.hrchase.data.DailySignalSnapshot
import com.ckz.hrchase.data.HitterSignalSnapshot
import com.ckz.hrchase.data.LearnedPatternRule
import com.ckz.hrchase.data.MetricLearning
import com.ckz.hrchase.data.ModelLearningProfile
import kotlin.math.absoluteValue

/**
 * Pure, testable outcome-learning engine. It only sees saved PRE-GAME signal snapshots and their
 * resolved HR outcome, so none of the learned pattern rates can accidentally use postgame contact.
 */
class PatternLearningEngine {
    data class SignalDefinition(
        val key: String,
        val label: String,
        val threshold: Double,
        val getter: (HitterSignalSnapshot) -> Double?
    )

    val signalDefinitions = listOf(
        SignalDefinition("seasonPower", "Season power", 62.0) { it.seasonPower },
        SignalDefinition("contactProfile", "Contact quality", 60.0) { it.contactProfile },
        SignalDefinition("recentPower", "Recent power", 60.0) { it.recentPower },
        SignalDefinition("powerPressure", "Power pressure", 55.0) { it.powerPressure },
        SignalDefinition("pitcherMatchup", "Pitcher matchup", 58.0) { it.pitcherMatchup },
        // Arsenal data only counts as a learned common denominator when the underlying pitch-type
        // sample is credible. Legacy snapshots did not store confidence, so their already-shrunk
        // fit score is allowed through at a conservative assumed 30% confidence.
        SignalDefinition("pitchArsenalFit", "Pitch arsenal fit", 68.0) { row ->
            val confidence = row.pitchArsenalConfidence ?: 0.30
            row.pitchArsenalFit?.takeIf { confidence >= 0.28 }
        },
        SignalDefinition("attackZoneFit", "Attack zone fit", 64.0) { row ->
            val confidence = row.attackZoneConfidence ?: 0.0
            row.attackZoneFit?.takeIf { confidence >= 0.28 }
        },
        SignalDefinition("statcastPower", "Statcast power", 66.0) { row ->
            row.statcastPower?.takeIf { (row.precisionConfidence ?: 0.0) >= 0.30 }
        },
        SignalDefinition("pullAirPower", "Pull-air power", 65.0) { row ->
            row.pullAirPower?.takeIf { (row.precisionConfidence ?: 0.0) >= 0.30 }
        },
        SignalDefinition("advancedPitcher", "Starter Statcast vulnerability", 62.0) { row ->
            row.advancedPitcher?.takeIf { (row.precisionConfidence ?: 0.0) >= 0.30 }
        },
        SignalDefinition("hrPronePitcher", "HR-prone starter", 66.0) { row ->
            row.hrPronePitcher?.takeIf { (row.precisionConfidence ?: 0.0) >= 0.28 }
        },
        SignalDefinition("platoon", "Handedness edge", 62.0) { it.platoon },
        SignalDefinition("environment", "Environment", 58.0) { it.environment }
    )

    fun build(snapshots: List<DailySignalSnapshot>): ModelLearningProfile {
        val resolved = snapshots.flatMap { it.hitters }.filter { it.outcomeHomeRun != null }
        if (resolved.isEmpty()) return ModelLearningProfile()

        val homeRuns = resolved.count { it.outcomeHomeRun == true }
        val baseline = homeRuns.toDouble() / resolved.size

        fun metric(getter: (HitterSignalSnapshot) -> Double?): MetricLearning {
            val exposed = resolved.mapNotNull { row -> getter(row)?.let { value -> row to value } }
                .filter { (_, value) -> value >= 65.0 }
                .map { it.first }
            val wins = exposed.count { it.outcomeHomeRun == true }
            val rawRate = if (exposed.isNotEmpty()) wins.toDouble() / exposed.size else 0.0
            val prior = 60.0
            val posteriorRate = if (exposed.isNotEmpty())
                (wins + baseline * prior) / (exposed.size + prior) else baseline
            val lift = if (baseline > 0.0) posteriorRate / baseline else 1.0
            return MetricLearning(exposed.size, wins, rawRate, lift.coerceIn(0.45, 2.25))
        }

        val rules = mutableListOf<LearnedPatternRule>()
        for (size in 2..3) {
            combinations(signalDefinitions, size).forEach { combo ->
                val keys = combo.map { it.key }.toSet()
                val isArsenalHandedness = "pitchArsenalFit" in keys && "platoon" in keys
                val isZoneInteraction = "attackZoneFit" in keys && ("pitchArsenalFit" in keys || "pitcherMatchup" in keys)
                val isPrecisionInteraction =
                    ("statcastPower" in keys && ("pullAirPower" in keys || "advancedPitcher" in keys || "hrPronePitcher" in keys || "pitchArsenalFit" in keys)) ||
                    ("hrPronePitcher" in keys && ("seasonPower" in keys || "contactProfile" in keys || "pitchArsenalFit" in keys))
                val priorityInteraction = isArsenalHandedness || isZoneInteraction || isPrecisionInteraction
                val available = resolved.filter { row -> combo.all { it.getter(row) != null } }
                if (available.size < if (priorityInteraction) 60 else 80) return@forEach
                val exposed = available.filter { row ->
                    combo.all { def -> (def.getter(row) ?: Double.NEGATIVE_INFINITY) >= def.threshold }
                }
                if (exposed.size < if (priorityInteraction) 8 else 12) return@forEach
                val wins = exposed.count { it.outcomeHomeRun == true }
                val rawRate = wins.toDouble() / exposed.size
                val priorStrength = if (size == 2) 70.0 else 95.0
                val posteriorRate = (wins + baseline * priorStrength) / (exposed.size + priorStrength)
                val lift = if (baseline > 0.0) posteriorRate / baseline else 1.0
                val sampleReliability = exposed.size.toDouble() / (exposed.size + priorStrength)
                val outcomeReliability = wins.toDouble() / (wins + 8.0)
                val reliability = (sampleReliability * (0.55 + outcomeReliability * 0.45)).coerceIn(0.0, 1.0)
                rules += LearnedPatternRule(
                    key = combo.joinToString("+") { it.key },
                    label = combo.joinToString(" + ") { it.label },
                    attempts = exposed.size,
                    homeRuns = wins,
                    rawRate = rawRate,
                    posteriorRate = posteriorRate,
                    posteriorLift = lift.coerceIn(0.45, 2.40),
                    reliability = reliability
                )
            }
        }

        // Keep the arsenal + handedness family visible even when it is not one of the loudest
        // overall rules. We are not forcing it to be positive; if the historical lift is weak or
        // negative, that evidence remains visible and the application layer can down-weight it.
        val priorityKeys = setOf(
            "pitchArsenalFit+platoon",
            "seasonPower+pitchArsenalFit+platoon",
            "contactProfile+pitchArsenalFit+platoon",
            "pitcherMatchup+pitchArsenalFit+platoon",
            "attackZoneFit+pitchArsenalFit",
            "pitcherMatchup+attackZoneFit",
            "seasonPower+attackZoneFit+pitchArsenalFit",
            "contactProfile+pitcherMatchup+attackZoneFit",
            "statcastPower+pullAirPower",
            "statcastPower+advancedPitcher",
            "pitchArsenalFit+statcastPower",
            "statcastPower+pullAirPower+advancedPitcher",
            "pitchArsenalFit+statcastPower+advancedPitcher",
            "seasonPower+hrPronePitcher",
            "contactProfile+hrPronePitcher",
            "pitchArsenalFit+hrPronePitcher",
            "seasonPower+statcastPower+hrPronePitcher"
        )
        val priority = rules.filter { it.key in priorityKeys }
            .sortedByDescending { (it.posteriorLift - 1.0).absoluteValue * it.reliability }
        val learnedPatterns = (priority + rules.sortedByDescending {
            (it.posteriorLift - 1.0).absoluteValue * it.reliability
        }).distinctBy { it.key }.take(20)

        return ModelLearningProfile(
            resolvedHitterGames = resolved.size,
            homeRuns = homeRuns,
            baselineRate = baseline,
            metrics = mapOf(
                "recentPower" to metric { it.recentPower },
                "powerPressure" to metric { it.powerPressure },
                "pitcherMatchup" to metric { it.pitcherMatchup },
                "environment" to metric { it.environment },
                "seasonPower" to metric { it.seasonPower },
                "platoon" to metric { it.platoon },
                "contactProfile" to metric { it.contactProfile },
                "pitchArsenalFit" to metric { row ->
                    val confidence = row.pitchArsenalConfidence ?: 0.30
                    row.pitchArsenalFit?.takeIf { confidence >= 0.28 }
                },
                "attackZoneFit" to metric { row ->
                    val confidence = row.attackZoneConfidence ?: 0.0
                    row.attackZoneFit?.takeIf { confidence >= 0.28 }
                },
                "statcastPower" to metric { row ->
                    row.statcastPower?.takeIf { (row.precisionConfidence ?: 0.0) >= 0.30 }
                },
                "pullAirPower" to metric { row ->
                    row.pullAirPower?.takeIf { (row.precisionConfidence ?: 0.0) >= 0.30 }
                },
                "advancedPitcher" to metric { row ->
                    row.advancedPitcher?.takeIf { (row.precisionConfidence ?: 0.0) >= 0.30 }
                },
                "hrPronePitcher" to metric { row ->
                    row.hrPronePitcher?.takeIf { (row.precisionConfidence ?: 0.0) >= 0.28 }
                }
            ),
            patterns = learnedPatterns
        )
    }

    private fun <T> combinations(items: List<T>, size: Int): List<List<T>> {
        if (size <= 0) return listOf(emptyList())
        if (size > items.size) return emptyList()
        val result = mutableListOf<List<T>>()
        fun walk(start: Int, current: MutableList<T>) {
            if (current.size == size) {
                result += current.toList()
                return
            }
            val needed = size - current.size
            for (i in start..items.size - needed) {
                current += items[i]
                walk(i + 1, current)
                current.removeAt(current.lastIndex)
            }
        }
        walk(0, mutableListOf())
        return result
    }
}
