package com.ckz.hrchase

import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ckz.hrchase.ui.HrChaseApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // HR Chase is a phone-first portrait dashboard. Lock it here as a second line of defense
        // in addition to AndroidManifest so sensor/rotation state cannot leave the UI sideways.
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        enableEdgeToEdge()
        setContent {
            val vm: MainViewModel = viewModel()
            HrChaseApp(vm)
        }
    }
}
