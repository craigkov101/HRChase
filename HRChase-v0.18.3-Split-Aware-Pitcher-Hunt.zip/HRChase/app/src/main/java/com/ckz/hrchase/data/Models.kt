package com.ckz.hrchase.data

import java.time.Instant
import java.time.LocalDate


data class TeamRef(
    val id: Int,
    val name: String,
    val abbreviation: String = name.take(3).uppercase()
)

data class PersonRef(
    val id: Int,
    val name: String,
    val batSide: String? = null,
    val pitchHand: String? = null
)

data class WeatherInfo(
    val temperatureF: Int? = null,
    val wind: String? = null,
    val condition: String? = null,
    val roofType: String? = null
)

data class GameInfo(
    val gamePk: Long,
    val gameDate: Instant,
    val status: String,
    val detailedStatus: String,
    val awayTeam: TeamRef,
    val homeTeam: TeamRef,
    val venueName: String,
    val awayProbablePitcher: PersonRef? = null,
    val homeProbablePitcher: PersonRef? = null,
    val weather: WeatherInfo = WeatherInfo()
)

data class HittingStats(
    val atBats: Int = 0,
    val plateAppearances: Int = 0,
    val hits: Int = 0,
    val doubles: Int = 0,
    val triples: Int = 0,
    val homeRuns: Int = 0,
    val walks: Int = 0,
    val strikeouts: Int = 0,
    val avg: Double? = null,
    val slg: Double? = null,
    val ops: Double? = null
)

data class HittingSplitStats(
    val atBats: Int = 0,
    val plateAppearances: Int = 0,
    val hits: Int = 0,
    val doubles: Int = 0,
    val triples: Int = 0,
    val homeRuns: Int = 0,
    val walks: Int = 0,
    val strikeouts: Int = 0,
    val avg: Double? = null,
    val obp: Double? = null,
    val slg: Double? = null,
    val ops: Double? = null
) {
    val iso: Double?
        get() = if (slg != null && avg != null) (slg - avg).coerceAtLeast(0.0) else null
    val hrPerPa: Double?
        get() = if (plateAppearances > 0) homeRuns.toDouble() / plateAppearances else null
    val strikeoutRate: Double?
        get() = if (plateAppearances > 0) strikeouts.toDouble() / plateAppearances else null
}



data class MinorLeagueHitterLine(
    val player: PersonRef,
    val team: TeamRef?,
    val parentOrgId: Int? = null,
    val parentOrgName: String? = null,
    val primaryPosition: String? = null,
    val currentAge: Int? = null,
    val stats: RecentHittingStats
)

data class AaaSluggerProspect(
    val player: PersonRef,
    val aaaTeam: TeamRef?,
    val mlbOrg: String,
    val position: String,
    val seasonStats: RecentHittingStats,
    val recentStats: RecentHittingStats?,
    val recentBattedBalls: List<BattedBall> = emptyList(),
    val contactMetrics: MustHaveMetrics? = null,
    val contactScore: Int? = null,
    val contactSourceGames: Int = 0,
    val powerScore: Int,
    val recentPowerScore: Int,
    val readinessScore: Int,
    val callupWatchScore: Int,
    val sluggerScore: Int,
    val watchLabel: String,
    val watchReason: String,
    val sourceNote: String = "Curated Triple-A call-up watch; scores are comparative model grades, not probabilities."
)

data class RecentHittingStats(
    val gamesPlayed: Int = 0,
    val atBats: Int = 0,
    val plateAppearances: Int = 0,
    val runs: Int = 0,
    val hits: Int = 0,
    val doubles: Int = 0,
    val triples: Int = 0,
    val homeRuns: Int = 0,
    val rbi: Int = 0,
    val walks: Int = 0,
    val strikeouts: Int = 0,
    val hitByPitch: Int = 0,
    val sacFlies: Int = 0,
    val avg: Double? = null,
    val obp: Double? = null,
    val slg: Double? = null,
    val ops: Double? = null
) {
    val extraBaseHits: Int get() = doubles + triples + homeRuns
    val iso: Double?
        get() = if (slg != null && avg != null) (slg - avg).coerceAtLeast(0.0) else null
    val hrPerPa: Double?
        get() = if (plateAppearances > 0) homeRuns.toDouble() / plateAppearances else null
    val strikeoutRate: Double?
        get() = if (plateAppearances > 0) strikeouts.toDouble() / plateAppearances else null
    val walkRate: Double?
        get() = if (plateAppearances > 0) walks.toDouble() / plateAppearances else null
}

data class BatterVsPitcherStats(
    val atBats: Int = 0,
    val plateAppearances: Int = 0,
    val hits: Int = 0,
    val doubles: Int = 0,
    val triples: Int = 0,
    val homeRuns: Int = 0,
    val walks: Int = 0,
    val strikeouts: Int = 0,
    val hitByPitch: Int = 0,
    val sacFlies: Int = 0,
    val avg: Double? = null,
    val obp: Double? = null,
    val slg: Double? = null,
    val ops: Double? = null
)

data class PitchingStats(
    val gamesPlayed: Int = 0,
    val gamesStarted: Int = 0,
    val inningsPitched: Double = 0.0,
    val hitsAllowed: Int = 0,
    val earnedRuns: Int = 0,
    val homeRunsAllowed: Int = 0,
    val strikeouts: Int = 0,
    val walks: Int = 0,
    val battersFaced: Int = 0,
    val pitchesThrown: Int = 0,
    val strikesThrown: Int = 0,
    val era: Double? = null,
    val whip: Double? = null
) {
    val hrPer9: Double?
        get() = if (inningsPitched > 0.0) homeRunsAllowed * 9.0 / inningsPitched else null
    val strikeoutsPer9: Double?
        get() = if (inningsPitched > 0.0) strikeouts * 9.0 / inningsPitched else null
    val strikeoutRate: Double?
        get() = if (battersFaced > 0) strikeouts.toDouble() / battersFaced else null
    val walkRate: Double?
        get() = if (battersFaced > 0) walks.toDouble() / battersFaced else null
    val inningsPerStart: Double?
        get() = if (gamesStarted > 0) inningsPitched / gamesStarted else null
    val battersFacedPerStart: Double?
        get() = if (gamesStarted > 0) battersFaced.toDouble() / gamesStarted else null
    val pitchesPerStart: Double?
        get() = if (gamesStarted > 0 && pitchesThrown > 0) pitchesThrown.toDouble() / gamesStarted else null
    val strikePct: Double?
        get() = if (pitchesThrown > 0 && strikesThrown > 0) strikesThrown.toDouble() / pitchesThrown else null
}


data class PlateDisciplineSample(
    val totalPitches: Int = 0,
    val swings: Int = 0,
    val whiffs: Int = 0
) {
    val whiffRate: Double?
        get() = if (swings > 0) whiffs.toDouble() / swings else null
    val swingRate: Double?
        get() = if (totalPitches > 0) swings.toDouble() / totalPitches else null

    operator fun plus(other: PlateDisciplineSample): PlateDisciplineSample = PlateDisciplineSample(
        totalPitches = totalPitches + other.totalPitches,
        swings = swings + other.swings,
        whiffs = whiffs + other.whiffs
    )
}

data class BattedBall(
    val gamePk: Long,
    val gameDate: LocalDate,
    val batterId: Int,
    val pitcherId: Int,
    val batterName: String,
    val pitcherName: String,
    val batterSide: String? = null,
    val exitVelocity: Double?,
    val launchAngle: Double?,
    val distanceFt: Double?,
    val trajectory: String? = null,
    val fieldLocation: Int? = null,
    val sprayX: Double? = null,
    val sprayY: Double? = null,
    val eventType: String,
    val isHomeRun: Boolean,
    val isOut: Boolean,
    val description: String? = null,
    val pitchType: String? = null,
    val plateX: Double? = null,
    val plateZ: Double? = null,
    val strikeZoneTop: Double? = null,
    val strikeZoneBottom: Double? = null
)

data class PitchLocationSample(
    val gamePk: Long,
    val gameDate: LocalDate,
    val batterId: Int,
    val pitcherId: Int,
    val batterSide: String? = null,
    val pitchType: String? = null,
    val plateX: Double,
    val plateZ: Double,
    val strikeZoneTop: Double? = null,
    val strikeZoneBottom: Double? = null,
    val description: String? = null,
    val isSwing: Boolean = false,
    val isWhiff: Boolean = false,
    val isInPlay: Boolean = false
)

data class MustHaveMetrics(
    val barrelPct: Double? = null,
    val pullBarrelPct: Double? = null,
    val pullAirPct: Double? = null,
    val hardHitPct: Double? = null,
    val avgDistanceFt: Double? = null,
    val avgExitVelocity: Double? = null,
    val avgLaunchAngle: Double? = null,
    val iso: Double? = null,
    val flyBallPct: Double? = null,
    val pullPct: Double? = null,
    val blastPct: Double? = null,
    val sweetSpotPct: Double? = null,
    val maxExitVelocity: Double? = null,
    val battedBallCount: Int = 0,
    val directionalBattedBallCount: Int = 0,
    val score: Double = 50.0,
    val confidence: Double = 0.0
)

data class LineupPlayer(
    val person: PersonRef,
    val battingOrder: Int,
    val seasonStats: HittingStats,
    val official: Boolean,
    val sourceGamePk: Long
)

data class TeamLineup(
    val team: TeamRef,
    val players: List<LineupPlayer>,
    val official: Boolean
)



data class PitchTypeUsage(
    val code: String,
    val name: String,
    val count: Int,
    val share: Double = 0.0
)

data class PitchHrTendency(
    val code: String,
    val name: String,
    val homeRuns: Int,
    val share: Double,
    val opposingPitcherUsage: Double,
    val batterSlg: Double? = null,
    val batterXslg: Double? = null,
    val batterHardHitPct: Double? = null,
    val pitcherXslgAllowed: Double? = null
)

/** Per-pitch-type Statcast leaderboard row from Baseball Savant. */
data class SavantPitchArsenalRow(
    val playerId: Int,
    val code: String,
    val name: String,
    val pitches: Int,
    val usagePct: Double? = null,
    val plateAppearances: Int = 0,
    val slg: Double? = null,
    val xslg: Double? = null,
    val woba: Double? = null,
    val xwoba: Double? = null,
    val hardHitPct: Double? = null,
    val whiffPct: Double? = null,
    val strikeoutPct: Double? = null,
    val putAwayPct: Double? = null
)

data class ZoneCellMatch(
    val label: String,
    val pitcherShare: Double,
    val batterDamageScore: Double,
    val batterContactCount: Int
)

data class AttackZoneMatch(
    val score: Double = 50.0,
    val confidence: Double = 0.0,
    val pitcherPitchSample: Int = 0,
    val batterContactSample: Int = 0,
    val coveredPitcherShare: Double = 0.0,
    val bestZones: List<ZoneCellMatch> = emptyList(),
    val source: String = "MLB Gameday pitch locations"
)

data class ResearchLensScore(
    val match: Double = 50.0,
    val processTest: Double = 50.0,
    val ceiling: Double = 50.0
)

data class PitchArsenalMatch(
    val score: Double = 50.0,
    val confidence: Double = 0.0,
    val batterHrSample: Int = 0,
    val batterPitchSample: Int = 0,
    val pitcherPitchSample: Int = 0,
    val feastPitches: List<PitchHrTendency> = emptyList(),
    val pitcherArsenal: List<PitchTypeUsage> = emptyList(),
    val source: String = "MLB Statcast"
)


data class StatcastContactProfile(
    val battedBallEvents: Int = 0,
    val avgLaunchAngle: Double? = null,
    val sweetSpotPct: Double? = null,
    val maxExitVelocity: Double? = null,
    val avgExitVelocity: Double? = null,
    val ev50: Double? = null,
    val maxDistanceFt: Double? = null,
    val avgDistanceFt: Double? = null,
    val hardHitPct: Double? = null,
    val barrels: Int = 0,
    val barrelPct: Double? = null,
    val barrelPerPaPct: Double? = null
)

data class ExpectedStatsProfile(
    val plateAppearances: Int = 0,
    val battedBalls: Int = 0,
    val avg: Double? = null,
    val xAvg: Double? = null,
    val slg: Double? = null,
    val xSlg: Double? = null,
    val woba: Double? = null,
    val xWoba: Double? = null,
    val era: Double? = null,
    val xEra: Double? = null
)

data class BatTrackingProfile(
    val competitiveSwings: Int = 0,
    val avgBatSpeed: Double? = null,
    val fastSwingRate: Double? = null,
    val squaredUpContactRate: Double? = null,
    val squaredUpSwingRate: Double? = null,
    val blastContactRate: Double? = null,
    val blastSwingRate: Double? = null,
    val swingLength: Double? = null,
    val whiffPerSwing: Double? = null
)

data class SwingPathProfile(
    val side: String? = null,
    val competitiveSwings: Int = 0,
    val avgBatSpeed: Double? = null,
    val swingTilt: Double? = null,
    val attackAngle: Double? = null,
    val attackDirection: Double? = null,
    val idealAttackAngleRate: Double? = null
)

data class BattedBallDirectionProfile(
    val battedBallEvents: Int = 0,
    val groundBallRate: Double? = null,
    val airRate: Double? = null,
    val flyBallRate: Double? = null,
    val pullRate: Double? = null,
    val pullAirRate: Double? = null
)


data class ExpectedHomeRunProfile(
    val actualHomeRuns: Int = 0,
    val expectedHomeRuns: Double? = null,
    val hrMinusExpected: Double? = null,
    val noDoubters: Int = 0,
    val mostlyGone: Int = 0,
    val doubters: Int = 0,
    val noDoubterPct: Double? = null,
    val source: String = "Statcast adjusted xHR"
)

data class ParkFactorProfile(
    val venueName: String,
    val batterSide: String? = null,
    val homeRunFactor: Double? = null,
    val source: String = "Statcast park factor"
)

data class PitcherProfile(
    val person: PersonRef,
    val seasonStats: PitchingStats,
    val recentBattedBallsAllowed: List<BattedBall>,
    val seasonPitchArsenal: List<PitchTypeUsage> = emptyList(),
    val seasonPitchArsenalStats: List<SavantPitchArsenalRow> = emptyList(),
    val statcastContact: StatcastContactProfile? = null,
    val expectedStats: ExpectedStatsProfile? = null,
    val expectedHomeRuns: ExpectedHomeRunProfile? = null
)

/**
 * Starter-level home-run susceptibility used by the game-first Pitcher Hunt view.
 * The score intentionally blends long-term HR allowance with recent HR rate and
 * Statcast contact quality, while confidence stays separate from the matchup score.
 */
data class PitcherHrVulnerabilityProfile(
    val score: Double = 50.0,
    val confidence: Double = 0.0,
    val label: String = "AVERAGE",
    val splitLabel: String? = null,
    val splitHrPer9: Double? = null,
    val splitHrPerBatter: Double? = null,
    val splitBattersFaced: Int? = null,
    val seasonHrPer9: Double? = null,
    val recent30HrPer9: Double? = null,
    val recent14HrPer9: Double? = null,
    val recent7HrPer9: Double? = null,
    val seasonHrPerBatter: Double? = null,
    val barrelPctAllowed: Double? = null,
    val hardHitPctAllowed: Double? = null,
    val xSlgAllowed: Double? = null,
    val xWobaAllowed: Double? = null
)

data class StrikeoutPitchMatch(
    val score: Double = 50.0,
    val confidence: Double = 0.0,
    val coveredUsage: Double = 0.0,
    val strongestPitches: List<String> = emptyList(),
    val source: String = "Savant pitch-type whiff data"
)

data class ScoreWeights(
    val recentPower: Float = 20f,
    val powerPressure: Float = 15f,
    val pitcherMatchup: Float = 28f,
    val environment: Float = 8f,
    val seasonPower: Float = 24f,
    val lineup: Float = 5f
) {
    val total: Float get() = recentPower + powerPressure + pitcherMatchup + environment + seasonPower + lineup
}

data class ScoreBreakdown(
    val recentPower: Double,
    val powerPressure: Double,
    val pitcherMatchup: Double,
    val environment: Double,
    val seasonPower: Double,
    val lineup: Double,
    val total: Double,
    val tags: List<String>,
    val notes: List<String>,
    val platoon: Double = 50.0
)

data class HitterCandidate(
    val player: PersonRef,
    val team: TeamRef,
    val opponent: TeamRef,
    val game: GameInfo,
    val battingOrder: Int,
    val lineupOfficial: Boolean,
    val seasonStats: HittingStats,
    val opponentPitcher: PitcherProfile?,
    val recentBattedBalls: List<BattedBall>,
    val todayBattedBalls: List<BattedBall>,
    val recentPlateDiscipline: PlateDisciplineSample = PlateDisciplineSample(),
    val last3PlateDiscipline: PlateDisciplineSample = PlateDisciplineSample(),
    val score: ScoreBreakdown,
    val vsPitcherStats: BatterVsPitcherStats? = null,
    val platoonStats: HittingSplitStats? = null,
    val pitchArsenalMatch: PitchArsenalMatch? = null,
    val strikeoutPitchMatch: StrikeoutPitchMatch? = null,
    val attackZoneMatch: AttackZoneMatch? = null,
    val statcastContact: StatcastContactProfile? = null,
    val expectedStats: ExpectedStatsProfile? = null,
    val batTracking: BatTrackingProfile? = null,
    val swingPath: SwingPathProfile? = null,
    val battedBallDirection: BattedBallDirectionProfile? = null,
    val opponentBullpenStats: PitchingStats? = null,
    val parkFactor: ParkFactorProfile? = null,
    val expectedHomeRuns: ExpectedHomeRunProfile? = null
)

data class BoardData(
    val date: LocalDate,
    val candidates: List<HitterCandidate>,
    val games: List<GameInfo>,
    val lastUpdated: Instant,
    val recentGameCount: Int,
    val recentWeekStats: Map<Int, RecentHittingStats> = emptyMap(),
    val recentThreeDayStats: Map<Int, RecentHittingStats> = emptyMap(),
    val recentFourteenDayStats: Map<Int, RecentHittingStats> = emptyMap(),
    val seasonProductionStats: Map<Int, RecentHittingStats> = emptyMap(),
    val pitcherRecentThirtyDayStats: Map<Int, PitchingStats> = emptyMap(),
    val pitcherRecentFourteenDayStats: Map<Int, PitchingStats> = emptyMap(),
    val pitcherRecentSevenDayStats: Map<Int, PitchingStats> = emptyMap(),
    val pitcherVsLeftStats: Map<Int, PitchingStats> = emptyMap(),
    val pitcherVsRightStats: Map<Int, PitchingStats> = emptyMap(),
    val previousNight: PreviousNightSummary? = null
)



data class PreviousNightHomer(
    val playerId: Int,
    val playerName: String,
    val team: TeamRef?,
    val gamePk: Long,
    val homeRuns: Int,
    val maxExitVelocity: Double? = null,
    val longestDistanceFt: Double? = null,
    val launchAngles: List<Double> = emptyList(),
    val pitchTypes: List<String> = emptyList()
)

data class PreviousNightSummary(
    val date: LocalDate,
    val totalHomeRuns: Int,
    val uniqueHitters: Int,
    val finalGames: Int,
    val homers: List<PreviousNightHomer> = emptyList()
)

data class HitterSignalSnapshot(
    val date: LocalDate,
    val playerId: Int,
    val recentPower: Double,
    val powerPressure: Double,
    val pitcherMatchup: Double,
    val environment: Double,
    val seasonPower: Double,
    val platoon: Double,
    val contactProfile: Double,
    val pitchArsenalFit: Double? = null,
    val pitchArsenalConfidence: Double? = null,
    val attackZoneFit: Double? = null,
    val attackZoneConfidence: Double? = null,
    val statcastPower: Double? = null,
    val pullAirPower: Double? = null,
    val advancedPitcher: Double? = null,
    val hrPronePitcher: Double? = null,
    val precisionConfidence: Double? = null,
    val outcomeHomeRun: Boolean? = null
)

data class DailySignalSnapshot(
    val date: LocalDate,
    val savedAt: Instant,
    val hitters: List<HitterSignalSnapshot>
)

data class MetricLearning(
    val attempts: Int = 0,
    val homeRuns: Int = 0,
    val rate: Double = 0.0,
    val lift: Double = 1.0
)

data class LearnedPatternRule(
    val key: String,
    val label: String,
    val attempts: Int,
    val homeRuns: Int,
    val rawRate: Double,
    val posteriorRate: Double,
    val posteriorLift: Double,
    val reliability: Double
) {
    val isPositive: Boolean get() = posteriorLift >= 1.05
}

data class ModelLearningProfile(
    val resolvedHitterGames: Int = 0,
    val homeRuns: Int = 0,
    val baselineRate: Double = 0.0,
    val metrics: Map<String, MetricLearning> = emptyMap(),
    val patterns: List<LearnedPatternRule> = emptyList()
) {
    // Pattern learning activates earlier than the old single-metric learner, but every rule is
    // Bayesian-shrunk and reliability-weighted so a tiny sample cannot hijack the board.
    val isActive: Boolean get() = resolvedHitterGames >= 250 && homeRuns >= 18
    val isMature: Boolean get() = resolvedHitterGames >= 900 && homeRuns >= 55
}

data class CommonDenominatorSignal(
    val key: String,
    val label: String,
    val threshold: Double,
    val homerCount: Int,
    val homerTotal: Int,
    val fieldCount: Int,
    val fieldTotal: Int,
    val homerCoverage: Double,
    val fieldCoverage: Double,
    val hrRateLift: Double,
    val homerAverage: Double,
    val fieldAverage: Double,
    val strength: Double
)

data class CommonDenominatorCombination(
    val key: String,
    val label: String,
    val homerCount: Int,
    val homerTotal: Int,
    val fieldCount: Int,
    val fieldTotal: Int,
    val homerCoverage: Double,
    val hrRateLift: Double,
    val strength: Double
)

data class MatchupConvergenceProfile(
    val score: Double = 50.0,
    val label: String = "NEUTRAL",
    val available: Boolean = false,
    val arsenalScore: Double? = null,
    val platoonScore: Double = 50.0,
    val evidenceConfidence: Double = 0.0,
    val learnedLift: Double? = null,
    val learnedAttempts: Int = 0
) {
    val isPerfectFit: Boolean get() = available && label == "PERFECT FIT"
    val isStrongFit: Boolean get() = available && (label == "PERFECT FIT" || label == "STRONG FIT")
}

data class NightHomerReference(
    val playerId: Int,
    val playerName: String,
    val homeRuns: Int = 1,
    val seasonPower: Double,
    val contactProfile: Double,
    val recentPower: Double,
    val powerPressure: Double,
    val pitcherMatchup: Double,
    val pitchArsenalFit: Double? = null,
    val attackZoneFit: Double? = null,
    val platoon: Double,
    val environment: Double
)

data class NightPatternProfile(
    val date: LocalDate? = null,
    val gradedHitters: Int = 0,
    val homerHitters: Int = 0,
    val signals: List<CommonDenominatorSignal> = emptyList(),
    val combinations: List<CommonDenominatorCombination> = emptyList(),
    val references: List<NightHomerReference> = emptyList(),
    val homerGreenLightsAverage: Double = 0.0,
    val fieldGreenLightsAverage: Double = 0.0,
    val confidence: Double = 0.0
) {
    val isUsable: Boolean
        get() = date != null && gradedHitters >= 50 && homerHitters >= 4 && (signals.size >= 2 || combinations.isNotEmpty() || references.size >= 4)
}

/** A strong pregame trait shared by hitters who have already homered earlier today. */
data class SameDaySharedSignal(
    val key: String,
    val label: String,
    val threshold: Double,
    val homerCount: Int,
    val homerTotal: Int,
    val coverage: Double,
    val homerAverage: Double
)

/** Pregame profile of an actual same-day HR hitter. Outcome/contact fields are result context only. */
data class SameDayHomerReference(
    val playerId: Int,
    val playerName: String,
    val team: TeamRef,
    val gamePk: Long,
    val homeRuns: Int,
    val maxExitVelocity: Double? = null,
    val longestDistanceFt: Double? = null,
    val pitchTypes: List<String> = emptyList(),
    val seasonPower: Double,
    val contactProfile: Double,
    val recentPower: Double,
    val powerPressure: Double,
    val pitcherMatchup: Double,
    val pitchArsenalFit: Double? = null,
    val attackZoneFit: Double? = null,
    val platoon: Double,
    val environment: Double
)

/** Live early-game -> late-game pattern transfer for the current MLB date. */
data class SameDayPatternProfile(
    val date: LocalDate? = null,
    val startedGames: Int = 0,
    val finalGames: Int = 0,
    val remainingGames: Int = 0,
    val totalHomeRuns: Int = 0,
    val references: List<SameDayHomerReference> = emptyList(),
    val sharedSignals: List<SameDaySharedSignal> = emptyList(),
    val confidence: Double = 0.0
) {
    val homerHitters: Int get() = references.size
    val isUsable: Boolean get() = date != null && references.isNotEmpty() && remainingGames > 0
}


enum class PickType { HOME_RUN }

data class PitcherStrikeoutPrediction(
    val pitcher: PersonRef,
    val team: TeamRef,
    val opponent: TeamRef,
    val game: GameInfo,
    val score: Double,
    val projectedStrikeouts: Double,
    val projectionLow: Double,
    val projectionHigh: Double,
    val confidence: Double,
    val pitcherAbilityScore: Double,
    val opponentStrikeoutScore: Double,
    val handednessScore: Double,
    val recentFormScore: Double,
    val arsenalWhiffScore: Double,
    val workloadScore: Double,
    val commandScore: Double,
    val seasonStrikeoutRate: Double?,
    val opponentStrikeoutRate: Double?,
    val opponentSplitStrikeoutRate: Double?,
    val recentOpponentStrikeoutRate: Double?,
    val projectedBattersFaced: Double,
    val lineupOfficial: Boolean,
    val tags: List<String> = emptyList(),
    val notes: List<String> = emptyList()
)

data class PitcherStrikeoutSnapshot(
    val date: LocalDate,
    val pitcherId: Int,
    val projectedStrikeouts: Double,
    val score: Double,
    val opponentStrikeoutRate: Double?,
    val seasonStrikeoutRate: Double?,
    val arsenalWhiffScore: Double,
    val workloadScore: Double,
    val outcomeStrikeouts: Int? = null
)

data class DailyPitcherStrikeoutSnapshot(
    val date: LocalDate,
    val savedAt: Instant,
    val pitchers: List<PitcherStrikeoutSnapshot>
)

data class PitcherStrikeoutCalibrationBucket(
    val label: String,
    val attempts: Int,
    val averageProjected: Double,
    val averageActual: Double,
    val meanAbsoluteError: Double,
    val sixPlusRate: Double
)

data class PitcherStrikeoutLearningProfile(
    val resolvedStarts: Int = 0,
    val meanAbsoluteError: Double = 0.0,
    val averageBias: Double = 0.0,
    val buckets: List<PitcherStrikeoutCalibrationBucket> = emptyList()
) {
    val isActive: Boolean get() = resolvedStarts >= 20
    val isMature: Boolean get() = resolvedStarts >= 100
}

data class TrackedPick(
    val playerId: Int,
    val playerName: String,
    val teamName: String,
    val date: LocalDate,
    val scoreAtTrack: Double,
    val trackedAt: Instant,
    val pickType: PickType = PickType.HOME_RUN
)

/** A concise postgame diagnosis for a target that was on the board. */
data class PostgameReview(
    val label: String,
    val explanation: String,
    val resultLine: String
)
