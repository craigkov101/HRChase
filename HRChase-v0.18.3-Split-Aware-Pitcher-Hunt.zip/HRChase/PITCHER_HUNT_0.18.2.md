# HR Chase v0.18.2 — Pitcher Hunt

This release shifts more of the HR workflow to a game-first question: **which starting pitchers are most vulnerable to home runs, and which real power hitters are best positioned to attack them?**

## New starter HR vulnerability profile
Each probable starter receives a dedicated HR-risk score built from:
- season HR/9
- season HR allowed per batter faced
- last 30-day HR/9, sample-regressed by innings
- last 14-day HR/9, sample-regressed by innings
- last 7-day HR/9, heavily sample-regressed
- Statcast barrel% allowed
- Statcast hard-hit% allowed
- xSLG allowed
- xwOBA allowed

Recent windows can move the score, but they cannot overpower the season baseline without enough innings. Statcast confirms whether the underlying contact quality agrees with the box-score HR rate.

Labels: RED ALERT, HR-PRONE, ATTACKABLE, AVERAGE, HR-SUPPRESSOR.

## Pitcher Hunt UI
- New **HR-Prone SP** filter on Picks.
- When active, hitters are sorted by starter HR vulnerability first, then data confidence, Target Score, and hitter power.
- New **TARGET PITCHERS** panel shows the most attackable starters on the slate and the best current HR Chase hitter against each one.
- Target cards now include a visible **STARTER HR RISK** strip with season/recent HR/9 and barrel allowance when available.

## Formula change
MATCH now gives more authority to starter-specific HR susceptibility. Generic pitcher quality and Statcast contact remain supporting signals.

A high-risk starter can boost a hitter only when the hitter already owns a legitimate power/process foundation. A weak hitter cannot become a top play solely because the opposing pitcher allows home runs.

## Outcome learning
Pregame snapshots now save the HR-prone starter score. Pattern Engine can learn whether combinations such as:
- Season Power + HR-Prone Starter
- Contact Quality + HR-Prone Starter
- Pitch Arsenal Fit + HR-Prone Starter
- Season Power + Statcast Power + HR-Prone Starter
actually produce elevated HR rates over time.

Synthetic learning smoke test: when the test data deliberately makes Season Power + HR-Prone Starter predictive, Pattern Engine recovered a positive posterior lift (~1.90x). This validates the learning path, not a real-world 1.90x claim.
