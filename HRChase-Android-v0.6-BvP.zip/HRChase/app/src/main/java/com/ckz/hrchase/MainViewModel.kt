package com.ckz.hrchase

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ckz.hrchase.data.AppPreferences
import com.ckz.hrchase.data.BoardData
import com.ckz.hrchase.data.HitterCandidate
import com.ckz.hrchase.data.Repository
import com.ckz.hrchase.data.ScoreWeights
import com.ckz.hrchase.data.TrackedPick
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import kotlin.math.absoluteValue

enum class SortMode { SCORE, ATTACK, POWER_PRESSURE, RECENT_POWER, MATCHUP }

data class AppUiState(
    val selectedDate: LocalDate = LocalDate.now(),
    val board: BoardData? = null,
    val isLoading: Boolean = false,
    val progress: String = "",
    val error: String? = null,
    val selectedPlayerId: Int? = null,
    val showRemainingOnly: Boolean = true,
    val officialLineupsOnly: Boolean = false,
    val sortMode: SortMode = SortMode.SCORE,
    val attackStrongOnly: Boolean = false,
    val weights: ScoreWeights = ScoreWeights(),
    val tracked: List<TrackedPick> = emptyList()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = AppPreferences(application)
    private val repository = Repository()
    private var refreshJob: Job? = null

    private val _state = MutableStateFlow(
        AppUiState(
            weights = prefs.loadWeights(),
            tracked = prefs.loadTracked()
        )
    )
    val state: StateFlow<AppUiState> = _state.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            val date = _state.value.selectedDate
            val weights = _state.value.weights
            mutate { it.copy(isLoading = true, error = null, progress = "Starting…") }
            runCatching {
                repository.loadBoard(date, weights) { message ->
                    mutate { s -> s.copy(progress = message) }
                }
            }.onSuccess { board ->
                mutate { it.copy(board = board, isLoading = false, progress = "Ready", error = null) }
            }.onFailure { error ->
                mutate {
                    it.copy(
                        isLoading = false,
                        progress = "",
                        error = error.message ?: error::class.java.simpleName
                    )
                }
            }
        }
    }

    fun changeDate(days: Long) {
        mutate { it.copy(selectedDate = it.selectedDate.plusDays(days), selectedPlayerId = null) }
        refresh()
    }

    fun setDate(date: LocalDate) {
        mutate { it.copy(selectedDate = date, selectedPlayerId = null) }
        refresh()
    }

    fun toggleRemainingOnly() = mutate { it.copy(showRemainingOnly = !it.showRemainingOnly) }
    fun toggleOfficialOnly() = mutate { it.copy(officialLineupsOnly = !it.officialLineupsOnly) }
    fun setSortMode(mode: SortMode) = mutate { it.copy(sortMode = mode) }
    fun toggleAttackStrongOnly() = mutate { it.copy(attackStrongOnly = !it.attackStrongOnly) }

    /**
     * The v0.3 combo signal. This remains available as a building block, but v0.4 presents it
     * inside a simpler game-first experience instead of exposing many competing sort modes.
     */
    fun attackScore(candidate: HitterCandidate): Double =
        candidate.score.powerPressure * 0.45 +
            candidate.score.pitcherMatchup * 0.45 +
            candidate.score.recentPower * 0.10

    /**
     * A single recommendation score used for game rankings and the parlay generator.
     * It deliberately emphasizes "pressure + matchup", then checks the overall model and
     * environment so a hot hitter in a terrible spot does not automatically rise to the top.
     */
    /**
     * Sample-size-aware BvP adjustment. Strong history matters, but it is intentionally capped so
     * a 2-for-3 matchup cannot overpower current contact quality and the pitcher profile.
     */
    fun bvpAdjustment(candidate: HitterCandidate): Double {
        val bvp = candidate.vsPitcherStats ?: return 0.0
        val pa = bvp.plateAppearances
        if (pa < 5) return 0.0

        var raw = 0.0
        raw += when {
            (bvp.ops ?: 0.0) >= 1.050 -> 5.0
            (bvp.ops ?: 0.0) >= .900 -> 3.0
            (bvp.ops ?: 9.0) < .600 -> -2.0
            else -> 0.0
        }
        raw += when {
            bvp.homeRuns >= 3 -> 4.0
            bvp.homeRuns == 2 -> 3.0
            bvp.homeRuns == 1 -> 1.5
            else -> 0.0
        }
        raw += when {
            (bvp.avg ?: 0.0) >= .350 -> 1.5
            (bvp.avg ?: 0.0) >= .300 -> 0.75
            else -> 0.0
        }

        val reliability = when {
            pa >= 20 -> 1.0
            pa >= 12 -> .85
            pa >= 8 -> .70
            else -> .55
        }
        return (raw * reliability).coerceIn(-4.0, 8.0)
    }

    fun pickScore(candidate: HitterCandidate): Double =
        attackScore(candidate) * 0.55 +
            candidate.score.total * 0.30 +
            candidate.score.environment * 0.10 +
            candidate.score.lineup * 0.05 +
            bvpAdjustment(candidate)

    fun selectPlayer(id: Int?) = mutate { it.copy(selectedPlayerId = id) }

    fun updateWeights(weights: ScoreWeights) {
        prefs.saveWeights(weights)
        mutate { s ->
            val rescored = s.board?.let { repository.rescore(it, weights) }
            s.copy(weights = weights, board = rescored)
        }
    }

    fun resetWeights() = updateWeights(ScoreWeights())

    fun toggleTracked(candidate: HitterCandidate) {
        val date = _state.value.selectedDate
        val existing = _state.value.tracked
        val keyMatch: (TrackedPick) -> Boolean = { it.playerId == candidate.player.id && it.date == date }
        val next = if (existing.any(keyMatch)) {
            existing.filterNot(keyMatch)
        } else {
            existing + TrackedPick(
                playerId = candidate.player.id,
                playerName = candidate.player.name,
                teamName = candidate.team.name,
                date = date,
                scoreAtTrack = candidate.score.total,
                trackedAt = Instant.now()
            )
        }
        prefs.saveTracked(next)
        mutate { it.copy(tracked = next) }
    }

    fun clearTrackedForSelectedDate() {
        val date = _state.value.selectedDate
        val next = _state.value.tracked.filterNot { it.date == date }
        prefs.saveTracked(next)
        mutate { it.copy(tracked = next) }
    }

    private fun mutate(block: (AppUiState) -> AppUiState) {
        _state.value = block(_state.value)
    }

    /** Base candidate set shared by Games and Parlays. */
    fun eligibleCandidates(state: AppUiState = _state.value): List<HitterCandidate> {
        val board = state.board ?: return emptyList()
        val nowDate = LocalDate.now()
        return board.candidates.asSequence()
            .filter { c ->
                if (!state.showRemainingOnly || board.date != nowDate) true
                else !c.game.status.equals("Final", true)
            }
            .filter { c -> !state.officialLineupsOnly || c.lineupOfficial }
            .toList()
    }

    fun visibleCandidates(state: AppUiState = _state.value): List<HitterCandidate> {
        return eligibleCandidates(state).asSequence()
            .filter { c ->
                state.sortMode != SortMode.ATTACK ||
                    !state.attackStrongOnly ||
                    (c.score.powerPressure >= 65.0 && c.score.pitcherMatchup >= 65.0)
            }
            .sortedWith(
                when (state.sortMode) {
                    SortMode.SCORE -> compareByDescending<HitterCandidate> { it.score.total }
                    SortMode.ATTACK -> compareByDescending<HitterCandidate> { attackScore(it) }
                        .thenByDescending { it.score.total }
                    SortMode.POWER_PRESSURE -> compareByDescending<HitterCandidate> { it.score.powerPressure }
                    SortMode.RECENT_POWER -> compareByDescending<HitterCandidate> { it.score.recentPower }
                    SortMode.MATCHUP -> compareByDescending<HitterCandidate> { it.score.pitcherMatchup }
                }
            )
            .toList()
    }

    fun topHittersForGame(
        gamePk: Long,
        limit: Int = 4,
        state: AppUiState = _state.value
    ): List<HitterCandidate> = eligibleCandidates(state)
        .filter { it.game.gamePk == gamePk }
        .sortedByDescending(::pickScore)
        .take(limit)

    /**
     * Parlay-specific quality score. It rewards hitters who are strong in BOTH Power Pressure and
     * Matchup, then penalizes weak environments or genuinely poor pitcher matchups. This prevents
     * the generator from simply copying the overall board ranking.
     */
    fun parlayScore(candidate: HitterCandidate): Double {
        var score = pickScore(candidate)
        val pressure = candidate.score.powerPressure
        val matchup = candidate.score.pitcherMatchup

        score += when {
            pressure >= 70.0 && matchup >= 70.0 -> 7.0
            pressure >= 60.0 && matchup >= 60.0 -> 4.0
            pressure >= 52.0 && matchup >= 52.0 -> 2.0
            else -> 0.0
        }

        if (candidate.score.environment < 35.0) score -= 8.0
        if (matchup < 35.0) score -= 6.0
        return score
    }

    private fun parlayCandidatePool(state: AppUiState): List<HitterCandidate> {
        val ranked = eligibleCandidates(state)
            .filter { it.score.total >= 40.0 }
            .sortedWith(
                compareByDescending<HitterCandidate>(::parlayScore)
                    .thenByDescending { it.score.powerPressure }
                    .thenByDescending { it.score.pitcherMatchup }
            )

        if (ranked.isEmpty()) return emptyList()

        // Keep the generator in a competitive quality window rather than letting "Generate again"
        // drift into weak long shots just for the sake of being different.
        val best = parlayScore(ranked.first())
        return ranked.filter { parlayScore(it) >= best - 18.0 }.take(40)
    }

    /**
     * Straight-bet rotation pool. Generate Another cycles through these players in ranked order,
     * so a 1-leg request no longer returns the same hitter forever.
     */
    fun straightCandidates(state: AppUiState = _state.value): List<HitterCandidate> {
        val base = parlayCandidatePool(state)
        if (base.isEmpty()) return emptyList()
        val best = parlayScore(base.first())
        val tightWindow = base.filter { parlayScore(it) >= best - 11.0 }.take(12)
        return if (tightWindow.isNotEmpty()) tightWindow else base.take(12)
    }

    /**
     * Generates a quality-first parlay while avoiding needless correlation.
     *
     * v0.5 behavior:
     * - 1-leg: cycles through a ranked pool of strong straight HR choices.
     * - 2-5 legs: rotates the anchor hitter and then builds around that anchor from the best
     *   remaining players, preferring different games and teams.
     * - Generate Another changes the slip without abandoning the strongest part of the board.
     */
    fun generateParlay(
        legs: Int,
        variant: Int = 0,
        state: AppUiState = _state.value
    ): List<HitterCandidate> {
        val targetLegs = legs.coerceIn(1, 5)
        val base = parlayCandidatePool(state)
        if (base.isEmpty()) return emptyList()

        if (targetLegs == 1) {
            val straights = straightCandidates(state)
            if (straights.isEmpty()) return emptyList()
            return listOf(straights[Math.floorMod(variant, straights.size)])
        }

        val chosen = mutableListOf<HitterCandidate>()
        val usedGames = mutableSetOf<Long>()
        val usedTeams = mutableSetOf<Int>()

        // Rotate the anchor among the best competitive candidates. This guarantees that a new
        // variant actually produces a different parlay while keeping the first leg high quality.
        val anchorPoolSize = minOf(10, base.size)
        val anchor = base[Math.floorMod(variant, anchorPoolSize)]
        chosen += anchor
        usedGames += anchor.game.gamePk
        usedTeams += anchor.team.id

        for (slot in 1 until targetLegs) {
            val options = base.asSequence()
                .filter { candidate -> chosen.none { it.player.id == candidate.player.id } }
                .map { candidate ->
                    var adjusted = parlayScore(candidate)

                    // Prefer independent games and teams before repeating either.
                    if (candidate.game.gamePk in usedGames) adjusted -= 16.0
                    if (candidate.team.id in usedTeams) adjusted -= 8.0

                    // Extra protection against obviously weak individual legs.
                    if (candidate.score.environment < 35.0) adjusted -= 6.0
                    if (candidate.score.pitcherMatchup < 35.0) adjusted -= 5.0

                    candidate to adjusted
                }
                .sortedByDescending { it.second }
                .take(5)
                .toList()

            if (options.isEmpty()) break

            // Variant zero is the pure best-score slip. Later variants can use the 2nd/3rd-best
            // option in a slot, but never wander farther than the top three adjusted choices.
            val depth = minOf(3, options.size)
            val optionIndex = if (variant == 0) 0 else Math.floorMod(variant + slot - 1, depth)
            val best = options[optionIndex].first

            chosen += best
            usedGames += best.game.gamePk
            usedTeams += best.team.id
        }

        return chosen.take(targetLegs)
    }

}
