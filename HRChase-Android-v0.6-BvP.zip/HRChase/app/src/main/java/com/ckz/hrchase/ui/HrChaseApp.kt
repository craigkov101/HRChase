package com.ckz.hrchase.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Casino
import androidx.compose.material.icons.outlined.SportsBaseball
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ckz.hrchase.AppUiState
import com.ckz.hrchase.MainViewModel
import com.ckz.hrchase.data.BattedBall
import com.ckz.hrchase.data.BatterVsPitcherStats
import com.ckz.hrchase.data.GameInfo
import com.ckz.hrchase.data.HitterCandidate
import com.ckz.hrchase.data.PitcherProfile
import com.ckz.hrchase.model.HrScoringModel
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

private val AppBackground = Color(0xFF07111F)
private val AppSurface = Color(0xFF0D1B2A)
private val AppSurfaceRaised = Color(0xFF122338)
private val AppOutline = Color(0xFF22364B)
private val AppPrimary = Color(0xFF38BDF8)
private val AppGreen = Color(0xFF34D399)
private val AppAmber = Color(0xFFFBBF24)
private val AppRed = Color(0xFFFB7185)
private val AppMuted = Color(0xFF8EA4B8)
private val AppText = Color(0xFFF4F8FC)

private val HrChaseColors = darkColorScheme(
    primary = AppPrimary,
    onPrimary = Color(0xFF03131E),
    secondary = AppGreen,
    tertiary = AppAmber,
    background = AppBackground,
    onBackground = AppText,
    surface = AppSurface,
    onSurface = AppText,
    surfaceVariant = AppSurfaceRaised,
    onSurfaceVariant = Color(0xFFC4D2DF),
    outline = AppOutline,
    error = AppRed
)

private enum class Tab { GAMES, PARLAYS, TRACKED }

private data class GameAlert(
    val title: String,
    val detail: String,
    val color: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HrChaseApp(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    val selected = state.selectedPlayerId?.let { id ->
        state.board?.candidates?.firstOrNull { it.player.id == id }
    }

    MaterialTheme(colorScheme = HrChaseColors) {
        Surface(Modifier.fillMaxSize(), color = AppBackground) {
            if (selected != null) {
                PlayerDetailScreen(
                    candidate = selected,
                    pickScore = viewModel.pickScore(selected),
                    tracked = state.tracked.any { it.playerId == selected.player.id && it.date == state.selectedDate },
                    onBack = { viewModel.selectPlayer(null) },
                    onTrack = { viewModel.toggleTracked(selected) }
                )
            } else {
                Scaffold(
                    containerColor = AppBackground,
                    topBar = {
                        TopAppBar(
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = AppBackground,
                                titleContentColor = AppText,
                                actionIconContentColor = AppText
                            ),
                            title = {
                                Column {
                                    Text("HR Chase", fontWeight = FontWeight.Black)
                                    Text("Find the best HR spots by game", style = MaterialTheme.typography.labelSmall, color = AppMuted)
                                }
                            },
                            actions = {
                                IconButton(onClick = { viewModel.refresh() }) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                                }
                            }
                        )
                    },
                    bottomBar = {
                        NavigationBar(containerColor = Color(0xFF091522), tonalElevation = 0.dp) {
                            NavigationBarItem(
                                selected = tab == 0,
                                onClick = { tab = 0 },
                                icon = { Icon(Icons.Outlined.SportsBaseball, null) },
                                label = { Text("Games") },
                                colors = navColors()
                            )
                            NavigationBarItem(
                                selected = tab == 1,
                                onClick = { tab = 1 },
                                icon = { Icon(Icons.Outlined.Casino, null) },
                                label = { Text("Parlays") },
                                colors = navColors()
                            )
                            NavigationBarItem(
                                selected = tab == 2,
                                onClick = { tab = 2 },
                                icon = { Icon(Icons.Default.Star, null) },
                                label = { Text("Tracked") },
                                colors = navColors()
                            )
                        }
                    }
                ) { padding ->
                    when (tab) {
                        0 -> GamesScreen(state, viewModel, padding)
                        1 -> ParlaysScreen(state, viewModel, padding)
                        else -> TrackedScreen(state, viewModel, padding)
                    }
                }
            }
        }
    }
}

@Composable
private fun navColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = AppPrimary,
    selectedTextColor = AppPrimary,
    indicatorColor = AppPrimary.copy(alpha = 0.14f),
    unselectedIconColor = AppMuted,
    unselectedTextColor = AppMuted
)

@Composable
private fun GamesScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val board = state.board
    val eligible = viewModel.eligibleCandidates(state)
    val candidateGameIds = eligible.map { it.game.gamePk }.toSet()
    val games = board?.games.orEmpty()
        .filter { it.gamePk in candidateGameIds }
        .sortedBy { it.gameDate }

    Column(
        Modifier
            .fillMaxSize()
            .padding(padding)
            .background(AppBackground)
    ) {
        DateControls(state, viewModel)
        SimpleFilters(state, viewModel)
        LoadState(state, viewModel)

        if (!state.isLoading && board != null && games.isEmpty()) {
            EmptyState("No games match the current lineup filters.")
        } else if (board == null && state.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AppPrimary)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Column(Modifier.padding(horizontal = 2.dp, vertical = 4.dp)) {
                        Text("Today's games", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                        Text("Each game shows our best HR candidates and the reasons behind them.", color = AppMuted, style = MaterialTheme.typography.bodySmall)
                    }
                }

                items(games, key = { it.gamePk }) { game ->
                    val top = viewModel.topHittersForGame(game.gamePk, 4, state)
                    GameCard(
                        game = game,
                        candidates = eligible.filter { it.game.gamePk == game.gamePk },
                        topHitters = top,
                        viewModel = viewModel,
                        state = state
                    )
                }

                item {
                    Text(
                        "Rankings are research signals, not guarantees. Home runs remain high-variance events.",
                        style = MaterialTheme.typography.labelSmall,
                        color = AppMuted,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun GameCard(
    game: GameInfo,
    candidates: List<HitterCandidate>,
    topHitters: List<HitterCandidate>,
    viewModel: MainViewModel,
    state: AppUiState
) {
    val time = game.gameDate.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("h:mm a"))
    val alerts = remember(game, candidates) { gameAlerts(game, candidates) }
    val avgEnvironment = candidates.map { it.score.environment }.average().takeUnless { it.isNaN() } ?: 50.0

    Card(
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, AppOutline)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "${game.awayTeam.abbreviation} @ ${game.homeTeam.abbreviation}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black
                    )
                    Text("$time • ${game.venueName}", style = MaterialTheme.typography.bodySmall, color = AppMuted)
                }
                EnvironmentBadge(avgEnvironment)
            }

            if (alerts.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                alerts.forEach { alert -> AlertRow(alert) }
            }

            Spacer(Modifier.height(12.dp))
            Text("Top HR looks", fontWeight = FontWeight.Black, color = AppText)
            Spacer(Modifier.height(5.dp))

            if (topHitters.isEmpty()) {
                Text("Lineup data is not available yet.", color = AppMuted, style = MaterialTheme.typography.bodySmall)
            } else {
                topHitters.forEachIndexed { index, candidate ->
                    if (index > 0) HorizontalDivider(color = AppOutline.copy(alpha = 0.7f), modifier = Modifier.padding(vertical = 5.dp))
                    GameHitterRow(
                        rank = index + 1,
                        candidate = candidate,
                        score = viewModel.pickScore(candidate),
                        tracked = state.tracked.any { it.playerId == candidate.player.id && it.date == state.selectedDate },
                        onOpen = { viewModel.selectPlayer(candidate.player.id) },
                        onTrack = { viewModel.toggleTracked(candidate) }
                    )
                }
            }
        }
    }
}

@Composable
private fun GameHitterRow(
    rank: Int,
    candidate: HitterCandidate,
    score: Double,
    tracked: Boolean,
    onOpen: () -> Unit,
    onTrack: () -> Unit
) {
    val scoreInt = score.roundToInt()
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
            .padding(vertical = 5.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                modifier = Modifier.size(46.dp),
                shape = RoundedCornerShape(13.dp),
                color = scoreColor(scoreInt).copy(alpha = 0.13f),
                border = BorderStroke(1.dp, scoreColor(scoreInt).copy(alpha = 0.35f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(scoreInt.toString(), fontWeight = FontWeight.Black, color = scoreColor(scoreInt))
                        Text("PICK", style = MaterialTheme.typography.labelSmall, color = AppMuted)
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("#$rank  ${candidate.player.name}", fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${candidate.team.abbreviation} • Batting #${candidate.battingOrder} • vs ${candidate.opponentPitcher?.person?.name ?: "TBD"}",
                    color = AppMuted,
                    style = MaterialTheme.typography.labelMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onTrack) {
                Icon(
                    if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder,
                    contentDescription = "Track",
                    tint = if (tracked) AppAmber else AppMuted
                )
            }
        }

        Text(
            quickJustification(candidate),
            modifier = Modifier.padding(start = 56.dp, end = 4.dp),
            color = Color(0xFFD3E0EA),
            style = MaterialTheme.typography.bodySmall
        )
        candidate.vsPitcherStats?.let { bvp ->
            Text(
                bvpSummary(bvp),
                modifier = Modifier.padding(start = 56.dp, end = 4.dp, top = 3.dp),
                color = bvpColor(bvp),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold
            )
        }
        candidate.score.notes.firstOrNull()?.let { note ->
            Text(
                note,
                modifier = Modifier.padding(start = 56.dp, end = 4.dp, top = 2.dp),
                color = AppMuted,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun EnvironmentBadge(value: Double) {
    val label = when {
        value >= 72 -> "HR+"
        value < 40 -> "HR−"
        else -> "NEUTRAL"
    }
    val color = when {
        value >= 72 -> AppGreen
        value < 40 -> AppAmber
        else -> AppMuted
    }
    Surface(color = color.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp), border = BorderStroke(1.dp, color.copy(alpha = 0.30f))) {
        Text(label, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = color, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun AlertRow(alert: GameAlert) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(bottom = 5.dp),
        color = alert.color.copy(alpha = 0.09f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, alert.color.copy(alpha = 0.24f))
    ) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Warning, null, tint = alert.color, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Column {
                Text(alert.title, color = alert.color, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                Text(alert.detail, color = Color(0xFFD3E0EA), style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

private fun gameAlerts(game: GameInfo, candidates: List<HitterCandidate>): List<GameAlert> = buildList {
    val pitchers = candidates.mapNotNull { it.opponentPitcher }.distinctBy { it.person.id }
    pitchers.filter(::isTopPitcher).forEach { pitcher ->
        val bits = listOfNotNull(
            pitcher.seasonStats.era?.let { "${"%.2f".format(it)} ERA" },
            pitcher.seasonStats.hrPer9?.let { "${"%.2f".format(it)} HR/9" }
        ).joinToString(" • ")
        val affectedTeam = candidates.firstOrNull { it.opponentPitcher?.person?.id == pitcher.person.id }?.team?.abbreviation
        val title = affectedTeam?.let { "Tough matchup for $it hitters" } ?: "Pitcher warning"
        add(GameAlert(title, "${pitcher.person.name}${if (bits.isNotBlank()) " • $bits" else ""}", AppAmber))
    }

    val weather = game.weather
    val roofClosed = weather.roofType?.contains("closed", true) == true || weather.condition?.contains("dome", true) == true
    if (!roofClosed) {
        val condition = weather.condition.orEmpty()
        val badCondition = listOf("rain", "storm", "shower", "drizzle", "snow").any { condition.contains(it, true) }
        if (badCondition) {
            add(GameAlert("Weather warning", condition.ifBlank { "Possible precipitation" }, AppRed))
        }

        val wind = weather.wind.orEmpty()
        val mph = Regex("(\\d+)\\s*mph", RegexOption.IGNORE_CASE).find(wind)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
        if (wind.contains("in", true) && mph >= 10) {
            add(GameAlert("Wind warning", "$wind may suppress carry", AppAmber))
        }
        weather.temperatureF?.let { temp ->
            if (temp <= 52) add(GameAlert("Cold-weather warning", "$temp°F can reduce home-run carry", AppAmber))
        }
    }
}

private fun isTopPitcher(pitcher: PitcherProfile): Boolean {
    val stats = pitcher.seasonStats
    if (stats.inningsPitched in 0.0..<20.0) return false
    val era = stats.era
    val hr9 = stats.hrPer9
    return (era != null && hr9 != null && era <= 3.25 && hr9 <= 1.10) ||
        (era != null && era <= 2.80) ||
        (hr9 != null && hr9 <= 0.75)
}

private fun quickJustification(candidate: HitterCandidate): String {
    val p = candidate.score.powerPressure.roundToInt()
    val m = candidate.score.pitcherMatchup.roundToInt()
    val c = candidate.score.recentPower.roundToInt()
    val e = candidate.score.environment.roundToInt()
    val bvp = candidate.vsPitcherStats
    return when {
        bvp != null && bvp.plateAppearances >= 8 && ((bvp.ops ?: 0.0) >= .900 || bvp.homeRuns >= 2) ->
            "BvP edge plus current form: ${bvp.hits}-for-${bvp.atBats}, ${bvp.homeRuns} HR vs this pitcher. Pressure $p • Matchup $m."
        p >= 72 && m >= 72 -> "Best combo: Power Pressure $p + Matchup $m."
        p >= 75 -> "Power Pressure $p: recent HR-quality contact is building. Matchup $m."
        m >= 75 -> "Matchup $m: favorable opposing-pitcher profile. Recent contact $c."
        c >= 75 -> "Recent contact $c is hot; matchup $m keeps him in play."
        e >= 75 -> "Strong park/weather spot ($e) with a balanced hitter profile."
        else -> "Balanced profile: Pressure $p • Matchup $m • Contact $c."
    }
}

private fun bvpSummary(bvp: BatterVsPitcherStats): String {
    val avg = bvp.avg?.let { String.format("%.3f", it).removePrefix("0") } ?: "—"
    val ops = bvp.ops?.let { String.format("%.3f", it).removePrefix("0") } ?: "—"
    val sample = if (bvp.plateAppearances < 8) " • small sample" else ""
    return "BvP: ${bvp.hits}-for-${bvp.atBats} ($avg) • ${bvp.homeRuns} HR • $ops OPS$sample"
}

private fun bvpColor(bvp: BatterVsPitcherStats): Color = when {
    bvp.plateAppearances < 5 -> AppMuted
    bvp.homeRuns >= 2 || (bvp.ops ?: 0.0) >= .950 -> AppGreen
    (bvp.ops ?: 0.0) < .600 && bvp.plateAppearances >= 8 -> AppAmber
    else -> Color(0xFFD3E0EA)
}

@Composable
private fun ParlaysScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    var legCount by remember { mutableIntStateOf(2) }
    var variant by remember { mutableIntStateOf(0) }
    val parlay = remember(
        state.board?.lastUpdated,
        state.selectedDate,
        state.showRemainingOnly,
        state.officialLineupsOnly,
        legCount,
        variant
    ) {
        viewModel.generateParlay(legCount, variant, state)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding).background(AppBackground),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Parlay generator", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            Text("Quality-first combinations built from today's strongest model spots.", color = AppMuted, style = MaterialTheme.typography.bodySmall)
        }

        item {
            DateControls(state, viewModel)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AppSurface),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, AppOutline)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("How many legs?", fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        (1..5).forEach { legs ->
                            FilterChip(
                                selected = legCount == legs,
                                onClick = { legCount = legs; variant = 0 },
                                label = { Text(legs.toString(), fontWeight = FontWeight.Bold) },
                                modifier = Modifier.weight(1f),
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = AppSurfaceRaised,
                                    selectedContainerColor = AppPrimary.copy(alpha = 0.18f),
                                    selectedLabelColor = AppPrimary
                                )
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { variant += 1 }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Outlined.Casino, null)
                        Spacer(Modifier.width(7.dp))
                        Text(if (legCount == 1) "Next straight pick" else "Generate another ${legCount}-leg")
                    }
                }
            }
        }

        if (state.isLoading) {
            item { LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = AppPrimary, trackColor = AppSurfaceRaised) }
        }

        if (!state.isLoading && parlay.isEmpty()) {
            item { EmptyCard("Not enough eligible hitters yet. Try again after lineups post.") }
        } else {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = AppSurface),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, AppPrimary.copy(alpha = 0.35f))
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(if (legCount == 1) "Straight HR pick" else "Suggested ${legCount}-leg HR parlay", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                                if (legCount == 1) {
                                    val straightCount = viewModel.straightCandidates(state).size.coerceAtLeast(1)
                                    Text("Ranked option ${(variant % straightCount) + 1} of $straightCount", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                                } else {
                                    Text("Model-generated • option ${variant + 1}", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            Surface(color = AppGreen.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp)) {
                                Text("QUALITY FIRST", modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = AppGreen, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        Spacer(Modifier.height(10.dp))
                        parlay.forEachIndexed { index, candidate ->
                            if (index > 0) HorizontalDivider(color = AppOutline, modifier = Modifier.padding(vertical = 7.dp))
                            ParlayLegRow(index + 1, candidate, viewModel.parlayScore(candidate)) {
                                viewModel.selectPlayer(candidate.player.id)
                            }
                        }
                    }
                }
            }

            if (legCount > 1) {
                item {
                    SectionCard("Why these players were paired") {
                        Text("• Players strong in BOTH Power Pressure and Matchup get an extra boost.", color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall)
                        Text("• It prefers different games and teams before repeating one, reducing unnecessary correlation.", color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 5.dp))
                        Text("• Generate another rotates the anchor and nearby top options instead of recycling the same slip.", color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 5.dp))
                    }
                }
            }
        }

        item {
            Text(
                "Longer HR parlays are increasingly unlikely even with strong individual picks. The generator ranks combinations; it does not predict a guaranteed outcome.",
                style = MaterialTheme.typography.labelSmall,
                color = AppMuted
            )
        }
    }
}

@Composable
private fun ParlayLegRow(number: Int, candidate: HitterCandidate, score: Double, onOpen: () -> Unit) {
    val scoreInt = score.roundToInt()
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(vertical = 3.dp),
        verticalAlignment = Alignment.Top
    ) {
        Surface(
            modifier = Modifier.size(38.dp),
            color = scoreColor(scoreInt).copy(alpha = 0.13f),
            shape = CircleShape,
            border = BorderStroke(1.dp, scoreColor(scoreInt).copy(alpha = 0.35f))
        ) {
            Box(contentAlignment = Alignment.Center) { Text(number.toString(), fontWeight = FontWeight.Black, color = scoreColor(scoreInt)) }
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(candidate.player.name, fontWeight = FontWeight.Black)
                Text(scoreInt.toString(), fontWeight = FontWeight.Black, color = scoreColor(scoreInt))
            }
            Text(
                "${candidate.team.abbreviation} vs ${candidate.opponent.abbreviation} • ${candidate.game.gameDate.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("h:mm a"))}",
                style = MaterialTheme.typography.labelMedium,
                color = AppMuted
            )
            Text(quickJustification(candidate), color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 3.dp))
        }
    }
}

@Composable
private fun DateControls(state: AppUiState, viewModel: MainViewModel) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        color = AppSurface,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, AppOutline)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = { viewModel.changeDate(-1) }) { Icon(Icons.Default.ChevronLeft, "Previous") }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(state.selectedDate.format(DateTimeFormatter.ofPattern("EEE, MMM d")), fontWeight = FontWeight.Black)
                state.board?.let { Text("${it.games.size} games", style = MaterialTheme.typography.labelSmall, color = AppMuted) }
            }
            IconButton(onClick = { viewModel.changeDate(1) }) { Icon(Icons.Default.ChevronRight, "Next") }
        }
    }
}

@Composable
private fun SimpleFilters(state: AppUiState, viewModel: MainViewModel) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FilterChip(
            selected = state.showRemainingOnly,
            onClick = { viewModel.toggleRemainingOnly() },
            label = { Text("Remaining games") },
            colors = simpleChipColors()
        )
        FilterChip(
            selected = state.officialLineupsOnly,
            onClick = { viewModel.toggleOfficialOnly() },
            label = { Text("Official lineups") },
            colors = simpleChipColors()
        )
    }
}

@Composable
private fun simpleChipColors() = FilterChipDefaults.filterChipColors(
    containerColor = AppSurface,
    labelColor = AppMuted,
    selectedContainerColor = AppPrimary.copy(alpha = 0.15f),
    selectedLabelColor = AppPrimary
)

@Composable
private fun LoadState(state: AppUiState, viewModel: MainViewModel) {
    if (state.isLoading) {
        Column {
            LinearProgressIndicator(Modifier.fillMaxWidth(), color = AppPrimary, trackColor = AppSurfaceRaised)
            Text(state.progress, Modifier.padding(horizontal = 15.dp, vertical = 5.dp), color = AppMuted, style = MaterialTheme.typography.labelSmall)
        }
    }
    state.error?.let { error ->
        Card(
            modifier = Modifier.padding(12.dp).fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = AppRed.copy(alpha = 0.11f)),
            border = BorderStroke(1.dp, AppRed.copy(alpha = 0.32f))
        ) {
            Column(Modifier.padding(12.dp)) {
                Text("Could not load MLB data", color = AppRed, fontWeight = FontWeight.Black)
                Text(error, color = AppMuted, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(7.dp))
                Button(onClick = { viewModel.refresh() }) { Text("Retry") }
            }
        }
    }
}

@Composable
private fun EmptyState(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = AppMuted, modifier = Modifier.padding(24.dp))
    }
}

@Composable
private fun EmptyCard(text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = AppSurface), border = BorderStroke(1.dp, AppOutline)) {
        Text(text, modifier = Modifier.padding(14.dp), color = AppMuted)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlayerDetailScreen(
    candidate: HitterCandidate,
    pickScore: Double,
    tracked: Boolean,
    onBack: () -> Unit,
    onTrack: () -> Unit
) {
    val model = remember { HrScoringModel() }
    val score = pickScore.roundToInt()

    Scaffold(
        containerColor = AppBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AppBackground),
                title = { Text(candidate.player.name, fontWeight = FontWeight.Black) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } },
                actions = {
                    IconButton(onClick = onTrack) {
                        Icon(if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder, "Track", tint = if (tracked) AppAmber else AppMuted)
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = AppSurface),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, AppOutline)
                ) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            modifier = Modifier.size(72.dp),
                            color = scoreColor(score).copy(alpha = 0.14f),
                            shape = CircleShape,
                            border = BorderStroke(2.dp, scoreColor(score).copy(alpha = 0.40f))
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(score.toString(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = scoreColor(score))
                                    Text("PICK", style = MaterialTheme.typography.labelSmall, color = AppMuted)
                                }
                            }
                        }
                        Spacer(Modifier.width(13.dp))
                        Column {
                            Text("Why we like it", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                            Text(quickJustification(candidate), color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall)
                            Text("${candidate.team.abbreviation} • Batting #${candidate.battingOrder}", color = AppMuted, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }

            item {
                SectionCard("Three key signals") {
                    ScoreBar("Power Pressure", candidate.score.powerPressure)
                    ScoreBar("Pitcher matchup", candidate.score.pitcherMatchup)
                    ScoreBar("Recent contact", candidate.score.recentPower)
                }
            }

            item {
                SectionCard("Opposing pitcher") {
                    val pitcher = candidate.opponentPitcher
                    if (pitcher == null) {
                        Text("Pitcher data not available yet.", color = AppMuted)
                    } else {
                        Text(pitcher.person.name, fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(7.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("ERA", pitcher.seasonStats.era?.let { "%.2f".format(it) } ?: "—")
                            StatCell("HR/9", pitcher.seasonStats.hrPer9?.let { "%.2f".format(it) } ?: "—")
                            StatCell("WHIP", pitcher.seasonStats.whip?.let { "%.2f".format(it) } ?: "—")
                        }
                    }
                }
            }

            item {
                SectionCard("Career vs this pitcher") {
                    val bvp = candidate.vsPitcherStats
                    val pitcherName = candidate.opponentPitcher?.person?.name ?: "today's pitcher"
                    if (bvp == null) {
                        Text("No MLB batter-vs-pitcher history found for $pitcherName, or this matchup was outside the pregame BvP lookup pool.", color = AppMuted, style = MaterialTheme.typography.bodySmall)
                    } else {
                        Text("vs $pitcherName", fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("AB", bvp.atBats.toString())
                            StatCell("H", bvp.hits.toString())
                            StatCell("HR", bvp.homeRuns.toString())
                            StatCell("K", bvp.strikeouts.toString())
                        }
                        Spacer(Modifier.height(9.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("AVG", bvp.avg?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("OBP", bvp.obp?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("SLG", bvp.slg?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("OPS", bvp.ops?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (bvp.plateAppearances < 8) "Only ${bvp.plateAppearances} PA — useful context, but too small a sample to drive the pick by itself."
                            else "${bvp.plateAppearances} career PA. BvP receives a capped, sample-size-weighted boost in the Pick/Parlay score.",
                            color = AppMuted,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }

            item {
                SectionCard("Justification") {
                    candidate.score.notes.take(5).forEach { note ->
                        Text("• $note", color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 5.dp))
                    }
                }
            }

            if (candidate.recentBattedBalls.isNotEmpty()) {
                item { Text("Recent contact", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black) }
                items(candidate.recentBattedBalls.sortedByDescending { it.gameDate }.take(12)) { ball -> BattedBallRow(ball, model) }
            }
        }
    }
}

@Composable
private fun ScoreBar(label: String, value: Double) {
    val intValue = value.roundToInt()
    Column(Modifier.padding(top = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color(0xFFD3E0EA))
            Text(intValue.toString(), color = scoreColor(intValue), fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { (value / 100.0).toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(5.dp),
            color = scoreColor(intValue),
            trackColor = AppSurfaceRaised
        )
    }
}

@Composable
private fun BattedBallRow(ball: BattedBall, model: HrScoringModel) {
    val signal = when {
        ball.isHomeRun -> "HR"
        model.isEliteNearHomeRun(ball) -> "NEAR-HR+"
        model.isNearHomeRun(ball) -> "NEAR-HR"
        model.isBarrelProxy(ball) -> "BARREL"
        model.isHardHit(ball) -> "HARD HIT"
        else -> "CONTACT"
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, AppOutline)
    ) {
        Row(Modifier.fillMaxWidth().padding(11.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(signal, fontWeight = FontWeight.Black, color = if (signal == "HR") AppGreen else AppPrimary)
                Text(ball.gameDate.toString(), color = AppMuted, style = MaterialTheme.typography.labelSmall)
            }
            Text(
                "${ball.exitVelocity?.let { "%.1f mph".format(it) } ?: "—"} • ${ball.launchAngle?.let { "%.0f°".format(it) } ?: "—"} • ${ball.distanceFt?.let { "%.0f ft".format(it) } ?: "—"}",
                color = Color(0xFFD3E0EA),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun TrackedScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val model = remember { HrScoringModel() }
    val tracked = state.tracked.filter { it.date == state.selectedDate }
    val byId = state.board?.candidates?.associateBy { it.player.id }.orEmpty()

    Column(Modifier.fillMaxSize().padding(padding).background(AppBackground)) {
        DateControls(state, viewModel)
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Tracked picks", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                Text("Review the process, not only HR/no-HR.", style = MaterialTheme.typography.bodySmall, color = AppMuted)
            }
            if (tracked.isNotEmpty()) {
                Button(onClick = { viewModel.clearTrackedForSelectedDate() }, colors = ButtonDefaults.buttonColors(containerColor = AppSurfaceRaised, contentColor = AppText)) {
                    Text("Clear")
                }
            }
        }

        if (tracked.isEmpty()) {
            EmptyState("Star hitters from the Games tab to track them here.")
        } else {
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(tracked, key = { "${it.date}-${it.playerId}" }) { pick ->
                    val c = byId[pick.playerId]
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable(enabled = c != null) { c?.let { viewModel.selectPlayer(it.player.id) } },
                        colors = CardDefaults.cardColors(containerColor = AppSurface),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, AppOutline)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(pick.playerName, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                            Text("Tracked at ${pick.scoreAtTrack.roundToInt()} Chase Score", style = MaterialTheme.typography.bodySmall, color = AppMuted)
                            Spacer(Modifier.height(7.dp))
                            if (c == null) {
                                Text("Load this date's board to evaluate contact.", color = AppMuted, style = MaterialTheme.typography.bodySmall)
                            } else {
                                val balls = c.todayBattedBalls
                                val hrs = balls.count { it.isHomeRun }
                                val hardest = balls.mapNotNull { it.exitVelocity }.maxOrNull()
                                val grade = when {
                                    hrs > 0 -> "HR HIT"
                                    balls.any { model.isEliteNearHomeRun(it) } -> "STRONG READ • ELITE NEAR-HR"
                                    balls.any { model.isNearHomeRun(it) } -> "GOOD READ • NEAR-HR"
                                    balls.any { model.isBarrelProxy(it) } -> "BARREL CONTACT • NO HR"
                                    balls.any { model.isHardHit(it) } -> "HARD CONTACT • NO HR"
                                    c.game.status.equals("Final", true) -> "QUIET CONTACT / MISS"
                                    else -> "GAME PENDING / IN PROGRESS"
                                }
                                SignalPill(grade)
                                Text("$hrs HR • ${balls.size} tracked balls • max EV ${hardest?.let { "%.1f".format(it) } ?: "—"}", style = MaterialTheme.typography.bodySmall, color = AppMuted, modifier = Modifier.padding(top = 6.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SignalPill(text: String) {
    val color = when {
        "HR HIT" in text -> AppGreen
        "STRONG" in text || "GOOD" in text -> AppPrimary
        "BARREL" in text || "HARD" in text -> AppAmber
        else -> AppMuted
    }
    Surface(color = color.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp)) {
        Text(text, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = color, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, AppOutline)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(4.dp))
            content()
        }
    }
}

@Composable
private fun StatCell(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
        Text(label, color = AppMuted, style = MaterialTheme.typography.labelSmall)
    }
}

private fun scoreColor(score: Int): Color = when {
    score >= 80 -> AppGreen
    score >= 68 -> AppPrimary
    score >= 55 -> AppAmber
    else -> AppMuted
}
