HR Chase Android v0.10.5 — Pitch Arsenal Fit

New metric: compares the pitch types behind a hitter's season home runs with the opposing pitcher's current-season pitch mix.

Implementation:
- MLB StatsAPI Statcast metrics endpoint is queried by pitch type.
- Hitter side: season home-run occurrence counts by pitch type.
- Pitcher side: season pitch occurrence counts by pitch type.
- Supported common pitch families: four-seam, sinker, cutter, slider, sweeper, curve, knuckle curve, changeup, splitter.
- Fit uses distribution similarity plus how heavily the pitcher throws the hitter's top HR pitch types.
- Small hitter HR samples are blended strongly toward a neutral score.
- Missing pitch data stays neutral rather than hurting a player.
- Pitch Arsenal Fit now contributes modestly to the Power Signal Lens and daily Target Score.
- Player detail pages show the hitter's HR pitch mix beside the opposing pitcher's usage.

Performance:
- Pitcher arsenal data is fetched in league-style batched requests by pitch type.
- Hitter HR pitch profiles are limited to the strongest six preliminary candidates per game plus the best 20 overall so the app remains responsive.
