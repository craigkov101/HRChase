# HR Chase v0.10.1 — Power Signal Lens

The signal lens is an independent convergence layer that combines recent form/pressure, batted-ball quality, swing-and-miss, pitcher resistance, handedness/platoon context, environment and lineup barrel depth.

It remains part of the daily Target Score while all analyst-specific branding has been removed from the app.
