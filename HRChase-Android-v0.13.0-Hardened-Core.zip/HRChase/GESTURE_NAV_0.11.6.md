# HR Chase v0.11.6 — Gesture Refresh + Android Back Navigation

## Pull-to-refresh
- Removed the circular refresh control from the upper-right header.
- Pull down from the top of any main tab to refresh the current MLB slate/data.
- The normal loading state remains visible while refresh is running.

## Android system Back button
- From a player detail screen, Android Back returns to the prior HR Chase screen instead of closing the app.
- From an expanded game Top 10 drilldown, Android Back collapses that game first.
- From Targets, Heating, Hot, Parlays, or Tracked, Android Back returns to Games.
- Only pressing Back from the root Games screen exits HR Chase, matching standard Android behavior.

This keeps the existing in-app back arrow while also making the phone navigation button/gesture behave naturally.
