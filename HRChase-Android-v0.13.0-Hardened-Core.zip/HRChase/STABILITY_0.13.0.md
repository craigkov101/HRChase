# HR Chase v0.13.0 — Hardened Core

This release is a stability and data-integrity pass over v0.12.1. It intentionally prioritizes trustworthy behavior over adding another large feature.

## Recommendation integrity

- Targets, Hot, Heating and Parlay recommendations for today's slate now use pregame hitters only. Players whose games have already started are no longer eligible for new recommendations.
- Postponed, cancelled, suspended and game-over states are excluded from pregame recommendation pools.
- Single-focus parlay filters are now strict. For example, Hot Now no longer silently falls back to unrelated hitters when the focused pool is small.
- Games remains usable for live-game review; the pregame restriction only applies to surfaces intended to generate future plays.
- Same-Day Echo considers only legitimate started games as references and legitimate not-yet-started games as targets.

## Lineup and candidate integrity

- Partial MLB lineup feeds are merged with the team's most recent real lineup by batting-order slot and clearly treated as projected.
- Lineups are cleaned for invalid IDs, duplicate hitters, duplicate batting-order slots and invalid batting positions.
- Candidate lists are sanitized for invalid games, teams, batting orders, duplicate player/game entries and non-finite scores.

## Network/data resilience

- Optional MLB/Savant enrichments now fail independently rather than taking down the full slate load.
- Coroutine cancellation is rethrown instead of accidentally being treated as a normal network failure.
- HTTP cache now supports stale-if-error behavior: if a refresh endpoint fails, recently cached data can remain visible instead of the app going blank.
- Cache eviction now removes the oldest-expiring entry instead of an arbitrary map entry.
- Triple-A refresh keeps the last good watchlist when a refresh is incomplete instead of erasing the screen.

## Numeric/model safety

- JSON numeric parsing rejects NaN and Infinity.
- Corrupted/negative custom model weights are clamped to safe values.
- If every model weight is zero, the total score becomes neutral (50) instead of incorrectly collapsing to zero.
- Score outputs remain finite and constrained to the expected range.

## Version/build hygiene

- Android versionCode: 33
- Android versionName: 0.13.0
- Network User-Agent updated to HRChase/0.13.0.

## Validation performed before packaging

Because this environment cannot download Gradle 8.10.2 from services.gradle.org, the complete Android Gradle build must still be run in GitHub Actions. Before packaging, the changed Kotlin core was independently syntax-compiled in isolated groups:

- Models + HR scoring model: compiled successfully.
- Repository + scoring/model types: compiled successfully using a stub API boundary.
- MainViewModel + model types: compiled successfully using Android/repository stubs.
- MlbApi + JsonExt + model types: compiled successfully using JSON stubs.
- A scoring smoke test verified that all-zero weights produce a finite neutral score of 50.

The GitHub Actions APK build remains the final Android/Compose integration check.
