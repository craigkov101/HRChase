# Pitch Arsenal Fit v2 — v0.10.7

## Why this changed
The previous implementation queried MLB StatsAPI `stats/metrics` separately for each pitch type. In practice that endpoint often returned empty maps for the home-run event filter, which left every hitter at N/A/neutral despite the model reserving weight for the feature.

## New primary data source
HR Chase now uses Baseball Savant's purpose-built Statcast pitch-arsenal datasets:

- Pitch Arsenal Stats — hitters: season SLG, xSLG, wOBA/xwOBA, hard-hit rate and pitch samples by pitch type.
- Pitch Arsenal Stats — pitchers: actual pitch usage plus outcomes allowed by pitch type.
- Statcast Search — direct home-run-ending pitch events for only the hitters on today's slate, batched into a few requests.

The core Games/Targets board still renders before this enrichment so the app cannot be held hostage by a slow Statcast response.

## Scoring
When available, Pitch Arsenal Fit combines:

1. Direct season HR pitch-type alignment with today's starter.
2. Exposure to the hitter's most frequently homered-off pitches.
3. Batter SLG/xSLG/hard-hit performance against the pitch mix the starter throws.
4. The starter's SLG/xSLG/hard-hit vulnerability on those same pitches.

Small samples are regressed toward neutral. If direct HR event data is unavailable, measured pitch-type performance can still produce a real lower-confidence score instead of N/A.

## Ranking impact
- Daily Target Score: 12% when measured.
- Signal Lens: 10% when measured.
- High-confidence elite fits receive a small capped bonus.
- High-confidence severe mismatches receive a small capped penalty.
- Missing data is redistributed rather than replaced by a fake 50.
