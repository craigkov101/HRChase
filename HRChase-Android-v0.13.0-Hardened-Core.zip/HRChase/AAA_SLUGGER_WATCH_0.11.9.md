# HR Chase v0.11.9 — Potential AAA Sluggers

## Goal
Create a small Triple-A prospect watch focused on power bats who could plausibly reach MLB before the end of the season. This is intentionally not a complete Triple-A leaderboard.

## Data pipeline
- MLB StatsAPI sportId `11` (Triple-A)
- Full-season hitting totals
- Rolling 21-day Triple-A hitting totals
- Curated call-up-proximity prior for a short list of near-ready hitters

## AAA Slugger Score
Comparative 0–100 grade built from:
- 42% season power
- 28% recent power
- 12% MLB readiness/contact
- 18% call-up watch score

Season/recent power uses HR/PA, ISO, SLG and OPS. Readiness emphasizes strikeout rate, walk rate and sample depth. Call-up Watch blends an editorial proximity prior with current statistical form and is **not a calibrated probability**.

## Initial curated watch
The first pool is intentionally small and can be edited as promotions happen:
- Ralphy Velazquez
- Franklin Arias
- Walker Jenkins
- Sean Keys
- Michael Arroyo
- Lazaro Montes
- Seaver King
- Charlie Condon
- Owen Ayers
- Leo Bernal
- Cooper Ingle
- Cam Cannarella

## UI
- New bottom navigation item: `AAA`
- Screen title: `Potential AAA Sluggers`
- Ranked prospect cards with four model grades and key power stats
- Tap any prospect for a full AAA Slugger Profile
- Native pull-to-refresh refreshes only the AAA feed while on this tab

## v1 limitation
AAA v1 does not yet consume Triple-A pitch-level Statcast EV/launch-angle/barrel data. It begins with reliable MiLB statistical signals and a transparent call-up watch. A future version can add Triple-A batted-ball data, pitch-type matchup and daily AAA game context.
