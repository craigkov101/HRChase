# HR Chase v0.10.9 — Visual Polish + Performance RC2

## Visual redesign
- Reworked the main HR CHASE wordmark into a more distinctive sports/analytics header while keeping it highly readable.
- Replaced the heavy floating bottom-navigation capsule with a slimmer full-width navigation rail.
- Removed the large boxed date selector in favor of a cleaner inline date control.
- Added a reusable low-overhead gradient panel treatment with subtle accent lines instead of heavy elevation/shadows.
- Applied the new panel treatment to Games, Targets, Heating, Hot, Parlays, Tracked, and player-detail sections.
- Removed boxed team abbreviation badges so matchup headers breathe more naturally.
- Refined screen headings and stat pills for a lighter, more editorial analytics look.

## Performance work
- Memoized expensive Games/Targets/Heating/Hot ranking lists so tracking changes and incidental UI state changes do not re-sort and re-score the entire slate.
- Memoized tracked-player lookup sets to avoid repeated linear scans for every visible player row.
- Switched ranked LazyColumn sections to itemsIndexed with stable keys/content types, removing indexOf scans and improving item reuse.
- Memoized selected-player lookup and Tracked-tab lookup maps.
- Reduced player-headshot network/decode size from 180px to 96px while retaining Coil memory/disk caching.
- Removed expensive card shadow elevations from the highest-density scrolling surfaces.
- Preserves all v0.10.8 stale-while-refresh/date-switch protections and network single-flight caching.

## Regression focus
Test Today -> Yesterday -> Today -> Refresh repeatedly, then rapidly switch between all six tabs while refresh/enrichment is active.
