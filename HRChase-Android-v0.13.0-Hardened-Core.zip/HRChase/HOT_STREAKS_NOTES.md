HR Chase Android v0.10.2 — Hot Streaks

New Hot tab:
- Today's scheduled hitters ranked by previous seven completed calendar days.
- One league-wide MLB StatsAPI date-range request for efficient weekly stats.
- Shows 7-day AVG, OPS, HR, XBH, games, hits/AB, runs, RBI, walks and strikeouts.
- Hot Streak Score blends actual seven-day production with recent batted-ball quality and pressure.
- Justifications call out home runs, OPS/AVG/SLG, extra-base hits, RBI, near-HR misses, barrel/hard-hit support, max EV and low K rate.
- Player headshots and team logos are retained.
- TODAY score keeps the user aware of current matchup quality even when a hitter is hot.
- Tough current pitcher matchup warning prevents blindly chasing recent results.

Data notes:
- Seven-day batting line ends with the previous completed day to avoid partial same-day stats.
- Near-HR/contact-quality context uses the recent tracked game-feed sample already used by the model.
