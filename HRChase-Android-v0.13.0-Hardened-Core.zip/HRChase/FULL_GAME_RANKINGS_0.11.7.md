# HR Chase v0.11.7 — Full Game Rankings

## What changed
- The Games tab no longer cuts each matchup off at the Top 10 hitters.
- Opening a matchup now shows every hitter currently available to the model from both teams.
- The full list remains sorted from strongest to weakest by the existing Pick Score.
- Rank numbers continue through the entire matchup instead of stopping at #10.
- The game card now says `VIEW ALL` and reports the actual number of ranked hitters loaded for that game.

## Lineup behavior
HR Chase still uses the same lineup pipeline as before:
- official batting orders when they are posted;
- otherwise the team's latest real lineup as the clearly projected fallback.

That means a normal game will usually show all modeled starting hitters from both teams (typically 18 total), rather than only the 10 highest-ranked names. No scoring logic, filters, parlay logic, pull-to-refresh behavior, or Android back-navigation behavior was removed.
