# HR Chase v0.11.2 — Last Night Pattern Lab

## Goal
Turn the previous-night HR list into a leakage-safe next-day learning signal. HR Chase now compares the PRE-GAME signal snapshot of actual HR hitters against every graded hitter from that same slate.

## Common-denominator engine
For each signal, the app measures:
- share of HR hitters above a meaningful threshold
- share of the full slate above that threshold
- HR rate among exposed hitters vs the night's baseline HR rate
- average signal value among HR hitters vs the full field

Signals considered: Season Power, Contact Quality, Recent Power, Power Pressure, Pitcher Matchup, Pitch Arsenal Fit, Handedness Edge, Environment.

Only meaningful denominators with adequate sample coverage are shown. The strongest five are retained.

## Next-day Pattern Match
Today's hitters receive a 0-100 Pattern Match score based on how closely they fit the strongest common denominators from last night's HR cohort. The top matches are shown directly under the Last Night card.

Pattern Match is intentionally a small ranking adjustment (max about +2.4 points before confidence scaling). It can separate close calls but cannot override the core model. This prevents one noisy night from overfitting the rankings.

## Leakage protection
The feature only uses saved PRE-GAME snapshots. It does not reconstruct yesterday's metrics after the result is known. This is critical for honest model learning.
