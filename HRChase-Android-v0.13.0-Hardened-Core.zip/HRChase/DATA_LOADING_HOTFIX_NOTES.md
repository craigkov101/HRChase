HR Chase Android v0.10.5.1 - Data Loading Hotfix

Fixes:
- Core slate now renders before Pitch Arsenal Fit enrichment runs.
- Pitch Arsenal Fit requests are capped with short timeouts and fail neutral instead of blocking the board.
- Reduced recent-feed budget from 30 to 24 games to lower startup memory/network load.
- Added one automatic retry for the critical MLB schedule request.
- Publishes another partial board after arsenal enrichment, before BvP completes.
- Keeps all v0.10.5 features including Pitch Arsenal Fit, Heating, Hot, Last 10 tracked stats, headshots, and date limits.
