package com.ckz.hrchase

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.SvgDecoder
import coil.disk.DiskCache
import coil.memory.MemoryCache

class HrChaseApplication : Application(), ImageLoaderFactory {
    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.16)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("hrchase_images"))
                    .maxSizeBytes(80L * 1024L * 1024L)
                    .build()
            }
            .components {
                add(SvgDecoder.Factory())
            }
            .crossfade(false)
            .build()
}
