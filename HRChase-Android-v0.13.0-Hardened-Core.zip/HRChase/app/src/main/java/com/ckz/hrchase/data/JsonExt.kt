package com.ckz.hrchase.data

import org.json.JSONArray
import org.json.JSONObject

fun JSONObject.optObject(name: String): JSONObject? = optJSONObject(name)
fun JSONObject.optArray(name: String): JSONArray? = optJSONArray(name)

fun JSONObject.optDoubleOrNull(name: String): Double? {
    if (!has(name) || isNull(name)) return null
    return when (val value = opt(name)) {
        is Number -> value.toDouble().takeIf { it.isFinite() }
        is String -> value.toDoubleOrNull()?.takeIf { it.isFinite() }
        else -> null
    }
}

fun JSONObject.optIntOrNull(name: String): Int? {
    if (!has(name) || isNull(name)) return null
    return when (val value = opt(name)) {
        is Number -> value.toInt()
        is String -> value.toIntOrNull()
        else -> null
    }
}

fun JSONArray.objects(): Sequence<JSONObject> = sequence {
    for (i in 0 until length()) {
        optJSONObject(i)?.let { yield(it) }
    }
}

fun JSONArray.ints(): List<Int> = buildList {
    for (i in 0 until length()) {
        val v = opt(i)
        when (v) {
            is Number -> add(v.toInt())
            is String -> v.toIntOrNull()?.let(::add)
        }
    }
}
