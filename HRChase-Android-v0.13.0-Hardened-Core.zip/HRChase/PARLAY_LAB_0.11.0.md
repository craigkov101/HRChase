# HR Chase v0.11.0 — Parlay Lab overhaul

## Generator profiles
- Balanced: full daily HR Chase model.
- Pure Power: season HR skill, power profile, barrels/hard contact, EV and recent power.
- Heating Up: three-day acceleration, emerging contact quality, near-HR pressure and whiff control.
- Hot Now: seven-day production supported by power/contact metrics.
- Matchup Edge: opposing pitcher vulnerability, Statcast pitch-arsenal fit, platoon context and environment.

## Variety engine
- Candidate pool widened from a very tight top cluster to a controlled competitive window.
- Straight picks use a stride-based rotation across up to 18 qualified hitters.
- Multi-leg generations rotate the anchor through up to 18 quality candidates.
- Later generations receive deterministic diversity boosts among comparable candidates.
- Same-game and same-team repeats are penalized.
- Weak matchup/environment legs are still penalized so variety does not become randomness.

## Card rating
Every generated slip now receives a 1–99 Relative Hit Rating. It is a comparative model grade, not a calibrated probability.

The rating uses:
- average profile-specific leg score,
- the weakest leg on the card,
- game diversity,
- and a substantial penalty as leg count increases.

This lets users compare two generated slips while correctly recognizing that a five-leg HR parlay is much less likely to hit than a one- or two-leg card, even when all individual hitters grade well.
