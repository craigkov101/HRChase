HR Chase Android v0.9.1 – Data Coverage Fix

What this fixes
- Pull%, PullBrl%, and PullAir% could show as blank/N/A even when recent tracked batted balls existed.
- The main causes were relying too heavily on free-text play descriptions and using a roster-level batting-side value that is "S" for switch hitters.

Changes
- Captures the actual batting side (R/L) used on every plate appearance from MLB matchup data.
- Uses MLB hitData.location as the primary spray-direction source.
- Uses MLB Gameday spray coordinates as the second direction source.
- Uses the play description only as a final fallback.
- Correctly calculates pulled contact for switch hitters based on the side they actually hit from on each batted ball.
- Adds a Directional coverage X/Y line so users can see how many recent BBE have usable direction data.
- Missing directional values now display N/A instead of a dash, making unavailable data distinct from 0.0%.

Accuracy impact
- More complete Pull%, PullBrl%, and PullAir% coverage.
- More accurate recent directional profiles for switch hitters.
- No fake zeroes: if MLB truly has no usable direction data, the metric remains unavailable and its weight is omitted rather than penalizing the hitter.
