# HR Chase v0.11.3 — Game Drilldown

- Games tab is now collapsed by default for a faster, cleaner slate scan.
- Tap any game to open its ranked HR board.
- Each expanded matchup shows up to 10 hitters combined from both teams, ranked by the current HR Chase Daily Target Score.
- Pitcher/weather alerts stay summarized on the collapsed row and expand with the matchup.
- Only one game is expanded at a time, which reduces Compose work and scrolling overhead on large slates.
- Date changes automatically reset the expanded matchup.
