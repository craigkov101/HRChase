# HR Chase v0.10.1 — Player headshots

Player headshots are loaded from MLB static player imagery using each MLB person ID and Coil. Images are clipped to a circular avatar and cached by Coil. A team-logo fallback is shown when a headshot is unavailable. Small team-logo badges remain overlaid on avatars for quick team recognition.
