# HR Chase 0.10.8 — Release Performance RC1

This build is focused on stability, responsiveness, and the date-switch/refresh bug reported before release.

## Critical state fix

- Added a small per-date in-memory board cache (LRU, four dates).
- Date changes restore the last usable board instantly and refresh it in the background.
- An early schedule-only partial can no longer wipe already-loaded hitters.
- A failed enrichment refresh keeps the last usable player board instead of leaving the screen blank.
- Refreshes use a generation token so a cancelled request for another date cannot overwrite the current date.
- Cancellation is propagated normally instead of being treated as a normal load failure.
- State mutations are synchronized because partial-board updates now arrive from background work.

## Performance work

- Board loading / JSON parsing / scoring runs off the UI thread on `Dispatchers.Default`.
- MLB/Savant HTTP responses use TTL-aware in-memory caching.
- Per-URL single-flight locks prevent rapid refresh/date switching from duplicating identical network requests.
- Final/recent game feeds use long cache windows; live/current feeds remain short-lived.
- Savant arsenal leaderboards and HR pitch history are cached so Arsenal Fit does not repeatedly download the same season data.
- Recent-feed concurrency reduced from 7 to 5 to lower mobile-network contention and memory spikes.
- Coil player/team image loading now has explicit memory and 80 MB disk caches.
- Compose state collection is lifecycle-aware so the UI stops collecting while the app is not active.

## Failure behavior

If MLB/Savant fails during a refresh but a usable board is already loaded, the app shows a non-destructive warning and keeps the saved board visible. The user can retry without restarting the app.

## Release smoke-test checklist

Before Play Store release, test on at least two Android phones:

1. Cold launch on Wi-Fi and cellular.
2. Today -> yesterday -> today repeatedly (10+ cycles).
3. Refresh after every date switch.
4. Refresh twice around official lineup posting time.
5. Background app for 5 minutes, return, refresh.
6. Toggle Remaining / Official Lineups repeatedly while loading.
7. Open/close 20+ player detail pages and scroll long lists.
8. Open Targets, Heating, Hot, Parlays, and Tracked after a refresh.
9. Disable network during refresh, then restore it and retry. Existing board should remain visible.
10. Confirm Pitch Arsenal Fit enriches without blocking the initial hitter board.

Do not enable code shrinking/minification for the public build until this RC passes the smoke tests; stability is more important than a slightly smaller APK this week.
