# HR Chase v0.12.0 — Triple-A Batted-Ball Layer

This upgrade extends the curated Potential AAA Sluggers watchlist with recent Triple-A game-feed contact data.

## Data layer
- Fetch one bounded Triple-A schedule window (sportId 11).
- Select at most 30 recent Final/Live games involving current watchlist Triple-A teams, targeting up to four games per team.
- Reuse the live-feed parser already used by the MLB model.
- Keep only watched prospects' batted balls.
- Consume launchSpeed, launchAngle, totalDistance, trajectory, hit location, spray coordinates and pitch type only when present.

## Scoring
- Contact quality uses the existing transparent HR Chase batted-ball model.
- Small samples are regressed toward 50 using the existing contact-profile confidence value.
- With tracked EV/LA data, the AAA Slugger Score is: 33.6% season power, 22.4% recent power, 9.6% readiness, 14.4% call-up watch, 20% batted-ball quality.
- Without tracked EV/LA data, weights renormalize to the exact v0.11.9 mix: 42% / 28% / 12% / 18%.

## Profile additions
- Avg EV / Max EV / Avg launch angle
- Hard-hit%
- HR Chase barrel proxy%
- Sweet-spot%
- Avg distance
- Blast% / fly-ball%
- Pull% / pull-barrel% / pull-air%
- Sample size + confidence
- Pitch-type contact grouping
- Recent Triple-A contact log with EV / LA / distance / pitch type

No missing Statcast-style values are estimated or backfilled.
