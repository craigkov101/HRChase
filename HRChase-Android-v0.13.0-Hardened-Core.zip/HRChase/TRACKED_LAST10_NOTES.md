HR Chase Android v0.10.4 — Recent Navigation + Tracked Last 10

Changes:
- Date navigation now has a hard floor of yesterday. The app no longer lets users browse/load older historical slates by repeatedly tapping back.
- The left date arrow is visibly disabled once yesterday is reached.
- Tracked Picks now load each tracked hitter's last 10 completed MLB games from the lightweight Stats API game log endpoint.
- Tracked cards show a compact Last 10 panel with AVG, OPS, HR, RBI, hits, extra-base hits, runs, walks, and strikeouts.
- Last-10 requests are cached in memory and only run for players on the selected Tracked slate, avoiding extra load on the main board.
- Future/today boards use the most recent completed date as the last-10 cutoff so incomplete games do not distort recent form.
