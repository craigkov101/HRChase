# HR Chase v0.9 — Accuracy + Logo Cleanup

## Logo cleanup
- Removed the bright white square/backplate behind team SVGs.
- Logos now sit on a subtle dark transparent surface that matches the app.

## Model/data upgrades
- Adds season hitter splits vs RHP and LHP using two league-wide MLB StatsAPI requests, not one request per player.
- Adds real platoon score to the daily Target Score.
- Adds hitter strikeout rate to season power/context.
- Adds pitcher strikeout rate, walk rate and batters faced.
- Pitcher matchup now considers HR/9, K%, WHIP, recent hard-hit%, recent barrel%, and recent Sweet Spot% allowed.
- Adds Sweet Spot% (8–32° launch angle) and Max EV to player detail.
- Keeps BvP sample-size capped so small samples cannot dominate the model.

## Performance intent
The new handedness data is fetched in only two league-wide calls and gracefully falls back if unavailable, so the board still loads even if the split endpoint fails.
