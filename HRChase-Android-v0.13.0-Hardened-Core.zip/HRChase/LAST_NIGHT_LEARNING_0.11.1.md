# HR Chase v0.11.1 — Last Night + Outcome Learning

## New Last Night feature
- Loads the complete previous MLB slate and identifies every home run from final games.
- Shows total MLB home runs, unique home-run hitters, multi-HR games, team, max EV, longest distance and HR pitch types when available.
- Reuses already-loaded recent game feeds and fetches only missing games to limit extra network work.

## Model feedback loop
- The first full board loaded for the current day is saved as a pregame signal snapshot.
- The next morning, that snapshot is graded against actual MLB home-run outcomes.
- Tracks whether elevated Recent Power, Power Pressure, Pitcher Matchup, Environment, Season Power, Platoon, Contact Profile and Pitch Arsenal Fit signals are producing HRs above or below the board baseline.
- Historical learning remains a small, capped calibration layer and does not become active until at least 500 graded hitter-games and 35 HR outcomes are available. This reduces one-night overfitting.
- A hitter who homered the previous night receives only a tiny tie-break confirmation because the HR is already represented in recent-contact metrics.

## Why this matters
The app now starts building its own outcome dataset instead of only generating daily predictions. Over time, this lets HR Chase measure which signals are actually associated with home runs and cautiously calibrate the ranking model from real results.
