# HR Chase v0.11.8 — Universal Player Profiles

## Goal
Make every hitter name in HR Chase lead to one consistent, complete, scrollable player profile.

## Entry points
The Player Profile can now be opened from:
- every game's full ranked hitter list,
- Targets,
- Heating,
- Hot,
- Parlay legs,
- Tracked picks,
- Last Night home-run hitters,
- Today's closest Last Night pattern matches.

## Profile contents
The profile keeps the full detailed HR Chase breakdown already used on hitter detail pages:
1. Pick Score and plain-English justification
2. Power Signal Lens
   - recent form / pressure
   - swing & miss
   - pitcher resistance
   - pitch arsenal fit
   - lineup barrel depth
3. Five Key Signals
   - Power Pressure
   - Pitcher matchup
   - Pitch arsenal fit
   - Handedness split
   - Recent contact
4. Pitch Arsenal Fit detail and pitch-type matchup rows
5. Must-Have Power Metrics
   - Barrel%
   - Hard-Hit%
   - EV
   - ISO
   - Fly Ball%
   - average distance
   - Pull%
   - Pull Barrel%
   - Pull Air%
   - Blast%
   - Sweet Spot%
   - Max EV
   - K%
   - profile confidence and directional coverage
6. Opposing pitcher profile
7. Season split vs pitcher hand
8. Career batter vs pitcher history
9. Model justification notes
10. Recent tracked batted-ball contact with EV / LA / distance / result labels

## Historical behavior
A Last Night hitter first resolves against today's loaded slate. If the player is not on today's board, HR Chase loads the previous-date board on demand and opens that player's complete historical matchup profile. A loading state is shown while that profile is assembled.

## Navigation
Both the profile back arrow and Android system Back return to the previous HR Chase screen.
