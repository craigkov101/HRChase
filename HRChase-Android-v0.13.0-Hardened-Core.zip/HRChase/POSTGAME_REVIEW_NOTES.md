# v0.10.6.1 Postgame Explain

- Yesterday's Top 15 now show a postgame diagnosis once the game is final.
- Exact player game lines are loaded from MLB game logs without blocking the main board.
- Misses are classified as matchup-driven, bad/quiet night, productive night without HR, hard-contact variance, barrel without HR, near-HR, or elite near-HR.
- Near-HR and barrel outcomes are explicitly treated as process-positive rather than identical to a complete miss.
- Matchup-driven misses reference the pregame matchup score and opposing starter profile.
- Builds on v0.10.6.0's calibrated scoring changes.
