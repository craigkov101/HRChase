# HR Chase v0.10.3 — Heating Up

New dedicated **Heating** tab focused on hitters who appear to be *in the process* of getting hot rather than hitters whose seven-day streak is already obvious.

## Window
- Previous 3 completed calendar days only for box-score form.
- Uses the same already-loaded recent MLB Gameday feeds for three-day batted-ball and swing/whiff evidence.
- Adds one league-wide three-day StatsAPI request, run alongside the existing seven-day request to minimize loading impact.

## Emerging Heat signals
A hitter must clear multiple signals to appear:
- improving 3-day AVG/OPS/hit production
- hard-hit rate
- barrel proxy
- max exit velocity
- near-HR / elite near-HR misses
- low recent whiff rate
- elevated Power Pressure
- acceleration versus the hitter's 7-day line

## Ranking
The HEAT score intentionally emphasizes process over actual home-run totals:
- 32% three-day contact quality
- 24% three-day box-score production
- 15% Power Pressure
- 10% three-day swing-and-miss control
- 12% acceleration vs seven-day form
- 7% today's Target Score

Small samples are confidence-weighted. Hitters who are already obvious seven-day hot streaks (very high Hot score plus multiple HRs) are filtered out so the board remains focused on emerging form.

## UI
Bottom navigation is now:
Games | Targets | Heating | Hot | Parlays | Tracked

Each Heating card shows:
- HEAT score
- 3-day AVG / OPS / XBH / max EV
- 3-day batting line
- multiple plain-English reasons
- signal count
- acceleration score
- today's HR Target score
