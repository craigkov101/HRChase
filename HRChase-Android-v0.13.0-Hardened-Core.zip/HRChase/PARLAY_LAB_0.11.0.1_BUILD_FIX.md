# HR Chase v0.11.0.1 Build Fix

- Fixes Kotlin compile error in the header credit line.
- Replaces undefined `AppMutedText` with the existing `AppMuted` color token.
- No model or parlay logic changes from v0.11.0.
