# HR Chase v0.8.1 Performance Notes

This build focuses on startup speed, responsiveness, and crash resistance without removing the Games, Targets, Parlays, Tracked, power-profile, BvP, pitcher-warning, or weather features.

## Data pipeline changes

1. Schedule-first rendering: games are pushed to the UI immediately after the MLB schedule call.
2. Progressive board rendering: full core scores are pushed before BvP calls finish.
3. Compact current feeds: the app extracts lineup/weather/batted-ball/pitcher information and releases the full JSONObject tree instead of retaining 15 live feeds.
4. Bounded history: at most 30 recent completed game feeds are requested from the five-day lookback window.
5. Bounded BvP: top two preliminary hitters per game plus the best 12 overall are enriched, instead of seven hitters per game.
6. Lower network timeouts so a stalled endpoint does not freeze the entire refresh for 20 seconds per request.

## UI changes

- Game candidates are grouped once for the Games screen.
- Main scrolling cards use zero default elevation and reduced navigation/header shadow cost.
- The existing slate remains usable during refreshes instead of being replaced by a blank loading state.
