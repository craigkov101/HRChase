# HR Chase 0.10.9.1 — Cxaig credit

- Adds a compact `• built by Cxaig` credit directly beside `HOME RUN INTELLIGENCE` in the main app header.
- Keeps the existing subtitle typography intact and renders the credit slightly smaller and more muted so it reads as a clean creator signature rather than competing with the HR Chase brand.
- Bumps the Android version to 0.10.9.1 / versionCode 21.
