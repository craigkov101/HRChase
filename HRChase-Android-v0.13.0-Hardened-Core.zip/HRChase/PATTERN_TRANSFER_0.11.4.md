# HR Chase 0.11.4 — Pattern Transfer

Minor calibration pass after the Aug. 27 slate.

## What changed

- Keeps the existing common-denominator analysis from Pattern Lab.
- Adds **Profile Echo**, a direct similarity comparison between today's hitter signal vector and each actual HR hitter's saved pregame signal vector from the previous night.
- Uses 8 signals: season power, contact profile, recent power, power pressure, pitcher matchup, pitch arsenal fit, platoon edge and environment.
- Shows the closest previous-night HR profile next to today's strongest Pattern Matches.
- Multi-HR hitters get only a tiny reference bump; one outlier cannot dominate the ranking.
- Pattern Match now blends group-level common denominators with individual HR archetype similarity.
- Pattern influence remains capped as a tie-breaking/calibration layer to avoid overfitting one night.

## Why

A group average can hide different ways a hitter reaches a home run. One night may include established power bats, heating contact bats and matchup-specific HRs at the same time. Profile Echo preserves those distinct winning shapes and searches the next slate for similar pregame profiles.
