# HR Chase model postmortem — Aug. 24, 2026

## What the slate taught us

The Aug. 24 slate reinforced two competing truths:

1. Recent hard contact / near-HR pressure is useful for finding hitters whose results may be about to turn.
2. Tiny recent samples can create false confidence, especially when a light-power hitter draws a strong starter.

Verified examples from the app screen included Kevin McGonigle and Hao-Yu Lee against Drew Rasmussen and Nick Sogard against Sandy Alcantara. The recent-contact signal was strong enough to keep those names interesting even though the pitcher/handedness context was unfavorable. None homered. Rasmussen and Alcantara both delivered strong starts.

At the same time, several of the night's actual home runs came from established power bats such as Rafael Devers, Jake Burger, Wyatt Langford, Julio Rodriguez and Cal Raleigh. This argues for giving the season power baseline more direct weight so a short cold spell cannot bury a hitter with real home-run skill.

The slate also included low-predictability homers from secondary bats. We do not want to overfit one night by teaching the model to chase every bottom-of-order outlier.

## v0.10.6 calibration changes

- Reduced default Recent Power weight: 25 -> 20.
- Reduced default Power Pressure weight: 20 -> 15.
- Increased Pitcher Matchup weight: 25 -> 28.
- Increased Season Power weight: 15 -> 24.
- Reduced Environment weight: 10 -> 8.
- Recent Power now regresses small Statcast samples toward neutral until roughly 10 tracked BBE.
- Power Pressure now regresses small samples until roughly 8 tracked BBE.
- Recent pitcher contact allowed now receives sample-size regression instead of treating a few BBE as stable.
- Pitcher Matchup now includes ERA directly in addition to HR/9, strikeout/contact opportunity, recent contact quality, WHIP and handedness.
- Daily Target Score no longer blends two overlapping composites. It is one transparent calibrated composite, preventing accidental double-counting of recent form and matchup.
- Season power receives a direct 15% share of Target Score.
- Pitch Arsenal Fit remains meaningful but is reduced from a de facto 10% repeated influence to a single 8% influence in Target Score and 6% in the signal lens.
- Added convergence bonuses when multiple independent signals agree.
- Added a strong-starter resistance penalty for low-season-power bats whose case is mostly a tiny recent sample.
- Added a small established-power tie-breaker so elite HR hitters are not buried by short-term noise.
- BvP remains capped and sample-size aware.

## Calibration philosophy

This is intentionally a moderate adjustment, not a one-day rewrite. Home-run outcomes are noisy. The goal is to improve the ranking of repeatable home-run skill and signal convergence while preserving the app's ability to catch hitters who are beginning to heat up.
