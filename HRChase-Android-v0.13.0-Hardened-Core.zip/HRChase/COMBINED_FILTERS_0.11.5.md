# HR Chase 0.11.5 — Combined Parlay Filters

## What changed
- Parlay Generator Focus chips are now true multi-select controls.
- Any combination of Balanced, Pure Power, Heating, Hot Now, and Matchup Edge can be active at the same time.
- Stacked filters use strict AND qualification: every generated hitter must pass every selected specialized lens.
- Combined ranking blends all active focus scores while giving extra weight to the weakest selected lens, so one poor filter cannot be averaged away.
- Balanced can be stacked with specialized filters when the full HR Chase model should remain part of the ranking.
- The UI shows AND MODE and the number of active filters.
- Generated cards and leg explanations display the combined filter stack and per-lens grades.
- If a combination is too restrictive for the requested parlay size, the app tells the user to remove a filter or reduce the number of legs instead of silently inserting unqualified hitters.

## Example
Selecting **Hot Now + Matchup Edge** requires hitters to satisfy both the 7-day hot-form qualification and the matchup/pitch-arsenal qualification. They are then ranked by their combined Hot + Matchup strength.
