HR Chase Android v0.8.2 UI Polish

Changes in this build:
- Raised overall text readability by providing a global default content color for dark surfaces.
- Brightened the top header title and subtitle.
- Brightened the date control card and date text for stronger contrast.
- Reworked the bottom navigation into a floating safe-area-aware bar.
- Added navigation bar bottom padding so tabs no longer collide with the system navigation area.
- Kept the sleek redesign while improving polish and usability.

Focus:
- Better readability
- Cleaner bottom tab layout
- More premium visual feel
