HR Chase v0.10.5.2 - Pitch Arsenal Data Fix

- Arsenal Fit now attempts data for every hitter on the daily board.
- Replaces one-shot 6 second Statcast timeouts with a 15 second retry strategy.
- Reduces pitch-metric request concurrency to avoid throttling.
- Uses releaseSpeed for pitcher pitch-frequency occurrence counts.
- Missing Arsenal Fit displays N/A instead of a misleading score of 50.
- If pitch data is unavailable, the 10% Arsenal Fit weight is redistributed across the remaining model signals rather than injecting a fake neutral value.
- Core slate still renders before pitch enrichment, so advanced pitch data cannot block the Games screen.
