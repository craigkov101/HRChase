HR Chase Android v0.8.3 – Team Logos

UI additions:
- MLB team logos now appear next to hitter names on Games cards.
- Team logos appear next to hitters on the Top 15 Targets board.
- Parlay legs now include each player's team logo.
- Player detail headers include the hitter's team logo.
- Tracked picks show team logos when the board data is available.
- Game matchup team badges now include logos as well.

Implementation:
- Logos are loaded from MLB's static team-logo CDN using the MLB team ID already present in the app's data model.
- Coil image loading with SVG support handles remote logos and caching.
- A small abbreviation fallback remains underneath the logo if the asset cannot load.
