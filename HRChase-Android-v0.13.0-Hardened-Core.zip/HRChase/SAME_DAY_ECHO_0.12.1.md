# HR Chase v0.12.1 — Live Day Echo

## Purpose
Use actual home runs from games that have already started today as a live, same-day comparison set for hitters in games that have not started yet.

## How it works
- Reads real same-day HR outcomes from the current MLB game feeds already loaded by HR Chase.
- Uses each HR hitter's saved PRE-GAME signal snapshot, not the result itself, for profile matching.
- Compares late-slate hitters across the same eight signal families used by Pattern Transfer:
  - season power
  - contact quality
  - recent power
  - power pressure
  - pitcher matchup
  - pitch arsenal fit (when measured)
  - handedness/platoon edge
  - environment
- Produces a 0-100 **Day Echo** similarity grade and identifies the closest same-day HR profile(s).
- Shows shared early-slate green signals when multiple HR hitters converge on the same traits.

## Ranking integration
Day Echo is a small live tie-breaker only. It can add at most 2 points to the Daily Target Score for games still in Preview status, and the effect is confidence-scaled when the early HR sample is small.

## UI
The Games tab now contains a **LIVE DAY ECHO** card when at least one game has started and later games remain. Pull-to-refresh updates the same-day reference pool and late-slate matches.

## Guardrails
- No claim that home runs occur in repeating sequences.
- No result leakage into the reference profile: saved pregame signals are used for the comparison.
- No forced match when no late hitter clears the similarity threshold.
- Live and completed games can contribute HR references; only not-yet-started games can receive the Day Echo boost.
