package com.ckz.hrchase.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate

class AppPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("hr_chase_prefs", Context.MODE_PRIVATE)

    fun loadWeights(): ScoreWeights = ScoreWeights(
        recentPower = prefs.getFloat("w_recent", 20f),
        powerPressure = prefs.getFloat("w_pressure", 15f),
        pitcherMatchup = prefs.getFloat("w_matchup", 28f),
        environment = prefs.getFloat("w_environment", 8f),
        seasonPower = prefs.getFloat("w_season", 24f),
        lineup = prefs.getFloat("w_lineup", 5f)
    )

    fun saveWeights(w: ScoreWeights) {
        prefs.edit()
            .putFloat("w_recent", w.recentPower)
            .putFloat("w_pressure", w.powerPressure)
            .putFloat("w_matchup", w.pitcherMatchup)
            .putFloat("w_environment", w.environment)
            .putFloat("w_season", w.seasonPower)
            .putFloat("w_lineup", w.lineup)
            .apply()
    }

    fun loadTracked(): List<TrackedPick> {
        val raw = prefs.getString("tracked", null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val o = array.optJSONObject(i) ?: continue
                    // v0.16 removed the H+R+RBI feature. Do not reinterpret old production
                    // watchlist rows as home-run picks; simply retire them from the visible watchlist.
                    if (o.optString("pickType", PickType.HOME_RUN.name) == "HRR_PRODUCTION") continue
                    add(
                        TrackedPick(
                            playerId = o.optInt("playerId"),
                            playerName = o.optString("playerName"),
                            teamName = o.optString("teamName"),
                            date = LocalDate.parse(o.optString("date")),
                            scoreAtTrack = o.optDouble("scoreAtTrack"),
                            trackedAt = Instant.parse(o.optString("trackedAt")),
                            pickType = PickType.HOME_RUN
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun saveTracked(picks: List<TrackedPick>) {
        val array = JSONArray()
        picks.forEach { p ->
            array.put(
                JSONObject()
                    .put("playerId", p.playerId)
                    .put("playerName", p.playerName)
                    .put("teamName", p.teamName)
                    .put("date", p.date.toString())
                    .put("scoreAtTrack", p.scoreAtTrack)
                    .put("trackedAt", p.trackedAt.toString())
                    .put("pickType", p.pickType.name)
            )
        }
        prefs.edit().putString("tracked", array.toString()).apply()
    }

    fun loadSignalSnapshots(): List<DailySignalSnapshot> {
        val raw = prefs.getString("signal_snapshots_v1", null) ?: return emptyList()
        return runCatching {
            val days = JSONArray(raw)
            buildList {
                for (i in 0 until days.length()) {
                    val day = days.optJSONObject(i) ?: continue
                    val date = runCatching { LocalDate.parse(day.optString("date")) }.getOrNull() ?: continue
                    val savedAt = runCatching { Instant.parse(day.optString("savedAt")) }.getOrDefault(Instant.EPOCH)
                    val hittersJson = day.optJSONArray("hitters") ?: JSONArray()
                    val hitters = buildList {
                        for (j in 0 until hittersJson.length()) {
                            val h = hittersJson.optJSONObject(j) ?: continue
                            add(
                                HitterSignalSnapshot(
                                    date = date,
                                    playerId = h.optInt("playerId"),
                                    recentPower = h.optDouble("recentPower", 50.0),
                                    powerPressure = h.optDouble("powerPressure", 50.0),
                                    pitcherMatchup = h.optDouble("pitcherMatchup", 50.0),
                                    environment = h.optDouble("environment", 50.0),
                                    seasonPower = h.optDouble("seasonPower", 50.0),
                                    platoon = h.optDouble("platoon", 50.0),
                                    contactProfile = h.optDouble("contactProfile", 50.0),
                                    pitchArsenalFit = if (h.has("pitchArsenalFit") && !h.isNull("pitchArsenalFit")) h.optDouble("pitchArsenalFit") else null,
                                    pitchArsenalConfidence = if (h.has("pitchArsenalConfidence") && !h.isNull("pitchArsenalConfidence")) h.optDouble("pitchArsenalConfidence") else null,
                                    outcomeHomeRun = if (h.has("outcomeHomeRun") && !h.isNull("outcomeHomeRun")) h.optBoolean("outcomeHomeRun") else null,
                                )
                            )
                        }
                    }
                    add(DailySignalSnapshot(date = date, savedAt = savedAt, hitters = hitters))
                }
            }
        }.getOrDefault(emptyList())
    }

    fun saveSignalSnapshotIfAbsent(snapshot: DailySignalSnapshot) {
        val existing = loadSignalSnapshots().toMutableList()
        if (existing.any { it.date == snapshot.date }) return
        existing += snapshot
        saveSignalSnapshots(existing)
    }

    /**
     * Keeps the learning set genuinely pregame. Morning refreshes are allowed to improve today's
     * snapshot as lineups, probable pitchers and arsenal data arrive, but once a player's game has
     * started their earlier row is frozen. A player first seen after first pitch is not added.
     * This fixes the old "first refresh of the morning wins forever" problem without introducing
     * postgame leakage.
     */
    fun mergePregameSignalSnapshot(snapshot: DailySignalSnapshot, lockedPlayerIds: Set<Int>) {
        val existing = loadSignalSnapshots().toMutableList()
        val index = existing.indexOfFirst { it.date == snapshot.date }
        if (index < 0) {
            existing += snapshot.copy(
                hitters = snapshot.hitters.filterNot { it.playerId in lockedPlayerIds }
            )
            saveSignalSnapshots(existing)
            return
        }

        val current = existing[index]
        if (current.hitters.any { it.outcomeHomeRun != null }) return
        val currentById = current.hitters.associateBy { it.playerId }
        val incomingById = snapshot.hitters.associateBy { it.playerId }
        val ids = (currentById.keys + incomingById.keys).toSet()
        val merged = ids.mapNotNull { playerId ->
            val old = currentById[playerId]
            val fresh = incomingById[playerId]
            when {
                playerId in lockedPlayerIds -> old
                fresh != null -> fresh
                else -> old
            }
        }
        existing[index] = snapshot.copy(
            savedAt = snapshot.savedAt,
            hitters = merged
        )
        saveSignalSnapshots(existing)
    }

    fun resolveSignalSnapshot(date: LocalDate, homerIds: Set<Int>) {
        val existing = loadSignalSnapshots().toMutableList()
        val index = existing.indexOfFirst { it.date == date }
        if (index < 0) return
        val current = existing[index]
        if (current.hitters.isEmpty() || current.hitters.all { it.outcomeHomeRun != null }) return
        existing[index] = current.copy(
            hitters = current.hitters.map { it.copy(outcomeHomeRun = it.playerId in homerIds) }
        )
        saveSignalSnapshots(existing)
    }

    /** Resolve the only hitter outcome the HR model needs. Scratches with no PA are ignored. */
    fun resolveHomeRunOutcomes(date: LocalDate, outcomes: Map<Int, RecentHittingStats>) {
        val existing = loadSignalSnapshots().toMutableList()
        val index = existing.indexOfFirst { it.date == date }
        if (index < 0) return
        val current = existing[index]
        if (current.hitters.isEmpty()) return
        val resolved = current.hitters.mapNotNull { row ->
            val result = outcomes[row.playerId] ?: return@mapNotNull null
            if (result.plateAppearances <= 0) return@mapNotNull null
            row.copy(outcomeHomeRun = result.homeRuns > 0)
        }
        if (resolved.isEmpty()) return
        existing[index] = current.copy(hitters = resolved)
        saveSignalSnapshots(existing)
    }

    private fun saveSignalSnapshots(snapshots: List<DailySignalSnapshot>) {
        val cutoff = LocalDate.now().minusDays(28)
        val kept = snapshots
            .filter { !it.date.isBefore(cutoff) }
            .distinctBy { it.date }
            .sortedBy { it.date }
            .takeLast(28)
        val days = JSONArray()
        kept.forEach { snapshot ->
            val hitters = JSONArray()
            snapshot.hitters.forEach { h ->
                val obj = JSONObject()
                    .put("playerId", h.playerId)
                    .put("recentPower", h.recentPower)
                    .put("powerPressure", h.powerPressure)
                    .put("pitcherMatchup", h.pitcherMatchup)
                    .put("environment", h.environment)
                    .put("seasonPower", h.seasonPower)
                    .put("platoon", h.platoon)
                    .put("contactProfile", h.contactProfile)
                if (h.pitchArsenalFit != null) obj.put("pitchArsenalFit", h.pitchArsenalFit)
                if (h.pitchArsenalConfidence != null) obj.put("pitchArsenalConfidence", h.pitchArsenalConfidence)
                if (h.outcomeHomeRun != null) obj.put("outcomeHomeRun", h.outcomeHomeRun)
                hitters.put(obj)
            }
            days.put(
                JSONObject()
                    .put("date", snapshot.date.toString())
                    .put("savedAt", snapshot.savedAt.toString())
                    .put("hitters", hitters)
            )
        }
        prefs.edit().putString("signal_snapshots_v1", days.toString()).apply()
    }

    fun loadPitcherStrikeoutSnapshots(): List<DailyPitcherStrikeoutSnapshot> {
        val raw = prefs.getString("pitcher_k_snapshots_v1", null) ?: return emptyList()
        return runCatching {
            val days = JSONArray(raw)
            buildList {
                for (i in 0 until days.length()) {
                    val day = days.optJSONObject(i) ?: continue
                    val date = runCatching { LocalDate.parse(day.optString("date")) }.getOrNull() ?: continue
                    val savedAt = runCatching { Instant.parse(day.optString("savedAt")) }.getOrDefault(Instant.EPOCH)
                    val pitchersJson = day.optJSONArray("pitchers") ?: JSONArray()
                    val rows = buildList {
                        for (j in 0 until pitchersJson.length()) {
                            val o = pitchersJson.optJSONObject(j) ?: continue
                            add(
                                PitcherStrikeoutSnapshot(
                                    date = date,
                                    pitcherId = o.optInt("pitcherId"),
                                    projectedStrikeouts = o.optDouble("projectedStrikeouts", 5.0),
                                    score = o.optDouble("score", 50.0),
                                    opponentStrikeoutRate = if (o.has("opponentStrikeoutRate") && !o.isNull("opponentStrikeoutRate")) o.optDouble("opponentStrikeoutRate") else null,
                                    seasonStrikeoutRate = if (o.has("seasonStrikeoutRate") && !o.isNull("seasonStrikeoutRate")) o.optDouble("seasonStrikeoutRate") else null,
                                    arsenalWhiffScore = o.optDouble("arsenalWhiffScore", 50.0),
                                    workloadScore = o.optDouble("workloadScore", 50.0),
                                    outcomeStrikeouts = if (o.has("outcomeStrikeouts") && !o.isNull("outcomeStrikeouts")) o.optInt("outcomeStrikeouts") else null
                                )
                            )
                        }
                    }
                    add(DailyPitcherStrikeoutSnapshot(date, savedAt, rows))
                }
            }
        }.getOrDefault(emptyList())
    }

    fun mergePregamePitcherStrikeoutSnapshot(
        snapshot: DailyPitcherStrikeoutSnapshot,
        lockedPitcherIds: Set<Int>
    ) {
        val existing = loadPitcherStrikeoutSnapshots().toMutableList()
        val index = existing.indexOfFirst { it.date == snapshot.date }
        if (index < 0) {
            existing += snapshot.copy(pitchers = snapshot.pitchers.filterNot { it.pitcherId in lockedPitcherIds })
            savePitcherStrikeoutSnapshots(existing)
            return
        }
        val current = existing[index]
        if (current.pitchers.any { it.outcomeStrikeouts != null }) return
        val oldBy = current.pitchers.associateBy { it.pitcherId }
        val freshBy = snapshot.pitchers.associateBy { it.pitcherId }
        val merged = (oldBy.keys + freshBy.keys).mapNotNull { id ->
            when {
                id in lockedPitcherIds -> oldBy[id]
                freshBy[id] != null -> freshBy[id]
                else -> oldBy[id]
            }
        }
        existing[index] = snapshot.copy(pitchers = merged)
        savePitcherStrikeoutSnapshots(existing)
    }

    fun resolvePitcherStrikeoutOutcomes(date: LocalDate, outcomes: Map<Int, PitchingStats>) {
        val existing = loadPitcherStrikeoutSnapshots().toMutableList()
        val index = existing.indexOfFirst { it.date == date }
        if (index < 0) return
        val current = existing[index]
        val resolved = current.pitchers.mapNotNull { row ->
            val result = outcomes[row.pitcherId] ?: return@mapNotNull null
            // If the listed probable pitcher was scratched and never faced a batter, do not grade it.
            if (result.battersFaced <= 0) return@mapNotNull null
            row.copy(outcomeStrikeouts = result.strikeouts)
        }
        if (resolved.isEmpty()) return
        existing[index] = current.copy(pitchers = resolved)
        savePitcherStrikeoutSnapshots(existing)
    }

    private fun savePitcherStrikeoutSnapshots(snapshots: List<DailyPitcherStrikeoutSnapshot>) {
        val cutoff = LocalDate.now().minusDays(45)
        val kept = snapshots.filter { !it.date.isBefore(cutoff) }.distinctBy { it.date }.sortedBy { it.date }.takeLast(45)
        val days = JSONArray()
        kept.forEach { day ->
            val pitchers = JSONArray()
            day.pitchers.forEach { row ->
                val o = JSONObject()
                    .put("pitcherId", row.pitcherId)
                    .put("projectedStrikeouts", row.projectedStrikeouts)
                    .put("score", row.score)
                    .put("arsenalWhiffScore", row.arsenalWhiffScore)
                    .put("workloadScore", row.workloadScore)
                row.opponentStrikeoutRate?.let { o.put("opponentStrikeoutRate", it) }
                row.seasonStrikeoutRate?.let { o.put("seasonStrikeoutRate", it) }
                row.outcomeStrikeouts?.let { o.put("outcomeStrikeouts", it) }
                pitchers.put(o)
            }
            days.put(JSONObject().put("date", day.date.toString()).put("savedAt", day.savedAt.toString()).put("pitchers", pitchers))
        }
        prefs.edit().putString("pitcher_k_snapshots_v1", days.toString()).apply()
    }

}
