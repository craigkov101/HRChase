package com.ckz.hrchase.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import com.ckz.hrchase.AppUiState
import com.ckz.hrchase.MainViewModel
import com.ckz.hrchase.SortMode
import com.ckz.hrchase.data.BattedBall
import com.ckz.hrchase.data.HitterCandidate
import com.ckz.hrchase.data.ScoreWeights
import com.ckz.hrchase.model.HrScoringModel
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

private enum class Tab { BOARD, TRACKED, SETTINGS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HrChaseApp(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    val selected = state.selectedPlayerId?.let { id -> state.board?.candidates?.firstOrNull { it.player.id == id } }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            if (selected != null) {
                PlayerDetailScreen(
                    candidate = selected,
                    tracked = state.tracked.any { it.playerId == selected.player.id && it.date == state.selectedDate },
                    onBack = { viewModel.selectPlayer(null) },
                    onTrack = { viewModel.toggleTracked(selected) }
                )
            } else {
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = {
                                Column {
                                    Text("HR Chase", fontWeight = FontWeight.Bold)
                                    Text("MLB home-run research model", style = MaterialTheme.typography.labelSmall)
                                }
                            },
                            actions = {
                                IconButton(onClick = { viewModel.refresh() }) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Refresh data")
                                }
                            }
                        )
                    },
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(
                                selected = tab == 0,
                                onClick = { tab = 0 },
                                icon = { Icon(Icons.Default.Home, null) },
                                label = { Text("Board") }
                            )
                            NavigationBarItem(
                                selected = tab == 1,
                                onClick = { tab = 1 },
                                icon = { Icon(Icons.Default.Star, null) },
                                label = { Text("Tracked") }
                            )
                            NavigationBarItem(
                                selected = tab == 2,
                                onClick = { tab = 2 },
                                icon = { Icon(Icons.Default.Settings, null) },
                                label = { Text("Model") }
                            )
                        }
                    }
                ) { padding ->
                    when (tab) {
                        0 -> BoardScreen(state, viewModel, padding)
                        1 -> TrackedScreen(state, viewModel, padding)
                        else -> SettingsScreen(state, viewModel, padding)
                    }
                }
            }
        }
    }
}

@Composable
private fun BoardScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val candidates = viewModel.visibleCandidates(state)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
    ) {
        DateControls(state, viewModel)
        if (state.isLoading) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            Text(state.progress, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp), style = MaterialTheme.typography.labelMedium)
        }
        state.error?.let {
            Card(
                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text("Could not load live MLB data", fontWeight = FontWeight.Bold)
                    Text(it, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { viewModel.refresh() }) { Text("Retry") }
                }
            }
        }
        FilterControls(state, viewModel)
        val board = state.board
        if (!state.isLoading && board != null && candidates.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No hitters match these filters yet. Try turning off Official lineups only.", modifier = Modifier.padding(24.dp))
            }
        } else if (board == null && state.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(candidates, key = { "${it.game.gamePk}-${it.player.id}" }) { candidate ->
                    CandidateCard(
                        candidate = candidate,
                        tracked = state.tracked.any { it.playerId == candidate.player.id && it.date == state.selectedDate },
                        onClick = { viewModel.selectPlayer(candidate.player.id) },
                        onTrack = { viewModel.toggleTracked(candidate) }
                    )
                }
                item {
                    Text(
                        "Scores are research signals, not win probabilities. HR outcomes are high variance.",
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun DateControls(state: AppUiState, viewModel: MainViewModel) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        IconButton(onClick = { viewModel.changeDate(-1) }) { Icon(Icons.Default.ChevronLeft, "Previous day") }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(state.selectedDate.format(DateTimeFormatter.ofPattern("EEE, MMM d")), fontWeight = FontWeight.Bold)
            state.board?.let {
                Text("${it.candidates.size} hitters • ${it.recentGameCount} recent games", style = MaterialTheme.typography.labelSmall)
            }
        }
        IconButton(onClick = { viewModel.changeDate(1) }) { Icon(Icons.Default.ChevronRight, "Next day") }
    }
}

@Composable
private fun FilterControls(state: AppUiState, viewModel: MainViewModel) {
    Column(Modifier.padding(horizontal = 12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = state.showRemainingOnly,
                onClick = { viewModel.toggleRemainingOnly() },
                label = { Text("Remaining only") }
            )
            FilterChip(
                selected = state.officialLineupsOnly,
                onClick = { viewModel.toggleOfficialOnly() },
                label = { Text("Official lineups") }
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SortChip("Overall", state.sortMode == SortMode.SCORE) { viewModel.setSortMode(SortMode.SCORE) }
            SortChip("Power Pressure", state.sortMode == SortMode.POWER_PRESSURE) { viewModel.setSortMode(SortMode.POWER_PRESSURE) }
            SortChip("Recent Contact", state.sortMode == SortMode.RECENT_POWER) { viewModel.setSortMode(SortMode.RECENT_POWER) }
            SortChip("Matchup", state.sortMode == SortMode.MATCHUP) { viewModel.setSortMode(SortMode.MATCHUP) }
        }
    }
}

@Composable
private fun SortChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(label) })
}

@Composable
private fun CandidateCard(candidate: HitterCandidate, tracked: Boolean, onClick: () -> Unit, onTrack: () -> Unit) {
    val gameTime = candidate.game.gameDate.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("h:mm a"))
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${candidate.score.total.roundToInt()}", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                        Spacer(Modifier.size(10.dp))
                        Column {
                            Text(candidate.player.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("${candidate.team.abbreviation} • #${candidate.battingOrder} vs ${candidate.opponent.abbreviation} • $gameTime", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    val pitcher = candidate.opponentPitcher
                    if (pitcher != null) {
                        val hr9 = pitcher.seasonStats.hrPer9?.let { " • ${"%.2f".format(it)} HR/9" } ?: ""
                        Text("vs ${pitcher.person.name}$hr9", style = MaterialTheme.typography.bodySmall)
                    }
                }
                IconButton(onClick = onTrack) {
                    Icon(if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder, if (tracked) "Untrack" else "Track")
                }
            }
            if (candidate.score.tags.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    candidate.score.tags.forEach { tag -> AssistChip(onClick = onClick, label = { Text(tag) }) }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                MiniMetric("Pressure", candidate.score.powerPressure)
                MiniMetric("Contact", candidate.score.recentPower)
                MiniMetric("Matchup", candidate.score.pitcherMatchup)
                MiniMetric("Env", candidate.score.environment)
            }
        }
    }
}

@Composable
private fun MiniMetric(label: String, value: Double) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value.roundToInt().toString(), fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlayerDetailScreen(candidate: HitterCandidate, tracked: Boolean, onBack: () -> Unit, onTrack: () -> Unit) {
    val model = remember { HrScoringModel() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(candidate.player.name) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } },
                actions = {
                    IconButton(onClick = onTrack) { Icon(if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder, "Track") }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(candidate.score.total.roundToInt().toString(), style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Black)
                    Spacer(Modifier.size(14.dp))
                    Column {
                        Text("HR Chase Score", fontWeight = FontWeight.Bold)
                        Text("#${candidate.battingOrder} • ${if (candidate.lineupOfficial) "Official lineup" else "Projected from latest lineup"}")
                    }
                }
            }
            item {
                Card { Column(Modifier.padding(12.dp)) {
                    Text("Model breakdown", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    ScoreBar("Recent contact", candidate.score.recentPower)
                    ScoreBar("Power Pressure", candidate.score.powerPressure)
                    ScoreBar("Pitcher matchup", candidate.score.pitcherMatchup)
                    ScoreBar("Park / weather", candidate.score.environment)
                    ScoreBar("Season power", candidate.score.seasonPower)
                    ScoreBar("Lineup opportunity", candidate.score.lineup)
                }}
            }
            item {
                Card { Column(Modifier.padding(12.dp)) {
                    Text("Why the model likes / dislikes it", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    candidate.score.notes.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp)) }
                }}
            }
            item {
                Card { Column(Modifier.padding(12.dp)) {
                    Text("Season", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    val s = candidate.seasonStats
                    Text("HR ${s.homeRuns} • AB ${s.atBats} • AVG ${s.avg?.let { "%.3f".format(it) } ?: "—"} • SLG ${s.slg?.let { "%.3f".format(it) } ?: "—"} • OPS ${s.ops?.let { "%.3f".format(it) } ?: "—"}")
                    candidate.opponentPitcher?.let { p ->
                        HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        Text("Opposing pitcher: ${p.person.name}", fontWeight = FontWeight.Bold)
                        Text("ERA ${p.seasonStats.era?.let { "%.2f".format(it) } ?: "—"} • HR/9 ${p.seasonStats.hrPer9?.let { "%.2f".format(it) } ?: "—"} • WHIP ${p.seasonStats.whip?.let { "%.2f".format(it) } ?: "—"}")
                    }
                }}
            }
            if (candidate.todayBattedBalls.isNotEmpty()) {
                item { Text("Today's contact", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                items(candidate.todayBattedBalls.reversed()) { ball -> BattedBallRow(ball, model) }
            }
            item { Text("Recent contact (${candidate.recentBattedBalls.size} tracked balls)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            if (candidate.recentBattedBalls.isEmpty()) {
                item { Text("No recent Statcast hitData was available in the MLB game feeds for this lookback window.") }
            } else {
                items(candidate.recentBattedBalls.sortedByDescending { it.gameDate }.take(20)) { ball -> BattedBallRow(ball, model) }
            }
            item {
                Text(
                    "Near-HR and barrel values are transparent model heuristics built from MLB game-feed exit velocity, launch angle and distance. They are not official Statcast barrel labels or betting probabilities.",
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

@Composable
private fun ScoreBar(label: String, value: Double) {
    Column(Modifier.padding(top = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text(value.roundToInt().toString(), fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(progress = { (value / 100.0).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun BattedBallRow(ball: BattedBall, model: HrScoringModel) {
    val signal = when {
        ball.isHomeRun -> "HR"
        model.isEliteNearHomeRun(ball) -> "NEAR-HR+"
        model.isNearHomeRun(ball) -> "NEAR-HR"
        model.isBarrelProxy(ball) -> "BARREL-PROXY"
        model.isHardHit(ball) -> "HARD HIT"
        else -> ""
    }
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(ball.gameDate.toString(), style = MaterialTheme.typography.labelMedium)
                if (signal.isNotBlank()) Text(signal, fontWeight = FontWeight.Bold)
            }
            Text(
                "EV ${ball.exitVelocity?.let { "%.1f mph".format(it) } ?: "—"} • LA ${ball.launchAngle?.let { "%.0f°".format(it) } ?: "—"} • ${ball.distanceFt?.let { "%.0f ft".format(it) } ?: "distance —"}",
                fontWeight = FontWeight.Medium
            )
            Text(ball.description ?: ball.eventType.replace('_', ' '), style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun TrackedScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val model = remember { HrScoringModel() }
    val tracked = state.tracked.filter { it.date == state.selectedDate }
    val byId = state.board?.candidates?.associateBy { it.player.id }.orEmpty()
    Column(Modifier.fillMaxSize().padding(padding)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("Tracked picks", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(state.selectedDate.toString(), style = MaterialTheme.typography.bodySmall)
            }
            if (tracked.isNotEmpty()) Button(onClick = { viewModel.clearTrackedForSelectedDate() }) { Text("Clear") }
        }
        if (tracked.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Tap the star on hitters you play or want to evaluate later.", modifier = Modifier.padding(24.dp))
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tracked, key = { "${it.date}-${it.playerId}" }) { pick ->
                    val c = byId[pick.playerId]
                    Card(modifier = Modifier.fillMaxWidth().clickable(enabled = c != null) { c?.let { viewModel.selectPlayer(it.player.id) } }) {
                        Column(Modifier.padding(12.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text(pick.playerName, fontWeight = FontWeight.Bold)
                                    Text("Tracked at score ${pick.scoreAtTrack.roundToInt()}", style = MaterialTheme.typography.bodySmall)
                                }
                                c?.let { Text(it.game.detailedStatus, style = MaterialTheme.typography.labelMedium) }
                            }
                            if (c == null) {
                                Text("Load this date's board to evaluate live contact.", style = MaterialTheme.typography.bodySmall)
                            } else {
                                val balls = c.todayBattedBalls
                                val hrs = balls.count { it.isHomeRun }
                                val hardest = balls.mapNotNull { it.exitVelocity }.maxOrNull()
                                val grade = when {
                                    hrs > 0 -> "✅ HR hit"
                                    balls.any { model.isEliteNearHomeRun(it) } -> "🟢 Strong read: elite near-HR"
                                    balls.any { model.isNearHomeRun(it) } -> "🟢 Good contact: near-HR"
                                    balls.any { model.isBarrelProxy(it) } -> "🟡 Barrel-quality contact, no HR"
                                    balls.any { model.isHardHit(it) } -> "🟡 Hard contact, no HR"
                                    c.game.status.equals("Final", true) -> "⚪ Quiet contact / miss"
                                    else -> "Game in progress / not started"
                                }
                                Text(grade, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 6.dp))
                                Text("Today: $hrs HR • ${balls.size} tracked balls • max EV ${hardest?.let { "%.1f".format(it) } ?: "—"}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    var recent by remember(state.weights) { mutableFloatStateOf(state.weights.recentPower) }
    var pressure by remember(state.weights) { mutableFloatStateOf(state.weights.powerPressure) }
    var matchup by remember(state.weights) { mutableFloatStateOf(state.weights.pitcherMatchup) }
    var environment by remember(state.weights) { mutableFloatStateOf(state.weights.environment) }
    var season by remember(state.weights) { mutableFloatStateOf(state.weights.seasonPower) }
    var lineup by remember(state.weights) { mutableFloatStateOf(state.weights.lineup) }
    val total = recent + pressure + matchup + environment + season + lineup

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Model Lab", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Change the weights, save, and the board re-ranks instantly without downloading the slate again.")
        }
        item { WeightSlider("Recent contact", recent) { recent = it } }
        item { WeightSlider("Power Pressure / near-HR", pressure) { pressure = it } }
        item { WeightSlider("Pitcher matchup", matchup) { matchup = it } }
        item { WeightSlider("Park / weather", environment) { environment = it } }
        item { WeightSlider("Season power", season) { season = it } }
        item { WeightSlider("Lineup opportunity", lineup) { lineup = it } }
        item {
            Card { Column(Modifier.padding(12.dp)) {
                Text("Weight total: ${total.roundToInt()}", fontWeight = FontWeight.Bold)
                Text("Weights do not have to sum to 100; the scorer normalizes them automatically.", style = MaterialTheme.typography.bodySmall)
                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        viewModel.updateWeights(ScoreWeights(recent, pressure, matchup, environment, season, lineup))
                    }) { Text("Save & re-rank") }
                    Button(onClick = { viewModel.resetWeights() }) { Text("Reset") }
                }
            }}
        }
        item {
            Card { Column(Modifier.padding(12.dp)) {
                Text("V0.1 data pipeline", fontWeight = FontWeight.Bold)
                Text("• MLB Stats API schedule, lineups and probable pitchers")
                Text("• MLB live game feeds for EV, launch angle and distance")
                Text("• Previous 3 days used for recent-contact signals")
                Text("• Current MLB game-feed weather when available")
                Text("• Local tracking of your picks")
                Text("• No sportsbook odds/API yet")
            }}
        }
        item {
            Text(
                "Research/entertainment tool only. The Chase Score is a ranking heuristic, not a predicted probability or guarantee of a home run.",
                style = MaterialTheme.typography.labelMedium
            )
        }
    }
}

@Composable
private fun WeightSlider(label: String, value: Float, onChange: (Float) -> Unit) {
    Card { Column(Modifier.padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontWeight = FontWeight.Medium)
            Text(value.roundToInt().toString(), fontWeight = FontWeight.Bold)
        }
        Slider(value = value, onValueChange = onChange, valueRange = 0f..50f, steps = 49)
    }}
}
