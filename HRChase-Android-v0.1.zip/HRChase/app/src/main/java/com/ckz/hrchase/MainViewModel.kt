package com.ckz.hrchase

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ckz.hrchase.data.AppPreferences
import com.ckz.hrchase.data.BoardData
import com.ckz.hrchase.data.HitterCandidate
import com.ckz.hrchase.data.Repository
import com.ckz.hrchase.data.ScoreWeights
import com.ckz.hrchase.data.TrackedPick
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate

enum class SortMode { SCORE, POWER_PRESSURE, RECENT_POWER, MATCHUP }

data class AppUiState(
    val selectedDate: LocalDate = LocalDate.now(),
    val board: BoardData? = null,
    val isLoading: Boolean = false,
    val progress: String = "",
    val error: String? = null,
    val selectedPlayerId: Int? = null,
    val showRemainingOnly: Boolean = true,
    val officialLineupsOnly: Boolean = false,
    val sortMode: SortMode = SortMode.SCORE,
    val weights: ScoreWeights = ScoreWeights(),
    val tracked: List<TrackedPick> = emptyList()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = AppPreferences(application)
    private val repository = Repository()
    private var refreshJob: Job? = null

    private val _state = MutableStateFlow(
        AppUiState(
            weights = prefs.loadWeights(),
            tracked = prefs.loadTracked()
        )
    )
    val state: StateFlow<AppUiState> = _state.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            val date = _state.value.selectedDate
            val weights = _state.value.weights
            mutate { it.copy(isLoading = true, error = null, progress = "Starting…") }
            runCatching {
                repository.loadBoard(date, weights) { message ->
                    mutate { s -> s.copy(progress = message) }
                }
            }.onSuccess { board ->
                mutate { it.copy(board = board, isLoading = false, progress = "Ready", error = null) }
            }.onFailure { error ->
                mutate {
                    it.copy(
                        isLoading = false,
                        progress = "",
                        error = error.message ?: error::class.java.simpleName
                    )
                }
            }
        }
    }

    fun changeDate(days: Long) {
        mutate { it.copy(selectedDate = it.selectedDate.plusDays(days), selectedPlayerId = null) }
        refresh()
    }

    fun setDate(date: LocalDate) {
        mutate { it.copy(selectedDate = date, selectedPlayerId = null) }
        refresh()
    }

    fun toggleRemainingOnly() = mutate { it.copy(showRemainingOnly = !it.showRemainingOnly) }
    fun toggleOfficialOnly() = mutate { it.copy(officialLineupsOnly = !it.officialLineupsOnly) }
    fun setSortMode(mode: SortMode) = mutate { it.copy(sortMode = mode) }

    fun selectPlayer(id: Int?) = mutate { it.copy(selectedPlayerId = id) }

    fun updateWeights(weights: ScoreWeights) {
        prefs.saveWeights(weights)
        mutate { s ->
            val rescored = s.board?.let { repository.rescore(it, weights) }
            s.copy(weights = weights, board = rescored)
        }
    }

    fun resetWeights() = updateWeights(ScoreWeights())

    fun toggleTracked(candidate: HitterCandidate) {
        val date = _state.value.selectedDate
        val existing = _state.value.tracked
        val keyMatch: (TrackedPick) -> Boolean = { it.playerId == candidate.player.id && it.date == date }
        val next = if (existing.any(keyMatch)) {
            existing.filterNot(keyMatch)
        } else {
            existing + TrackedPick(
                playerId = candidate.player.id,
                playerName = candidate.player.name,
                teamName = candidate.team.name,
                date = date,
                scoreAtTrack = candidate.score.total,
                trackedAt = Instant.now()
            )
        }
        prefs.saveTracked(next)
        mutate { it.copy(tracked = next) }
    }

    fun clearTrackedForSelectedDate() {
        val date = _state.value.selectedDate
        val next = _state.value.tracked.filterNot { it.date == date }
        prefs.saveTracked(next)
        mutate { it.copy(tracked = next) }
    }

    private fun mutate(block: (AppUiState) -> AppUiState) {
        _state.value = block(_state.value)
    }

    fun visibleCandidates(state: AppUiState = _state.value): List<HitterCandidate> {
        val board = state.board ?: return emptyList()
        val nowDate = LocalDate.now()
        return board.candidates.asSequence()
            .filter { c ->
                if (!state.showRemainingOnly || board.date != nowDate) true
                else !c.game.status.equals("Final", true)
            }
            .filter { c -> !state.officialLineupsOnly || c.lineupOfficial }
            .sortedWith(
                when (state.sortMode) {
                    SortMode.SCORE -> compareByDescending { it.score.total }
                    SortMode.POWER_PRESSURE -> compareByDescending { it.score.powerPressure }
                    SortMode.RECENT_POWER -> compareByDescending { it.score.recentPower }
                    SortMode.MATCHUP -> compareByDescending { it.score.pitcherMatchup }
                }
            )
            .toList()
    }
}
