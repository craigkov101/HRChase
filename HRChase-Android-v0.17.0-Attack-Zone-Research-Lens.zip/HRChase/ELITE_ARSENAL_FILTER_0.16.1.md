# HR Chase 0.16.1 — Elite Arsenal Filter

## What changed
- Adds a strict **Elite Arsenal** filter to hitter screens.
- Qualifying hitters must have:
  - Pitch Arsenal Fit score >= 82
  - Arsenal confidence >= 45%
  - Meaningful pitcher pitch-type sample (300+ pitches)
  - Meaningful batter evidence (90+ pitch-type pitches or 3+ HR pitch-type events)
- Missing or thin pitch-type data never qualifies.
- When the filter is active, qualifying hitters are ranked by arsenal fit first, then confidence and the HR Target model.
- There is no fallback to unrelated hitters. An empty result means nobody cleared the strict threshold.
- Adds **Elite Arsenal** to Parlay Lab as a stackable AND filter. It can be combined with Hot Now, Heating, Pure Power, Matchup Edge, or Balanced.

## Intent
This is a precision mode for finding only the clearest measured pitch-type matchups rather than treating every above-average arsenal score as actionable.
