# HR Chase 0.16.2 — Top Arsenal Ranking Filter

## What changed
- Reworks the former **Elite Arsenal** hard gate into **Top Arsenal** ranking mode.
- The filter no longer requires an 82+ fit or 45%+ confidence to return a hitter.
- Instead, HR Chase takes the hitters with real measured pitch-arsenal data and surfaces the **top 15 available matches on that slate**.
- Ranking order is:
  1. Pitch Arsenal Fit score
  2. Arsenal data confidence
  3. HR Target Score
  4. Underlying power profile
- A genuinely elite match still keeps the stricter 82+/45% evidence definition for badges and small model bonuses, so "best available" is not mislabeled as "perfect."
- Missing arsenal data is still excluded rather than replaced with a fake neutral score.
- On today's slate, pregame and already-started games use separate Top Arsenal pools so live-game review cannot crowd tonight's best pregame matches out of the filter.
- Parlay Lab now uses **Top Arsenal** as a relative top-match filter too. It can still be combined with Hot Now, Heating Up, Pure Power, Matchup Edge, or Balanced.

## Why
The previous strict version could honestly return zero names on a slate where nobody cleared the absolute threshold. That was too restrictive for the user's goal. v0.16.2 always answers the more useful question: **who has the best pitch-arsenal matchup available today?**
