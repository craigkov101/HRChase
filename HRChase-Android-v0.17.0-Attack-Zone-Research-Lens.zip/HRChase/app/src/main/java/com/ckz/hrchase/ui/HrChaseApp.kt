package com.ckz.hrchase.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Casino
import androidx.compose.material.icons.outlined.SportsBaseball
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.activity.compose.BackHandler
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ckz.hrchase.AppUiState
import com.ckz.hrchase.MainViewModel
import com.ckz.hrchase.ParlayFocus
import com.ckz.hrchase.data.AaaSluggerProspect
import com.ckz.hrchase.data.BattedBall
import com.ckz.hrchase.data.BatterVsPitcherStats
import com.ckz.hrchase.data.GameInfo
import com.ckz.hrchase.data.HitterCandidate
import com.ckz.hrchase.data.MatchupConvergenceProfile
import com.ckz.hrchase.data.MustHaveMetrics
import com.ckz.hrchase.data.PostgameReview
import com.ckz.hrchase.data.PickType
import com.ckz.hrchase.data.PreviousNightSummary
import com.ckz.hrchase.data.ModelLearningProfile
import com.ckz.hrchase.data.NightPatternProfile
import com.ckz.hrchase.data.SameDayPatternProfile
import com.ckz.hrchase.data.RecentHittingStats
import com.ckz.hrchase.data.ResearchLensScore
import com.ckz.hrchase.data.PitcherProfile
import com.ckz.hrchase.data.PitcherStrikeoutPrediction
import com.ckz.hrchase.data.PersonRef
import com.ckz.hrchase.data.TeamRef
import com.ckz.hrchase.model.HrScoringModel
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

private val AppBackground = Color(0xFF050A12)
private val AppBackgroundTop = Color(0xFF07111F)
private val AppSurface = Color(0xFF0B1320)
private val AppSurfaceRaised = Color(0xFF101C2D)
private val AppSurfaceSoft = Color(0xFF0D1726)
private val AppOutline = Color(0xFF1C2B3D)
private val AppPrimary = Color(0xFF49C8FF)
private val AppViolet = Color(0xFF8B7CFF)
private val AppGreen = Color(0xFF2FE6A6)
private val AppAmber = Color(0xFFFFB547)
private val AppRed = Color(0xFFFF637D)
private val AppMuted = Color(0xFF8194AA)
private val AppText = Color(0xFFF6FAFF)
private val AppSubtleText = Color(0xFFC7D4E2)
private val AppGlow = Color(0xFF80E2FF)

private val HrChaseColors = darkColorScheme(
    primary = AppPrimary,
    onPrimary = Color(0xFF03131E),
    secondary = AppViolet,
    tertiary = AppGreen,
    background = AppBackground,
    onBackground = AppText,
    surface = AppSurface,
    onSurface = AppText,
    surfaceVariant = AppSurfaceRaised,
    onSurfaceVariant = Color(0xFFC4D2DF),
    outline = AppOutline,
    error = AppRed
)

private enum class Tab { GAMES, TARGETS, STRIKEOUTS, HEATING, HOT, PARLAYS, AAA, TRACKED }

private data class GameAlert(
    val title: String,
    val detail: String,
    val color: Color
)


private data class PowerMetricSignal(
    val label: String,
    val display: String,
    val quality: Double
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HrChaseApp(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var tab by remember { mutableIntStateOf(0) }
    val selected = remember(
        state.selectedPlayerId,
        state.selectedProfileCandidate,
        state.selectedProfileDate,
        state.selectedDate,
        state.board?.lastUpdated
    ) {
        val id = state.selectedPlayerId
        val saved = state.selectedProfileCandidate
        val live = id?.let { playerId ->
            state.board?.takeIf { it.date == state.selectedProfileDate }
                ?.candidates
                ?.firstOrNull { it.player.id == playerId }
        }
        when {
            live != null && saved != null -> live.copy(
                vsPitcherStats = saved.vsPitcherStats ?: live.vsPitcherStats,
                pitchArsenalMatch = live.pitchArsenalMatch ?: saved.pitchArsenalMatch
            )
            live != null -> live
            else -> saved ?: id?.let { playerId -> state.board?.candidates?.firstOrNull { it.player.id == playerId } }
        }
    }
    val profileOpen = state.selectedPlayerId != null
    val aaaProfileOpen = state.selectedAaaProspect != null

    BackHandler(enabled = aaaProfileOpen) {
        viewModel.selectAaaProspect(null)
    }
    BackHandler(enabled = profileOpen && !aaaProfileOpen) {
        viewModel.selectPlayer(null)
    }
    BackHandler(enabled = !profileOpen && !aaaProfileOpen && tab != 0) {
        tab = 0
    }

    MaterialTheme(colorScheme = HrChaseColors) {
        CompositionLocalProvider(LocalContentColor provides AppText) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(AppBackgroundTop, AppBackground)))
            ) {
                if (aaaProfileOpen) {
                    AaaProspectProfileScreen(
                        prospect = state.selectedAaaProspect!!,
                        onBack = { viewModel.selectAaaProspect(null) }
                    )
                } else if (profileOpen) {
                    if (selected != null) {
                        val profileDate = state.selectedProfileDate ?: state.selectedDate
                        PlayerDetailScreen(
                            candidate = selected,
                            profileDate = profileDate,
                            pickScore = viewModel.pickScore(selected),
                            signalScore = viewModel.signalLensScore(selected),
                            signalTier = viewModel.signalTier(selected),
                            signalReasons = viewModel.signalReasons(selected),
                            swingMissScore = viewModel.swingMissScore(selected),
                            teamDepthScore = viewModel.teamBarrelDepthScore(selected),
                            matchupConvergence = viewModel.arsenalHandednessConvergence(selected),
                            researchLens = viewModel.researchLens(selected),
                            bvpLoading = state.isProfileBvpLoading,
                            tracked = state.tracked.any { it.playerId == selected.player.id && it.date == profileDate },
                            onBack = { viewModel.selectPlayer(null) },
                            onTrack = { viewModel.toggleTracked(selected, profileDate, PickType.HOME_RUN) }
                        )
                    } else {
                        PlayerProfileLoadingScreen(
                            loading = state.isProfileLoading,
                            error = state.profileError,
                            onBack = { viewModel.selectPlayer(null) }
                        )
                    }
                } else {
                    Scaffold(
                        containerColor = Color.Transparent,
                        topBar = { PremiumHeader(isLoading = state.isLoading) },
                        bottomBar = {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(AppBackgroundTop.copy(alpha = 0.985f))
                                    .navigationBarsPadding()
                            ) {
                                HorizontalDivider(color = AppOutline.copy(alpha = 0.72f), thickness = 1.dp)
                                NavigationBar(
                                    containerColor = Color.Transparent,
                                    tonalElevation = 0.dp,
                                    modifier = Modifier.fillMaxWidth().height(64.dp)
                                ) {
                                    NavigationBarItem(
                                        selected = tab == 0,
                                        onClick = { tab = 0 },
                                        icon = { Icon(Icons.Outlined.SportsBaseball, null, modifier = Modifier.size(22.dp)) },
                                        label = { Text("Games", fontWeight = FontWeight.SemiBold, fontSize = 9.sp) },
                                        colors = navColors()
                                    )
                                    NavigationBarItem(
                                        selected = tab == 1,
                                        onClick = { tab = 1 },
                                        icon = { Icon(Icons.Default.Star, null, modifier = Modifier.size(22.dp)) },
                                        label = { Text("Picks", fontWeight = FontWeight.SemiBold, fontSize = 9.sp) },
                                        colors = navColors()
                                    )
                                    NavigationBarItem(
                                        selected = tab == 2,
                                        onClick = { tab = 2 },
                                        icon = { Icon(Icons.Outlined.SportsBaseball, null, modifier = Modifier.size(21.dp)) },
                                        label = { Text("Ks", fontWeight = FontWeight.SemiBold, fontSize = 9.sp) },
                                        colors = navColors()
                                    )
                                    NavigationBarItem(
                                        selected = tab == 3,
                                        onClick = { tab = 3 },
                                        icon = { Icon(Icons.Default.TrendingUp, null, modifier = Modifier.size(21.dp)) },
                                        label = { Text("Heating", fontWeight = FontWeight.SemiBold, fontSize = 8.sp) },
                                        colors = navColors()
                                    )
                                    NavigationBarItem(
                                        selected = tab == 4,
                                        onClick = { tab = 4 },
                                        icon = { Icon(Icons.Default.LocalFireDepartment, null, modifier = Modifier.size(22.dp)) },
                                        label = { Text("Hot", fontWeight = FontWeight.SemiBold, fontSize = 9.sp) },
                                        colors = navColors()
                                    )
                                    NavigationBarItem(
                                        selected = tab == 5,
                                        onClick = { tab = 5 },
                                        icon = { Icon(Icons.Outlined.Casino, null, modifier = Modifier.size(22.dp)) },
                                        label = { Text("Parlays", fontWeight = FontWeight.SemiBold, fontSize = 9.sp) },
                                        colors = navColors()
                                    )
                                    NavigationBarItem(
                                        selected = tab == 6,
                                        onClick = {
                                            tab = 6
                                            viewModel.ensureAaaProspects()
                                        },
                                        icon = { Icon(Icons.Default.Person, null, modifier = Modifier.size(22.dp)) },
                                        label = { Text("AAA", fontWeight = FontWeight.SemiBold, fontSize = 9.sp) },
                                        colors = navColors()
                                    )
                                    NavigationBarItem(
                                        selected = tab == 7,
                                        onClick = { tab = 7 },
                                        icon = { Icon(Icons.Outlined.StarBorder, null, modifier = Modifier.size(22.dp)) },
                                        label = { Text("Tracked", fontWeight = FontWeight.SemiBold, fontSize = 9.sp) },
                                        colors = navColors()
                                    )
                                }
                            }
                        }
                    ) { padding ->
                        PullToRefreshBox(
                            isRefreshing = if (tab == 6) state.isAaaLoading else state.isLoading,
                            onRefresh = {
                                if (tab == 6) viewModel.refreshAaaProspects() else viewModel.refresh()
                            },
                            modifier = Modifier.fillMaxSize()
                        ) {
                            when (tab) {
                                0 -> GamesScreen(state, viewModel, padding)
                                1 -> PicksScreen(state, viewModel, padding)
                                2 -> StrikeoutsScreen(state, viewModel, padding)
                                3 -> HeatingScreen(state, viewModel, padding)
                                4 -> HotScreen(state, viewModel, padding)
                                5 -> ParlaysScreen(state, viewModel, padding)
                                6 -> AaaSluggersScreen(state, viewModel, padding)
                                else -> TrackedScreen(state, viewModel, padding)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PremiumHeader(isLoading: Boolean) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(
                Brush.horizontalGradient(
                    listOf(
                        AppBackgroundTop,
                        Color(0xFF071827),
                        AppBackgroundTop
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 18.dp, end = 12.dp, top = 10.dp, bottom = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(43.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(
                                AppPrimary.copy(alpha = 0.22f),
                                AppViolet.copy(alpha = 0.11f)
                            )
                        )
                    )
                    .border(1.dp, AppPrimary.copy(alpha = 0.35f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Outlined.SportsBaseball,
                    contentDescription = null,
                    tint = AppGlow,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        "HR",
                        color = AppPrimary,
                        fontWeight = FontWeight.Black,
                        fontStyle = FontStyle.Italic,
                        fontSize = 28.sp,
                        letterSpacing = (-0.8).sp,
                        lineHeight = 28.sp
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(
                        "CHASE",
                        color = AppText,
                        fontWeight = FontWeight.Black,
                        fontSize = 23.sp,
                        letterSpacing = 2.0.sp,
                        lineHeight = 26.sp
                    )
                    Spacer(Modifier.width(8.dp))
                    Surface(
                        color = AppViolet.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(50.dp),
                        border = BorderStroke(1.dp, AppViolet.copy(alpha = 0.24f))
                    ) {
                        Text(
                            "MODEL",
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                            color = AppViolet,
                            fontWeight = FontWeight.Black,
                            fontSize = 9.sp,
                            letterSpacing = 0.9.sp
                        )
                    }
                }
                Row(
                    modifier = Modifier.padding(top = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "HOME RUN INTELLIGENCE",
                        color = AppSubtleText,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 9.5.sp,
                        letterSpacing = 1.55.sp
                    )
                    Spacer(Modifier.width(7.dp))
                    Text(
                        "• built by Cxaig",
                        color = AppMuted.copy(alpha = 0.88f),
                        fontWeight = FontWeight.Medium,
                        fontSize = 8.sp,
                        letterSpacing = 0.25.sp
                    )
                }
            }

        }
        if (isLoading) {
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = AppPrimary,
                trackColor = Color.Transparent
            )
        } else {
            HorizontalDivider(color = AppOutline.copy(alpha = 0.55f), thickness = 1.dp)
        }
    }
}

@Composable
private fun SleekPanel(
    modifier: Modifier = Modifier,
    accent: Color = AppPrimary,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(
                        AppSurfaceRaised.copy(alpha = 0.78f),
                        AppSurface.copy(alpha = 0.96f),
                        AppBackgroundTop.copy(alpha = 0.94f)
                    )
                )
            )
            .border(1.dp, accent.copy(alpha = 0.20f), shape)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(2.dp)
                .background(Brush.horizontalGradient(listOf(accent.copy(alpha = 0.70f), Color.Transparent)))
                .align(Alignment.TopCenter)
        )
        content()
    }
}

@Composable
private fun navColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = AppPrimary,
    selectedTextColor = AppText,
    indicatorColor = AppPrimary.copy(alpha = 0.14f),
    unselectedIconColor = AppMuted,
    unselectedTextColor = AppMuted
)

@Composable
private fun GamesScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val board = state.board
    var expandedGamePk by remember(state.selectedDate) { mutableStateOf<Long?>(null) }
    BackHandler(enabled = expandedGamePk != null) {
        expandedGamePk = null
    }
    val eligible = remember(
        board?.lastUpdated, state.selectedDate, state.showRemainingOnly,
        state.officialLineupsOnly, state.eliteArsenalOnly, state.sortMode, state.attackStrongOnly, state.weights
    ) { viewModel.eligibleCandidates(state) }
    val trackedIds = remember(state.tracked, state.selectedDate) {
        state.tracked.asSequence().filter { it.date == state.selectedDate && it.pickType == PickType.HOME_RUN }.map { it.playerId }.toSet()
    }
    val candidatesByGame = remember(eligible) { eligible.groupBy { it.game.gamePk } }
    val candidateGameIds = candidatesByGame.keys
    val games = board?.games.orEmpty()
        .filter { game -> state.isLoading || game.gamePk in candidateGameIds }
        .sortedBy { it.gameDate }

    Column(
        Modifier
            .fillMaxSize()
            .padding(padding)
            .background(Color.Transparent)
    ) {
        DateControls(state, viewModel)
        SimpleFilters(state, viewModel)
        LoadState(state, viewModel)

        if (!state.isLoading && board != null && games.isEmpty()) {
            EmptyState("No games match the current filters.")
        } else if (board == null && state.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AppPrimary)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    ScreenIntro(
                        eyebrow = "TODAY'S SLATE",
                        title = "Best HR spots by game",
                        subtitle = "Tap a matchup to open every available hitter from both teams, ranked by the HR model with pitcher alerts and weather context."
                    )
                }

                if (
                    state.selectedDate == LocalDate.now() &&
                    state.sameDayPattern.startedGames > 0 &&
                    state.sameDayPattern.remainingGames > 0
                ) {
                    item(key = "same-day-pattern-${state.selectedDate}") {
                        SameDayPatternCard(state.sameDayPattern, board?.candidates.orEmpty(), viewModel)
                    }
                }

                board?.previousNight?.takeIf { it.finalGames > 0 }?.let { previous ->
                    item(key = "previous-night-${previous.date}") {
                        LastNightHomeRunsCard(previous, state.learningProfile, state.lastNightPattern, board.candidates, viewModel)
                    }
                }

                items(games, key = { it.gamePk }, contentType = { "game-card" }) { game ->
                    val gameCandidates = candidatesByGame[game.gamePk].orEmpty()
                    val rankedHitters = gameCandidates.sortedByDescending(viewModel::pickScore)
                    val expanded = expandedGamePk == game.gamePk
                    GameCard(
                        game = game,
                        candidates = gameCandidates,
                        topHitters = rankedHitters,
                        viewModel = viewModel,
                        trackedIds = trackedIds,
                        expanded = expanded,
                        onToggle = {
                            expandedGamePk = if (expanded) null else game.gamePk
                        }
                    )
                }

                item {
                    Text(
                        "Rankings are research signals, not guarantees. Home runs remain high-variance events.",
                        style = MaterialTheme.typography.labelSmall,
                        color = AppMuted,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun LastNightHomeRunsCard(
    summary: PreviousNightSummary,
    learning: ModelLearningProfile,
    pattern: NightPatternProfile,
    todayCandidates: List<HitterCandidate>,
    viewModel: MainViewModel
) {
    var expanded by remember(summary.date) { mutableStateOf(false) }
    val visible = if (expanded) summary.homers else summary.homers.take(8)
    val dateLabel = summary.date.format(DateTimeFormatter.ofPattern("MMM d"))

    SleekPanel(
        modifier = Modifier.fillMaxWidth(),
        accent = AppAmber
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(43.dp),
                    shape = CircleShape,
                    color = AppAmber.copy(alpha = 0.13f),
                    border = BorderStroke(1.dp, AppAmber.copy(alpha = 0.32f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Outlined.SportsBaseball, contentDescription = null, tint = AppAmber)
                    }
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "LAST NIGHT • $dateLabel",
                        color = AppAmber,
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.labelLarge,
                        letterSpacing = 0.7.sp
                    )
                    Text(
                        "${summary.totalHomeRuns} home runs",
                        color = AppText,
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text(
                        "${summary.uniqueHitters} hitters across ${summary.finalGames} final games",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }

            if (visible.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                visible.forEachIndexed { index, homer ->
                    if (index > 0) HorizontalDivider(color = AppOutline.copy(alpha = 0.45f))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.openPlayerProfile(homer.playerId, summary.date) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PlayerAvatar(
                            player = PersonRef(homer.playerId, homer.playerName),
                            team = homer.team,
                            size = 34.dp
                        )
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    homer.playerName,
                                    color = AppText,
                                    fontWeight = FontWeight.Black,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                if (homer.homeRuns > 1) {
                                    Surface(
                                        shape = RoundedCornerShape(50.dp),
                                        color = AppAmber.copy(alpha = 0.14f)
                                    ) {
                                        Text(
                                            "${homer.homeRuns} HR",
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                            color = AppAmber,
                                            fontWeight = FontWeight.Black,
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                }
                            }
                            val details = buildList {
                                homer.team?.abbreviation?.let { add(it) }
                                homer.maxExitVelocity?.let { add("${"%.1f".format(it)} mph") }
                                homer.longestDistanceFt?.let { add("${it.roundToInt()} ft") }
                                if (homer.pitchTypes.isNotEmpty()) add(homer.pitchTypes.take(2).joinToString("/"))
                            }.joinToString(" • ")
                            if (details.isNotBlank()) {
                                Text(details, color = AppMuted, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }

                if (summary.homers.size > 8) {
                    TextButton(
                        onClick = { expanded = !expanded },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(if (expanded) "Show less" else "Show all ${summary.homers.size} hitters")
                    }
                }
            }

            HorizontalDivider(color = AppOutline.copy(alpha = 0.55f), modifier = Modifier.padding(vertical = 10.dp))
            Text(
                "WHAT THEY HAD IN COMMON",
                color = AppPrimary,
                fontWeight = FontWeight.Black,
                style = MaterialTheme.typography.labelLarge,
                letterSpacing = 0.55.sp
            )
            Text(
                "Pregame traits shared by last night's HR hitters, plus direct full-profile comparisons against today's bats.",
                color = AppMuted,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 3.dp, bottom = 7.dp)
            )

            if (pattern.isUsable && (pattern.signals.isNotEmpty() || pattern.combinations.isNotEmpty())) {
                if (pattern.combinations.isNotEmpty()) {
                    Text(
                        "TOP COMBINATIONS",
                        color = AppAmber,
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(bottom = 3.dp)
                    )
                    pattern.combinations.take(3).forEach { combo ->
                        val special = combo.key.contains("pitchArsenalFit") && combo.key.contains("platoon")
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    combo.label,
                                    color = if (special) AppAmber else AppText,
                                    fontWeight = FontWeight.Black,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    "${combo.homerCount}/${combo.homerTotal} HR hitters • ${(combo.homerCoverage * 100).roundToInt()}% coverage • ${"%.2f".format(combo.hrRateLift)}× baseline HR rate",
                                    color = AppMuted,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                            if (special) {
                                Surface(
                                    color = AppAmber.copy(alpha = .13f),
                                    shape = RoundedCornerShape(50.dp),
                                    border = BorderStroke(1.dp, AppAmber.copy(alpha = .28f))
                                ) {
                                    Text("A+H", modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp), color = AppAmber, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                    HorizontalDivider(color = AppOutline.copy(alpha = .45f), modifier = Modifier.padding(vertical = 5.dp))
                }
                pattern.signals.take(4).forEach { signal ->
                    val coverage = (signal.homerCoverage * 100.0).roundToInt()
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                signal.label,
                                color = AppText,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                "${signal.homerCount}/${signal.homerTotal} HR hitters • ${coverage}% coverage • ${"%.2f".format(signal.hrRateLift)}× baseline HR rate",
                                color = AppMuted,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                        Text(
                            "+${(signal.homerAverage - signal.fieldAverage).coerceAtLeast(0.0).roundToInt()}",
                            color = if (signal.hrRateLift >= 1.25) AppGreen else AppPrimary,
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
                Text(
                    "Convergence: HR hitters averaged ${"%.1f".format(pattern.homerGreenLightsAverage)} green signals vs ${"%.1f".format(pattern.fieldGreenLightsAverage)} across the full slate.",
                    color = AppMuted,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(top = 3.dp)
                )
                if (pattern.references.isNotEmpty()) {
                    Text(
                        "Profile Echo also compares today's complete 8-signal profile to each actual HR hitter's saved pregame profile. This catches distinct winning archetypes that can disappear inside group averages.",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 5.dp)
                    )
                }

                val todayMatches = remember(todayCandidates, pattern) {
                    todayCandidates.asSequence()
                        .map { it to viewModel.lastNightPatternScore(it) }
                        .filter { (_, score) -> score >= 62.0 }
                        .sortedByDescending { it.second }
                        .take(5)
                        .toList()
                }
                if (todayMatches.isNotEmpty()) {
                    Text(
                        "TODAY'S CLOSEST PATTERN MATCHES",
                        color = AppAmber,
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                    )
                    todayMatches.forEach { (candidate, score) ->
                        val reasons = viewModel.lastNightPatternReasons(candidate)
                        val echoScore = viewModel.lastNightProfileEchoScore(candidate)
                        val closestProfile = viewModel.lastNightClosestProfiles(candidate, 1).firstOrNull()
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.openPlayerProfile(candidate.player.id) }
                                .padding(vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            PlayerAvatar(candidate.player, candidate.team, 30.dp)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    candidate.player.name,
                                    color = AppText,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    buildString {
                                        append(candidate.team.abbreviation)
                                        if (reasons.isNotEmpty()) append(" • ").append(reasons.joinToString(" + "))
                                        if (echoScore > 0.0) append(" • Echo ").append(echoScore.roundToInt())
                                        closestProfile?.let { (name, similarity) ->
                                            append(" • like ").append(name).append(" ").append(similarity)
                                        }
                                    },
                                    color = AppMuted,
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Text(
                                score.roundToInt().toString(),
                                color = if (score >= 80.0) AppGreen else AppPrimary,
                                fontWeight = FontWeight.Black,
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                    }
                    Text(
                        "Pattern Match blends common denominators with Profile Echo. It remains a small next-day ranking layer: yesterday can separate close calls, but it cannot overpower season power, matchup, contact quality or arsenal fit.",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            } else {
                Text(
                    if (pattern.gradedHitters > 0) {
                        "Pattern Lab is collecting a larger same-day sample before using last night's common traits in today's ranking."
                    } else {
                        "Pattern Lab activates after HR Chase has a complete pregame signal snapshot to grade the next morning."
                    },
                    color = AppMuted,
                    style = MaterialTheme.typography.labelSmall
                )
            }

            HorizontalDivider(color = AppOutline.copy(alpha = 0.55f), modifier = Modifier.padding(vertical = 10.dp))
            val learningText = if (learning.isActive) {
                "Outcome learning active • ${learning.resolvedHitterGames} graded hitter-games • ${learning.homeRuns} HR outcomes"
            } else {
                "Learning warm-up • ${learning.resolvedHitterGames} graded hitter-games • ${learning.homeRuns} HR outcomes"
            }
            Text(
                learningText,
                color = if (learning.isActive) AppGreen else AppPrimary,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelMedium
            )
            Text(
                "HR Chase saves the day's pregame signal snapshot, grades it against the next morning's real HR results, and uses the growing history only as a small calibration layer so one noisy night cannot overfit the rankings.",
                color = AppMuted,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
private fun SameDayPatternCard(
    pattern: SameDayPatternProfile,
    todayCandidates: List<HitterCandidate>,
    viewModel: MainViewModel
) {
    val lateMatches = remember(todayCandidates, pattern) {
        if (!pattern.isUsable) emptyList()
        else todayCandidates.asSequence()
            .filter { it.game.status.equals("Preview", true) }
            .map { it to viewModel.sameDayPatternScore(it) }
            .filter { (_, score) -> score >= 58.0 }
            .sortedByDescending { it.second }
            .take(8)
            .toList()
    }

    SleekPanel(
        modifier = Modifier.fillMaxWidth(),
        accent = AppGreen
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(43.dp),
                    shape = CircleShape,
                    color = AppGreen.copy(alpha = 0.13f),
                    border = BorderStroke(1.dp, AppGreen.copy(alpha = 0.32f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Outlined.SportsBaseball, contentDescription = null, tint = AppGreen)
                    }
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "LIVE DAY ECHO",
                        color = AppGreen,
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.labelLarge,
                        letterSpacing = 0.7.sp
                    )
                    Text(
                        if (pattern.totalHomeRuns > 0) "${pattern.totalHomeRuns} HR already today" else "Waiting for today's first HR",
                        color = AppText,
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text(
                        "${pattern.startedGames} games started • ${pattern.remainingGames} still to play",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }

            Text(
                "HR Chase compares the saved pregame profiles of hitters who already homered today with hitters whose games have not started yet. Pull down to refresh as the early slate produces new HR references.",
                color = AppSubtleText,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 10.dp)
            )

            if (pattern.references.isEmpty()) {
                HorizontalDivider(color = AppOutline.copy(alpha = 0.55f), modifier = Modifier.padding(vertical = 10.dp))
                Text(
                    "No same-day homer profile is available yet. As soon as an early-game hitter homers, the late-slate comparison activates automatically on the next refresh.",
                    color = AppMuted,
                    style = MaterialTheme.typography.labelSmall
                )
                return@SleekPanel
            }

            HorizontalDivider(color = AppOutline.copy(alpha = 0.55f), modifier = Modifier.padding(vertical = 10.dp))
            Text(
                "TODAY'S HR REFERENCES",
                color = AppPrimary,
                fontWeight = FontWeight.Black,
                style = MaterialTheme.typography.labelMedium
            )
            pattern.references.take(5).forEach { homer ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.openPlayerProfile(homer.playerId) }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PlayerAvatar(PersonRef(homer.playerId, homer.playerName), homer.team, 30.dp)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            homer.playerName,
                            color = AppText,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val details = buildList {
                            add(homer.team.abbreviation)
                            if (homer.homeRuns > 1) add("${homer.homeRuns} HR")
                            homer.maxExitVelocity?.let { add("${"%.1f".format(it)} mph") }
                            homer.longestDistanceFt?.let { add("${it.roundToInt()} ft") }
                            if (homer.pitchTypes.isNotEmpty()) add(homer.pitchTypes.take(2).joinToString("/"))
                        }.joinToString(" • ")
                        Text(details, color = AppMuted, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            if (pattern.references.size > 5) {
                Text(
                    "+${pattern.references.size - 5} more HR profiles included in the comparison",
                    color = AppMuted,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            if (pattern.sharedSignals.isNotEmpty()) {
                Text(
                    "SHARED EARLY-SLATE SIGNALS",
                    color = AppPrimary,
                    fontWeight = FontWeight.Black,
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(top = 10.dp, bottom = 3.dp)
                )
                pattern.sharedSignals.take(4).forEach { signal ->
                    val coverage = (signal.coverage * 100.0).roundToInt()
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(signal.label, color = AppSubtleText, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        Text(
                            "${signal.homerCount}/${signal.homerTotal} • $coverage%",
                            color = if (coverage >= 75) AppGreen else AppPrimary,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }

            HorizontalDivider(color = AppOutline.copy(alpha = 0.55f), modifier = Modifier.padding(vertical = 10.dp))
            Text(
                "LATE-SLATE PROFILE MATCHES",
                color = AppGreen,
                fontWeight = FontWeight.Black,
                style = MaterialTheme.typography.labelLarge,
                letterSpacing = 0.4.sp
            )

            if (lateMatches.isEmpty()) {
                Text(
                    "No unplayed hitter currently clears the minimum similarity threshold. That is useful too — the model will not force a match just because someone homered earlier.",
                    color = AppMuted,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(top = 5.dp)
                )
            } else {
                lateMatches.forEachIndexed { index, (candidate, score) ->
                    if (index > 0) HorizontalDivider(color = AppOutline.copy(alpha = 0.35f))
                    val reasons = viewModel.sameDayPatternReasons(candidate)
                    val closest = viewModel.sameDayClosestProfiles(candidate, 1).firstOrNull()
                    val time = candidate.game.gameDate.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("h:mm a"))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.openPlayerProfile(candidate.player.id) }
                            .padding(vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "${index + 1}",
                            color = AppMuted,
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.width(20.dp)
                        )
                        PlayerAvatar(candidate.player, candidate.team, 32.dp)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                candidate.player.name,
                                color = AppText,
                                fontWeight = FontWeight.Black,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                buildString {
                                    append(candidate.team.abbreviation).append(" • ").append(time)
                                    closest?.let { (name, similarity) ->
                                        append(" • like ").append(name).append(" ").append(similarity)
                                    }
                                },
                                color = AppMuted,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (reasons.isNotEmpty()) {
                                Text(
                                    reasons.joinToString(" + "),
                                    color = AppSubtleText,
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                score.roundToInt().toString(),
                                color = when {
                                    score >= 85.0 -> AppGreen
                                    score >= 72.0 -> AppPrimary
                                    else -> AppAmber
                                },
                                fontWeight = FontWeight.Black,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text("DAY ECHO", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            Text(
                "Live Day Echo is a similarity/tie-breaker layer, not a claim that HRs occur in repeating sequences. It can add at most 2 points to an unplayed hitter's ranking, scaled down when only a small early-game HR sample exists.",
                color = AppMuted,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 9.dp)
            )
        }
    }
}

@Composable
private fun GameCard(
    game: GameInfo,
    candidates: List<HitterCandidate>,
    topHitters: List<HitterCandidate>,
    viewModel: MainViewModel,
    trackedIds: Set<Int>,
    expanded: Boolean,
    onToggle: () -> Unit
) {
    val time = game.gameDate.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("h:mm a"))
    val alerts = remember(game, candidates) { gameAlerts(game, candidates) }
    val avgEnvironment = candidates.map { it.score.environment }.average().takeUnless { it.isNaN() } ?: 50.0

    SleekPanel(
        modifier = Modifier.fillMaxWidth(),
        accent = scoreColor(avgEnvironment.roundToInt())
    ) {
        Column(Modifier.fillMaxWidth()) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onToggle)
                    .padding(16.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    TeamBadge(game.awayTeam)
                    Text("@", color = AppMuted, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp))
                    TeamBadge(game.homeTeam)
                    Spacer(Modifier.weight(1f))
                    EnvironmentBadge(avgEnvironment)
                }

                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(time, color = AppText, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                    Text(
                        game.venueName,
                        color = AppMuted,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).padding(start = 12.dp)
                    )
                }

                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = AppPrimary.copy(alpha = 0.10f),
                        shape = RoundedCornerShape(50.dp),
                        border = BorderStroke(1.dp, AppPrimary.copy(alpha = 0.18f))
                    ) {
                        Text(
                            "${topHitters.size} RANKED HR LOOKS",
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                            color = AppPrimary,
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.labelSmall,
                            letterSpacing = 0.4.sp
                        )
                    }
                    if (alerts.isNotEmpty()) {
                        Spacer(Modifier.width(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = null,
                                tint = AppAmber,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(
                                "${alerts.size} alert${if (alerts.size == 1) "" else "s"}",
                                color = AppAmber,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Text(
                        if (expanded) "CLOSE" else "VIEW ALL",
                        color = if (expanded) AppMuted else AppText,
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.labelMedium,
                        letterSpacing = 0.4.sp
                    )
                }
            }

            if (expanded) {
                HorizontalDivider(color = AppOutline.copy(alpha = 0.70f))
                Column(Modifier.padding(horizontal = 16.dp, vertical = 13.dp)) {
                    if (alerts.isNotEmpty()) {
                        alerts.forEach { alert -> AlertRow(alert) }
                        Spacer(Modifier.height(10.dp))
                    }

                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "ALL RANKED HITTERS",
                            fontWeight = FontWeight.Black,
                            color = AppText,
                            letterSpacing = 0.7.sp,
                            style = MaterialTheme.typography.labelLarge
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Every available hitter from both teams",
                            color = AppMuted,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                    Spacer(Modifier.height(7.dp))

                    if (topHitters.isEmpty()) {
                        Text("Lineup data is not available yet.", color = AppMuted, style = MaterialTheme.typography.bodySmall)
                    } else {
                        topHitters.forEachIndexed { index, candidate ->
                            if (index > 0) {
                                HorizontalDivider(
                                    color = AppOutline.copy(alpha = 0.55f),
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            }
                            GameHitterRow(
                                rank = index + 1,
                                candidate = candidate,
                                score = viewModel.pickScore(candidate),
                                tracked = candidate.player.id in trackedIds,
                                onOpen = { viewModel.openPlayerProfile(candidate.player.id) },
                                onTrack = { viewModel.toggleTracked(candidate) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TeamBadge(team: TeamRef) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 3.dp)
    ) {
        TeamLogo(team = team, size = 27.dp)
        Spacer(Modifier.width(7.dp))
        Text(
            team.abbreviation,
            fontWeight = FontWeight.Black,
            color = AppText,
            fontSize = 18.sp,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
private fun TeamLogo(
    team: TeamRef,
    size: androidx.compose.ui.unit.Dp = 22.dp,
    container: Boolean = false
) {
    val logoUrl = "https://www.mlbstatic.com/team-logos/${team.id}.svg"
    val shape = RoundedCornerShape((size.value * 0.30f).dp)
    Box(
        modifier = Modifier
            .size(size)
            .then(
                if (container) {
                    Modifier
                        .clip(shape)
                        .background(AppSurfaceRaised.copy(alpha = 0.72f))
                        .padding(1.dp)
                } else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = logoUrl,
            contentDescription = "${team.name} logo",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Fit
        )
    }
}


@Composable
private fun PlayerAvatar(
    player: PersonRef,
    team: TeamRef?,
    size: androidx.compose.ui.unit.Dp = 32.dp
) {
    var imageFailed by remember(player.id) { mutableStateOf(false) }
    val headshotUrl = "https://img.mlbstatic.com/mlb-photos/image/upload/w_96,q_auto:best/v1/people/${player.id}/headshot/67/current"
    val badgeSize = (size.value * 0.42f).dp

    Box(modifier = Modifier.size(size), contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(AppSurfaceRaised)
                .border(1.dp, AppOutline, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (!imageFailed) {
                AsyncImage(
                    model = headshotUrl,
                    contentDescription = "${player.name} headshot",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    onError = { imageFailed = true }
                )
            } else if (team != null) {
                TeamLogo(team = team, size = (size.value * 0.62f).dp)
            } else {
                Icon(
                    Icons.Default.Person,
                    contentDescription = null,
                    tint = AppMuted,
                    modifier = Modifier.size((size.value * 0.58f).dp)
                )
            }
        }

        if (team != null && !imageFailed && size.value >= 28f) {
            Surface(
                modifier = Modifier.size(badgeSize).align(Alignment.BottomEnd),
                shape = CircleShape,
                color = AppBackground,
                border = BorderStroke(1.dp, AppOutline)
            ) {
                Box(Modifier.padding(1.dp), contentAlignment = Alignment.Center) {
                    TeamLogo(team = team, size = (badgeSize.value * 0.78f).dp)
                }
            }
        }
    }
}

@Composable
private fun GameHitterRow(
    rank: Int,
    candidate: HitterCandidate,
    score: Double,
    tracked: Boolean,
    onOpen: () -> Unit,
    onTrack: () -> Unit
) {
    val scoreInt = score.roundToInt()
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
            .padding(vertical = 5.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                modifier = Modifier.size(46.dp),
                shape = RoundedCornerShape(13.dp),
                color = scoreColor(scoreInt).copy(alpha = 0.13f),
                border = BorderStroke(1.dp, scoreColor(scoreInt).copy(alpha = 0.35f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(scoreInt.toString(), fontWeight = FontWeight.Black, color = scoreColor(scoreInt))
                        Text("PICK", style = MaterialTheme.typography.labelSmall, color = AppMuted)
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PlayerAvatar(candidate.player, candidate.team, size = 32.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "#$rank  ${candidate.player.name}",
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                }
                Text(
                    "${candidate.team.abbreviation} • Batting #${candidate.battingOrder} • vs ${candidate.opponentPitcher?.person?.name ?: "TBD"}",
                    color = AppMuted,
                    style = MaterialTheme.typography.labelMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onTrack) {
                Icon(
                    if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder,
                    contentDescription = "Track",
                    tint = if (tracked) AppAmber else AppMuted
                )
            }
        }

        Text(
            quickJustification(candidate),
            modifier = Modifier.padding(start = 56.dp, end = 4.dp),
            color = Color(0xFFD3E0EA),
            style = MaterialTheme.typography.bodySmall
        )
        candidate.vsPitcherStats?.let { bvp ->
            Text(
                bvpSummary(bvp),
                modifier = Modifier.padding(start = 56.dp, end = 4.dp, top = 3.dp),
                color = bvpColor(bvp),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold
            )
        }
        candidate.score.notes.firstOrNull()?.let { note ->
            Text(
                note,
                modifier = Modifier.padding(start = 56.dp, end = 4.dp, top = 2.dp),
                color = AppMuted,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun EnvironmentBadge(value: Double) {
    val label = when {
        value >= 72 -> "HR+"
        value < 40 -> "HR−"
        else -> "NEUTRAL"
    }
    val color = when {
        value >= 72 -> AppGreen
        value < 40 -> AppAmber
        else -> AppMuted
    }
    Surface(color = color.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp), border = BorderStroke(1.dp, color.copy(alpha = 0.30f))) {
        Text(label, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = color, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun AlertRow(alert: GameAlert) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(bottom = 5.dp),
        color = alert.color.copy(alpha = 0.09f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, alert.color.copy(alpha = 0.24f))
    ) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Warning, null, tint = alert.color, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Column {
                Text(alert.title, color = alert.color, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                Text(alert.detail, color = Color(0xFFD3E0EA), style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

private fun gameAlerts(game: GameInfo, candidates: List<HitterCandidate>): List<GameAlert> = buildList {
    val pitchers = candidates.mapNotNull { it.opponentPitcher }.distinctBy { it.person.id }
    pitchers.filter(::isTopPitcher).forEach { pitcher ->
        val bits = listOfNotNull(
            pitcher.seasonStats.era?.let { "${"%.2f".format(it)} ERA" },
            pitcher.seasonStats.hrPer9?.let { "${"%.2f".format(it)} HR/9" }
        ).joinToString(" • ")
        val affectedTeam = candidates.firstOrNull { it.opponentPitcher?.person?.id == pitcher.person.id }?.team?.abbreviation
        val title = affectedTeam?.let { "Tough matchup for $it hitters" } ?: "Pitcher warning"
        add(GameAlert(title, "${pitcher.person.name}${if (bits.isNotBlank()) " • $bits" else ""}", AppAmber))
    }

    val weather = game.weather
    val roofClosed = weather.roofType?.contains("closed", true) == true || weather.condition?.contains("dome", true) == true
    if (!roofClosed) {
        val condition = weather.condition.orEmpty()
        val badCondition = listOf("rain", "storm", "shower", "drizzle", "snow").any { condition.contains(it, true) }
        if (badCondition) {
            add(GameAlert("Weather warning", condition.ifBlank { "Possible precipitation" }, AppRed))
        }

        val wind = weather.wind.orEmpty()
        val mph = Regex("(\\d+)\\s*mph", RegexOption.IGNORE_CASE).find(wind)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
        if (wind.contains("in", true) && mph >= 10) {
            add(GameAlert("Wind warning", "$wind may suppress carry", AppAmber))
        }
        weather.temperatureF?.let { temp ->
            if (temp <= 52) add(GameAlert("Cold-weather warning", "$temp°F can reduce home-run carry", AppAmber))
        }
    }
}

private fun isTopPitcher(pitcher: PitcherProfile): Boolean {
    val stats = pitcher.seasonStats
    if (stats.inningsPitched in 0.0..<20.0) return false
    val era = stats.era
    val hr9 = stats.hrPer9
    return (era != null && hr9 != null && era <= 3.25 && hr9 <= 1.10) ||
        (era != null && era <= 2.80) ||
        (hr9 != null && hr9 <= 0.75)
}

private fun quickJustification(candidate: HitterCandidate): String {
    val p = candidate.score.powerPressure.roundToInt()
    val m = candidate.score.pitcherMatchup.roundToInt()
    val c = candidate.score.recentPower.roundToInt()
    val e = candidate.score.environment.roundToInt()
    val bvp = candidate.vsPitcherStats
    val arsenal = candidate.pitchArsenalMatch
    val perfectArsenalHand = arsenal != null && arsenal.score >= 80.0 && arsenal.confidence >= .42 && candidate.score.platoon >= 70.0
    return when {
        perfectArsenalHand -> {
            val hand = candidate.opponentPitcher?.person?.pitchHand ?: "?"
            "Perfect pitch arsenal + handedness setup: Arsenal ${arsenal!!.score.roundToInt()} • vs ${hand}HP split ${candidate.score.platoon.roundToInt()} • Matchup $m."
        }
        arsenal != null && arsenal.batterHrSample >= 3 && arsenal.confidence >= .30 && arsenal.score >= 72.0 -> {
            val top = arsenal.feastPitches.take(2).joinToString(" + ") { "${it.name} ${it.homeRuns} HR" }
            "Pitch arsenal fit ${arsenal.score.roundToInt()}: $top align with today's pitcher mix. Pressure $p • Matchup $m."
        }
        bvp != null && bvp.plateAppearances >= 8 && ((bvp.ops ?: 0.0) >= .900 || bvp.homeRuns >= 2) ->
            "BvP edge plus current form: ${bvp.hits}-for-${bvp.atBats}, ${bvp.homeRuns} HR vs this pitcher. Pressure $p • Matchup $m."
        candidate.platoonStats != null && candidate.platoonStats.plateAppearances >= 35 && candidate.score.platoon >= 70 -> {
            val hand = candidate.opponentPitcher?.person?.pitchHand ?: "?"
            val splitIso = candidate.platoonStats.iso?.let { String.format("%.3f", it).removePrefix("0") } ?: "—"
            "Strong vs ${hand}HP split: $splitIso ISO • ${candidate.platoonStats.homeRuns} HR in ${candidate.platoonStats.plateAppearances} PA. Matchup $m."
        }
        p >= 72 && m >= 72 -> "Best combo: Power Pressure $p + Matchup $m."
        p >= 75 -> "Power Pressure $p: recent HR-quality contact is building. Matchup $m."
        m >= 75 -> "Matchup $m: favorable opposing-pitcher profile. Recent contact $c."
        c >= 75 -> "Recent contact $c is hot; matchup $m keeps him in play."
        e >= 75 -> "Strong park/weather spot ($e) with a balanced hitter profile."
        else -> "Balanced profile: Pressure $p • Matchup $m • Contact $c."
    }
}

private fun bvpSummary(bvp: BatterVsPitcherStats): String {
    val avg = bvp.avg?.let { String.format("%.3f", it).removePrefix("0") } ?: "—"
    val ops = bvp.ops?.let { String.format("%.3f", it).removePrefix("0") } ?: "—"
    val sample = if (bvp.plateAppearances < 8) " • small sample" else ""
    return "BvP: ${bvp.hits}-for-${bvp.atBats} ($avg) • ${bvp.homeRuns} HR • $ops OPS$sample"
}

private fun bvpColor(bvp: BatterVsPitcherStats): Color = when {
    bvp.plateAppearances < 5 -> AppMuted
    bvp.homeRuns >= 2 || (bvp.ops ?: 0.0) >= .950 -> AppGreen
    (bvp.ops ?: 0.0) < .600 && bvp.plateAppearances >= 8 -> AppAmber
    else -> Color(0xFFD3E0EA)
}

@Composable
private fun PicksScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    TargetsScreen(state, viewModel, padding)
}

@Composable
private fun TargetsScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val board = state.board
    val targets = remember(
        board?.lastUpdated, state.selectedDate, state.showRemainingOnly,
        state.officialLineupsOnly, state.eliteArsenalOnly, state.sortMode, state.attackStrongOnly, state.weights,
        state.learningProfile, state.lastNightPattern, state.sameDayPattern
    ) { viewModel.topTargets(15, state) }
    val trackedIds = remember(state.tracked, state.selectedDate) {
        state.tracked.asSequence().filter { it.date == state.selectedDate && it.pickType == PickType.HOME_RUN }.map { it.playerId }.toSet()
    }
    val reviewingYesterday = state.selectedDate == LocalDate.now().minusDays(1)
    val perfectFits = remember(targets, state.learningProfile) {
        targets.filter { viewModel.arsenalHandednessConvergence(it).isPerfectFit }.take(4)
    }

    LaunchedEffect(state.selectedDate, board?.lastUpdated) {
        if (reviewingYesterday && board != null) viewModel.loadPostgameTargetStats()
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(padding)
            .background(Color.Transparent)
    ) {
        DateControls(state, viewModel)
        SimpleFilters(state, viewModel)
        LoadState(state, viewModel)

        if (board == null && state.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AppPrimary)
            }
        } else if (!state.isLoading && board != null && targets.isEmpty()) {
            EmptyState("No eligible hitters are available for the current filters.")
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    ScreenIntro(
                        eyebrow = "DAILY TARGET BOARD",
                        title = "Top 15 HR targets",
                        subtitle = if (reviewingYesterday)
                            "Yesterday's target board with a postgame diagnosis explaining hits, near-misses, matchup-driven misses and genuinely poor nights."
                        else
                            "Pattern-first HR targets: stable power foundation + learned signal combinations + tonight-specific triggers."
                    )
                }

                if (perfectFits.isNotEmpty() && !reviewingYesterday) {
                    item {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .background(AppAmber.copy(alpha = .08f))
                                .border(1.dp, AppAmber.copy(alpha = .25f), RoundedCornerShape(20.dp))
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                Text("PERFECT ARSENAL + HAND FITS", color = AppAmber, fontWeight = FontWeight.Black, letterSpacing = .6.sp, style = MaterialTheme.typography.labelLarge)
                                Text(
                                    "These hitters clear both the pitch-type fit and handedness thresholds with enough evidence. They still need the power/contact foundation to rank highly.",
                                    color = AppMuted,
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(top = 3.dp, bottom = 6.dp)
                                )
                                perfectFits.forEachIndexed { index, candidate ->
                                    if (index > 0) HorizontalDivider(color = AppOutline.copy(alpha = .45f))
                                    val convergence = viewModel.arsenalHandednessConvergence(candidate)
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .clickable { viewModel.openPlayerProfile(candidate.player.id) }
                                            .padding(vertical = 7.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        PlayerAvatar(candidate.player, candidate.team, size = 30.dp)
                                        Spacer(Modifier.width(8.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(candidate.player.name, color = AppText, fontWeight = FontWeight.Black)
                                            Text(
                                                "${candidate.team.abbreviation} • Arsenal ${convergence.arsenalScore?.roundToInt() ?: 0} • Hand ${convergence.platoonScore.roundToInt()} • Target ${viewModel.targetScore(candidate).roundToInt()}",
                                                color = AppMuted,
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        }
                                        Text(convergence.score.roundToInt().toString(), color = AppAmber, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(22.dp))
                            .background(AppGreen.copy(alpha = 0.08f))
                            .border(1.dp, AppGreen.copy(alpha = 0.24f), RoundedCornerShape(22.dp))
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = AppGreen.copy(alpha = 0.13f),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, AppGreen.copy(alpha = 0.28f))
                                ) {
                                    Text(
                                        "V2",
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                        color = AppGreen,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("Pattern Engine", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        if (state.learningProfile.isActive)
                                            "Learning from ${state.learningProfile.resolvedHitterGames} pregame hitter profiles • ${state.learningProfile.homeRuns} HR outcomes"
                                        else
                                            "Building a clean pregame outcome sample • ${state.learningProfile.resolvedHitterGames} hitter profiles so far",
                                        color = AppMuted,
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                }
                            }
                            Text(
                                "The board now ranks combinations of signals that repeatedly appear before actual home runs, instead of simply adding every good-looking stat together.",
                                color = AppSubtleText,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(top = 10.dp)
                            )
                            val arsenalHandRule = state.learningProfile.patterns.firstOrNull {
                                it.key == "pitchArsenalFit+platoon"
                            }
                            Surface(
                                modifier = Modifier.fillMaxWidth().padding(top = 9.dp),
                                color = AppAmber.copy(alpha = .08f),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, AppAmber.copy(alpha = .22f))
                            ) {
                                Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                                    Text("FOCUS: ARSENAL + HANDEDNESS", color = AppAmber, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelMedium)
                                    Text(
                                        if (arsenalHandRule != null)
                                            "Historical pair: ${"%.2f".format(arsenalHandRule.posteriorLift)}× learned HR lift • n=${arsenalHandRule.attempts}. The model only boosts it when both sides clear their thresholds."
                                        else
                                            "Now tracked as a dedicated interaction. A high arsenal score alone is not enough; the batter also needs the handedness split and a real power foundation.",
                                        color = AppMuted,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(top = 3.dp)
                                    )
                                }
                            }
                            val learned = state.learningProfile.patterns
                                .filter { it.posteriorLift >= 1.05 }
                                .sortedByDescending { (it.posteriorLift - 1.0) * it.reliability }
                                .take(3)
                            if (learned.isNotEmpty()) {
                                Spacer(Modifier.height(8.dp))
                                learned.forEach { rule ->
                                    Text(
                                        "• ${rule.label}: ${"%.2f".format(rule.posteriorLift)}x learned HR lift • n=${rule.attempts}",
                                        color = AppGreen,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(top = 2.dp)
                                    )
                                }
                            } else {
                                Text(
                                    "Early mode uses structural convergence with heavy shrinkage until enough outcomes are collected.",
                                    color = AppMuted,
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(top = 7.dp)
                                )
                            }
                        }
                    }
                }

                item {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(22.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(AppPrimary.copy(alpha = 0.16f), AppViolet.copy(alpha = 0.11f), AppSurface)
                                )
                            )
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = AppPrimary.copy(alpha = 0.14f),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, AppPrimary.copy(alpha = 0.28f))
                                ) {
                                    Text("10", modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp), color = AppPrimary, fontWeight = FontWeight.Black)
                                }
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text("Power Profile", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                                    Text("Ten must-have HR signals", color = AppMuted, style = MaterialTheme.typography.labelMedium)
                                }
                            }
                            Text(
                                "Barrel • Pull Barrel • Pull Air • Hard Hit • Distance • EV • ISO • Fly Ball • Pull • Blast",
                                color = AppSubtleText,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(top = 11.dp)
                            )
                        }
                    }
                }

                item {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(AppViolet.copy(alpha = 0.09f))
                            .border(1.dp, AppViolet.copy(alpha = 0.24f), RoundedCornerShape(20.dp))
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text("POWER SIGNAL LENS", color = AppViolet, fontWeight = FontWeight.Black, letterSpacing = 0.8.sp, style = MaterialTheme.typography.labelLarge)
                            Text(
                                "Hitter-first form • barrel/hard-hit/air quality • recent swing-and-miss • pitcher resistance • platoon edge • lineup barrel depth.",
                                color = AppSubtleText,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(top = 5.dp)
                            )
                            Text(
                                "A convergence layer combining recent form, batted-ball quality, swing-and-miss, pitcher resistance, platoon context and lineup power.",
                                color = AppMuted,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(top = 5.dp)
                            )
                        }
                    }
                }

                itemsIndexed(
                    targets,
                    key = { _, candidate -> "target-${candidate.game.gamePk}-${candidate.player.id}" },
                    contentType = { _, _ -> "target-card" }
                ) { index, candidate ->
                    val rank = index + 1
                    val metrics = viewModel.mustHaveMetrics(candidate)
                    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        TargetCard(
                            rank = rank,
                            candidate = candidate,
                            targetScore = viewModel.targetScore(candidate),
                            powerProfileScore = viewModel.mustHavePowerScore(candidate),
                            patternScore = viewModel.patternEngineScore(candidate),
                            patternReasons = viewModel.patternEngineReasons(candidate),
                            matchupConvergence = viewModel.arsenalHandednessConvergence(candidate),
                            researchLens = viewModel.researchLens(candidate),
                            signalScore = viewModel.signalLensScore(candidate),
                            signalTier = viewModel.signalTier(candidate),
                            signalReasons = viewModel.signalReasons(candidate),
                            whiffRate = viewModel.recentWhiffRate(candidate),
                            swingSample = candidate.recentPlateDiscipline.swings,
                            metrics = metrics,
                            tracked = candidate.player.id in trackedIds,
                            onOpen = { viewModel.openPlayerProfile(candidate.player.id) },
                            onTrack = { viewModel.toggleTracked(candidate) }
                        )
                        if (reviewingYesterday && candidate.game.status.equals("Final", ignoreCase = true)) {
                            val stats = state.postgameStats[candidate.player.id]
                            val loading = candidate.player.id in state.postgameStatsLoading
                            PostgameReviewCard(
                                review = if (!loading) viewModel.postgameReview(candidate, stats) else null,
                                loading = loading
                            )
                        }
                    }
                }

                item {
                    Text(
                        "Power metrics use recent MLB tracked batted balls plus season ISO. Pull-based rates use MLB hit locations/spray coordinates (description fallback), and Blast% is a 105+ mph / 15–35° proxy. Small samples are automatically blended toward season power.",
                        style = MaterialTheme.typography.labelSmall,
                        color = AppMuted,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PostgameReviewCard(review: PostgameReview?, loading: Boolean) {
    val accent = when {
        review == null -> AppMuted
        "MODEL HIT" in review.label || "GOOD READ" in review.label -> AppGreen
        "GOOD NIGHT" in review.label || "BARREL" in review.label || "HARD CONTACT" in review.label -> AppPrimary
        "MATCHUP" in review.label -> AppAmber
        else -> AppRed
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.07f)),
        shape = RoundedCornerShape(17.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.28f))
    ) {
        Column(Modifier.padding(horizontal = 13.dp, vertical = 11.dp)) {
            Text("POSTGAME REVIEW", color = accent, fontWeight = FontWeight.Black, letterSpacing = 0.7.sp, style = MaterialTheme.typography.labelSmall)
            if (loading) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 7.dp)) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = AppPrimary)
                    Spacer(Modifier.width(8.dp))
                    Text("Loading final game line…", color = AppMuted, style = MaterialTheme.typography.bodySmall)
                }
            } else if (review != null) {
                Text(review.label, color = accent, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 5.dp))
                Text(review.resultLine, color = AppSubtleText, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
                Text(review.explanation, color = AppMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 5.dp))
            } else {
                Text("Final game line unavailable.", color = AppMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}

@Composable
private fun TargetCard(
    rank: Int,
    candidate: HitterCandidate,
    targetScore: Double,
    powerProfileScore: Double,
    patternScore: Double,
    patternReasons: List<String>,
    matchupConvergence: MatchupConvergenceProfile,
    researchLens: ResearchLensScore,
    signalScore: Double,
    signalTier: String,
    signalReasons: List<String>,
    whiffRate: Double?,
    swingSample: Int,
    metrics: MustHaveMetrics,
    tracked: Boolean,
    onOpen: () -> Unit,
    onTrack: () -> Unit
) {
    val target = targetScore.roundToInt()
    val profile = powerProfileScore.roundToInt()
    val pattern = patternScore.roundToInt()
    val signal = signalScore.roundToInt()
    val signals = powerMetricSignals(metrics).take(3)
    val convergence = matchupConvergence.score.roundToInt()
    val corePlay = target >= 76 && pattern >= 70 && profile >= 64

    SleekPanel(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        accent = if (corePlay) AppGreen else AppPrimary.copy(alpha = 0.72f)
    ) {
        Column(Modifier.padding(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    color = scoreColor(target).copy(alpha = 0.13f),
                    border = BorderStroke(1.dp, scoreColor(target).copy(alpha = 0.35f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(target.toString(), fontWeight = FontWeight.Black, color = scoreColor(target))
                            Text("TARGET", style = MaterialTheme.typography.labelSmall, color = AppMuted)
                        }
                    }
                }

                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PlayerAvatar(candidate.player, candidate.team, size = 34.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "#$rank  ${candidate.player.name}",
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        if (corePlay) {
                            Surface(color = AppGreen.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp)) {
                                Text("CORE", modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp), color = AppGreen, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        if (matchupConvergence.isPerfectFit) {
                            Spacer(Modifier.width(5.dp))
                            Surface(
                                color = AppAmber.copy(alpha = 0.14f),
                                shape = RoundedCornerShape(50.dp),
                                border = BorderStroke(1.dp, AppAmber.copy(alpha = 0.30f))
                            ) {
                                Text(
                                    "PERFECT FIT",
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                                    color = AppAmber,
                                    fontWeight = FontWeight.Black,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                    Text(
                        "${candidate.team.abbreviation} • Batting #${candidate.battingOrder} • vs ${candidate.opponentPitcher?.person?.name ?: "TBD"}",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onTrack) {
                    Icon(
                        if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder,
                        contentDescription = "Track",
                        tint = if (tracked) AppAmber else AppMuted
                    )
                }
            }

            Spacer(Modifier.height(7.dp))
            Text(
                targetReason(candidate, profile),
                color = Color(0xFFD3E0EA),
                style = MaterialTheme.typography.bodySmall
            )

            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                MiniScorePill("MATCH", researchLens.match.roundToInt(), Modifier.weight(1f))
                MiniScorePill("PROCESS", researchLens.processTest.roundToInt(), Modifier.weight(1f))
                MiniScorePill("CEILING", researchLens.ceiling.roundToInt(), Modifier.weight(1f))
                candidate.attackZoneMatch?.takeIf { it.confidence >= .18 }?.let {
                    MiniScorePill("ZONE", it.score.roundToInt(), Modifier.weight(1f))
                }
            }

            if (matchupConvergence.available) {
                val convergenceColor = when {
                    matchupConvergence.isPerfectFit -> AppAmber
                    matchupConvergence.isStrongFit -> AppGreen
                    convergence >= 65 -> AppPrimary
                    else -> AppMuted
                }
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    color = convergenceColor.copy(alpha = 0.09f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, convergenceColor.copy(alpha = 0.24f))
                ) {
                    Row(
                        Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "ARSENAL + HAND $convergence",
                            color = convergenceColor,
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.labelMedium
                        )
                        Spacer(Modifier.width(7.dp))
                        Text(
                            matchupConvergence.label,
                            color = convergenceColor,
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.labelSmall
                        )
                        Spacer(Modifier.weight(1f))
                        matchupConvergence.learnedLift?.let { lift ->
                            if (matchupConvergence.learnedAttempts >= 12) {
                                Text(
                                    "${"%.2f".format(lift)}× learned • n=${matchupConvergence.learnedAttempts}",
                                    color = AppMuted,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.padding(top = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Surface(color = AppViolet.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp), border = BorderStroke(1.dp, AppViolet.copy(alpha = 0.28f))) {
                    Text("SIGNAL $signal • $signalTier", modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp), color = AppViolet, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
                }
                if (whiffRate != null && swingSample >= 6) {
                    Text("Whiff ${"%.1f".format(whiffRate * 100)}% ($swingSample swings)", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                }
            }
            if (signalReasons.isNotEmpty()) {
                Text(
                    signalReasons.joinToString("  •  "),
                    color = AppSubtleText,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 5.dp)
                )
            }

            Row(
                modifier = Modifier.padding(top = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Surface(
                    color = AppGreen.copy(alpha = 0.10f),
                    shape = RoundedCornerShape(50.dp),
                    border = BorderStroke(1.dp, AppGreen.copy(alpha = 0.26f))
                ) {
                    Text(
                        "PATTERN $pattern",
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                        color = AppGreen,
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
                Text(
                    patternReasons.firstOrNull() ?: "No strong multi-signal pattern",
                    color = AppMuted,
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(7.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                MiniScorePill("POWER", profile, Modifier.weight(1f))
                MiniScorePill("PRESSURE", candidate.score.powerPressure.roundToInt(), Modifier.weight(1f))
                MiniScorePill("MATCHUP", candidate.score.pitcherMatchup.roundToInt(), Modifier.weight(1f))
            }

            if (signals.isNotEmpty()) {
                Text(
                    signals.joinToString("  •  ") { "${it.label} ${it.display}" },
                    color = AppPrimary,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            val sampleText = buildString {
                append("${metrics.battedBallCount} recent tracked BBE")
                if (metrics.directionalBattedBallCount > 0) append(" • ${metrics.directionalBattedBallCount} directional")
                append(" • ${(metrics.confidence * 100).roundToInt()}% profile confidence")
            }
            Text(sampleText, color = AppMuted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 4.dp))

            candidate.vsPitcherStats?.let { bvp ->
                if (bvp.plateAppearances >= 5) {
                    Text(
                        bvpSummary(bvp),
                        color = bvpColor(bvp),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun MiniScorePill(label: String, score: Int, modifier: Modifier = Modifier) {
    val color = scoreColor(score)
    Surface(
        modifier = modifier,
        color = color.copy(alpha = 0.10f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.24f))
    ) {
        Column(Modifier.padding(horizontal = 7.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(score.toString(), color = color, fontWeight = FontWeight.Black)
            Text(label, color = AppMuted, style = MaterialTheme.typography.labelSmall, maxLines = 1)
        }
    }
}

private fun targetReason(candidate: HitterCandidate, powerProfile: Int): String {
    val pressure = candidate.score.powerPressure.roundToInt()
    val matchup = candidate.score.pitcherMatchup.roundToInt()
    val bvp = candidate.vsPitcherStats
    val arsenal = candidate.pitchArsenalMatch
    val perfectArsenalHand = arsenal != null && arsenal.score >= 80.0 && arsenal.confidence >= .42 && candidate.score.platoon >= 70.0
    return when {
        perfectArsenalHand && powerProfile >= 60 ->
            "Perfect pitch-type + handedness setup: Arsenal ${arsenal!!.score.roundToInt()} • Handedness ${candidate.score.platoon.roundToInt()} • Power $powerProfile."
        powerProfile >= 75 && pressure >= 70 && matchup >= 70 ->
            "Complete HR profile: must-have power metrics are strong and both Pressure + Matchup clear 70."
        powerProfile >= 78 && matchup >= 68 ->
            "Power-profile standout ($powerProfile) with a supportive pitcher matchup ($matchup)."
        powerProfile >= 75 ->
            "Must-have power profile is carrying the case ($powerProfile), with Pressure $pressure and Matchup $matchup."
        pressure >= 75 && matchup >= 75 ->
            "Pressure + Matchup is the hook ($pressure / $matchup), backed by a playable power profile ($powerProfile)."
        bvp != null && bvp.plateAppearances >= 8 && ((bvp.ops ?: 0.0) >= .900 || bvp.homeRuns >= 2) ->
            "Good current profile plus a meaningful BvP edge: ${bvp.hits}-for-${bvp.atBats}, ${bvp.homeRuns} HR."
        else ->
            "Balanced daily target: Power $powerProfile • Pressure $pressure • Matchup $matchup."
    }
}

private fun powerMetricSignals(metrics: MustHaveMetrics): List<PowerMetricSignal> = buildList {
    fun quality(value: Double, low: Double, high: Double): Double =
        if (high <= low) 50.0 else (((value - low) / (high - low)) * 100.0).coerceIn(0.0, 100.0)

    metrics.barrelPct?.let { add(PowerMetricSignal("Barrel", "${"%.1f".format(it)}%", quality(it, 4.0, 20.0))) }
    metrics.pullBarrelPct?.let { add(PowerMetricSignal("PullBrl", "${"%.1f".format(it)}%", quality(it, 1.0, 10.0))) }
    metrics.pullAirPct?.let { add(PowerMetricSignal("PullAir", "${"%.1f".format(it)}%", quality(it, 6.0, 28.0))) }
    metrics.hardHitPct?.let { add(PowerMetricSignal("HH", "${"%.1f".format(it)}%", quality(it, 28.0, 62.0))) }
    metrics.avgDistanceFt?.let { add(PowerMetricSignal("Dist", "${it.roundToInt()} ft", quality(it, 145.0, 285.0))) }
    metrics.avgExitVelocity?.let { add(PowerMetricSignal("EV", "${"%.1f".format(it)}", quality(it, 84.0, 95.0))) }
    metrics.avgLaunchAngle?.let {
        val q = when {
            it in 16.0..30.0 -> 92.0
            it in 10.0..36.0 -> 72.0
            else -> 40.0
        }
        add(PowerMetricSignal("LA", "${"%.1f".format(it)}°", q))
    }
    metrics.sweetSpotPct?.let { add(PowerMetricSignal("Sweet", "${"%.1f".format(it)}%", quality(it, 18.0, 45.0))) }
    metrics.iso?.let { add(PowerMetricSignal("ISO", String.format("%.3f", it).removePrefix("0"), quality(it, .110, .300))) }
    metrics.flyBallPct?.let { add(PowerMetricSignal("FB", "${"%.1f".format(it)}%", quality(it, 22.0, 48.0))) }
    metrics.pullPct?.let { add(PowerMetricSignal("Pull", "${"%.1f".format(it)}%", quality(it, 28.0, 52.0))) }
    metrics.blastPct?.let { add(PowerMetricSignal("Blast", "${"%.1f".format(it)}%", quality(it, 1.5, 12.0))) }
}.sortedByDescending { it.quality }

@Composable
private fun HeatingScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val board = state.board
    val heating = remember(
        board?.lastUpdated, state.selectedDate, state.showRemainingOnly,
        state.officialLineupsOnly, state.eliteArsenalOnly, state.sortMode, state.attackStrongOnly, state.weights
    ) { viewModel.heatingCandidates(20, state) }
    val trackedIds = remember(state.tracked, state.selectedDate) {
        state.tracked.asSequence().filter { it.date == state.selectedDate && it.pickType == PickType.HOME_RUN }.map { it.playerId }.toSet()
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(padding)
            .background(Color.Transparent)
    ) {
        DateControls(state, viewModel)
        SimpleFilters(state, viewModel)
        LoadState(state, viewModel)

        if (board == null && state.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AppPrimary)
            }
        } else if (!state.isLoading && board != null && heating.isEmpty()) {
            EmptyState("No hitters currently clear the 3-day emerging-heat signal threshold for this slate and filters.")
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    ScreenIntro(
                        eyebrow = "LAST 3 DAYS",
                        title = "Heating up",
                        subtitle = "Catch the bat before the full hot streak becomes obvious. These hitters are showing multiple short-window signals that their contact and results are accelerating."
                    )
                }

                item {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(AppPrimary.copy(alpha = 0.07f))
                            .border(1.dp, AppPrimary.copy(alpha = 0.24f), RoundedCornerShape(20.dp))
                    ) {
                        Row(
                            Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                modifier = Modifier.size(42.dp),
                                shape = CircleShape,
                                color = AppPrimary.copy(alpha = 0.13f)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.TrendingUp, null, tint = AppPrimary)
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("EMERGING HEAT", color = AppPrimary, fontWeight = FontWeight.Black, letterSpacing = 0.7.sp)
                                Text(
                                    "A player needs multiple signals to appear here: improving 3-day production plus evidence such as hard contact, barrels, near-HR misses, low whiff, rising power pressure or a clear acceleration versus his 7-day line.",
                                    color = AppSubtleText,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(top = 3.dp)
                                )
                            }
                        }
                    }
                }

                itemsIndexed(
                    heating,
                    key = { _, candidate -> "heating-${candidate.game.gamePk}-${candidate.player.id}" },
                    contentType = { _, _ -> "heating-card" }
                ) { index, candidate ->
                    val rank = index + 1
                    val stats = viewModel.recentThreeDayStats(candidate, state)
                    if (stats != null) {
                        HeatingHitterCard(
                            rank = rank,
                            candidate = candidate,
                            stats = stats,
                            heatScore = viewModel.heatingScore(candidate, state),
                            targetScore = viewModel.targetScore(candidate),
                            signalCount = viewModel.heatingSignalCount(candidate, state),
                            acceleration = viewModel.heatingAcceleration(candidate, state),
                            reasons = viewModel.heatingReasons(candidate, state),
                            metrics = viewModel.heatingMetrics(candidate, state),
                            tracked = candidate.player.id in trackedIds,
                            onOpen = { viewModel.openPlayerProfile(candidate.player.id) },
                            onTrack = { viewModel.toggleTracked(candidate) }
                        )
                    }
                }

                item {
                    Text(
                        "The Heating board uses only the previous three completed calendar days for its box-score window and filters the already-established hottest streaks so it can focus on emerging form. Short samples are confidence-weighted and require multiple supporting signals.",
                        style = MaterialTheme.typography.labelSmall,
                        color = AppMuted,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun HeatingHitterCard(
    rank: Int,
    candidate: HitterCandidate,
    stats: RecentHittingStats,
    heatScore: Double,
    targetScore: Double,
    signalCount: Int,
    acceleration: Double,
    reasons: List<String>,
    metrics: MustHaveMetrics,
    tracked: Boolean,
    onOpen: () -> Unit,
    onTrack: () -> Unit
) {
    val heatValue = heatScore.roundToInt()
    val targetValue = targetScore.roundToInt()
    val accelValue = acceleration.roundToInt()

    SleekPanel(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        accent = if (rank <= 5) AppPrimary else AppOutline
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(52.dp),
                    shape = RoundedCornerShape(15.dp),
                    color = AppPrimary.copy(alpha = 0.11f),
                    border = BorderStroke(1.dp, AppPrimary.copy(alpha = 0.32f))
                ) {
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(heatValue.toString(), color = AppPrimary, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                        Text("HEAT", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                    }
                }
                Spacer(Modifier.width(10.dp))
                PlayerAvatar(candidate.player, candidate.team, size = 44.dp)
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "#$rank  ${candidate.player.name}",
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        "${candidate.team.abbreviation} • Batting #${candidate.battingOrder} • vs ${candidate.opponentPitcher?.person?.name ?: "TBD"}",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onTrack) {
                    Icon(
                        if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder,
                        contentDescription = "Track",
                        tint = if (tracked) AppAmber else AppMuted
                    )
                }
            }

            Spacer(Modifier.height(11.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                HotStatPill("AVG", stats.avg?.let { "%.3f".format(it).removePrefix("0") } ?: "—", Modifier.weight(1f))
                HotStatPill("OPS", stats.ops?.let { "%.3f".format(it) } ?: "—", Modifier.weight(1f))
                HotStatPill("XBH", stats.extraBaseHits.toString(), Modifier.weight(1f))
                HotStatPill("MAX EV", metrics.maxExitVelocity?.let { "%.1f".format(it) } ?: "—", Modifier.weight(1f))
            }

            Text(
                "${stats.gamesPlayed} G • ${stats.hits}-for-${stats.atBats} • ${stats.runs} R • ${stats.rbi} RBI • ${stats.homeRuns} HR • ${stats.strikeouts} K",
                color = AppSubtleText,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.padding(top = 9.dp)
            )

            if (reasons.isNotEmpty()) {
                Column(Modifier.padding(top = 9.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    reasons.forEach { reason ->
                        Row(verticalAlignment = Alignment.Top) {
                            Text("•", color = AppPrimary, fontWeight = FontWeight.Black)
                            Spacer(Modifier.width(7.dp))
                            Text(reason, color = AppSubtleText, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Surface(
                    color = AppPrimary.copy(alpha = 0.10f),
                    shape = RoundedCornerShape(50.dp),
                    border = BorderStroke(1.dp, AppPrimary.copy(alpha = 0.25f))
                ) {
                    Text(
                        "$signalCount SIGNALS",
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                        color = AppPrimary,
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
                if (accelValue >= 60) {
                    Surface(
                        color = AppGreen.copy(alpha = 0.09f),
                        shape = RoundedCornerShape(50.dp),
                        border = BorderStroke(1.dp, AppGreen.copy(alpha = 0.22f))
                    ) {
                        Text(
                            "ACCEL $accelValue",
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                            color = AppGreen,
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
                Surface(
                    color = scoreColor(targetValue).copy(alpha = 0.10f),
                    shape = RoundedCornerShape(50.dp),
                    border = BorderStroke(1.dp, scoreColor(targetValue).copy(alpha = 0.24f))
                ) {
                    Text(
                        "TODAY $targetValue",
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                        color = scoreColor(targetValue),
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
    }
}

@Composable
private fun HotScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val board = state.board
    val hot = remember(
        board?.lastUpdated, state.selectedDate, state.showRemainingOnly,
        state.officialLineupsOnly, state.eliteArsenalOnly, state.sortMode, state.attackStrongOnly, state.weights
    ) { viewModel.hotCandidates(20, state) }
    val trackedIds = remember(state.tracked, state.selectedDate) {
        state.tracked.asSequence().filter { it.date == state.selectedDate && it.pickType == PickType.HOME_RUN }.map { it.playerId }.toSet()
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(padding)
            .background(Color.Transparent)
    ) {
        DateControls(state, viewModel)
        SimpleFilters(state, viewModel)
        LoadState(state, viewModel)

        if (board == null && state.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AppPrimary)
            }
        } else if (!state.isLoading && board != null && hot.isEmpty()) {
            EmptyState("No seven-day hitter stats are available for the current slate and filters.")
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    ScreenIntro(
                        eyebrow = "LAST 7 DAYS",
                        title = "Who's hot right now",
                        subtitle = "Today's hitters ranked by seven-day production, then checked against contact quality, near-HR pressure and today's matchup."
                    )
                }

                item {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(AppAmber.copy(alpha = 0.08f))
                            .border(1.dp, AppAmber.copy(alpha = 0.24f), RoundedCornerShape(20.dp))
                    ) {
                        Row(
                            Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                modifier = Modifier.size(42.dp),
                                shape = CircleShape,
                                color = AppAmber.copy(alpha = 0.14f)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.LocalFireDepartment, null, tint = AppAmber)
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("HOT STREAK BOARD", color = AppAmber, fontWeight = FontWeight.Black, letterSpacing = 0.7.sp)
                                Text(
                                    "Box-score heat alone isn't enough. We also show recent tracked batted-ball quality and near-home-run misses so you can see whether the streak has underlying power support.",
                                    color = AppSubtleText,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(top = 3.dp)
                                )
                            }
                        }
                    }
                }

                itemsIndexed(
                    hot,
                    key = { _, candidate -> "hot-${candidate.game.gamePk}-${candidate.player.id}" },
                    contentType = { _, _ -> "hot-card" }
                ) { index, candidate ->
                    val rank = index + 1
                    val stats = viewModel.recentWeekStats(candidate, state)
                    if (stats != null) {
                        HotHitterCard(
                            rank = rank,
                            candidate = candidate,
                            stats = stats,
                            hotScore = viewModel.hotStreakScore(candidate, state),
                            targetScore = viewModel.targetScore(candidate),
                            reasons = viewModel.hotStreakReasons(candidate, state),
                            metrics = viewModel.mustHaveMetrics(candidate),
                            tracked = candidate.player.id in trackedIds,
                            onOpen = { viewModel.openPlayerProfile(candidate.player.id) },
                            onTrack = { viewModel.toggleTracked(candidate) }
                        )
                    }
                }

                item {
                    Text(
                        "Seven-day batting stats cover the previous seven completed calendar days. Near-HR and contact-quality notes use the app's recent tracked MLB batted-ball sample and may cover fewer games when feed-loading is limited for performance.",
                        style = MaterialTheme.typography.labelSmall,
                        color = AppMuted,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun HotHitterCard(
    rank: Int,
    candidate: HitterCandidate,
    stats: RecentHittingStats,
    hotScore: Double,
    targetScore: Double,
    reasons: List<String>,
    metrics: MustHaveMetrics,
    tracked: Boolean,
    onOpen: () -> Unit,
    onTrack: () -> Unit
) {
    val hotValue = hotScore.roundToInt()
    val targetValue = targetScore.roundToInt()
    val todayTough = candidate.score.pitcherMatchup < 45.0

    SleekPanel(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        accent = if (rank <= 5) AppAmber else AppOutline
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(52.dp),
                    shape = RoundedCornerShape(15.dp),
                    color = AppAmber.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, AppAmber.copy(alpha = 0.34f))
                ) {
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(hotValue.toString(), color = AppAmber, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                        Text("HOT", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                    }
                }
                Spacer(Modifier.width(10.dp))
                PlayerAvatar(candidate.player, candidate.team, size = 44.dp)
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "#$rank  ${candidate.player.name}",
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        "${candidate.team.abbreviation} • Batting #${candidate.battingOrder} • vs ${candidate.opponentPitcher?.person?.name ?: "TBD"}",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onTrack) {
                    Icon(
                        if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder,
                        contentDescription = "Track",
                        tint = if (tracked) AppAmber else AppMuted
                    )
                }
            }

            Spacer(Modifier.height(11.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                HotStatPill("AVG", stats.avg?.let { "%.3f".format(it).removePrefix("0") } ?: "—", Modifier.weight(1f))
                HotStatPill("OPS", stats.ops?.let { "%.3f".format(it) } ?: "—", Modifier.weight(1f))
                HotStatPill("HR", stats.homeRuns.toString(), Modifier.weight(1f))
                HotStatPill("XBH", stats.extraBaseHits.toString(), Modifier.weight(1f))
            }

            Text(
                "${stats.gamesPlayed} G • ${stats.hits}-for-${stats.atBats} • ${stats.runs} R • ${stats.rbi} RBI • ${stats.walks} BB • ${stats.strikeouts} K",
                color = AppSubtleText,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.padding(top = 9.dp)
            )

            if (reasons.isNotEmpty()) {
                Column(Modifier.padding(top = 9.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    reasons.forEach { reason ->
                        Row(verticalAlignment = Alignment.Top) {
                            Text("•", color = AppAmber, fontWeight = FontWeight.Black)
                            Spacer(Modifier.width(7.dp))
                            Text(reason, color = AppSubtleText, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Surface(
                    color = scoreColor(targetValue).copy(alpha = 0.10f),
                    shape = RoundedCornerShape(50.dp),
                    border = BorderStroke(1.dp, scoreColor(targetValue).copy(alpha = 0.24f))
                ) {
                    Text(
                        "TODAY $targetValue",
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                        color = scoreColor(targetValue),
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
                metrics.maxExitVelocity?.let {
                    Text("Max EV ${"%.1f".format(it)}", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                }
            }

            if (todayTough) {
                Text(
                    "Hot bat, but today's pitcher matchup is tougher than average (${candidate.score.pitcherMatchup.roundToInt()}).",
                    color = AppAmber,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 7.dp)
                )
            }
        }
    }
}

@Composable
private fun HotStatPill(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = AppSurfaceRaised.copy(alpha = 0.62f),
        shape = RoundedCornerShape(9.dp)
    ) {
        Column(Modifier.padding(vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = AppText, fontWeight = FontWeight.Black)
            Text(label, color = AppMuted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun StrikeoutsScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val predictions = remember(
        state.board?.lastUpdated,
        state.selectedDate,
        state.showRemainingOnly,
        state.pitcherStrikeoutLearningProfile
    ) { viewModel.pitcherStrikeoutPredictions(state) }
    val learning = state.pitcherStrikeoutLearningProfile

    Column(Modifier.fillMaxSize().padding(padding).background(Color.Transparent)) {
        DateControls(state, viewModel)
        ScreenIntro(
            eyebrow = "STARTER MATCHUP MODEL",
            title = "Pitcher strikeouts",
            subtitle = "Projected Ks from pitcher ability × opponent K tendency × handedness × arsenal whiffs × workload.",
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
        )

        if (predictions.isEmpty()) {
            EmptyState(
                if (state.isLoading) "Building pitcher strikeout projections…"
                else "No probable starters with enough matchup data are available for this slate yet."
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    SleekPanel(accent = AppPrimary) {
                        Column(Modifier.padding(13.dp)) {
                            Text("K MODEL CALIBRATION", color = AppPrimary, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
                            if (learning.isActive) {
                                Text(
                                    "${learning.resolvedStarts} resolved starts • MAE ${"%.2f".format(learning.meanAbsoluteError)} K • bias ${"%+.2f".format(learning.averageBias)} K",
                                    color = AppSubtleText,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                                learning.buckets.takeLast(3).forEach { bucket ->
                                    Text(
                                        "${bucket.label}: ${"%.2f".format(bucket.averageActual)} actual K avg • ${(bucket.sixPlusRate * 100).roundToInt()}% reached 6+ • n=${bucket.attempts}",
                                        color = AppMuted,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(top = 3.dp)
                                    )
                                }
                            } else {
                                Text(
                                    "Learning starts after 20 resolved starter projections. Until then, the matchup model runs without historical bias correction.",
                                    color = AppMuted,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }
                }
                itemsIndexed(predictions, key = { _, p -> "${p.game.gamePk}-${p.pitcher.id}" }, contentType = { _, _ -> "pitcher-k" }) { index, p ->
                    PitcherStrikeoutCard(index + 1, p)
                }
                item { Spacer(Modifier.height(8.dp)) }
            }
        }
    }
}

@Composable
private fun PitcherStrikeoutCard(rank: Int, prediction: PitcherStrikeoutPrediction) {
    val score = prediction.score.roundToInt()
    val accent = scoreColor(score)
    SleekPanel(accent = accent) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(44.dp),
                    shape = CircleShape,
                    color = accent.copy(alpha = .14f),
                    border = BorderStroke(1.dp, accent.copy(alpha = .38f))
                ) {
                    Box(contentAlignment = Alignment.Center) { Text("#$rank", color = accent, fontWeight = FontWeight.Black) }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(prediction.pitcher.name, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${prediction.team.abbreviation} vs ${prediction.opponent.abbreviation} • ${prediction.game.gameDate.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("h:mm a"))}",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("${"%.1f".format(prediction.projectedStrikeouts)} K", color = accent, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                    Text("${prediction.score.roundToInt()} MODEL", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                }
            }

            Spacer(Modifier.height(10.dp))
            Surface(
                color = AppSurfaceSoft,
                shape = RoundedCornerShape(13.dp),
                border = BorderStroke(1.dp, AppOutline.copy(alpha = .85f))
            ) {
                Column(Modifier.padding(10.dp)) {
                    Text(
                        "Projected range ${"%.1f".format(prediction.projectionLow)}–${"%.1f".format(prediction.projectionHigh)} K • ${(prediction.confidence * 100).roundToInt()}% data confidence • ${"%.1f".format(prediction.projectedBattersFaced)} BF",
                        color = AppSubtleText,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        HotStatPill("PITCHER", prediction.pitcherAbilityScore.roundToInt().toString(), Modifier.weight(1f))
                        HotStatPill("OPP K", prediction.opponentStrikeoutScore.roundToInt().toString(), Modifier.weight(1f))
                        HotStatPill("HAND", prediction.handednessScore.roundToInt().toString(), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        HotStatPill("ARSENAL", prediction.arsenalWhiffScore.roundToInt().toString(), Modifier.weight(1f))
                        HotStatPill("FORM", prediction.recentFormScore.roundToInt().toString(), Modifier.weight(1f))
                        HotStatPill("WORK", prediction.workloadScore.roundToInt().toString(), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        HotStatPill("CMD", prediction.commandScore.roundToInt().toString(), Modifier.weight(1f))
                        HotStatPill("P K%", prediction.seasonStrikeoutRate?.let { "%.1f".format(it * 100) } ?: "—", Modifier.weight(1f))
                        HotStatPill("OPP K%", prediction.opponentStrikeoutRate?.let { "%.1f".format(it * 100) } ?: "—", Modifier.weight(1f))
                    }
                }
            }

            if (prediction.tags.isNotEmpty()) {
                Text(
                    prediction.tags.joinToString(" • "),
                    color = if (prediction.tags.any { "K-PRONE" in it || "ELITE" in it }) AppGreen else AppPrimary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(top = 9.dp)
                )
            }
            prediction.notes.take(3).forEach { note ->
                Text("• $note", color = AppMuted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

@Composable
private fun AaaSluggersScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    LaunchedEffect(Unit) { viewModel.ensureAaaProspects() }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 14.dp,
            end = 14.dp,
            top = padding.calculateTopPadding() + 12.dp,
            bottom = padding.calculateBottomPadding() + 20.dp
        ),
        verticalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        item {
            Column(Modifier.padding(horizontal = 2.dp)) {
                Text(
                    "POTENTIAL AAA SLUGGERS",
                    color = AppPrimary,
                    fontWeight = FontWeight.Black,
                    fontSize = 21.sp,
                    letterSpacing = 0.8.sp
                )
                Text(
                    "Triple-A power bats who could reach MLB before the season ends",
                    color = AppSubtleText,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = AppViolet.copy(alpha = 0.10f),
                    border = BorderStroke(1.dp, AppViolet.copy(alpha = 0.28f))
                ) {
                    Text(
                        "Small curated watchlist • MiLB season, recent form + tracked batted-ball quality refresh automatically. Call-up Watch is a comparative HR Chase grade, not a probability or official promotion prediction.",
                        modifier = Modifier.padding(11.dp),
                        color = AppMuted,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        if (state.isAaaLoading && state.aaaProspects.isEmpty()) {
            item {
                SleekPanel(accent = AppPrimary) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = AppPrimary, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.height(9.dp))
                        Text("Scanning Triple-A power + batted-ball + call-up signals…", color = AppMuted)
                    }
                }
            }
        }

        state.aaaError?.let { error ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = AppRed.copy(alpha = 0.09f)),
                    border = BorderStroke(1.dp, AppRed.copy(alpha = 0.28f))
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text("AAA feed issue", color = AppRed, fontWeight = FontWeight.Black)
                        Text(error, color = AppMuted, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { viewModel.refreshAaaProspects() }, enabled = !state.isAaaLoading) {
                            Text("Retry AAA data")
                        }
                    }
                }
            }
        }

        itemsIndexed(state.aaaProspects, key = { _, prospect -> prospect.player.id }) { index, prospect ->
            AaaProspectCard(
                rank = index + 1,
                prospect = prospect,
                onOpen = { viewModel.selectAaaProspect(prospect) }
            )
        }

        if (!state.isAaaLoading && state.aaaProspects.isEmpty() && state.aaaError == null) {
            item { EmptyCard("No Triple-A watch hitters are available yet. Pull down to refresh.") }
        }
    }
}

@Composable
private fun AaaProspectCard(
    rank: Int,
    prospect: AaaSluggerProspect,
    onOpen: () -> Unit
) {
    val season = prospect.seasonStats
    val recent = prospect.recentStats
    SleekPanel(accent = scoreColor(prospect.sluggerScore)) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onOpen)
                .padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "#$rank",
                    color = AppPrimary,
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp,
                    modifier = Modifier.width(31.dp)
                )
                PlayerAvatar(player = prospect.player, team = null, size = 46.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        prospect.player.name,
                        color = AppText,
                        fontWeight = FontWeight.Black,
                        fontSize = 19.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        listOfNotNull(
                            prospect.mlbOrg,
                            prospect.position,
                            prospect.aaaTeam?.name
                        ).joinToString(" • "),
                        color = AppMuted,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = scoreColor(prospect.sluggerScore).copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, scoreColor(prospect.sluggerScore).copy(alpha = 0.30f))
                ) {
                    Column(
                        Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("${prospect.sluggerScore}", color = scoreColor(prospect.sluggerScore), fontWeight = FontWeight.Black, fontSize = 19.sp)
                        Text("AAA", color = AppMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            Text(prospect.watchLabel, color = AppAmber, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(7.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                AaaMiniStat("HR", season.homeRuns.toString(), Modifier.weight(1f))
                AaaMiniStat("ISO", season.iso?.let { "%.3f".format(it).removePrefix("0") } ?: "—", Modifier.weight(1f))
                AaaMiniStat("OPS", season.ops?.let { "%.3f".format(it) } ?: "—", Modifier.weight(1f))
                AaaMiniStat("21D HR", recent?.homeRuns?.toString() ?: "—", Modifier.weight(1f))
            }

            Spacer(Modifier.height(10.dp))
            AaaSignalRow("Power", prospect.powerScore, AppAmber)
            AaaSignalRow("Recent power", prospect.recentPowerScore, AppGreen)
            prospect.contactScore?.let { AaaSignalRow("Batted-ball", it, AppGlow) }
            AaaSignalRow("MLB readiness", prospect.readinessScore, AppPrimary)
            AaaSignalRow("Call-up watch", prospect.callupWatchScore, AppViolet)

            Spacer(Modifier.height(7.dp))
            Text(
                prospect.watchReason,
                color = AppSubtleText,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(4.dp))
            Text("Tap for AAA slugger profile  ›", color = AppPrimary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun AaaMiniStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = AppText, fontWeight = FontWeight.Black, fontSize = 15.sp)
        Text(label, color = AppMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun AaaSignalRow(label: String, score: Int, color: Color) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = AppMuted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.width(92.dp))
        LinearProgressIndicator(
            progress = { score.coerceIn(0, 100) / 100f },
            modifier = Modifier.weight(1f).height(5.dp).clip(CircleShape),
            color = color,
            trackColor = AppSurfaceRaised
        )
        Spacer(Modifier.width(8.dp))
        Text(score.toString(), color = color, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelMedium, modifier = Modifier.width(28.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AaaProspectProfileScreen(
    prospect: AaaSluggerProspect,
    onBack: () -> Unit
) {
    val season = prospect.seasonStats
    val recent = prospect.recentStats
    val seasonPa = maxOf(season.plateAppearances, season.atBats)
    val recentPa = recent?.let { maxOf(it.plateAppearances, it.atBats) } ?: 0
    val seasonK = if (seasonPa > 0) season.strikeouts * 100.0 / seasonPa else null
    val seasonBb = if (seasonPa > 0) season.walks * 100.0 / seasonPa else null
    val recentK = recent?.takeIf { recentPa > 0 }?.let { it.strikeouts * 100.0 / recentPa }
    val recentBb = recent?.takeIf { recentPa > 0 }?.let { it.walks * 100.0 / recentPa }
    val contact = prospect.contactMetrics
    val tracked = prospect.recentBattedBalls.filter { it.exitVelocity != null && it.launchAngle != null }
    val contactRows = prospect.recentBattedBalls
        .filter { it.exitVelocity != null || it.launchAngle != null || it.distanceFt != null }
        .take(10)
    val avgLaunchAngle = tracked.mapNotNull { it.launchAngle }.takeIf { it.isNotEmpty() }?.average()
    val pitchGroups = tracked
        .filter { !it.pitchType.isNullOrBlank() }
        .groupBy { it.pitchType!! }
        .entries
        .sortedWith(
            compareByDescending<Map.Entry<String, List<BattedBall>>> { it.value.count { ball -> ball.isHomeRun } }
                .thenByDescending { entry -> entry.value.mapNotNull { it.exitVelocity }.maxOrNull() ?: 0.0 }
        )
        .take(5)

    Scaffold(
        containerColor = AppBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AppBackground),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PlayerAvatar(player = prospect.player, team = null, size = 38.dp)
                        Spacer(Modifier.width(9.dp))
                        Column {
                            Text(prospect.player.name, fontWeight = FontWeight.Black, color = AppText)
                            Text("AAA SLUGGER PROFILE • ${prospect.mlbOrg}", color = AppPrimary, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 14.dp,
                end = 14.dp,
                top = padding.calculateTopPadding() + 8.dp,
                bottom = padding.calculateBottomPadding() + 24.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SleekPanel(accent = scoreColor(prospect.sluggerScore)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            modifier = Modifier.size(78.dp),
                            shape = CircleShape,
                            color = scoreColor(prospect.sluggerScore).copy(alpha = .12f),
                            border = BorderStroke(2.dp, scoreColor(prospect.sluggerScore).copy(alpha = .55f))
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Text("${prospect.sluggerScore}", color = scoreColor(prospect.sluggerScore), fontWeight = FontWeight.Black, fontSize = 28.sp)
                                Text("SLUGGER", color = AppMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(prospect.watchLabel, color = AppAmber, fontWeight = FontWeight.Black)
                            Text(
                                listOfNotNull(prospect.position, prospect.aaaTeam?.name).joinToString(" • "),
                                color = AppSubtleText,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text("Call-up Watch ${prospect.callupWatchScore}/100", color = AppViolet, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                            prospect.contactScore?.let {
                                Text("Batted-ball quality $it/100", color = AppGlow, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }

            item {
                SectionCard("Why he is on the watchlist") {
                    Text(prospect.watchReason, color = AppSubtleText, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Call-up Watch blends a curated MLB-proximity prior with current Triple-A power, recent form and contact/readiness. It is not a calibrated promotion probability.",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            item {
                SectionCard("HR Chase AAA signals") {
                    AaaSignalRow("Power", prospect.powerScore, AppAmber)
                    AaaSignalRow("Recent power", prospect.recentPowerScore, AppGreen)
                    prospect.contactScore?.let { AaaSignalRow("Batted-ball", it, AppGlow) }
                    AaaSignalRow("MLB readiness", prospect.readinessScore, AppPrimary)
                    AaaSignalRow("Call-up watch", prospect.callupWatchScore, AppViolet)
                    Spacer(Modifier.height(7.dp))
                    Text(
                        if (prospect.contactScore != null)
                            "Batted-ball quality now contributes 20% of the AAA Slugger Score. Small samples are regressed toward neutral."
                        else
                            "No tracked EV + launch-angle sample is available, so the original stats-only AAA weighting is preserved.",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            item {
                SectionCard("Triple-A batted-ball quality") {
                    if (contact == null || contact.battedBallCount <= 0) {
                        Text(
                            "Recent Triple-A game feeds have not returned enough exit-velocity + launch-angle tracking for this hitter yet. Missing tracking is excluded from the score instead of being treated as zero.",
                            color = AppMuted,
                            style = MaterialTheme.typography.bodySmall
                        )
                    } else {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("AVG EV", contact.avgExitVelocity?.let { "%.1f".format(it) } ?: "—")
                            StatCell("MAX EV", contact.maxExitVelocity?.let { "%.1f".format(it) } ?: "—")
                            StatCell("AVG LA", avgLaunchAngle?.let { "%.1f°".format(it) } ?: "—")
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("HH%", contact.hardHitPct?.let { "%.1f%%".format(it) } ?: "—")
                            StatCell("BARREL*", contact.barrelPct?.let { "%.1f%%".format(it) } ?: "—")
                            StatCell("SWEET%", contact.sweetSpotPct?.let { "%.1f%%".format(it) } ?: "—")
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("AVG DIST", contact.avgDistanceFt?.let { "%.0f ft".format(it) } ?: "—")
                            StatCell("BLAST%", contact.blastPct?.let { "%.1f%%".format(it) } ?: "—")
                            StatCell("FB%", contact.flyBallPct?.let { "%.1f%%".format(it) } ?: "—")
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("PULL%", contact.pullPct?.let { "%.1f%%".format(it) } ?: "—")
                            StatCell("PULL BRL%", contact.pullBarrelPct?.let { "%.1f%%".format(it) } ?: "—")
                            StatCell("PULL AIR%", contact.pullAirPct?.let { "%.1f%%".format(it) } ?: "—")
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "${contact.battedBallCount} tracked EV/LA contacts across ${prospect.contactSourceGames} recent Triple-A games • ${(contact.confidence * 100).roundToInt()}% sample confidence.",
                            color = AppSubtleText,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(5.dp))
                        Text(
                            "*Barrel is the same transparent HR Chase EV/LA barrel proxy used elsewhere in the app, not an official Statcast barrel classification.",
                            color = AppMuted,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }

            if (pitchGroups.isNotEmpty()) {
                item {
                    SectionCard("Pitch-type contact") {
                        Text(
                            "Recent tracked balls grouped by the pitch type attached to the Triple-A game feed.",
                            color = AppMuted,
                            style = MaterialTheme.typography.labelSmall
                        )
                        Spacer(Modifier.height(7.dp))
                        pitchGroups.forEachIndexed { index, entry ->
                            val rows = entry.value
                            val avgEv = rows.mapNotNull { it.exitVelocity }.takeIf { it.isNotEmpty() }?.average()
                            val maxEv = rows.mapNotNull { it.exitVelocity }.maxOrNull()
                            val hrs = rows.count { it.isHomeRun }
                            if (index > 0) HorizontalDivider(color = AppOutline.copy(alpha = .55f), modifier = Modifier.padding(vertical = 7.dp))
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(9.dp),
                                    color = AppViolet.copy(alpha = .11f),
                                    border = BorderStroke(1.dp, AppViolet.copy(alpha = .28f))
                                ) {
                                    Text(entry.key, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = AppViolet, fontWeight = FontWeight.Black)
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("${rows.size} tracked contacts • $hrs HR", color = AppText, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                    Text(
                                        "Avg EV ${avgEv?.let { "%.1f".format(it) } ?: "—"} • Max EV ${maxEv?.let { "%.1f".format(it) } ?: "—"}",
                                        color = AppMuted,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (contactRows.isNotEmpty()) {
                item {
                    SectionCard("Recent Triple-A contact") {
                        contactRows.forEachIndexed { index, ball ->
                            if (index > 0) HorizontalDivider(color = AppOutline.copy(alpha = .50f), modifier = Modifier.padding(vertical = 7.dp))
                            val outcome = when {
                                ball.isHomeRun -> "HR"
                                ball.isOut -> "OUT"
                                else -> ball.eventType.replace('_', ' ').uppercase()
                            }
                            val ev = ball.exitVelocity?.let { "%.1f mph".format(it) } ?: "EV —"
                            val la = ball.launchAngle?.let { "%.0f°".format(it) } ?: "LA —"
                            val dist = ball.distanceFt?.let { "%.0f ft".format(it) } ?: "DIST —"
                            val pitch = ball.pitchType?.let { " • $it" }.orEmpty()
                            Text(
                                "${ball.gameDate.format(DateTimeFormatter.ofPattern("MMM d"))} • $outcome",
                                color = if (ball.isHomeRun) AppGreen else AppText,
                                fontWeight = FontWeight.Black,
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text("$ev • $la • $dist$pitch", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            item {
                SectionCard("Triple-A season power") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatCell("HR", season.homeRuns.toString())
                        StatCell("AVG", season.avg?.let { "%.3f".format(it).removePrefix("0") } ?: "—")
                        StatCell("OPS", season.ops?.let { "%.3f".format(it) } ?: "—")
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatCell("ISO", season.iso?.let { "%.3f".format(it).removePrefix("0") } ?: "—")
                        StatCell("SLG", season.slg?.let { "%.3f".format(it).removePrefix("0") } ?: "—")
                        StatCell("HR/PA", season.hrPerPa?.let { "%.1f%%".format(it * 100) } ?: "—")
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatCell("K%", seasonK?.let { "%.1f%%".format(it) } ?: "—")
                        StatCell("BB%", seasonBb?.let { "%.1f%%".format(it) } ?: "—")
                        StatCell("PA", seasonPa.toString())
                    }
                }
            }

            item {
                SectionCard("Recent 21-day trend") {
                    if (recent == null || recentPa <= 0) {
                        Text("Recent Triple-A date-range data is not available yet.", color = AppMuted)
                    } else {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("HR", recent.homeRuns.toString())
                            StatCell("AVG", recent.avg?.let { "%.3f".format(it).removePrefix("0") } ?: "—")
                            StatCell("OPS", recent.ops?.let { "%.3f".format(it) } ?: "—")
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("ISO", recent.iso?.let { "%.3f".format(it).removePrefix("0") } ?: "—")
                            StatCell("K%", recentK?.let { "%.1f%%".format(it) } ?: "—")
                            StatCell("BB%", recentBb?.let { "%.1f%%".format(it) } ?: "—")
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("$recentPa plate appearances in the rolling window", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            item {
                SectionCard("What AAA v2 measures") {
                    Text(
                        "Season HR rate • ISO • SLG • OPS • recent HR/PA • recent OPS/ISO • strikeout rate • walk rate • sample depth • curated call-up proximity • recent EV/LA contact quality when supplied by Triple-A game feeds.",
                        color = AppSubtleText,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(7.dp))
                    Text(
                        "Batted-ball layer: average/max EV, launch angle, hard-hit rate, HR Chase barrel proxy, sweet-spot rate, distance, fly-ball/pull/blast shape, recent contact log and pitch-type context. Missing tracking is excluded rather than estimated.",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
    }
}

@Composable
private fun ParlaysScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    var legCount by remember { mutableIntStateOf(2) }
    var variant by remember { mutableIntStateOf(0) }
    var focuses by remember { mutableStateOf(setOf(ParlayFocus.BALANCED)) }

    fun toggleFocus(option: ParlayFocus) {
        focuses = if (option in focuses) {
            val next = focuses - option
            if (next.isEmpty()) setOf(ParlayFocus.BALANCED) else next
        } else {
            focuses + option
        }
        variant = 0
    }

    val parlay = remember(
        state.board?.lastUpdated,
        state.selectedDate,
        state.showRemainingOnly,
        state.officialLineupsOnly,
        state.eliteArsenalOnly,
        legCount,
        variant,
        focuses
    ) {
        viewModel.generateCombinedParlay(legCount, variant, focuses, state)
    }
    val evaluation = remember(parlay, focuses, state.board?.lastUpdated) {
        viewModel.evaluateCombinedParlay(parlay, focuses, state)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding).background(Color.Transparent),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ScreenIntro(
                eyebrow = "PARLAY LAB",
                title = "Build the card your way",
                subtitle = "Select one filter or stack several together. Combined filters use AND logic, then rotate through quality-controlled combinations."
            )
        }

        item { DateControls(state, viewModel) }

        item {
            SleekPanel(accent = AppViolet) {
                Column(Modifier.padding(14.dp)) {
                    Text(
                        "GENERATOR FOCUS",
                        color = AppMuted,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.7.sp,
                        style = MaterialTheme.typography.labelLarge
                    )
                    Spacer(Modifier.height(8.dp))

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        ParlayFocusChip(
                            label = "Balanced",
                            selected = ParlayFocus.BALANCED in focuses,
                            modifier = Modifier.weight(1f)
                        ) { toggleFocus(ParlayFocus.BALANCED) }
                        ParlayFocusChip(
                            label = "Pure Power",
                            selected = ParlayFocus.PURE_POWER in focuses,
                            modifier = Modifier.weight(1f)
                        ) { toggleFocus(ParlayFocus.PURE_POWER) }
                        ParlayFocusChip(
                            label = "Heating",
                            selected = ParlayFocus.HEATING_UP in focuses,
                            modifier = Modifier.weight(1f)
                        ) { toggleFocus(ParlayFocus.HEATING_UP) }
                    }
                    Spacer(Modifier.height(7.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        ParlayFocusChip(
                            label = "Hot Now",
                            selected = ParlayFocus.HOT_NOW in focuses,
                            modifier = Modifier.weight(1f)
                        ) { toggleFocus(ParlayFocus.HOT_NOW) }
                        ParlayFocusChip(
                            label = "Matchup Edge",
                            selected = ParlayFocus.MATCHUP_EDGE in focuses,
                            modifier = Modifier.weight(1f)
                        ) { toggleFocus(ParlayFocus.MATCHUP_EDGE) }
                    }
                    Spacer(Modifier.height(7.dp))
                    Row(Modifier.fillMaxWidth()) {
                        ParlayFocusChip(
                            label = "Top Arsenal",
                            selected = ParlayFocus.ELITE_ARSENAL in focuses,
                            modifier = Modifier.weight(1f)
                        ) { toggleFocus(ParlayFocus.ELITE_ARSENAL) }
                        Spacer(Modifier.weight(1f))
                    }

                    Spacer(Modifier.height(8.dp))
                    Surface(
                        color = if (focuses.size > 1) AppGreen.copy(alpha = 0.10f) else AppSurfaceRaised,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (focuses.size > 1) AppGreen.copy(alpha = 0.28f) else AppOutline)
                    ) {
                        Text(
                            if (focuses.size > 1) "STACKED FILTERS • AND MODE • ${focuses.size} ACTIVE" else "MULTI-SELECT READY • TAP ANY FILTERS TO COMBINE",
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                            color = if (focuses.size > 1) AppGreen else AppMuted,
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        viewModel.parlayCombinedDescription(focuses),
                        color = AppSubtleText,
                        style = MaterialTheme.typography.bodySmall
                    )

                    Spacer(Modifier.height(16.dp))
                    Text(
                        "PARLAY SIZE",
                        color = AppMuted,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.7.sp,
                        style = MaterialTheme.typography.labelLarge
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        (1..5).forEach { legs ->
                            FilterChip(
                                selected = legCount == legs,
                                onClick = { legCount = legs; variant = 0 },
                                label = { Text(legs.toString(), fontWeight = FontWeight.Bold) },
                                modifier = Modifier.weight(1f),
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = AppSurfaceRaised,
                                    selectedContainerColor = AppPrimary.copy(alpha = 0.18f),
                                    selectedLabelColor = AppPrimary
                                )
                            )
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { variant += 1 },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(15.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AppPrimary, contentColor = Color(0xFF04131D))
                    ) {
                        Icon(Icons.Outlined.Casino, null)
                        Spacer(Modifier.width(7.dp))
                        Text(
                            if (legCount == 1) "GENERATE ANOTHER STRAIGHT" else "GENERATE ANOTHER ${legCount}-LEG",
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.25.sp,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        if (state.isLoading) {
            item { LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = AppPrimary, trackColor = AppSurfaceRaised) }
        }

        if (!state.isLoading && parlay.isEmpty()) {
            item { EmptyCard(if (focuses.size > 1) "Not enough hitters qualify for every selected filter. Remove one filter, lower the parlay size, or try again after more data loads." else "Not enough eligible hitters yet. Try again after lineups and recent-form data load.") }
        } else if (parlay.isNotEmpty()) {
            item {
                SleekPanel(accent = scoreColor(evaluation.rating)) {
                    Column(Modifier.padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                modifier = Modifier.size(68.dp),
                                color = scoreColor(evaluation.rating).copy(alpha = 0.13f),
                                shape = CircleShape,
                                border = BorderStroke(1.dp, scoreColor(evaluation.rating).copy(alpha = 0.35f))
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        evaluation.rating.toString(),
                                        color = scoreColor(evaluation.rating),
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    "${evaluation.label} RELATIVE HIT RATING",
                                    color = scoreColor(evaluation.rating),
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 0.4.sp,
                                    style = MaterialTheme.typography.labelLarge
                                )
                                Text(
                                    if (legCount == 1) "${viewModel.parlayCombinedLabel(focuses)} straight HR pick" else "${viewModel.parlayCombinedLabel(focuses)} ${legCount}-leg HR card",
                                    fontWeight = FontWeight.Black,
                                    style = MaterialTheme.typography.titleLarge
                                )
                                Text(
                                    "Avg leg ${evaluation.averageLegScore} • floor ${evaluation.weakestLegScore} • ${evaluation.uniqueGames}/${parlay.size} unique games",
                                    color = AppMuted,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }

                        Spacer(Modifier.height(7.dp))
                        Text(
                            evaluation.note,
                            color = AppSubtleText,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "Comparative model grade — not a calibrated probability.",
                            color = AppMuted,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(top = 3.dp)
                        )
                    }
                }
            }

            item {
                SleekPanel(accent = AppGreen) {
                    Column(Modifier.padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text(
                                    if (legCount == 1) "Straight HR pick" else "Suggested ${legCount}-leg HR parlay",
                                    fontWeight = FontWeight.Black,
                                    style = MaterialTheme.typography.titleLarge
                                )
                                if (legCount == 1) {
                                    val straightCount = viewModel.straightCombinedCandidates(focuses, state).size.coerceAtLeast(1)
                                    val displayed = Math.floorMod(variant * 5 + viewModel.parlayCombinedRotationOffset(focuses), straightCount) + 1
                                    Text("Rotation $displayed of $straightCount • ${viewModel.parlayCombinedLabel(focuses)}", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                                } else {
                                    Text("Generation ${variant + 1} • ${viewModel.parlayCombinedLabel(focuses)}", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            Surface(color = AppGreen.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp)) {
                                Text(
                                    "ROTATION ON",
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                                    color = AppGreen,
                                    fontWeight = FontWeight.Black,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }

                        Spacer(Modifier.height(10.dp))
                        parlay.forEachIndexed { index, candidate ->
                            if (index > 0) HorizontalDivider(color = AppOutline, modifier = Modifier.padding(vertical = 7.dp))
                            ParlayLegRow(
                                number = index + 1,
                                candidate = candidate,
                                score = viewModel.parlayCombinedScore(candidate, focuses, state),
                                reason = viewModel.parlayCombinedLegReason(candidate, focuses, state)
                            ) {
                                viewModel.openPlayerProfile(candidate.player.id)
                            }
                        }
                    }
                }
            }

            if (legCount > 1) {
                item {
                    SectionCard("How this generation works") {
                        Text("• ${viewModel.parlayCombinedDescription(focuses)}", color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall)
                        Text("• Generate Another rotates through a deeper competitive pool instead of only swapping the same top few names.", color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 5.dp))
                        Text("• Same-game and same-team repeats are penalized, and a weak individual leg drags down the card rating.", color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 5.dp))
                        Text("• The first card is the pure highest-rated build; later generations trade a small amount of model rank for meaningful variety while staying inside a quality window.", color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 5.dp))
                    }
                }
            }
        }

        item {
            Text(
                "HR outcomes are high-variance. The card rating is useful for comparing generated slips, but it is not a guaranteed hit rate or sportsbook probability.",
                style = MaterialTheme.typography.labelSmall,
                color = AppMuted
            )
        }
    }
}

@Composable
private fun ParlayFocusChip(
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = {
            Text(
                label,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        },
        modifier = modifier,
        colors = FilterChipDefaults.filterChipColors(
            containerColor = AppSurfaceRaised,
            selectedContainerColor = AppViolet.copy(alpha = 0.18f),
            selectedLabelColor = Color(0xFFC7C0FF)
        )
    )
}

@Composable
private fun ParlayLegRow(
    number: Int,
    candidate: HitterCandidate,
    score: Double,
    reason: String,
    onOpen: () -> Unit
) {
    val scoreInt = score.roundToInt()
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(vertical = 3.dp),
        verticalAlignment = Alignment.Top
    ) {
        Surface(
            modifier = Modifier.size(38.dp),
            color = scoreColor(scoreInt).copy(alpha = 0.13f),
            shape = CircleShape,
            border = BorderStroke(1.dp, scoreColor(scoreInt).copy(alpha = 0.35f))
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(number.toString(), fontWeight = FontWeight.Black, color = scoreColor(scoreInt))
            }
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                PlayerAvatar(candidate.player, candidate.team, size = 30.dp)
                Spacer(Modifier.width(8.dp))
                Text(
                    candidate.player.name,
                    fontWeight = FontWeight.Black,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Text(scoreInt.toString(), fontWeight = FontWeight.Black, color = scoreColor(scoreInt))
            }
            Text(
                "${candidate.team.abbreviation} vs ${candidate.opponent.abbreviation} • ${candidate.game.gameDate.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("h:mm a"))}",
                style = MaterialTheme.typography.labelMedium,
                color = AppMuted
            )
            Text(
                reason,
                color = Color(0xFFD3E0EA),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 3.dp)
            )
        }
    }
}

@Composable
private fun DateControls(state: AppUiState, viewModel: MainViewModel) {
    val minimumDate = LocalDate.now().minusDays(1)
    val canGoBack = state.selectedDate.isAfter(minimumDate)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = { viewModel.changeDate(-1) },
            enabled = canGoBack,
            modifier = Modifier.size(38.dp)
        ) {
            Icon(
                Icons.Default.ChevronLeft,
                "Previous day",
                tint = if (canGoBack) AppSubtleText else AppMuted.copy(alpha = 0.35f)
            )
        }

        Column(
            modifier = Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                state.selectedDate.format(DateTimeFormatter.ofPattern("EEE, MMM d")),
                fontWeight = FontWeight.Black,
                color = AppText,
                fontSize = 18.sp,
                letterSpacing = 0.15.sp
            )
            state.board?.let {
                Text(
                    "${it.games.size} GAMES",
                    color = AppPrimary,
                    fontWeight = FontWeight.Black,
                    fontSize = 9.5.sp,
                    letterSpacing = 1.25.sp,
                    modifier = Modifier.padding(top = 1.dp)
                )
            }
        }

        IconButton(
            onClick = { viewModel.changeDate(1) },
            modifier = Modifier.size(38.dp)
        ) {
            Icon(Icons.Default.ChevronRight, "Next", tint = AppSubtleText)
        }
    }
}

@Composable
private fun SimpleFilters(state: AppUiState, viewModel: MainViewModel) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 3.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = state.showRemainingOnly,
                onClick = { viewModel.toggleRemainingOnly() },
                label = { Text("Remaining", fontWeight = FontWeight.SemiBold) },
                shape = RoundedCornerShape(50.dp),
                colors = simpleChipColors()
            )
            FilterChip(
                selected = state.officialLineupsOnly,
                onClick = { viewModel.toggleOfficialOnly() },
                label = { Text("Official lineups", fontWeight = FontWeight.SemiBold) },
                shape = RoundedCornerShape(50.dp),
                colors = simpleChipColors()
            )
        }
        Row(Modifier.fillMaxWidth()) {
            FilterChip(
                selected = state.eliteArsenalOnly,
                onClick = { viewModel.toggleEliteArsenalOnly() },
                label = { Text("Top Arsenal", fontWeight = FontWeight.Black) },
                leadingIcon = if (state.eliteArsenalOnly) {
                    { Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(16.dp)) }
                } else null,
                shape = RoundedCornerShape(50.dp),
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = AppSurface,
                    labelColor = AppMuted,
                    iconColor = AppMuted,
                    selectedContainerColor = AppAmber.copy(alpha = 0.14f),
                    selectedLabelColor = AppAmber,
                    selectedLeadingIconColor = AppAmber
                )
            )
            if (state.eliteArsenalOnly) {
                Text(
                    "Top 15 available arsenal matches • arsenal score first • no hard cutoff",
                    modifier = Modifier.padding(start = 9.dp).align(Alignment.CenterVertically),
                    color = AppMuted,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

@Composable
private fun simpleChipColors() = FilterChipDefaults.filterChipColors(
    containerColor = AppSurface,
    labelColor = AppMuted,
    selectedContainerColor = AppPrimary.copy(alpha = 0.15f),
    selectedLabelColor = AppPrimary
)

@Composable
private fun LoadState(state: AppUiState, viewModel: MainViewModel) {
    if (state.isLoading) {
        Column {
            LinearProgressIndicator(Modifier.fillMaxWidth(), color = AppPrimary, trackColor = AppSurfaceRaised)
            Text(state.progress, Modifier.padding(horizontal = 15.dp, vertical = 5.dp), color = AppMuted, style = MaterialTheme.typography.labelSmall)
        }
    }
    state.error?.let { error ->
        val hasSavedBoard = state.board?.candidates?.isNotEmpty() == true
        val accent = if (hasSavedBoard) AppAmber else AppRed
        Card(
            modifier = Modifier.padding(12.dp).fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.11f)),
            border = BorderStroke(1.dp, accent.copy(alpha = 0.32f))
        ) {
            Column(Modifier.padding(12.dp)) {
                Text(
                    if (hasSavedBoard) "Refresh issue • saved data kept" else "Could not load MLB data",
                    color = accent,
                    fontWeight = FontWeight.Black
                )
                Text(error, color = AppMuted, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(7.dp))
                Button(onClick = { viewModel.refresh() }, enabled = !state.isLoading) {
                    Text(if (hasSavedBoard) "Refresh again" else "Retry")
                }
            }
        }
    }
}

@Composable
private fun EmptyState(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = AppMuted, modifier = Modifier.padding(24.dp))
    }
}

@Composable
private fun EmptyCard(text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = AppSurface), border = BorderStroke(1.dp, AppOutline)) {
        Text(text, modifier = Modifier.padding(14.dp), color = AppMuted)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlayerProfileLoadingScreen(
    loading: Boolean,
    error: String?,
    onBack: () -> Unit
) {
    Scaffold(
        containerColor = AppBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AppBackground),
                title = {
                    Column {
                        Text("Player Profile", fontWeight = FontWeight.Black)
                        Text("Loading complete HR Chase data", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            SleekPanel(accent = if (error == null) AppPrimary else AppRed) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (loading) {
                        CircularProgressIndicator(color = AppPrimary)
                        Spacer(Modifier.height(16.dp))
                        Text("Building player profile…", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Pulling the player's full matchup, power signals, splits, pitch-arsenal fit and recent contact history.",
                            color = AppMuted,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    } else {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = AppRed, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.height(10.dp))
                        Text("Profile unavailable", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                        Text(
                            error ?: "HR Chase could not build this profile right now.",
                            color = AppMuted,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlayerDetailScreen(
    candidate: HitterCandidate,
    profileDate: LocalDate,
    pickScore: Double,
    signalScore: Double,
    signalTier: String,
    signalReasons: List<String>,
    swingMissScore: Double,
    teamDepthScore: Double,
    matchupConvergence: MatchupConvergenceProfile,
    researchLens: ResearchLensScore,
    bvpLoading: Boolean,
    tracked: Boolean,
    onBack: () -> Unit,
    onTrack: () -> Unit
) {
    val model = remember { HrScoringModel() }
    val score = pickScore.roundToInt()
    val mustHave = remember(candidate.player.id, candidate.recentBattedBalls, candidate.seasonStats) {
        model.mustHaveMetrics(candidate.player, candidate.seasonStats, candidate.recentBattedBalls)
    }

    Scaffold(
        containerColor = AppBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AppBackground),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PlayerAvatar(candidate.player, candidate.team, size = 38.dp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(candidate.player.name, fontWeight = FontWeight.Black)
                            Text(
                                "PLAYER PROFILE • ${profileDate.format(DateTimeFormatter.ofPattern("MMM d"))}",
                                color = AppMuted,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } },
                actions = {
                    IconButton(onClick = onTrack) {
                        Icon(if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder, "Track", tint = if (tracked) AppAmber else AppMuted)
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SleekPanel(accent = scoreColor(score)) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            modifier = Modifier.size(72.dp),
                            color = scoreColor(score).copy(alpha = 0.14f),
                            shape = CircleShape,
                            border = BorderStroke(2.dp, scoreColor(score).copy(alpha = 0.40f))
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(score.toString(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = scoreColor(score))
                                    Text("PICK", style = MaterialTheme.typography.labelSmall, color = AppMuted)
                                }
                            }
                        }
                        Spacer(Modifier.width(13.dp))
                        Column {
                            Text("Why we like it", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                            Text(quickJustification(candidate), color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall)
                            Text("${candidate.team.abbreviation} • Batting #${candidate.battingOrder}", color = AppMuted, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }

            item {
                SectionCard("Research lens") {
                    Text(
                        "Three separate reads keep matchup, process quality and raw upside from being hidden inside one score.",
                        color = AppMuted,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(9.dp))
                    ScoreBar("MATCH — tonight's matchup", researchLens.match)
                    ScoreBar("PROCESS — underlying quality", researchLens.processTest)
                    ScoreBar("CEILING — one-swing upside", researchLens.ceiling)
                }
            }

            item {
                SectionCard("Power signal lens") {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = AppViolet.copy(alpha = 0.13f),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, AppViolet.copy(alpha = 0.30f))
                        ) {
                            Column(Modifier.padding(horizontal = 14.dp, vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(signalScore.roundToInt().toString(), color = AppViolet, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                                Text(signalTier, color = AppViolet, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Hitter-first convergence check", fontWeight = FontWeight.Black)
                            Text(
                                if (signalReasons.isEmpty()) "No single signal dominates this matchup." else signalReasons.joinToString(" • "),
                                color = AppSubtleText,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    ScoreBar("Recent form / pressure", candidate.score.powerPressure)
                    ScoreBar("Swing & miss", swingMissScore)
                    ScoreBar("Pitcher resistance", candidate.score.pitcherMatchup)
                    NullableScoreBar("Pitch arsenal fit", candidate.pitchArsenalMatch?.score)
                    NullableScoreBar("Attack zone fit", candidate.attackZoneMatch?.score)
                    ScoreBar("Lineup barrel depth", teamDepthScore)
                    val whiff = candidate.recentPlateDiscipline.whiffRate
                    Text(
                        if (whiff != null) "Recent whiff: ${"%.1f".format(whiff * 100)}% across ${candidate.recentPlateDiscipline.swings} swings / ${candidate.recentPlateDiscipline.totalPitches} pitches." else "Recent pitch-level swing/whiff sample unavailable; season contact is used as the fallback.",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                    Text(
                        "Independent HR Chase convergence score using hitter form, contact quality, swing-and-miss, pitcher resistance, pitch-type fit, platoon context and lineup power.",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            item {
                SectionCard("Five key signals") {
                    ScoreBar("Power Pressure", candidate.score.powerPressure)
                    ScoreBar("Pitcher matchup", candidate.score.pitcherMatchup)
                    NullableScoreBar("Pitch arsenal fit", candidate.pitchArsenalMatch?.score)
                    ScoreBar("Handedness split", candidate.score.platoon)
                    ScoreBar("Recent contact", candidate.score.recentPower)
                }
            }

            item {
                SectionCard("Arsenal + handedness convergence") {
                    if (!matchupConvergence.available) {
                        Text(
                            "A combined grade will appear when reliable pitch-type data is available. The model does not fabricate a neutral arsenal observation.",
                            color = AppMuted,
                            style = MaterialTheme.typography.bodySmall
                        )
                    } else {
                        val cScore = matchupConvergence.score.roundToInt()
                        val cColor = when {
                            matchupConvergence.isPerfectFit -> AppAmber
                            matchupConvergence.isStrongFit -> AppGreen
                            cScore >= 65 -> AppPrimary
                            else -> scoreColor(cScore)
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = cColor.copy(alpha = .13f),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, cColor.copy(alpha = .30f))
                            ) {
                                Column(Modifier.padding(horizontal = 14.dp, vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(cScore.toString(), color = cColor, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                                    Text("A + H", color = cColor, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(matchupConvergence.label, color = cColor, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "Arsenal ${matchupConvergence.arsenalScore?.roundToInt() ?: 0} • Handedness ${matchupConvergence.platoonScore.roundToInt()} • ${(matchupConvergence.evidenceConfidence * 100).roundToInt()}% evidence confidence",
                                    color = AppMuted,
                                    style = MaterialTheme.typography.labelSmall
                                )
                                matchupConvergence.learnedLift?.let { lift ->
                                    if (matchupConvergence.learnedAttempts >= 12) {
                                        Text(
                                            "Historical pair: ${"%.2f".format(lift)}× learned HR lift across ${matchupConvergence.learnedAttempts} qualifying hitter-games.",
                                            color = if (lift >= 1.05) AppGreen else AppMuted,
                                            style = MaterialTheme.typography.labelSmall,
                                            modifier = Modifier.padding(top = 3.dp)
                                        )
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(9.dp))
                        ScoreBar("Pitch arsenal fit", matchupConvergence.arsenalScore ?: 50.0)
                        ScoreBar("Handedness split", matchupConvergence.platoonScore)
                        Text(
                            "The combined score is intentionally limited by the weaker side. An elite arsenal fit does not qualify as a perfect matchup when the platoon split is poor, and vice versa.",
                            color = AppMuted,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(top = 5.dp)
                        )
                    }
                }
            }

            item {
                SectionCard("Attack zone fit") {
                    val zone = candidate.attackZoneMatch
                    if (zone == null) {
                        Text(
                            "No reliable recent pitch-location overlap is available. HR Chase leaves this signal missing instead of inventing a neutral observation.",
                            color = AppMuted,
                            style = MaterialTheme.typography.bodySmall
                        )
                    } else {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = scoreColor(zone.score.roundToInt()).copy(alpha = .13f),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, scoreColor(zone.score.roundToInt()).copy(alpha = .30f))
                            ) {
                                Column(Modifier.padding(horizontal = 14.dp, vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(zone.score.roundToInt().toString(), color = scoreColor(zone.score.roundToInt()), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                                    Text("ZONE", color = AppMuted, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Pitcher attack map × hitter damage map", fontWeight = FontWeight.Black)
                                Text(
                                    "${zone.pitcherPitchSample} recent pitcher locations • ${zone.batterContactSample} located hitter BBE • ${(zone.confidence * 100).roundToInt()}% confidence",
                                    color = AppMuted,
                                    style = MaterialTheme.typography.labelSmall
                                )
                                Text(
                                    "${(zone.coveredPitcherShare * 100).roundToInt()}% of the pitcher's mapped attack areas have hitter contact evidence.",
                                    color = AppMuted,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                        if (zone.bestZones.isNotEmpty()) {
                            Spacer(Modifier.height(10.dp))
                            zone.bestZones.forEach { cell ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(cell.label, color = AppSubtleText, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                    Text(
                                        "Pitcher ${(cell.pitcherShare * 100).roundToInt()}% • Damage ${cell.batterDamageScore.roundToInt()} • ${cell.batterContactCount} BBE",
                                        color = AppMuted,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                        }
                        Text(
                            "This is HR Chase's independent zone-overlap model from MLB Gameday coordinates. It does not copy or estimate another creator's proprietary Zone formula.",
                            color = AppMuted,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(top = 7.dp)
                        )
                    }
                }
            }

            item {
                SectionCard("Pitch arsenal fit") {
                    val arsenal = candidate.pitchArsenalMatch
                    val pitcherName = candidate.opponentPitcher?.person?.name ?: "today's pitcher"
                    if (arsenal == null) {
                        Text(
                            "Pitch-type data is temporarily unavailable after both Statcast and MLB fallback checks. The ranking redistributes this weight rather than inventing a score.",
                            color = AppMuted,
                            style = MaterialTheme.typography.bodySmall
                        )
                    } else {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = scoreColor(arsenal.score.roundToInt()).copy(alpha = 0.13f),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, scoreColor(arsenal.score.roundToInt()).copy(alpha = 0.32f))
                            ) {
                                Column(
                                    Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        arsenal.score.roundToInt().toString(),
                                        color = scoreColor(arsenal.score.roundToInt()),
                                        fontWeight = FontWeight.Black,
                                        style = MaterialTheme.typography.titleLarge
                                    )
                                    Text("FIT", color = AppMuted, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("HR pitch preference vs $pitcherName", fontWeight = FontWeight.Black)
                                Text(
                                    if (arsenal.batterHrSample > 0)
                                        "${arsenal.batterHrSample} season HR pitch events • ${arsenal.batterPitchSample} pitch sample • ${(arsenal.confidence * 100).roundToInt()}% confidence"
                                    else
                                        "${arsenal.batterPitchSample} pitch sample • pitch-type damage model • ${(arsenal.confidence * 100).roundToInt()}% confidence",
                                    color = AppMuted,
                                    style = MaterialTheme.typography.labelSmall
                                )
                                Text(arsenal.source, color = AppMuted, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        arsenal.feastPitches.take(4).forEach { pitch ->
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val hitterDetail = if (pitch.homeRuns > 0) {
                                    "${pitch.name}: ${pitch.homeRuns} HR (${(pitch.share * 100).roundToInt()}%)"
                                } else {
                                    val xslg = pitch.batterXslg?.let { "xSLG ${"%.3f".format(it)}" }
                                    val slg = pitch.batterSlg?.let { "SLG ${"%.3f".format(it)}" }
                                    listOfNotNull(xslg, slg).joinToString(" • ").ifBlank { pitch.name }
                                        .let { "${pitch.name}: $it" }
                                }
                                Text(
                                    hitterDetail,
                                    color = AppSubtleText,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    "$pitcherName ${(pitch.opposingPitcherUsage * 100).roundToInt()}%",
                                    color = if (pitch.opposingPitcherUsage >= .20) AppPrimary else AppMuted,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        if (arsenal.pitcherArsenal.isNotEmpty()) {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Pitcher arsenal: " + arsenal.pitcherArsenal.take(5).joinToString(" • ") { "${it.name} ${(it.share * 100).roundToInt()}%" },
                                color = AppMuted,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                        Spacer(Modifier.height(5.dp))
                        Text(
                            "Arsenal Fit now combines direct HR pitch history, the hitter's SLG/xSLG/hard-hit results by pitch type, the starter's actual usage, and how much damage that starter allows with those pitches. It carries 12% of the daily Target Score when available, with small samples regressed toward neutral.",
                            color = AppMuted,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }

            item {
                SectionCard("Must-have power metrics") {
                    Text(
                        "Power profile ${mustHave.score.roundToInt()} • ${mustHave.battedBallCount} recent tracked BBE",
                        color = scoreColor(mustHave.score.roundToInt()),
                        fontWeight = FontWeight.Black
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatCell("Barrel%", mustHave.barrelPct?.let { "%.1f%%".format(it) } ?: "—")
                        StatCell("HH%", mustHave.hardHitPct?.let { "%.1f%%".format(it) } ?: "—")
                        StatCell("EV", mustHave.avgExitVelocity?.let { "%.1f".format(it) } ?: "—")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatCell("ISO", mustHave.iso?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                        StatCell("FB%", mustHave.flyBallPct?.let { "%.1f%%".format(it) } ?: "—")
                        StatCell("Avg Dist", mustHave.avgDistanceFt?.let { "${it.roundToInt()} ft" } ?: "—")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatCell("Pull%", mustHave.pullPct?.let { "%.1f%%".format(it) } ?: "N/A")
                        StatCell("PullBrl%", mustHave.pullBarrelPct?.let { "%.1f%%".format(it) } ?: "N/A")
                        StatCell("PullAir%", mustHave.pullAirPct?.let { "%.1f%%".format(it) } ?: "N/A")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatCell("Blast%", mustHave.blastPct?.let { "%.1f%%".format(it) } ?: "—")
                        StatCell("Profile", mustHave.score.roundToInt().toString())
                        StatCell("Conf.", "${(mustHave.confidence * 100).roundToInt()}%")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatCell("Sweet Spot%", mustHave.sweetSpotPct?.let { "%.1f%%".format(it) } ?: "—")
                        StatCell("Avg LA", mustHave.avgLaunchAngle?.let { "%.1f°".format(it) } ?: "—")
                        StatCell("Max EV", mustHave.maxExitVelocity?.let { "%.1f".format(it) } ?: "—")
                        StatCell("K%", if (candidate.seasonStats.plateAppearances > 0) "%.1f%%".format(candidate.seasonStats.strikeouts * 100.0 / candidate.seasonStats.plateAppearances) else "—")
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Directional coverage: ${mustHave.directionalBattedBallCount}/${mustHave.battedBallCount} recent tracked BBE",
                        color = if (mustHave.directionalBattedBallCount > 0) AppSubtleText else AppAmber,
                        style = MaterialTheme.typography.labelSmall
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Pull metrics use MLB hit locations/spray coordinates with a description fallback. Blast% is our 105+ mph / 15–35° proxy. Small recent samples are down-weighted in the daily Target Score.",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            item {
                SectionCard("Opposing pitcher") {
                    val pitcher = candidate.opponentPitcher
                    if (pitcher == null) {
                        Text("Pitcher data not available yet.", color = AppMuted)
                    } else {
                        Text(pitcher.person.name, fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(7.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("ERA", pitcher.seasonStats.era?.let { "%.2f".format(it) } ?: "—")
                            StatCell("HR/9", pitcher.seasonStats.hrPer9?.let { "%.2f".format(it) } ?: "—")
                            StatCell("WHIP", pitcher.seasonStats.whip?.let { "%.2f".format(it) } ?: "—")
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("K%", pitcher.seasonStats.strikeoutRate?.let { "%.1f%%".format(it * 100.0) } ?: "—")
                            StatCell("BB%", pitcher.seasonStats.walkRate?.let { "%.1f%%".format(it * 100.0) } ?: "—")
                            StatCell("BF", pitcher.seasonStats.battersFaced.takeIf { it > 0 }?.toString() ?: "—")
                        }
                    }
                }
            }

            item {
                SectionCard("Season split vs pitcher hand") {
                    val split = candidate.platoonStats
                    val hand = candidate.opponentPitcher?.person?.pitchHand
                    if (split == null || hand == null) {
                        Text("Handedness split data is not available for this matchup.", color = AppMuted, style = MaterialTheme.typography.bodySmall)
                    } else {
                        Text("vs ${hand}HP • ${split.plateAppearances} PA", fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("HR", split.homeRuns.toString())
                            StatCell("ISO", split.iso?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("SLG", split.slg?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("OPS", split.ops?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("AVG", split.avg?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("K%", split.strikeoutRate?.let { "%.1f%%".format(it * 100.0) } ?: "—")
                            StatCell("HR/PA", split.hrPerPa?.let { "%.1f%%".format(it * 100.0) } ?: "—")
                        }
                    }
                }
            }

            item {
                SectionCard("Career vs this pitcher") {
                    val bvp = candidate.vsPitcherStats
                    val pitcherName = candidate.opponentPitcher?.person?.name ?: "today's pitcher"
                    if (bvp == null) {
                        if (bvpLoading) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = AppPrimary
                                )
                                Spacer(Modifier.width(9.dp))
                                Text(
                                    "Loading career BvP vs $pitcherName…",
                                    color = AppMuted,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        } else {
                            Text(
                                "No MLB batter-vs-pitcher history found for $pitcherName.",
                                color = AppMuted,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    } else {
                        Text("vs $pitcherName", fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("AB", bvp.atBats.toString())
                            StatCell("H", bvp.hits.toString())
                            StatCell("HR", bvp.homeRuns.toString())
                            StatCell("K", bvp.strikeouts.toString())
                        }
                        Spacer(Modifier.height(9.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("AVG", bvp.avg?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("OBP", bvp.obp?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("SLG", bvp.slg?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("OPS", bvp.ops?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (bvp.plateAppearances < 8) "Only ${bvp.plateAppearances} PA — useful context, but too small a sample to drive the pick by itself."
                            else "${bvp.plateAppearances} career PA. BvP receives a capped, sample-size-weighted boost in the Pick/Parlay score.",
                            color = AppMuted,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }

            item {
                SectionCard("Justification") {
                    candidate.score.notes.take(5).forEach { note ->
                        Text("• $note", color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 5.dp))
                    }
                }
            }

            if (candidate.recentBattedBalls.isNotEmpty()) {
                item { Text("Recent contact", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black) }
                items(candidate.recentBattedBalls.sortedByDescending { it.gameDate }.take(12)) { ball -> BattedBallRow(ball, model) }
            }
        }
    }
}

@Composable
private fun NullableScoreBar(label: String, value: Double?) {
    if (value != null) {
        ScoreBar(label, value)
        return
    }
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = AppSubtleText)
        Text("N/A", color = AppMuted, fontWeight = FontWeight.Bold)
    }
    Text(
        "Waiting for MLB pitch-type data; this metric is excluded from scoring until available.",
        color = AppMuted,
        style = MaterialTheme.typography.labelSmall
    )
}

@Composable
private fun ScoreBar(label: String, value: Double) {
    val intValue = value.roundToInt()
    Column(Modifier.padding(top = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color(0xFFD3E0EA))
            Text(intValue.toString(), color = scoreColor(intValue), fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { (value / 100.0).toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(5.dp),
            color = scoreColor(intValue),
            trackColor = AppSurfaceRaised
        )
    }
}

@Composable
private fun BattedBallRow(ball: BattedBall, model: HrScoringModel) {
    val signal = when {
        ball.isHomeRun -> "HR"
        model.isEliteNearHomeRun(ball) -> "NEAR-HR+"
        model.isNearHomeRun(ball) -> "NEAR-HR"
        model.isBarrelProxy(ball) -> "BARREL"
        model.isHardHit(ball) -> "HARD HIT"
        else -> "CONTACT"
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, AppOutline)
    ) {
        Row(Modifier.fillMaxWidth().padding(11.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(signal, fontWeight = FontWeight.Black, color = if (signal == "HR") AppGreen else AppPrimary)
                Text(ball.gameDate.toString(), color = AppMuted, style = MaterialTheme.typography.labelSmall)
            }
            Text(
                "${ball.exitVelocity?.let { "%.1f mph".format(it) } ?: "—"} • ${ball.launchAngle?.let { "%.0f°".format(it) } ?: "—"} • ${ball.distanceFt?.let { "%.0f ft".format(it) } ?: "—"}",
                color = Color(0xFFD3E0EA),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun TrackedScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val model = remember { HrScoringModel() }
    val tracked = remember(state.tracked, state.selectedDate) { state.tracked.filter { it.date == state.selectedDate } }
    val byId = remember(state.board?.lastUpdated) { state.board?.candidates?.associateBy { it.player.id }.orEmpty() }
    val trackedKey = tracked.joinToString(separator = ",") { it.playerId.toString() }

    LaunchedEffect(state.selectedDate, trackedKey) {
        viewModel.loadTrackedLast10Stats()
    }

    Column(Modifier.fillMaxSize().padding(padding).background(Color.Transparent)) {
        DateControls(state, viewModel)
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ScreenIntro(
                eyebrow = "YOUR WATCHLIST",
                title = "Tracked picks",
                subtitle = "Review the quality of the read, not only HR or no HR.",
                modifier = Modifier.weight(1f)
            )
            if (tracked.isNotEmpty()) {
                Spacer(Modifier.width(10.dp))
                TextButton(onClick = { viewModel.clearTrackedForSelectedDate() }) {
                    Text("CLEAR", color = AppRed, fontWeight = FontWeight.Black)
                }
            }
        }

        if (tracked.isEmpty()) {
            EmptyState("Star hitters from the Games tab to track them here.")
        } else {
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(tracked, key = { "${it.date}-${it.playerId}-${it.pickType}" }, contentType = { "tracked-card" }) { pick ->
                    val c = byId[pick.playerId]
                    SleekPanel(
                        modifier = Modifier.fillMaxWidth().clickable { viewModel.openPlayerProfile(pick.playerId, pick.date) },
                        accent = AppViolet
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                c?.let { PlayerAvatar(it.player, it.team, size = 34.dp) }
                                if (c != null) Spacer(Modifier.width(9.dp))
                                Text(pick.playerName, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                            }
                            Text(
                                "Home Run pick • tracked at ${pick.scoreAtTrack.roundToInt()} Target",
                                style = MaterialTheme.typography.bodySmall,
                                color = AppMuted
                            )

                            Spacer(Modifier.height(9.dp))
                            val last10 = state.trackedLast10[pick.playerId]
                            val loadingLast10 = pick.playerId in state.trackedLast10Loading
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                color = AppSurfaceSoft,
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, AppOutline.copy(alpha = 0.85f))
                            ) {
                                Column(Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "LAST 10 COMPLETED GAMES",
                                            color = AppPrimary,
                                            fontWeight = FontWeight.Black,
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                        if (last10 != null) {
                                            Text(
                                                "${last10.gamesPlayed} G",
                                                color = AppMuted,
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        }
                                    }
                                    Spacer(Modifier.height(7.dp))
                                    when {
                                        last10 != null -> {
                                            Row(
                                                Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                HotStatPill("AVG", last10.avg?.let { "%.3f".format(it).removePrefix("0") } ?: "—", Modifier.weight(1f))
                                                HotStatPill("OPS", last10.ops?.let { "%.3f".format(it) } ?: "—", Modifier.weight(1f))
                                                HotStatPill("HR", last10.homeRuns.toString(), Modifier.weight(1f))
                                                HotStatPill("RBI", last10.rbi.toString(), Modifier.weight(1f))
                                            }
                                            Text(
                                                "${last10.hits} H • ${last10.extraBaseHits} XBH • ${last10.runs} R • ${last10.walks} BB • ${last10.strikeouts} K",
                                                color = AppMuted,
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.padding(top = 7.dp)
                                            )
                                        }
                                        loadingLast10 -> Text(
                                            "Loading recent form…",
                                            color = AppMuted,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        else -> Text(
                                            "Last-10 game log is not available yet.",
                                            color = AppMuted,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }

                            Spacer(Modifier.height(9.dp))
                            if (c == null) {
                                Text("Load this date's board to evaluate contact.", color = AppMuted, style = MaterialTheme.typography.bodySmall)
                            } else {
                                val balls = c.todayBattedBalls
                                val hrs = balls.count { it.isHomeRun }
                                val hardest = balls.mapNotNull { it.exitVelocity }.maxOrNull()
                                val grade = when {
                                    hrs > 0 -> "HR HIT"
                                    balls.any { model.isEliteNearHomeRun(it) } -> "STRONG READ • ELITE NEAR-HR"
                                    balls.any { model.isNearHomeRun(it) } -> "GOOD READ • NEAR-HR"
                                    balls.any { model.isBarrelProxy(it) } -> "BARREL CONTACT • NO HR"
                                    balls.any { model.isHardHit(it) } -> "HARD CONTACT • NO HR"
                                    c.game.status.equals("Final", true) -> "QUIET CONTACT / MISS"
                                    else -> "GAME PENDING / IN PROGRESS"
                                }
                                SignalPill(grade)
                                Text("$hrs HR • ${balls.size} tracked balls • max EV ${hardest?.let { "%.1f".format(it) } ?: "—"}", style = MaterialTheme.typography.bodySmall, color = AppMuted, modifier = Modifier.padding(top = 6.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SignalPill(text: String) {
    val color = when {
        "HR HIT" in text -> AppGreen
        "STRONG" in text || "GOOD" in text -> AppPrimary
        "BARREL" in text || "HARD" in text -> AppAmber
        else -> AppMuted
    }
    Surface(color = color.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp)) {
        Text(text, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = color, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun ScreenIntro(
    eyebrow: String,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Column(modifier.padding(horizontal = 4.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .width(22.dp)
                    .height(2.dp)
                    .background(AppPrimary)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                eyebrow,
                color = AppPrimary,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.35.sp,
                fontSize = 10.sp
            )
        }
        Text(
            title,
            color = AppText,
            fontSize = 27.sp,
            lineHeight = 30.sp,
            letterSpacing = (-0.35).sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier.padding(top = 5.dp)
        )
        Text(
            subtitle,
            color = AppMuted,
            style = MaterialTheme.typography.bodySmall,
            lineHeight = 18.sp,
            modifier = Modifier.padding(top = 5.dp, end = 8.dp)
        )
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    SleekPanel(accent = AppPrimary.copy(alpha = 0.65f)) {
        Column(Modifier.padding(16.dp)) {
            Text(title.uppercase(), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black, color = AppSubtleText, letterSpacing = 0.7.sp)
            Spacer(Modifier.height(7.dp))
            content()
        }
    }
}

@Composable
private fun StatCell(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
        Text(label, color = AppMuted, style = MaterialTheme.typography.labelSmall)
    }
}

private fun scoreColor(score: Int): Color = when {
    score >= 80 -> AppGreen
    score >= 68 -> AppPrimary
    score >= 55 -> AppAmber
    else -> AppMuted
}
