package com.ckz.hrchase.model

import com.ckz.hrchase.data.GameInfo
import com.ckz.hrchase.data.HitterCandidate
import com.ckz.hrchase.data.PitcherProfile
import com.ckz.hrchase.data.PitcherStrikeoutLearningProfile
import com.ckz.hrchase.data.PitcherStrikeoutPrediction
import com.ckz.hrchase.data.PitchingStats
import com.ckz.hrchase.data.RecentHittingStats
import com.ckz.hrchase.data.TeamRef
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Starter strikeout projection built from both sides of the matchup.
 *
 * The model deliberately separates strikeout RATE from expected WORKLOAD:
 *   projected K = projected batters faced × matchup K rate.
 * This keeps a high-K five-inning starter from automatically outranking a durable seven-inning arm.
 */
class PitcherStrikeoutScoringModel {
    data class Context(
        val pitcherThirtyDay: PitchingStats? = null,
        val pitcherFourteenDay: PitchingStats? = null,
        val pitcherSevenDay: PitchingStats? = null,
        val pitcherVsLeft: PitchingStats? = null,
        val pitcherVsRight: PitchingStats? = null,
        val seasonHitting: Map<Int, RecentHittingStats> = emptyMap(),
        val recentFourteenHitting: Map<Int, RecentHittingStats> = emptyMap(),
        val recentSevenHitting: Map<Int, RecentHittingStats> = emptyMap(),
        val recentThreeHitting: Map<Int, RecentHittingStats> = emptyMap(),
        val learning: PitcherStrikeoutLearningProfile = PitcherStrikeoutLearningProfile()
    )

    private val leagueKRate = .225

    fun score(
        pitcher: PitcherProfile,
        team: TeamRef,
        opponent: TeamRef,
        game: GameInfo,
        opposingLineup: List<HitterCandidate>,
        context: Context
    ): PitcherStrikeoutPrediction {
        val lineup = opposingLineup.sortedBy { it.battingOrder }.take(9)
        val official = lineup.size >= 9 && lineup.all { it.lineupOfficial }
        val season = pitcher.seasonStats

        val pitcherSeasonK = season.strikeoutRate
        val pitcher30K = context.pitcherThirtyDay?.strikeoutRate
        val pitcher14K = context.pitcherFourteenDay?.strikeoutRate
        val pitcher7K = context.pitcherSevenDay?.strikeoutRate
        val pitcherKRate = weightedAvailable(
            pitcherSeasonK to .48,
            pitcher30K to .25,
            pitcher14K to .19,
            pitcher7K to .08
        ) ?: leagueKRate

        val seasonOpponentK = lineupRate(lineup) { hitter ->
            context.seasonHitting[hitter.player.id]?.strikeoutRate
                ?: hitter.seasonStats.let { if (it.plateAppearances > 0) it.strikeouts.toDouble() / it.plateAppearances else null }
        }
        val splitOpponentK = lineupRate(lineup) { it.platoonStats?.strikeoutRate }
        val recent14OpponentK = lineupRate(lineup) { context.recentFourteenHitting[it.player.id]?.strikeoutRate }
        val recent7OpponentK = lineupRate(lineup) { context.recentSevenHitting[it.player.id]?.strikeoutRate }
        val recent3OpponentK = lineupRate(lineup) { context.recentThreeHitting[it.player.id]?.strikeoutRate }
        val recentOpponentK = weightedAvailable(
            recent14OpponentK to .48,
            recent7OpponentK to .34,
            recent3OpponentK to .18
        )
        val opponentKRate = weightedAvailable(
            seasonOpponentK to .44,
            splitOpponentK to .31,
            recentOpponentK to .25
        ) ?: leagueKRate

        val lineupWhiff = lineupRate(lineup) { it.recentPlateDiscipline.whiffRate }
        val lineupWhiff3 = lineupRate(lineup) { it.last3PlateDiscipline.whiffRate }
        val whiffRate = weightedAvailable(lineupWhiff to .72, lineupWhiff3 to .28)

        val arsenalScore = lineupScore(lineup) { it.strikeoutPitchMatch?.score }
        val arsenalConfidence = lineupScore(lineup) { it.strikeoutPitchMatch?.confidence?.times(100.0) }
            ?.div(100.0) ?: 0.0

        val handRate = projectedPitcherHandednessKRate(pitcher, lineup, context)
        val batterSplitRate = splitOpponentK
        val handednessRate = weightedAvailable(handRate to .48, batterSplitRate to .52)
        val handednessScore = rateScore(handednessRate ?: leagueKRate, leagueKRate, .09)

        // Combine pitcher ability and opponent strikeout tendency on the log-odds scale so neither
        // side can overwhelm the other and extreme tiny samples are naturally constrained.
        val matchupLogit = logit(leagueKRate) +
            .58 * (logit(pitcherKRate.coerceIn(.08, .45)) - logit(leagueKRate)) +
            .42 * (logit(opponentKRate.coerceIn(.10, .40)) - logit(leagueKRate))
        var matchupKRate = logistic(matchupLogit)

        // Recent pitch-level whiff information is independent of the box-score K rate and receives
        // only a controlled adjustment. MLB/Savant fields can be missing, so null is neutral.
        whiffRate?.let { matchupKRate += ((it - .245) * .13).coerceIn(-.018, .022) }
        if (arsenalScore != null) {
            matchupKRate += (((arsenalScore - 50.0) / 50.0) * .018 * arsenalConfidence).coerceIn(-.014, .016)
        }
        handednessRate?.let { matchupKRate += ((it - leagueKRate) * .12).coerceIn(-.012, .014) }
        matchupKRate = matchupKRate.coerceIn(.105, .415)

        val commandScore = commandScore(season, context.pitcherThirtyDay)
        var projectedBf = projectedBattersFaced(season, context, lineup)
        // Command/strike efficiency and demonstrated pitch-count leash slightly adjust the
        // workload estimate. The cap is intentionally small because BF/start remains primary.
        projectedBf += (((commandScore - 50.0) / 50.0) * 0.65).coerceIn(-0.65, 0.65)
        val recentPitchesPerStart = context.pitcherThirtyDay?.pitchesPerStart
        val workloadPitches = weightedAvailable(season.pitchesPerStart to .65, recentPitchesPerStart to .35)
        workloadPitches?.let { projectedBf += (((it - 86.0) / 18.0) * 0.45).coerceIn(-0.55, 0.55) }
        projectedBf = projectedBf.coerceIn(17.5, 30.5)
        var projectedKs = projectedBf * matchupKRate

        // Once the app has enough resolved starts, correct only persistent calibration bias.
        // Cap the correction so a short historical run never replaces today's matchup data.
        if (context.learning.isActive) {
            projectedKs -= context.learning.averageBias.coerceIn(-.55, .55) * .65
        }
        projectedKs = projectedKs.coerceIn(1.4, 12.5)

        val sampleConfidence = ((season.battersFaced / 450.0).coerceIn(.15, 1.0) * .23) +
            (((context.pitcherThirtyDay?.gamesStarted ?: 0) / 5.0).coerceIn(0.0, 1.0) * .14) +
            ((lineup.size / 9.0).coerceIn(0.0, 1.0) * .16) +
            ((lineupSplitCoverage(lineup) * .18)) +
            ((lineupRecentCoverage(lineup, context) * .10)) +
            ((arsenalConfidence * .09)) +
            (if (official) .10 else .04)
        val confidence = sampleConfidence.coerceIn(.28, .95)

        val uncertainty = (1.05 + sqrt(projectedKs) * .28 + (1.0 - confidence) * .95).coerceIn(1.2, 2.35)
        val low = (projectedKs - uncertainty).coerceAtLeast(0.0)
        val high = projectedKs + uncertainty

        val pitcherAbilityScore = rateScore(pitcherKRate, leagueKRate, .105)
        val opponentStrikeoutScore = rateScore(opponentKRate, leagueKRate, .085)
        val recentFormScore = rateScore(
            weightedAvailable(pitcher30K to .45, pitcher14K to .38, pitcher7K to .17) ?: pitcherKRate,
            pitcherSeasonK ?: leagueKRate,
            .075
        )
        val workloadScore = workloadScore(projectedBf)
        val arsenalWhiffScore = arsenalScore ?: whiffRate?.let { rateScore(it, .245, .13) } ?: 50.0

        val score = (45.0 + (projectedKs - 4.0) * 9.5 + (confidence - .55) * 8.0)
            .coerceIn(18.0, 97.0)

        val tags = buildList {
            if (projectedKs >= 7.5) add("ELITE K CEILING")
            else if (projectedKs >= 6.3) add("STRONG K LOOK")
            if (opponentStrikeoutScore >= 68) add("K-PRONE LINEUP")
            if (splitOpponentK != null && splitOpponentK >= .255) add("HANDEDNESS K EDGE")
            if (arsenalWhiffScore >= 68 && arsenalConfidence >= .30) add("ARSENAL WHIFF EDGE")
            if (workloadScore >= 65) add("WORKLOAD SUPPORT")
            if (!official) add("PROJECTED LINEUP")
        }

        val notes = buildList {
            add("Projected ${"%.1f".format(projectedBf)} batters faced at a ${"%.1f".format(matchupKRate * 100)}% matchup K rate.")
            add("Pitcher K% ${pct(pitcherSeasonK)} • opponent lineup K% ${pct(seasonOpponentK)}${splitOpponentK?.let { " • split K% ${pct(it)}" } ?: ""}.")
            recentOpponentK?.let { add("Opponent recent K% ${pct(it)}; recent pitcher K% ${pct(weightedAvailable(pitcher14K to .65, pitcher7K to .35))}.") }
            if (arsenalScore != null && arsenalConfidence >= .20) {
                add("Pitch-type whiff alignment ${arsenalScore.toInt()}/100 across ${(arsenalConfidence * 100).toInt()}% confidence.")
            }
            if (!official) add("Lineup is projected; refresh after the official batting order posts for the strongest read.")
        }

        return PitcherStrikeoutPrediction(
            pitcher = pitcher.person,
            team = team,
            opponent = opponent,
            game = game,
            score = score,
            projectedStrikeouts = projectedKs,
            projectionLow = low,
            projectionHigh = high,
            confidence = confidence,
            pitcherAbilityScore = pitcherAbilityScore,
            opponentStrikeoutScore = opponentStrikeoutScore,
            handednessScore = handednessScore,
            recentFormScore = recentFormScore,
            arsenalWhiffScore = arsenalWhiffScore,
            workloadScore = workloadScore,
            commandScore = commandScore,
            seasonStrikeoutRate = pitcherSeasonK,
            opponentStrikeoutRate = seasonOpponentK,
            opponentSplitStrikeoutRate = splitOpponentK,
            recentOpponentStrikeoutRate = recentOpponentK,
            projectedBattersFaced = projectedBf,
            lineupOfficial = official,
            tags = tags,
            notes = notes
        )
    }

    private fun projectedPitcherHandednessKRate(
        pitcher: PitcherProfile,
        lineup: List<HitterCandidate>,
        context: Context
    ): Double? {
        var total = 0.0
        var weight = 0.0
        val pitcherHand = pitcher.person.pitchHand
        lineup.forEach { hitter ->
            val effectiveSide = when (hitter.player.batSide) {
                "S" -> if (pitcherHand == "L") "R" else "L"
                else -> hitter.player.batSide
            }
            val split = if (effectiveSide == "L") context.pitcherVsLeft else context.pitcherVsRight
            val rate = split?.strikeoutRate ?: return@forEach
            val w = orderWeight(hitter.battingOrder)
            total += rate * w
            weight += w
        }
        return if (weight > 0) total / weight else null
    }

    private fun projectedBattersFaced(
        season: PitchingStats,
        context: Context,
        lineup: List<HitterCandidate>
    ): Double {
        fun bfStart(stats: PitchingStats?): Double? {
            stats ?: return null
            stats.battersFacedPerStart?.takeIf { it in 12.0..36.0 }?.let { return it }
            val ip = stats.inningsPerStart ?: return null
            return (ip * 4.25).takeIf { it in 12.0..36.0 }
        }
        var base = weightedAvailable(
            bfStart(season) to .48,
            bfStart(context.pitcherThirtyDay) to .27,
            bfStart(context.pitcherFourteenDay) to .18,
            bfStart(context.pitcherSevenDay) to .07
        ) ?: 23.5

        val era = weightedAvailable(season.era to .62, context.pitcherThirtyDay?.era to .38)
        val whip = weightedAvailable(season.whip to .62, context.pitcherThirtyDay?.whip to .38)
        var adjustment = 0.0
        era?.let { adjustment += ((4.15 - it) / 4.15 * .65).coerceIn(-.75, .65) }
        whip?.let { adjustment += ((1.30 - it) / 1.30 * .55).coerceIn(-.65, .55) }

        val teamOps = lineupRate(lineup) { hitter ->
            // HitterCandidate's season line can be sparse before official lineups, so use only real OPS.
            hitter.platoonStats?.ops ?: hitter.seasonStats.ops
        }
        teamOps?.let {
            // Strong offenses can create extra BF but also shorten outings. The net effect is small;
            // we primarily use it as an early-hook penalty rather than pretending more traffic is good.
            adjustment += ((.720 - it) * 2.2).coerceIn(-.65, .45)
        }
        base += adjustment
        return base.coerceIn(17.5, 30.5)
    }

    private fun commandScore(season: PitchingStats, recent: PitchingStats?): Double {
        val bb = weightedAvailable(season.walkRate to .68, recent?.walkRate to .32) ?: .085
        val whip = weightedAvailable(season.whip to .68, recent?.whip to .32) ?: 1.30
        val strike = weightedAvailable(season.strikePct to .68, recent?.strikePct to .32)
        var score = 50.0 + (.085 - bb) / .05 * 18.0 + (1.30 - whip) / .45 * 13.0
        strike?.let { score += (it - .635) / .07 * 8.0 }
        return score.coerceIn(10.0, 92.0)
    }

    private fun workloadScore(projectedBf: Double): Double =
        (50.0 + (projectedBf - 23.0) / 6.5 * 28.0).coerceIn(15.0, 92.0)

    private fun lineupSplitCoverage(lineup: List<HitterCandidate>): Double {
        if (lineup.isEmpty()) return 0.0
        val weightedTotal = lineup.sumOf { orderWeight(it.battingOrder) }
        val covered = lineup.filter { (it.platoonStats?.plateAppearances ?: 0) >= 20 }
            .sumOf { orderWeight(it.battingOrder) }
        return if (weightedTotal > 0) (covered / weightedTotal).coerceIn(0.0, 1.0) else 0.0
    }

    private fun lineupRecentCoverage(lineup: List<HitterCandidate>, context: Context): Double {
        if (lineup.isEmpty()) return 0.0
        val weightedTotal = lineup.sumOf { orderWeight(it.battingOrder) }
        val covered = lineup.filter { (context.recentFourteenHitting[it.player.id]?.plateAppearances ?: 0) >= 12 }
            .sumOf { orderWeight(it.battingOrder) }
        return if (weightedTotal > 0) (covered / weightedTotal).coerceIn(0.0, 1.0) else 0.0
    }

    private fun lineupScore(lineup: List<HitterCandidate>, getter: (HitterCandidate) -> Double?): Double? =
        weightedLineup(lineup, getter)

    private fun lineupRate(lineup: List<HitterCandidate>, getter: (HitterCandidate) -> Double?): Double? =
        weightedLineup(lineup, getter)

    private fun weightedLineup(lineup: List<HitterCandidate>, getter: (HitterCandidate) -> Double?): Double? {
        var total = 0.0
        var weight = 0.0
        lineup.forEach { hitter ->
            val value = getter(hitter) ?: return@forEach
            if (!value.isFinite()) return@forEach
            val w = orderWeight(hitter.battingOrder)
            total += value * w
            weight += w
        }
        return if (weight > 0) total / weight else null
    }

    private fun orderWeight(order: Int): Double = when (order) {
        1 -> 1.10
        2 -> 1.09
        3 -> 1.07
        4 -> 1.05
        5 -> 1.02
        6 -> .99
        7 -> .96
        8 -> .93
        9 -> .90
        else -> 1.0
    }

    private fun weightedAvailable(vararg values: Pair<Double?, Double>): Double? {
        var total = 0.0
        var weight = 0.0
        values.forEach { (value, w) ->
            if (value != null && value.isFinite() && w > 0) {
                total += value * w
                weight += w
            }
        }
        return if (weight > 0) total / weight else null
    }

    private fun rateScore(rate: Double, baseline: Double, spread: Double): Double =
        (50.0 + (rate - baseline) / spread * 30.0).coerceIn(8.0, 95.0)

    private fun logit(p: Double): Double = ln(p / (1.0 - p))
    private fun logistic(x: Double): Double = 1.0 / (1.0 + exp(-x))
    private fun pct(value: Double?): String = value?.let { "%.1f%%".format(it * 100) } ?: "—"
}
