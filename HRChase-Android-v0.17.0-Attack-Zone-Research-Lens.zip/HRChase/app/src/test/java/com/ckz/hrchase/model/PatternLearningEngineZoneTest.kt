package com.ckz.hrchase.model

import com.ckz.hrchase.data.DailySignalSnapshot
import com.ckz.hrchase.data.HitterSignalSnapshot
import java.time.Instant
import java.time.LocalDate
import org.junit.Assert.assertTrue
import org.junit.Test

class PatternLearningEngineZoneTest {
    @Test
    fun zoneAndArsenalInteractionCanBeLearnedFromOutcomes() {
        val date = LocalDate.of(2026, 9, 1)
        val hitters = (0 until 400).map { id ->
            val exposed = id < 100
            val homer = if (exposed) id % 7 == 0 else id % 32 == 0
            HitterSignalSnapshot(
                date = date,
                playerId = id,
                recentPower = if (exposed) 67.0 else 48.0,
                powerPressure = if (exposed) 64.0 else 48.0,
                pitcherMatchup = if (exposed) 67.0 else 50.0,
                environment = 55.0,
                seasonPower = if (exposed) 67.0 else 52.0,
                platoon = if (exposed) 66.0 else 50.0,
                contactProfile = if (exposed) 65.0 else 52.0,
                pitchArsenalFit = if (exposed) 76.0 else 50.0,
                pitchArsenalConfidence = .65,
                attackZoneFit = if (exposed) 74.0 else 48.0,
                attackZoneConfidence = .70,
                outcomeHomeRun = homer
            )
        }
        val profile = PatternLearningEngine().build(
            listOf(DailySignalSnapshot(date, Instant.now(), hitters))
        )
        assertTrue(profile.patterns.any {
            it.key.contains("attackZoneFit") && it.posteriorLift > 1.0
        })
    }
}
