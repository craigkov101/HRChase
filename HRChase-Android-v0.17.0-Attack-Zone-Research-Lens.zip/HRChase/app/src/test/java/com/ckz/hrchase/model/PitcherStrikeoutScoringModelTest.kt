package com.ckz.hrchase.model

import com.ckz.hrchase.data.*
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant

class PitcherStrikeoutScoringModelTest {
    private val game = GameInfo(
        gamePk = 1,
        gameDate = Instant.parse("2026-09-06T23:10:00Z"),
        status = "Preview",
        detailedStatus = "Scheduled",
        awayTeam = TeamRef(1, "A", "A"),
        homeTeam = TeamRef(2, "B", "B"),
        venueName = "Park"
    )

    @Test
    fun strikeoutProneLineupRaisesProjection() {
        val model = PitcherStrikeoutScoringModel()
        val pitcher = PitcherProfile(
            person = PersonRef(99, "Starter", pitchHand = "R"),
            seasonStats = PitchingStats(gamesStarted = 25, inningsPitched = 150.0, strikeouts = 180, walks = 45, battersFaced = 610, era = 3.30, whip = 1.12),
            recentBattedBallsAllowed = emptyList()
        )
        fun hitter(id: Int, kRate: Double) = HitterCandidate(
            player = PersonRef(id, "H$id", batSide = if (id % 2 == 0) "L" else "R"),
            team = game.homeTeam,
            opponent = game.awayTeam,
            game = game,
            battingOrder = id,
            lineupOfficial = true,
            seasonStats = HittingStats(plateAppearances = 400, strikeouts = (400 * kRate).toInt()),
            opponentPitcher = pitcher,
            recentBattedBalls = emptyList(),
            todayBattedBalls = emptyList(),
            score = ScoreBreakdown(50.0,50.0,50.0,50.0,50.0,50.0,50.0, emptyList(), emptyList())
        )
        val highK = (1..9).map { hitter(it, .30) }
        val lowK = (1..9).map { hitter(it, .16) }
        val high = model.score(pitcher, game.awayTeam, game.homeTeam, game, highK, PitcherStrikeoutScoringModel.Context())
        val low = model.score(pitcher, game.awayTeam, game.homeTeam, game, lowK, PitcherStrikeoutScoringModel.Context())
        assertTrue(high.projectedStrikeouts > low.projectedStrikeouts)
        assertTrue(high.opponentStrikeoutScore > low.opponentStrikeoutScore)
    }
}
