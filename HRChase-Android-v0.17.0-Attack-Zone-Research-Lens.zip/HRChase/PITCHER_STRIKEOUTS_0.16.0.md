# HR Chase v0.16.0 — Pitcher Strikeout Model

The H+R+RBI prediction mode was removed. A dedicated **Ks** tab now ranks probable MLB starters by projected strikeouts.

## Projection architecture

Projected strikeouts are modeled as:

**Projected batters faced × matchup strikeout rate**

The matchup strikeout rate uses the starter's season/recent K%, the opponent lineup's season and handedness-split K%, 14/7/3-day strikeout form, recent pitch-level whiff samples, and Savant pitch-type whiff/K alignment when those fields are available.

Workload is estimated from season/recent batters faced and innings per start with command/quality and opponent-strength adjustments.

## Data shown

- projected Ks and projection range
- pitcher K ability
- opponent strikeout tendency
- handedness matchup
- pitch-arsenal whiff fit
- recent form
- workload support
- command/efficiency context
- official/projected lineup confidence

## Learning

Pregame starter projections are frozen at first pitch. Completed starts are graded against actual strikeouts. The app tracks mean absolute error, prediction bias, 6+ K hit rates, and calibration buckets. Persistent bias can make a small capped correction to future projections after enough resolved starts.

No missing Savant or split data is fabricated; unavailable inputs remain neutral and lower confidence.
