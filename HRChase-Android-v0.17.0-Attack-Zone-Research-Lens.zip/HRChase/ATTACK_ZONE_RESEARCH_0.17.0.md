# HR Chase v0.17.0 — Attack Zone + Research Lens

## Goal
Convert useful, repeatedly visible tactics from public MLB HR research into transparent HR Chase signals without copying or claiming access to any private/proprietary formula.

## Public-research observations incorporated
Across public slate breakdowns and matchup cards, the recurring ideas were: game-by-game shortlisting; distinct matchup/process/ceiling reads; zone fit; barrel and hard-hit quality; launch/air-ball shape; swing-and-miss; current form; pitch-mix matchup; handedness; lineup position; and sample-size caution.

## Attack Zone Fit
HR Chase now reuses MLB Gameday pitch coordinates from the recent game feeds it already downloads. No new per-player HTTP request is needed.

For each current hitter/pitcher matchup:
- the starter's recent pitch locations are placed into a transparent 3x3 attack grid;
- the hitter's recent located batted balls are scored by EV, launch angle and outcome quality in the same grid;
- pitcher attack share is multiplied by the hitter's regressed damage score in each cell;
- confidence uses pitcher pitch sample, hitter located-BBE sample and how much of the pitcher's attack map has hitter evidence;
- missing coordinate data remains missing. It is never estimated.

The score is intentionally sample-shrunk toward 50. One hard-hit ball in a cell cannot create an elite Zone score.

## Research Lens
Every hitter now has three independent reads:
- **MATCH** — today's pitcher matchup, Arsenal + Handedness convergence, Attack Zone Fit, environment and lineup context.
- **PROCESS** — stable power/contact foundation, swing-and-miss, Power Pressure and 14-day/current form.
- **CEILING** — raw one-swing upside from established power, batted-ball quality, current power pressure and environment.

The daily Target Score uses: 39% PROCESS, 29% Pattern Engine, 22% MATCH, 10% CEILING, followed by small convergence/veto/tie-break adjustments.

## Outcome learning
Attack Zone Fit is saved in true pregame snapshots. Pattern Engine can learn whether Zone + Arsenal, Zone + Pitcher Matchup, or other interactions actually produce higher HR rates. The app does not assume Zone Fit is predictive forever; historical outcomes must support it.

## UI
Target cards show MATCH / PROCESS / CEILING and ZONE when available. Player Profile has a dedicated Attack Zone Fit section with sample size, confidence, mapped pitcher-share coverage and the strongest overlapping zones.

## Important limitation
This is HR Chase's independent implementation based on public concepts. It does not reproduce another creator's unpublished definitions for Match, Test, Ceiling, Zone, PB, or any other proprietary score.
