package com.ckz.hrchase.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Casino
import androidx.compose.material.icons.outlined.SportsBaseball
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.activity.compose.BackHandler
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ckz.hrchase.AppUiState
import com.ckz.hrchase.MainViewModel
import com.ckz.hrchase.ParlayFocus
import com.ckz.hrchase.data.BattedBall
import com.ckz.hrchase.data.BatterVsPitcherStats
import com.ckz.hrchase.data.GameInfo
import com.ckz.hrchase.data.HitterCandidate
import com.ckz.hrchase.data.MustHaveMetrics
import com.ckz.hrchase.data.PostgameReview
import com.ckz.hrchase.data.PreviousNightSummary
import com.ckz.hrchase.data.ModelLearningProfile
import com.ckz.hrchase.data.NightPatternProfile
import com.ckz.hrchase.data.RecentHittingStats
import com.ckz.hrchase.data.PitcherProfile
import com.ckz.hrchase.data.PersonRef
import com.ckz.hrchase.data.TeamRef
import com.ckz.hrchase.model.HrScoringModel
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

private val AppBackground = Color(0xFF050A12)
private val AppBackgroundTop = Color(0xFF07111F)
private val AppSurface = Color(0xFF0B1320)
private val AppSurfaceRaised = Color(0xFF101C2D)
private val AppSurfaceSoft = Color(0xFF0D1726)
private val AppOutline = Color(0xFF1C2B3D)
private val AppPrimary = Color(0xFF49C8FF)
private val AppViolet = Color(0xFF8B7CFF)
private val AppGreen = Color(0xFF2FE6A6)
private val AppAmber = Color(0xFFFFB547)
private val AppRed = Color(0xFFFF637D)
private val AppMuted = Color(0xFF8194AA)
private val AppText = Color(0xFFF6FAFF)
private val AppSubtleText = Color(0xFFC7D4E2)
private val AppGlow = Color(0xFF80E2FF)

private val HrChaseColors = darkColorScheme(
    primary = AppPrimary,
    onPrimary = Color(0xFF03131E),
    secondary = AppViolet,
    tertiary = AppGreen,
    background = AppBackground,
    onBackground = AppText,
    surface = AppSurface,
    onSurface = AppText,
    surfaceVariant = AppSurfaceRaised,
    onSurfaceVariant = Color(0xFFC4D2DF),
    outline = AppOutline,
    error = AppRed
)

private enum class Tab { GAMES, TARGETS, HEATING, HOT, PARLAYS, TRACKED }

private data class GameAlert(
    val title: String,
    val detail: String,
    val color: Color
)


private data class PowerMetricSignal(
    val label: String,
    val display: String,
    val quality: Double
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HrChaseApp(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var tab by remember { mutableIntStateOf(0) }
    val selected = remember(
        state.selectedPlayerId,
        state.selectedProfileCandidate,
        state.selectedProfileDate,
        state.selectedDate,
        state.board?.lastUpdated
    ) {
        val id = state.selectedPlayerId
        val saved = state.selectedProfileCandidate
        val live = id?.let { playerId ->
            state.board?.takeIf { it.date == state.selectedProfileDate }
                ?.candidates
                ?.firstOrNull { it.player.id == playerId }
        }
        when {
            live != null && saved != null -> live.copy(
                vsPitcherStats = saved.vsPitcherStats ?: live.vsPitcherStats,
                pitchArsenalMatch = live.pitchArsenalMatch ?: saved.pitchArsenalMatch
            )
            live != null -> live
            else -> saved ?: id?.let { playerId -> state.board?.candidates?.firstOrNull { it.player.id == playerId } }
        }
    }
    val profileOpen = state.selectedPlayerId != null

    BackHandler(enabled = profileOpen) {
        viewModel.selectPlayer(null)
    }
    BackHandler(enabled = !profileOpen && tab != 0) {
        tab = 0
    }

    MaterialTheme(colorScheme = HrChaseColors) {
        CompositionLocalProvider(LocalContentColor provides AppText) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(AppBackgroundTop, AppBackground)))
            ) {
                if (profileOpen) {
                    if (selected != null) {
                        val profileDate = state.selectedProfileDate ?: state.selectedDate
                        PlayerDetailScreen(
                            candidate = selected,
                            profileDate = profileDate,
                            pickScore = viewModel.pickScore(selected),
                            signalScore = viewModel.signalLensScore(selected),
                            signalTier = viewModel.signalTier(selected),
                            signalReasons = viewModel.signalReasons(selected),
                            swingMissScore = viewModel.swingMissScore(selected),
                            teamDepthScore = viewModel.teamBarrelDepthScore(selected),
                            bvpLoading = state.isProfileBvpLoading,
                            tracked = state.tracked.any { it.playerId == selected.player.id && it.date == profileDate },
                            onBack = { viewModel.selectPlayer(null) },
                            onTrack = { viewModel.toggleTracked(selected, profileDate) }
                        )
                    } else {
                        PlayerProfileLoadingScreen(
                            loading = state.isProfileLoading,
                            error = state.profileError,
                            onBack = { viewModel.selectPlayer(null) }
                        )
                    }
                } else {
                    Scaffold(
                        containerColor = Color.Transparent,
                        topBar = { PremiumHeader(isLoading = state.isLoading) },
                        bottomBar = {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(AppBackgroundTop.copy(alpha = 0.985f))
                                    .navigationBarsPadding()
                            ) {
                                HorizontalDivider(color = AppOutline.copy(alpha = 0.72f), thickness = 1.dp)
                                NavigationBar(
                                    containerColor = Color.Transparent,
                                    tonalElevation = 0.dp,
                                    modifier = Modifier.fillMaxWidth().height(64.dp)
                                ) {
                                    NavigationBarItem(
                                        selected = tab == 0,
                                        onClick = { tab = 0 },
                                        icon = { Icon(Icons.Outlined.SportsBaseball, null, modifier = Modifier.size(22.dp)) },
                                        label = { Text("Games", fontWeight = FontWeight.SemiBold, fontSize = 9.sp) },
                                        colors = navColors()
                                    )
                                    NavigationBarItem(
                                        selected = tab == 1,
                                        onClick = { tab = 1 },
                                        icon = { Icon(Icons.Default.Star, null, modifier = Modifier.size(22.dp)) },
                                        label = { Text("Targets", fontWeight = FontWeight.SemiBold, fontSize = 9.sp) },
                                        colors = navColors()
                                    )
                                    NavigationBarItem(
                                        selected = tab == 2,
                                        onClick = { tab = 2 },
                                        icon = { Icon(Icons.Default.TrendingUp, null, modifier = Modifier.size(22.dp)) },
                                        label = { Text("Heating", fontWeight = FontWeight.SemiBold, fontSize = 9.sp) },
                                        colors = navColors()
                                    )
                                    NavigationBarItem(
                                        selected = tab == 3,
                                        onClick = { tab = 3 },
                                        icon = { Icon(Icons.Default.LocalFireDepartment, null, modifier = Modifier.size(22.dp)) },
                                        label = { Text("Hot", fontWeight = FontWeight.SemiBold, fontSize = 9.sp) },
                                        colors = navColors()
                                    )
                                    NavigationBarItem(
                                        selected = tab == 4,
                                        onClick = { tab = 4 },
                                        icon = { Icon(Icons.Outlined.Casino, null, modifier = Modifier.size(22.dp)) },
                                        label = { Text("Parlays", fontWeight = FontWeight.SemiBold, fontSize = 9.sp) },
                                        colors = navColors()
                                    )
                                    NavigationBarItem(
                                        selected = tab == 5,
                                        onClick = { tab = 5 },
                                        icon = { Icon(Icons.Outlined.StarBorder, null, modifier = Modifier.size(22.dp)) },
                                        label = { Text("Tracked", fontWeight = FontWeight.SemiBold, fontSize = 9.sp) },
                                        colors = navColors()
                                    )
                                }
                            }
                        }
                    ) { padding ->
                        PullToRefreshBox(
                            isRefreshing = state.isLoading,
                            onRefresh = { viewModel.refresh() },
                            modifier = Modifier.fillMaxSize()
                        ) {
                            when (tab) {
                                0 -> GamesScreen(state, viewModel, padding)
                                1 -> TargetsScreen(state, viewModel, padding)
                                2 -> HeatingScreen(state, viewModel, padding)
                                3 -> HotScreen(state, viewModel, padding)
                                4 -> ParlaysScreen(state, viewModel, padding)
                                else -> TrackedScreen(state, viewModel, padding)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PremiumHeader(isLoading: Boolean) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(
                Brush.horizontalGradient(
                    listOf(
                        AppBackgroundTop,
                        Color(0xFF071827),
                        AppBackgroundTop
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 18.dp, end = 12.dp, top = 10.dp, bottom = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(43.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(
                                AppPrimary.copy(alpha = 0.22f),
                                AppViolet.copy(alpha = 0.11f)
                            )
                        )
                    )
                    .border(1.dp, AppPrimary.copy(alpha = 0.35f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Outlined.SportsBaseball,
                    contentDescription = null,
                    tint = AppGlow,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        "HR",
                        color = AppPrimary,
                        fontWeight = FontWeight.Black,
                        fontStyle = FontStyle.Italic,
                        fontSize = 28.sp,
                        letterSpacing = (-0.8).sp,
                        lineHeight = 28.sp
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(
                        "CHASE",
                        color = AppText,
                        fontWeight = FontWeight.Black,
                        fontSize = 23.sp,
                        letterSpacing = 2.0.sp,
                        lineHeight = 26.sp
                    )
                    Spacer(Modifier.width(8.dp))
                    Surface(
                        color = AppViolet.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(50.dp),
                        border = BorderStroke(1.dp, AppViolet.copy(alpha = 0.24f))
                    ) {
                        Text(
                            "MODEL",
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                            color = AppViolet,
                            fontWeight = FontWeight.Black,
                            fontSize = 9.sp,
                            letterSpacing = 0.9.sp
                        )
                    }
                }
                Row(
                    modifier = Modifier.padding(top = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "HOME RUN INTELLIGENCE",
                        color = AppSubtleText,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 9.5.sp,
                        letterSpacing = 1.55.sp
                    )
                    Spacer(Modifier.width(7.dp))
                    Text(
                        "• built by Cxaig",
                        color = AppMuted.copy(alpha = 0.88f),
                        fontWeight = FontWeight.Medium,
                        fontSize = 8.sp,
                        letterSpacing = 0.25.sp
                    )
                }
            }

        }
        if (isLoading) {
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = AppPrimary,
                trackColor = Color.Transparent
            )
        } else {
            HorizontalDivider(color = AppOutline.copy(alpha = 0.55f), thickness = 1.dp)
        }
    }
}

@Composable
private fun SleekPanel(
    modifier: Modifier = Modifier,
    accent: Color = AppPrimary,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(
                        AppSurfaceRaised.copy(alpha = 0.78f),
                        AppSurface.copy(alpha = 0.96f),
                        AppBackgroundTop.copy(alpha = 0.94f)
                    )
                )
            )
            .border(1.dp, accent.copy(alpha = 0.20f), shape)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(2.dp)
                .background(Brush.horizontalGradient(listOf(accent.copy(alpha = 0.70f), Color.Transparent)))
                .align(Alignment.TopCenter)
        )
        content()
    }
}

@Composable
private fun navColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = AppPrimary,
    selectedTextColor = AppText,
    indicatorColor = AppPrimary.copy(alpha = 0.14f),
    unselectedIconColor = AppMuted,
    unselectedTextColor = AppMuted
)

@Composable
private fun GamesScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val board = state.board
    var expandedGamePk by remember(state.selectedDate) { mutableStateOf<Long?>(null) }
    BackHandler(enabled = expandedGamePk != null) {
        expandedGamePk = null
    }
    val eligible = remember(
        board?.lastUpdated, state.selectedDate, state.showRemainingOnly,
        state.officialLineupsOnly, state.sortMode, state.attackStrongOnly, state.weights
    ) { viewModel.eligibleCandidates(state) }
    val trackedIds = remember(state.tracked, state.selectedDate) {
        state.tracked.asSequence().filter { it.date == state.selectedDate }.map { it.playerId }.toSet()
    }
    val candidatesByGame = remember(eligible) { eligible.groupBy { it.game.gamePk } }
    val candidateGameIds = candidatesByGame.keys
    val games = board?.games.orEmpty()
        .filter { game -> state.isLoading || game.gamePk in candidateGameIds }
        .sortedBy { it.gameDate }

    Column(
        Modifier
            .fillMaxSize()
            .padding(padding)
            .background(Color.Transparent)
    ) {
        DateControls(state, viewModel)
        SimpleFilters(state, viewModel)
        LoadState(state, viewModel)

        if (!state.isLoading && board != null && games.isEmpty()) {
            EmptyState("No games match the current lineup filters.")
        } else if (board == null && state.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AppPrimary)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    ScreenIntro(
                        eyebrow = "TODAY'S SLATE",
                        title = "Best HR spots by game",
                        subtitle = "Tap a matchup to open every available hitter from both teams, ranked by the HR model with pitcher alerts and weather context."
                    )
                }

                board?.previousNight?.takeIf { it.finalGames > 0 }?.let { previous ->
                    item(key = "previous-night-${previous.date}") {
                        LastNightHomeRunsCard(previous, state.learningProfile, state.lastNightPattern, board.candidates, viewModel)
                    }
                }

                items(games, key = { it.gamePk }, contentType = { "game-card" }) { game ->
                    val gameCandidates = candidatesByGame[game.gamePk].orEmpty()
                    val rankedHitters = gameCandidates.sortedByDescending(viewModel::pickScore)
                    val expanded = expandedGamePk == game.gamePk
                    GameCard(
                        game = game,
                        candidates = gameCandidates,
                        topHitters = rankedHitters,
                        viewModel = viewModel,
                        trackedIds = trackedIds,
                        expanded = expanded,
                        onToggle = {
                            expandedGamePk = if (expanded) null else game.gamePk
                        }
                    )
                }

                item {
                    Text(
                        "Rankings are research signals, not guarantees. Home runs remain high-variance events.",
                        style = MaterialTheme.typography.labelSmall,
                        color = AppMuted,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun LastNightHomeRunsCard(
    summary: PreviousNightSummary,
    learning: ModelLearningProfile,
    pattern: NightPatternProfile,
    todayCandidates: List<HitterCandidate>,
    viewModel: MainViewModel
) {
    var expanded by remember(summary.date) { mutableStateOf(false) }
    val visible = if (expanded) summary.homers else summary.homers.take(8)
    val dateLabel = summary.date.format(DateTimeFormatter.ofPattern("MMM d"))

    SleekPanel(
        modifier = Modifier.fillMaxWidth(),
        accent = AppAmber
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(43.dp),
                    shape = CircleShape,
                    color = AppAmber.copy(alpha = 0.13f),
                    border = BorderStroke(1.dp, AppAmber.copy(alpha = 0.32f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Outlined.SportsBaseball, contentDescription = null, tint = AppAmber)
                    }
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "LAST NIGHT • $dateLabel",
                        color = AppAmber,
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.labelLarge,
                        letterSpacing = 0.7.sp
                    )
                    Text(
                        "${summary.totalHomeRuns} home runs",
                        color = AppText,
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text(
                        "${summary.uniqueHitters} hitters across ${summary.finalGames} final games",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }

            if (visible.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                visible.forEachIndexed { index, homer ->
                    if (index > 0) HorizontalDivider(color = AppOutline.copy(alpha = 0.45f))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.openPlayerProfile(homer.playerId, summary.date) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PlayerAvatar(
                            player = PersonRef(homer.playerId, homer.playerName),
                            team = homer.team,
                            size = 34.dp
                        )
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    homer.playerName,
                                    color = AppText,
                                    fontWeight = FontWeight.Black,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                if (homer.homeRuns > 1) {
                                    Surface(
                                        shape = RoundedCornerShape(50.dp),
                                        color = AppAmber.copy(alpha = 0.14f)
                                    ) {
                                        Text(
                                            "${homer.homeRuns} HR",
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                            color = AppAmber,
                                            fontWeight = FontWeight.Black,
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                }
                            }
                            val details = buildList {
                                homer.team?.abbreviation?.let { add(it) }
                                homer.maxExitVelocity?.let { add("${"%.1f".format(it)} mph") }
                                homer.longestDistanceFt?.let { add("${it.roundToInt()} ft") }
                                if (homer.pitchTypes.isNotEmpty()) add(homer.pitchTypes.take(2).joinToString("/"))
                            }.joinToString(" • ")
                            if (details.isNotBlank()) {
                                Text(details, color = AppMuted, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }

                if (summary.homers.size > 8) {
                    TextButton(
                        onClick = { expanded = !expanded },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(if (expanded) "Show less" else "Show all ${summary.homers.size} hitters")
                    }
                }
            }

            HorizontalDivider(color = AppOutline.copy(alpha = 0.55f), modifier = Modifier.padding(vertical = 10.dp))
            Text(
                "WHAT THEY HAD IN COMMON",
                color = AppPrimary,
                fontWeight = FontWeight.Black,
                style = MaterialTheme.typography.labelLarge,
                letterSpacing = 0.55.sp
            )
            Text(
                "Pregame traits shared by last night's HR hitters, plus direct full-profile comparisons against today's bats.",
                color = AppMuted,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 3.dp, bottom = 7.dp)
            )

            if (pattern.isUsable && pattern.signals.isNotEmpty()) {
                pattern.signals.take(4).forEach { signal ->
                    val coverage = (signal.homerCoverage * 100.0).roundToInt()
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                signal.label,
                                color = AppText,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                "${signal.homerCount}/${signal.homerTotal} HR hitters • ${coverage}% coverage • ${"%.2f".format(signal.hrRateLift)}× baseline HR rate",
                                color = AppMuted,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                        Text(
                            "+${(signal.homerAverage - signal.fieldAverage).coerceAtLeast(0.0).roundToInt()}",
                            color = if (signal.hrRateLift >= 1.25) AppGreen else AppPrimary,
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
                Text(
                    "Convergence: HR hitters averaged ${"%.1f".format(pattern.homerGreenLightsAverage)} green signals vs ${"%.1f".format(pattern.fieldGreenLightsAverage)} across the full slate.",
                    color = AppMuted,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(top = 3.dp)
                )
                if (pattern.references.isNotEmpty()) {
                    Text(
                        "Profile Echo also compares today's complete 8-signal profile to each actual HR hitter's saved pregame profile. This catches distinct winning archetypes that can disappear inside group averages.",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 5.dp)
                    )
                }

                val todayMatches = remember(todayCandidates, pattern) {
                    todayCandidates.asSequence()
                        .map { it to viewModel.lastNightPatternScore(it) }
                        .filter { (_, score) -> score >= 62.0 }
                        .sortedByDescending { it.second }
                        .take(5)
                        .toList()
                }
                if (todayMatches.isNotEmpty()) {
                    Text(
                        "TODAY'S CLOSEST PATTERN MATCHES",
                        color = AppAmber,
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                    )
                    todayMatches.forEach { (candidate, score) ->
                        val reasons = viewModel.lastNightPatternReasons(candidate)
                        val echoScore = viewModel.lastNightProfileEchoScore(candidate)
                        val closestProfile = viewModel.lastNightClosestProfiles(candidate, 1).firstOrNull()
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.openPlayerProfile(candidate.player.id) }
                                .padding(vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            PlayerAvatar(candidate.player, candidate.team, 30.dp)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    candidate.player.name,
                                    color = AppText,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    buildString {
                                        append(candidate.team.abbreviation)
                                        if (reasons.isNotEmpty()) append(" • ").append(reasons.joinToString(" + "))
                                        if (echoScore > 0.0) append(" • Echo ").append(echoScore.roundToInt())
                                        closestProfile?.let { (name, similarity) ->
                                            append(" • like ").append(name).append(" ").append(similarity)
                                        }
                                    },
                                    color = AppMuted,
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Text(
                                score.roundToInt().toString(),
                                color = if (score >= 80.0) AppGreen else AppPrimary,
                                fontWeight = FontWeight.Black,
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                    }
                    Text(
                        "Pattern Match blends common denominators with Profile Echo. It remains a small next-day ranking layer: yesterday can separate close calls, but it cannot overpower season power, matchup, contact quality or arsenal fit.",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            } else {
                Text(
                    if (pattern.gradedHitters > 0) {
                        "Pattern Lab is collecting a larger same-day sample before using last night's common traits in today's ranking."
                    } else {
                        "Pattern Lab activates after HR Chase has a complete pregame signal snapshot to grade the next morning."
                    },
                    color = AppMuted,
                    style = MaterialTheme.typography.labelSmall
                )
            }

            HorizontalDivider(color = AppOutline.copy(alpha = 0.55f), modifier = Modifier.padding(vertical = 10.dp))
            val learningText = if (learning.isActive) {
                "Outcome learning active • ${learning.resolvedHitterGames} graded hitter-games • ${learning.homeRuns} HR outcomes"
            } else {
                "Learning warm-up • ${learning.resolvedHitterGames} graded hitter-games • ${learning.homeRuns} HR outcomes"
            }
            Text(
                learningText,
                color = if (learning.isActive) AppGreen else AppPrimary,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelMedium
            )
            Text(
                "HR Chase saves the day's pregame signal snapshot, grades it against the next morning's real HR results, and uses the growing history only as a small calibration layer so one noisy night cannot overfit the rankings.",
                color = AppMuted,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
private fun GameCard(
    game: GameInfo,
    candidates: List<HitterCandidate>,
    topHitters: List<HitterCandidate>,
    viewModel: MainViewModel,
    trackedIds: Set<Int>,
    expanded: Boolean,
    onToggle: () -> Unit
) {
    val time = game.gameDate.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("h:mm a"))
    val alerts = remember(game, candidates) { gameAlerts(game, candidates) }
    val avgEnvironment = candidates.map { it.score.environment }.average().takeUnless { it.isNaN() } ?: 50.0

    SleekPanel(
        modifier = Modifier.fillMaxWidth(),
        accent = scoreColor(avgEnvironment.roundToInt())
    ) {
        Column(Modifier.fillMaxWidth()) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onToggle)
                    .padding(16.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    TeamBadge(game.awayTeam)
                    Text("@", color = AppMuted, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp))
                    TeamBadge(game.homeTeam)
                    Spacer(Modifier.weight(1f))
                    EnvironmentBadge(avgEnvironment)
                }

                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(time, color = AppText, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                    Text(
                        game.venueName,
                        color = AppMuted,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).padding(start = 12.dp)
                    )
                }

                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = AppPrimary.copy(alpha = 0.10f),
                        shape = RoundedCornerShape(50.dp),
                        border = BorderStroke(1.dp, AppPrimary.copy(alpha = 0.18f))
                    ) {
                        Text(
                            "${topHitters.size} RANKED HR LOOKS",
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                            color = AppPrimary,
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.labelSmall,
                            letterSpacing = 0.4.sp
                        )
                    }
                    if (alerts.isNotEmpty()) {
                        Spacer(Modifier.width(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = null,
                                tint = AppAmber,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(
                                "${alerts.size} alert${if (alerts.size == 1) "" else "s"}",
                                color = AppAmber,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Text(
                        if (expanded) "CLOSE" else "VIEW ALL",
                        color = if (expanded) AppMuted else AppText,
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.labelMedium,
                        letterSpacing = 0.4.sp
                    )
                }
            }

            if (expanded) {
                HorizontalDivider(color = AppOutline.copy(alpha = 0.70f))
                Column(Modifier.padding(horizontal = 16.dp, vertical = 13.dp)) {
                    if (alerts.isNotEmpty()) {
                        alerts.forEach { alert -> AlertRow(alert) }
                        Spacer(Modifier.height(10.dp))
                    }

                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "ALL RANKED HITTERS",
                            fontWeight = FontWeight.Black,
                            color = AppText,
                            letterSpacing = 0.7.sp,
                            style = MaterialTheme.typography.labelLarge
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Every available hitter from both teams",
                            color = AppMuted,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                    Spacer(Modifier.height(7.dp))

                    if (topHitters.isEmpty()) {
                        Text("Lineup data is not available yet.", color = AppMuted, style = MaterialTheme.typography.bodySmall)
                    } else {
                        topHitters.forEachIndexed { index, candidate ->
                            if (index > 0) {
                                HorizontalDivider(
                                    color = AppOutline.copy(alpha = 0.55f),
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            }
                            GameHitterRow(
                                rank = index + 1,
                                candidate = candidate,
                                score = viewModel.pickScore(candidate),
                                tracked = candidate.player.id in trackedIds,
                                onOpen = { viewModel.openPlayerProfile(candidate.player.id) },
                                onTrack = { viewModel.toggleTracked(candidate) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TeamBadge(team: TeamRef) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 3.dp)
    ) {
        TeamLogo(team = team, size = 27.dp)
        Spacer(Modifier.width(7.dp))
        Text(
            team.abbreviation,
            fontWeight = FontWeight.Black,
            color = AppText,
            fontSize = 18.sp,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
private fun TeamLogo(
    team: TeamRef,
    size: androidx.compose.ui.unit.Dp = 22.dp,
    container: Boolean = false
) {
    val logoUrl = "https://www.mlbstatic.com/team-logos/${team.id}.svg"
    val shape = RoundedCornerShape((size.value * 0.30f).dp)
    Box(
        modifier = Modifier
            .size(size)
            .then(
                if (container) {
                    Modifier
                        .clip(shape)
                        .background(AppSurfaceRaised.copy(alpha = 0.72f))
                        .padding(1.dp)
                } else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = logoUrl,
            contentDescription = "${team.name} logo",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Fit
        )
    }
}


@Composable
private fun PlayerAvatar(
    player: PersonRef,
    team: TeamRef?,
    size: androidx.compose.ui.unit.Dp = 32.dp
) {
    var imageFailed by remember(player.id) { mutableStateOf(false) }
    val headshotUrl = "https://img.mlbstatic.com/mlb-photos/image/upload/w_96,q_auto:best/v1/people/${player.id}/headshot/67/current"
    val badgeSize = (size.value * 0.42f).dp

    Box(modifier = Modifier.size(size), contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(AppSurfaceRaised)
                .border(1.dp, AppOutline, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (!imageFailed) {
                AsyncImage(
                    model = headshotUrl,
                    contentDescription = "${player.name} headshot",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    onError = { imageFailed = true }
                )
            } else if (team != null) {
                TeamLogo(team = team, size = (size.value * 0.62f).dp)
            } else {
                Icon(
                    Icons.Default.Person,
                    contentDescription = null,
                    tint = AppMuted,
                    modifier = Modifier.size((size.value * 0.58f).dp)
                )
            }
        }

        if (team != null && !imageFailed && size.value >= 28f) {
            Surface(
                modifier = Modifier.size(badgeSize).align(Alignment.BottomEnd),
                shape = CircleShape,
                color = AppBackground,
                border = BorderStroke(1.dp, AppOutline)
            ) {
                Box(Modifier.padding(1.dp), contentAlignment = Alignment.Center) {
                    TeamLogo(team = team, size = (badgeSize.value * 0.78f).dp)
                }
            }
        }
    }
}

@Composable
private fun GameHitterRow(
    rank: Int,
    candidate: HitterCandidate,
    score: Double,
    tracked: Boolean,
    onOpen: () -> Unit,
    onTrack: () -> Unit
) {
    val scoreInt = score.roundToInt()
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
            .padding(vertical = 5.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                modifier = Modifier.size(46.dp),
                shape = RoundedCornerShape(13.dp),
                color = scoreColor(scoreInt).copy(alpha = 0.13f),
                border = BorderStroke(1.dp, scoreColor(scoreInt).copy(alpha = 0.35f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(scoreInt.toString(), fontWeight = FontWeight.Black, color = scoreColor(scoreInt))
                        Text("PICK", style = MaterialTheme.typography.labelSmall, color = AppMuted)
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PlayerAvatar(candidate.player, candidate.team, size = 32.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "#$rank  ${candidate.player.name}",
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                }
                Text(
                    "${candidate.team.abbreviation} • Batting #${candidate.battingOrder} • vs ${candidate.opponentPitcher?.person?.name ?: "TBD"}",
                    color = AppMuted,
                    style = MaterialTheme.typography.labelMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onTrack) {
                Icon(
                    if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder,
                    contentDescription = "Track",
                    tint = if (tracked) AppAmber else AppMuted
                )
            }
        }

        Text(
            quickJustification(candidate),
            modifier = Modifier.padding(start = 56.dp, end = 4.dp),
            color = Color(0xFFD3E0EA),
            style = MaterialTheme.typography.bodySmall
        )
        candidate.vsPitcherStats?.let { bvp ->
            Text(
                bvpSummary(bvp),
                modifier = Modifier.padding(start = 56.dp, end = 4.dp, top = 3.dp),
                color = bvpColor(bvp),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold
            )
        }
        candidate.score.notes.firstOrNull()?.let { note ->
            Text(
                note,
                modifier = Modifier.padding(start = 56.dp, end = 4.dp, top = 2.dp),
                color = AppMuted,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun EnvironmentBadge(value: Double) {
    val label = when {
        value >= 72 -> "HR+"
        value < 40 -> "HR−"
        else -> "NEUTRAL"
    }
    val color = when {
        value >= 72 -> AppGreen
        value < 40 -> AppAmber
        else -> AppMuted
    }
    Surface(color = color.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp), border = BorderStroke(1.dp, color.copy(alpha = 0.30f))) {
        Text(label, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = color, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun AlertRow(alert: GameAlert) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(bottom = 5.dp),
        color = alert.color.copy(alpha = 0.09f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, alert.color.copy(alpha = 0.24f))
    ) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Warning, null, tint = alert.color, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Column {
                Text(alert.title, color = alert.color, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                Text(alert.detail, color = Color(0xFFD3E0EA), style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

private fun gameAlerts(game: GameInfo, candidates: List<HitterCandidate>): List<GameAlert> = buildList {
    val pitchers = candidates.mapNotNull { it.opponentPitcher }.distinctBy { it.person.id }
    pitchers.filter(::isTopPitcher).forEach { pitcher ->
        val bits = listOfNotNull(
            pitcher.seasonStats.era?.let { "${"%.2f".format(it)} ERA" },
            pitcher.seasonStats.hrPer9?.let { "${"%.2f".format(it)} HR/9" }
        ).joinToString(" • ")
        val affectedTeam = candidates.firstOrNull { it.opponentPitcher?.person?.id == pitcher.person.id }?.team?.abbreviation
        val title = affectedTeam?.let { "Tough matchup for $it hitters" } ?: "Pitcher warning"
        add(GameAlert(title, "${pitcher.person.name}${if (bits.isNotBlank()) " • $bits" else ""}", AppAmber))
    }

    val weather = game.weather
    val roofClosed = weather.roofType?.contains("closed", true) == true || weather.condition?.contains("dome", true) == true
    if (!roofClosed) {
        val condition = weather.condition.orEmpty()
        val badCondition = listOf("rain", "storm", "shower", "drizzle", "snow").any { condition.contains(it, true) }
        if (badCondition) {
            add(GameAlert("Weather warning", condition.ifBlank { "Possible precipitation" }, AppRed))
        }

        val wind = weather.wind.orEmpty()
        val mph = Regex("(\\d+)\\s*mph", RegexOption.IGNORE_CASE).find(wind)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
        if (wind.contains("in", true) && mph >= 10) {
            add(GameAlert("Wind warning", "$wind may suppress carry", AppAmber))
        }
        weather.temperatureF?.let { temp ->
            if (temp <= 52) add(GameAlert("Cold-weather warning", "$temp°F can reduce home-run carry", AppAmber))
        }
    }
}

private fun isTopPitcher(pitcher: PitcherProfile): Boolean {
    val stats = pitcher.seasonStats
    if (stats.inningsPitched in 0.0..<20.0) return false
    val era = stats.era
    val hr9 = stats.hrPer9
    return (era != null && hr9 != null && era <= 3.25 && hr9 <= 1.10) ||
        (era != null && era <= 2.80) ||
        (hr9 != null && hr9 <= 0.75)
}

private fun quickJustification(candidate: HitterCandidate): String {
    val p = candidate.score.powerPressure.roundToInt()
    val m = candidate.score.pitcherMatchup.roundToInt()
    val c = candidate.score.recentPower.roundToInt()
    val e = candidate.score.environment.roundToInt()
    val bvp = candidate.vsPitcherStats
    val arsenal = candidate.pitchArsenalMatch
    return when {
        arsenal != null && arsenal.batterHrSample >= 3 && arsenal.confidence >= .30 && arsenal.score >= 72.0 -> {
            val top = arsenal.feastPitches.take(2).joinToString(" + ") { "${it.name} ${it.homeRuns} HR" }
            "Pitch arsenal fit ${arsenal.score.roundToInt()}: $top align with today's pitcher mix. Pressure $p • Matchup $m."
        }
        bvp != null && bvp.plateAppearances >= 8 && ((bvp.ops ?: 0.0) >= .900 || bvp.homeRuns >= 2) ->
            "BvP edge plus current form: ${bvp.hits}-for-${bvp.atBats}, ${bvp.homeRuns} HR vs this pitcher. Pressure $p • Matchup $m."
        candidate.platoonStats != null && candidate.platoonStats.plateAppearances >= 35 && candidate.score.platoon >= 70 -> {
            val hand = candidate.opponentPitcher?.person?.pitchHand ?: "?"
            val splitIso = candidate.platoonStats.iso?.let { String.format("%.3f", it).removePrefix("0") } ?: "—"
            "Strong vs ${hand}HP split: $splitIso ISO • ${candidate.platoonStats.homeRuns} HR in ${candidate.platoonStats.plateAppearances} PA. Matchup $m."
        }
        p >= 72 && m >= 72 -> "Best combo: Power Pressure $p + Matchup $m."
        p >= 75 -> "Power Pressure $p: recent HR-quality contact is building. Matchup $m."
        m >= 75 -> "Matchup $m: favorable opposing-pitcher profile. Recent contact $c."
        c >= 75 -> "Recent contact $c is hot; matchup $m keeps him in play."
        e >= 75 -> "Strong park/weather spot ($e) with a balanced hitter profile."
        else -> "Balanced profile: Pressure $p • Matchup $m • Contact $c."
    }
}

private fun bvpSummary(bvp: BatterVsPitcherStats): String {
    val avg = bvp.avg?.let { String.format("%.3f", it).removePrefix("0") } ?: "—"
    val ops = bvp.ops?.let { String.format("%.3f", it).removePrefix("0") } ?: "—"
    val sample = if (bvp.plateAppearances < 8) " • small sample" else ""
    return "BvP: ${bvp.hits}-for-${bvp.atBats} ($avg) • ${bvp.homeRuns} HR • $ops OPS$sample"
}

private fun bvpColor(bvp: BatterVsPitcherStats): Color = when {
    bvp.plateAppearances < 5 -> AppMuted
    bvp.homeRuns >= 2 || (bvp.ops ?: 0.0) >= .950 -> AppGreen
    (bvp.ops ?: 0.0) < .600 && bvp.plateAppearances >= 8 -> AppAmber
    else -> Color(0xFFD3E0EA)
}

@Composable
private fun TargetsScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val board = state.board
    val targets = remember(
        board?.lastUpdated, state.selectedDate, state.showRemainingOnly,
        state.officialLineupsOnly, state.sortMode, state.attackStrongOnly, state.weights
    ) { viewModel.topTargets(15, state) }
    val trackedIds = remember(state.tracked, state.selectedDate) {
        state.tracked.asSequence().filter { it.date == state.selectedDate }.map { it.playerId }.toSet()
    }
    val reviewingYesterday = state.selectedDate == LocalDate.now().minusDays(1)

    LaunchedEffect(state.selectedDate, board?.lastUpdated) {
        if (reviewingYesterday && board != null) viewModel.loadPostgameTargetStats()
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(padding)
            .background(Color.Transparent)
    ) {
        DateControls(state, viewModel)
        SimpleFilters(state, viewModel)
        LoadState(state, viewModel)

        if (board == null && state.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AppPrimary)
            }
        } else if (!state.isLoading && board != null && targets.isEmpty()) {
            EmptyState("No eligible hitters are available for the current filters.")
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    ScreenIntro(
                        eyebrow = "DAILY TARGET BOARD",
                        title = "Top 15 HR targets",
                        subtitle = if (reviewingYesterday)
                            "Yesterday's target board with a postgame diagnosis explaining hits, near-misses, matchup-driven misses and genuinely poor nights."
                        else
                            "The strongest power profiles on the slate, filtered through matchup, pressure, environment and BvP context."
                    )
                }

                item {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(22.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(AppPrimary.copy(alpha = 0.16f), AppViolet.copy(alpha = 0.11f), AppSurface)
                                )
                            )
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = AppPrimary.copy(alpha = 0.14f),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, AppPrimary.copy(alpha = 0.28f))
                                ) {
                                    Text("10", modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp), color = AppPrimary, fontWeight = FontWeight.Black)
                                }
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text("Power Profile", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                                    Text("Ten must-have HR signals", color = AppMuted, style = MaterialTheme.typography.labelMedium)
                                }
                            }
                            Text(
                                "Barrel • Pull Barrel • Pull Air • Hard Hit • Distance • EV • ISO • Fly Ball • Pull • Blast",
                                color = AppSubtleText,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(top = 11.dp)
                            )
                        }
                    }
                }

                item {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(AppViolet.copy(alpha = 0.09f))
                            .border(1.dp, AppViolet.copy(alpha = 0.24f), RoundedCornerShape(20.dp))
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text("POWER SIGNAL LENS", color = AppViolet, fontWeight = FontWeight.Black, letterSpacing = 0.8.sp, style = MaterialTheme.typography.labelLarge)
                            Text(
                                "Hitter-first form • barrel/hard-hit/air quality • recent swing-and-miss • pitcher resistance • platoon edge • lineup barrel depth.",
                                color = AppSubtleText,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(top = 5.dp)
                            )
                            Text(
                                "A convergence layer combining recent form, batted-ball quality, swing-and-miss, pitcher resistance, platoon context and lineup power.",
                                color = AppMuted,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(top = 5.dp)
                            )
                        }
                    }
                }

                itemsIndexed(
                    targets,
                    key = { _, candidate -> "target-${candidate.game.gamePk}-${candidate.player.id}" },
                    contentType = { _, _ -> "target-card" }
                ) { index, candidate ->
                    val rank = index + 1
                    val metrics = viewModel.mustHaveMetrics(candidate)
                    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        TargetCard(
                            rank = rank,
                            candidate = candidate,
                            targetScore = viewModel.targetScore(candidate),
                            powerProfileScore = viewModel.mustHavePowerScore(candidate),
                            signalScore = viewModel.signalLensScore(candidate),
                            signalTier = viewModel.signalTier(candidate),
                            signalReasons = viewModel.signalReasons(candidate),
                            whiffRate = viewModel.recentWhiffRate(candidate),
                            swingSample = candidate.recentPlateDiscipline.swings,
                            metrics = metrics,
                            tracked = candidate.player.id in trackedIds,
                            onOpen = { viewModel.openPlayerProfile(candidate.player.id) },
                            onTrack = { viewModel.toggleTracked(candidate) }
                        )
                        if (reviewingYesterday && candidate.game.status.equals("Final", ignoreCase = true)) {
                            val stats = state.postgameStats[candidate.player.id]
                            val loading = candidate.player.id in state.postgameStatsLoading
                            PostgameReviewCard(
                                review = if (!loading) viewModel.postgameReview(candidate, stats) else null,
                                loading = loading
                            )
                        }
                    }
                }

                item {
                    Text(
                        "Power metrics use recent MLB tracked batted balls plus season ISO. Pull-based rates use MLB hit locations/spray coordinates (description fallback), and Blast% is a 105+ mph / 15–35° proxy. Small samples are automatically blended toward season power.",
                        style = MaterialTheme.typography.labelSmall,
                        color = AppMuted,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PostgameReviewCard(review: PostgameReview?, loading: Boolean) {
    val accent = when {
        review == null -> AppMuted
        "MODEL HIT" in review.label || "GOOD READ" in review.label -> AppGreen
        "GOOD NIGHT" in review.label || "BARREL" in review.label || "HARD CONTACT" in review.label -> AppPrimary
        "MATCHUP" in review.label -> AppAmber
        else -> AppRed
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.07f)),
        shape = RoundedCornerShape(17.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.28f))
    ) {
        Column(Modifier.padding(horizontal = 13.dp, vertical = 11.dp)) {
            Text("POSTGAME REVIEW", color = accent, fontWeight = FontWeight.Black, letterSpacing = 0.7.sp, style = MaterialTheme.typography.labelSmall)
            if (loading) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 7.dp)) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = AppPrimary)
                    Spacer(Modifier.width(8.dp))
                    Text("Loading final game line…", color = AppMuted, style = MaterialTheme.typography.bodySmall)
                }
            } else if (review != null) {
                Text(review.label, color = accent, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 5.dp))
                Text(review.resultLine, color = AppSubtleText, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
                Text(review.explanation, color = AppMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 5.dp))
            } else {
                Text("Final game line unavailable.", color = AppMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}

@Composable
private fun TargetCard(
    rank: Int,
    candidate: HitterCandidate,
    targetScore: Double,
    powerProfileScore: Double,
    signalScore: Double,
    signalTier: String,
    signalReasons: List<String>,
    whiffRate: Double?,
    swingSample: Int,
    metrics: MustHaveMetrics,
    tracked: Boolean,
    onOpen: () -> Unit,
    onTrack: () -> Unit
) {
    val target = targetScore.roundToInt()
    val profile = powerProfileScore.roundToInt()
    val signal = signalScore.roundToInt()
    val signals = powerMetricSignals(metrics).take(3)

    SleekPanel(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        accent = if (rank <= 3) scoreColor(target) else AppPrimary.copy(alpha = 0.72f)
    ) {
        Column(Modifier.padding(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    color = scoreColor(target).copy(alpha = 0.13f),
                    border = BorderStroke(1.dp, scoreColor(target).copy(alpha = 0.35f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(target.toString(), fontWeight = FontWeight.Black, color = scoreColor(target))
                            Text("TARGET", style = MaterialTheme.typography.labelSmall, color = AppMuted)
                        }
                    }
                }

                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PlayerAvatar(candidate.player, candidate.team, size = 34.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "#$rank  ${candidate.player.name}",
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        if (rank <= 3) {
                            Surface(color = AppViolet.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp)) {
                                Text("ELITE", modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp), color = AppViolet, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                    Text(
                        "${candidate.team.abbreviation} • Batting #${candidate.battingOrder} • vs ${candidate.opponentPitcher?.person?.name ?: "TBD"}",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onTrack) {
                    Icon(
                        if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder,
                        contentDescription = "Track",
                        tint = if (tracked) AppAmber else AppMuted
                    )
                }
            }

            Spacer(Modifier.height(7.dp))
            Text(
                targetReason(candidate, profile),
                color = Color(0xFFD3E0EA),
                style = MaterialTheme.typography.bodySmall
            )

            Row(
                modifier = Modifier.padding(top = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Surface(color = AppViolet.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp), border = BorderStroke(1.dp, AppViolet.copy(alpha = 0.28f))) {
                    Text("SIGNAL $signal • $signalTier", modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp), color = AppViolet, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
                }
                if (whiffRate != null && swingSample >= 6) {
                    Text("Whiff ${"%.1f".format(whiffRate * 100)}% ($swingSample swings)", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                }
            }
            if (signalReasons.isNotEmpty()) {
                Text(
                    signalReasons.joinToString("  •  "),
                    color = AppSubtleText,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 5.dp)
                )
            }

            Spacer(Modifier.height(7.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                MiniScorePill("POWER", profile, Modifier.weight(1f))
                MiniScorePill("PRESSURE", candidate.score.powerPressure.roundToInt(), Modifier.weight(1f))
                MiniScorePill("MATCHUP", candidate.score.pitcherMatchup.roundToInt(), Modifier.weight(1f))
            }

            if (signals.isNotEmpty()) {
                Text(
                    signals.joinToString("  •  ") { "${it.label} ${it.display}" },
                    color = AppPrimary,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            val sampleText = buildString {
                append("${metrics.battedBallCount} recent tracked BBE")
                if (metrics.directionalBattedBallCount > 0) append(" • ${metrics.directionalBattedBallCount} directional")
                append(" • ${(metrics.confidence * 100).roundToInt()}% profile confidence")
            }
            Text(sampleText, color = AppMuted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 4.dp))

            candidate.vsPitcherStats?.let { bvp ->
                if (bvp.plateAppearances >= 5) {
                    Text(
                        bvpSummary(bvp),
                        color = bvpColor(bvp),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun MiniScorePill(label: String, score: Int, modifier: Modifier = Modifier) {
    val color = scoreColor(score)
    Surface(
        modifier = modifier,
        color = color.copy(alpha = 0.10f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.24f))
    ) {
        Column(Modifier.padding(horizontal = 7.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(score.toString(), color = color, fontWeight = FontWeight.Black)
            Text(label, color = AppMuted, style = MaterialTheme.typography.labelSmall, maxLines = 1)
        }
    }
}

private fun targetReason(candidate: HitterCandidate, powerProfile: Int): String {
    val pressure = candidate.score.powerPressure.roundToInt()
    val matchup = candidate.score.pitcherMatchup.roundToInt()
    val bvp = candidate.vsPitcherStats
    val arsenal = candidate.pitchArsenalMatch
    return when {
        powerProfile >= 75 && pressure >= 70 && matchup >= 70 ->
            "Complete HR profile: must-have power metrics are strong and both Pressure + Matchup clear 70."
        powerProfile >= 78 && matchup >= 68 ->
            "Power-profile standout ($powerProfile) with a supportive pitcher matchup ($matchup)."
        powerProfile >= 75 ->
            "Must-have power profile is carrying the case ($powerProfile), with Pressure $pressure and Matchup $matchup."
        pressure >= 75 && matchup >= 75 ->
            "Pressure + Matchup is the hook ($pressure / $matchup), backed by a playable power profile ($powerProfile)."
        bvp != null && bvp.plateAppearances >= 8 && ((bvp.ops ?: 0.0) >= .900 || bvp.homeRuns >= 2) ->
            "Good current profile plus a meaningful BvP edge: ${bvp.hits}-for-${bvp.atBats}, ${bvp.homeRuns} HR."
        else ->
            "Balanced daily target: Power $powerProfile • Pressure $pressure • Matchup $matchup."
    }
}

private fun powerMetricSignals(metrics: MustHaveMetrics): List<PowerMetricSignal> = buildList {
    fun quality(value: Double, low: Double, high: Double): Double =
        if (high <= low) 50.0 else (((value - low) / (high - low)) * 100.0).coerceIn(0.0, 100.0)

    metrics.barrelPct?.let { add(PowerMetricSignal("Barrel", "${"%.1f".format(it)}%", quality(it, 4.0, 20.0))) }
    metrics.pullBarrelPct?.let { add(PowerMetricSignal("PullBrl", "${"%.1f".format(it)}%", quality(it, 1.0, 10.0))) }
    metrics.pullAirPct?.let { add(PowerMetricSignal("PullAir", "${"%.1f".format(it)}%", quality(it, 6.0, 28.0))) }
    metrics.hardHitPct?.let { add(PowerMetricSignal("HH", "${"%.1f".format(it)}%", quality(it, 28.0, 62.0))) }
    metrics.avgDistanceFt?.let { add(PowerMetricSignal("Dist", "${it.roundToInt()} ft", quality(it, 145.0, 285.0))) }
    metrics.avgExitVelocity?.let { add(PowerMetricSignal("EV", "${"%.1f".format(it)}", quality(it, 84.0, 95.0))) }
    metrics.iso?.let { add(PowerMetricSignal("ISO", String.format("%.3f", it).removePrefix("0"), quality(it, .110, .300))) }
    metrics.flyBallPct?.let { add(PowerMetricSignal("FB", "${"%.1f".format(it)}%", quality(it, 22.0, 48.0))) }
    metrics.pullPct?.let { add(PowerMetricSignal("Pull", "${"%.1f".format(it)}%", quality(it, 28.0, 52.0))) }
    metrics.blastPct?.let { add(PowerMetricSignal("Blast", "${"%.1f".format(it)}%", quality(it, 1.5, 12.0))) }
}.sortedByDescending { it.quality }

@Composable
private fun HeatingScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val board = state.board
    val heating = remember(
        board?.lastUpdated, state.selectedDate, state.showRemainingOnly,
        state.officialLineupsOnly, state.sortMode, state.attackStrongOnly, state.weights
    ) { viewModel.heatingCandidates(20, state) }
    val trackedIds = remember(state.tracked, state.selectedDate) {
        state.tracked.asSequence().filter { it.date == state.selectedDate }.map { it.playerId }.toSet()
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(padding)
            .background(Color.Transparent)
    ) {
        DateControls(state, viewModel)
        SimpleFilters(state, viewModel)
        LoadState(state, viewModel)

        if (board == null && state.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AppPrimary)
            }
        } else if (!state.isLoading && board != null && heating.isEmpty()) {
            EmptyState("No hitters currently clear the 3-day emerging-heat signal threshold for this slate and filters.")
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    ScreenIntro(
                        eyebrow = "LAST 3 DAYS",
                        title = "Heating up",
                        subtitle = "Catch the bat before the full hot streak becomes obvious. These hitters are showing multiple short-window signals that their contact and results are accelerating."
                    )
                }

                item {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(AppPrimary.copy(alpha = 0.07f))
                            .border(1.dp, AppPrimary.copy(alpha = 0.24f), RoundedCornerShape(20.dp))
                    ) {
                        Row(
                            Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                modifier = Modifier.size(42.dp),
                                shape = CircleShape,
                                color = AppPrimary.copy(alpha = 0.13f)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.TrendingUp, null, tint = AppPrimary)
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("EMERGING HEAT", color = AppPrimary, fontWeight = FontWeight.Black, letterSpacing = 0.7.sp)
                                Text(
                                    "A player needs multiple signals to appear here: improving 3-day production plus evidence such as hard contact, barrels, near-HR misses, low whiff, rising power pressure or a clear acceleration versus his 7-day line.",
                                    color = AppSubtleText,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(top = 3.dp)
                                )
                            }
                        }
                    }
                }

                itemsIndexed(
                    heating,
                    key = { _, candidate -> "heating-${candidate.game.gamePk}-${candidate.player.id}" },
                    contentType = { _, _ -> "heating-card" }
                ) { index, candidate ->
                    val rank = index + 1
                    val stats = viewModel.recentThreeDayStats(candidate, state)
                    if (stats != null) {
                        HeatingHitterCard(
                            rank = rank,
                            candidate = candidate,
                            stats = stats,
                            heatScore = viewModel.heatingScore(candidate, state),
                            targetScore = viewModel.targetScore(candidate),
                            signalCount = viewModel.heatingSignalCount(candidate, state),
                            acceleration = viewModel.heatingAcceleration(candidate, state),
                            reasons = viewModel.heatingReasons(candidate, state),
                            metrics = viewModel.heatingMetrics(candidate, state),
                            tracked = candidate.player.id in trackedIds,
                            onOpen = { viewModel.openPlayerProfile(candidate.player.id) },
                            onTrack = { viewModel.toggleTracked(candidate) }
                        )
                    }
                }

                item {
                    Text(
                        "The Heating board uses only the previous three completed calendar days for its box-score window and filters the already-established hottest streaks so it can focus on emerging form. Short samples are confidence-weighted and require multiple supporting signals.",
                        style = MaterialTheme.typography.labelSmall,
                        color = AppMuted,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun HeatingHitterCard(
    rank: Int,
    candidate: HitterCandidate,
    stats: RecentHittingStats,
    heatScore: Double,
    targetScore: Double,
    signalCount: Int,
    acceleration: Double,
    reasons: List<String>,
    metrics: MustHaveMetrics,
    tracked: Boolean,
    onOpen: () -> Unit,
    onTrack: () -> Unit
) {
    val heatValue = heatScore.roundToInt()
    val targetValue = targetScore.roundToInt()
    val accelValue = acceleration.roundToInt()

    SleekPanel(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        accent = if (rank <= 5) AppPrimary else AppOutline
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(52.dp),
                    shape = RoundedCornerShape(15.dp),
                    color = AppPrimary.copy(alpha = 0.11f),
                    border = BorderStroke(1.dp, AppPrimary.copy(alpha = 0.32f))
                ) {
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(heatValue.toString(), color = AppPrimary, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                        Text("HEAT", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                    }
                }
                Spacer(Modifier.width(10.dp))
                PlayerAvatar(candidate.player, candidate.team, size = 44.dp)
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "#$rank  ${candidate.player.name}",
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        "${candidate.team.abbreviation} • Batting #${candidate.battingOrder} • vs ${candidate.opponentPitcher?.person?.name ?: "TBD"}",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onTrack) {
                    Icon(
                        if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder,
                        contentDescription = "Track",
                        tint = if (tracked) AppAmber else AppMuted
                    )
                }
            }

            Spacer(Modifier.height(11.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                HotStatPill("AVG", stats.avg?.let { "%.3f".format(it).removePrefix("0") } ?: "—", Modifier.weight(1f))
                HotStatPill("OPS", stats.ops?.let { "%.3f".format(it) } ?: "—", Modifier.weight(1f))
                HotStatPill("XBH", stats.extraBaseHits.toString(), Modifier.weight(1f))
                HotStatPill("MAX EV", metrics.maxExitVelocity?.let { "%.1f".format(it) } ?: "—", Modifier.weight(1f))
            }

            Text(
                "${stats.gamesPlayed} G • ${stats.hits}-for-${stats.atBats} • ${stats.runs} R • ${stats.rbi} RBI • ${stats.homeRuns} HR • ${stats.strikeouts} K",
                color = AppSubtleText,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.padding(top = 9.dp)
            )

            if (reasons.isNotEmpty()) {
                Column(Modifier.padding(top = 9.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    reasons.forEach { reason ->
                        Row(verticalAlignment = Alignment.Top) {
                            Text("•", color = AppPrimary, fontWeight = FontWeight.Black)
                            Spacer(Modifier.width(7.dp))
                            Text(reason, color = AppSubtleText, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Surface(
                    color = AppPrimary.copy(alpha = 0.10f),
                    shape = RoundedCornerShape(50.dp),
                    border = BorderStroke(1.dp, AppPrimary.copy(alpha = 0.25f))
                ) {
                    Text(
                        "$signalCount SIGNALS",
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                        color = AppPrimary,
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
                if (accelValue >= 60) {
                    Surface(
                        color = AppGreen.copy(alpha = 0.09f),
                        shape = RoundedCornerShape(50.dp),
                        border = BorderStroke(1.dp, AppGreen.copy(alpha = 0.22f))
                    ) {
                        Text(
                            "ACCEL $accelValue",
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                            color = AppGreen,
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
                Surface(
                    color = scoreColor(targetValue).copy(alpha = 0.10f),
                    shape = RoundedCornerShape(50.dp),
                    border = BorderStroke(1.dp, scoreColor(targetValue).copy(alpha = 0.24f))
                ) {
                    Text(
                        "TODAY $targetValue",
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                        color = scoreColor(targetValue),
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
    }
}

@Composable
private fun HotScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val board = state.board
    val hot = remember(
        board?.lastUpdated, state.selectedDate, state.showRemainingOnly,
        state.officialLineupsOnly, state.sortMode, state.attackStrongOnly, state.weights
    ) { viewModel.hotCandidates(20, state) }
    val trackedIds = remember(state.tracked, state.selectedDate) {
        state.tracked.asSequence().filter { it.date == state.selectedDate }.map { it.playerId }.toSet()
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(padding)
            .background(Color.Transparent)
    ) {
        DateControls(state, viewModel)
        SimpleFilters(state, viewModel)
        LoadState(state, viewModel)

        if (board == null && state.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AppPrimary)
            }
        } else if (!state.isLoading && board != null && hot.isEmpty()) {
            EmptyState("No seven-day hitter stats are available for the current slate and filters.")
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    ScreenIntro(
                        eyebrow = "LAST 7 DAYS",
                        title = "Who's hot right now",
                        subtitle = "Today's hitters ranked by seven-day production, then checked against contact quality, near-HR pressure and today's matchup."
                    )
                }

                item {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(AppAmber.copy(alpha = 0.08f))
                            .border(1.dp, AppAmber.copy(alpha = 0.24f), RoundedCornerShape(20.dp))
                    ) {
                        Row(
                            Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                modifier = Modifier.size(42.dp),
                                shape = CircleShape,
                                color = AppAmber.copy(alpha = 0.14f)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.LocalFireDepartment, null, tint = AppAmber)
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("HOT STREAK BOARD", color = AppAmber, fontWeight = FontWeight.Black, letterSpacing = 0.7.sp)
                                Text(
                                    "Box-score heat alone isn't enough. We also show recent tracked batted-ball quality and near-home-run misses so you can see whether the streak has underlying power support.",
                                    color = AppSubtleText,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(top = 3.dp)
                                )
                            }
                        }
                    }
                }

                itemsIndexed(
                    hot,
                    key = { _, candidate -> "hot-${candidate.game.gamePk}-${candidate.player.id}" },
                    contentType = { _, _ -> "hot-card" }
                ) { index, candidate ->
                    val rank = index + 1
                    val stats = viewModel.recentWeekStats(candidate, state)
                    if (stats != null) {
                        HotHitterCard(
                            rank = rank,
                            candidate = candidate,
                            stats = stats,
                            hotScore = viewModel.hotStreakScore(candidate, state),
                            targetScore = viewModel.targetScore(candidate),
                            reasons = viewModel.hotStreakReasons(candidate, state),
                            metrics = viewModel.mustHaveMetrics(candidate),
                            tracked = candidate.player.id in trackedIds,
                            onOpen = { viewModel.openPlayerProfile(candidate.player.id) },
                            onTrack = { viewModel.toggleTracked(candidate) }
                        )
                    }
                }

                item {
                    Text(
                        "Seven-day batting stats cover the previous seven completed calendar days. Near-HR and contact-quality notes use the app's recent tracked MLB batted-ball sample and may cover fewer games when feed-loading is limited for performance.",
                        style = MaterialTheme.typography.labelSmall,
                        color = AppMuted,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun HotHitterCard(
    rank: Int,
    candidate: HitterCandidate,
    stats: RecentHittingStats,
    hotScore: Double,
    targetScore: Double,
    reasons: List<String>,
    metrics: MustHaveMetrics,
    tracked: Boolean,
    onOpen: () -> Unit,
    onTrack: () -> Unit
) {
    val hotValue = hotScore.roundToInt()
    val targetValue = targetScore.roundToInt()
    val todayTough = candidate.score.pitcherMatchup < 45.0

    SleekPanel(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        accent = if (rank <= 5) AppAmber else AppOutline
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(52.dp),
                    shape = RoundedCornerShape(15.dp),
                    color = AppAmber.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, AppAmber.copy(alpha = 0.34f))
                ) {
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(hotValue.toString(), color = AppAmber, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                        Text("HOT", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                    }
                }
                Spacer(Modifier.width(10.dp))
                PlayerAvatar(candidate.player, candidate.team, size = 44.dp)
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "#$rank  ${candidate.player.name}",
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        "${candidate.team.abbreviation} • Batting #${candidate.battingOrder} • vs ${candidate.opponentPitcher?.person?.name ?: "TBD"}",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onTrack) {
                    Icon(
                        if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder,
                        contentDescription = "Track",
                        tint = if (tracked) AppAmber else AppMuted
                    )
                }
            }

            Spacer(Modifier.height(11.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                HotStatPill("AVG", stats.avg?.let { "%.3f".format(it).removePrefix("0") } ?: "—", Modifier.weight(1f))
                HotStatPill("OPS", stats.ops?.let { "%.3f".format(it) } ?: "—", Modifier.weight(1f))
                HotStatPill("HR", stats.homeRuns.toString(), Modifier.weight(1f))
                HotStatPill("XBH", stats.extraBaseHits.toString(), Modifier.weight(1f))
            }

            Text(
                "${stats.gamesPlayed} G • ${stats.hits}-for-${stats.atBats} • ${stats.runs} R • ${stats.rbi} RBI • ${stats.walks} BB • ${stats.strikeouts} K",
                color = AppSubtleText,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.padding(top = 9.dp)
            )

            if (reasons.isNotEmpty()) {
                Column(Modifier.padding(top = 9.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    reasons.forEach { reason ->
                        Row(verticalAlignment = Alignment.Top) {
                            Text("•", color = AppAmber, fontWeight = FontWeight.Black)
                            Spacer(Modifier.width(7.dp))
                            Text(reason, color = AppSubtleText, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Surface(
                    color = scoreColor(targetValue).copy(alpha = 0.10f),
                    shape = RoundedCornerShape(50.dp),
                    border = BorderStroke(1.dp, scoreColor(targetValue).copy(alpha = 0.24f))
                ) {
                    Text(
                        "TODAY $targetValue",
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                        color = scoreColor(targetValue),
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
                metrics.maxExitVelocity?.let {
                    Text("Max EV ${"%.1f".format(it)}", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                }
            }

            if (todayTough) {
                Text(
                    "Hot bat, but today's pitcher matchup is tougher than average (${candidate.score.pitcherMatchup.roundToInt()}).",
                    color = AppAmber,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 7.dp)
                )
            }
        }
    }
}

@Composable
private fun HotStatPill(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = AppSurfaceRaised.copy(alpha = 0.62f),
        shape = RoundedCornerShape(9.dp)
    ) {
        Column(Modifier.padding(vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = AppText, fontWeight = FontWeight.Black)
            Text(label, color = AppMuted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun ParlaysScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    var legCount by remember { mutableIntStateOf(2) }
    var variant by remember { mutableIntStateOf(0) }
    var focuses by remember { mutableStateOf(setOf(ParlayFocus.BALANCED)) }

    fun toggleFocus(option: ParlayFocus) {
        focuses = if (option in focuses) {
            val next = focuses - option
            if (next.isEmpty()) setOf(ParlayFocus.BALANCED) else next
        } else {
            focuses + option
        }
        variant = 0
    }

    val parlay = remember(
        state.board?.lastUpdated,
        state.selectedDate,
        state.showRemainingOnly,
        state.officialLineupsOnly,
        legCount,
        variant,
        focuses
    ) {
        viewModel.generateCombinedParlay(legCount, variant, focuses, state)
    }
    val evaluation = remember(parlay, focuses, state.board?.lastUpdated) {
        viewModel.evaluateCombinedParlay(parlay, focuses, state)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding).background(Color.Transparent),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ScreenIntro(
                eyebrow = "PARLAY LAB",
                title = "Build the card your way",
                subtitle = "Select one filter or stack several together. Combined filters use AND logic, then rotate through quality-controlled combinations."
            )
        }

        item { DateControls(state, viewModel) }

        item {
            SleekPanel(accent = AppViolet) {
                Column(Modifier.padding(14.dp)) {
                    Text(
                        "GENERATOR FOCUS",
                        color = AppMuted,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.7.sp,
                        style = MaterialTheme.typography.labelLarge
                    )
                    Spacer(Modifier.height(8.dp))

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        ParlayFocusChip(
                            label = "Balanced",
                            selected = ParlayFocus.BALANCED in focuses,
                            modifier = Modifier.weight(1f)
                        ) { toggleFocus(ParlayFocus.BALANCED) }
                        ParlayFocusChip(
                            label = "Pure Power",
                            selected = ParlayFocus.PURE_POWER in focuses,
                            modifier = Modifier.weight(1f)
                        ) { toggleFocus(ParlayFocus.PURE_POWER) }
                        ParlayFocusChip(
                            label = "Heating",
                            selected = ParlayFocus.HEATING_UP in focuses,
                            modifier = Modifier.weight(1f)
                        ) { toggleFocus(ParlayFocus.HEATING_UP) }
                    }
                    Spacer(Modifier.height(7.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        ParlayFocusChip(
                            label = "Hot Now",
                            selected = ParlayFocus.HOT_NOW in focuses,
                            modifier = Modifier.weight(1f)
                        ) { toggleFocus(ParlayFocus.HOT_NOW) }
                        ParlayFocusChip(
                            label = "Matchup Edge",
                            selected = ParlayFocus.MATCHUP_EDGE in focuses,
                            modifier = Modifier.weight(1f)
                        ) { toggleFocus(ParlayFocus.MATCHUP_EDGE) }
                    }

                    Spacer(Modifier.height(8.dp))
                    Surface(
                        color = if (focuses.size > 1) AppGreen.copy(alpha = 0.10f) else AppSurfaceRaised,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (focuses.size > 1) AppGreen.copy(alpha = 0.28f) else AppOutline)
                    ) {
                        Text(
                            if (focuses.size > 1) "STACKED FILTERS • AND MODE • ${focuses.size} ACTIVE" else "MULTI-SELECT READY • TAP ANY FILTERS TO COMBINE",
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                            color = if (focuses.size > 1) AppGreen else AppMuted,
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        viewModel.parlayCombinedDescription(focuses),
                        color = AppSubtleText,
                        style = MaterialTheme.typography.bodySmall
                    )

                    Spacer(Modifier.height(16.dp))
                    Text(
                        "PARLAY SIZE",
                        color = AppMuted,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.7.sp,
                        style = MaterialTheme.typography.labelLarge
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        (1..5).forEach { legs ->
                            FilterChip(
                                selected = legCount == legs,
                                onClick = { legCount = legs; variant = 0 },
                                label = { Text(legs.toString(), fontWeight = FontWeight.Bold) },
                                modifier = Modifier.weight(1f),
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = AppSurfaceRaised,
                                    selectedContainerColor = AppPrimary.copy(alpha = 0.18f),
                                    selectedLabelColor = AppPrimary
                                )
                            )
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { variant += 1 },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(15.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AppPrimary, contentColor = Color(0xFF04131D))
                    ) {
                        Icon(Icons.Outlined.Casino, null)
                        Spacer(Modifier.width(7.dp))
                        Text(
                            if (legCount == 1) "GENERATE ANOTHER STRAIGHT" else "GENERATE ANOTHER ${legCount}-LEG",
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.25.sp,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        if (state.isLoading) {
            item { LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = AppPrimary, trackColor = AppSurfaceRaised) }
        }

        if (!state.isLoading && parlay.isEmpty()) {
            item { EmptyCard(if (focuses.size > 1) "Not enough hitters qualify for every selected filter. Remove one filter, lower the parlay size, or try again after more data loads." else "Not enough eligible hitters yet. Try again after lineups and recent-form data load.") }
        } else if (parlay.isNotEmpty()) {
            item {
                SleekPanel(accent = scoreColor(evaluation.rating)) {
                    Column(Modifier.padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                modifier = Modifier.size(68.dp),
                                color = scoreColor(evaluation.rating).copy(alpha = 0.13f),
                                shape = CircleShape,
                                border = BorderStroke(1.dp, scoreColor(evaluation.rating).copy(alpha = 0.35f))
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        evaluation.rating.toString(),
                                        color = scoreColor(evaluation.rating),
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    "${evaluation.label} RELATIVE HIT RATING",
                                    color = scoreColor(evaluation.rating),
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 0.4.sp,
                                    style = MaterialTheme.typography.labelLarge
                                )
                                Text(
                                    if (legCount == 1) "${viewModel.parlayCombinedLabel(focuses)} straight HR pick" else "${viewModel.parlayCombinedLabel(focuses)} ${legCount}-leg HR card",
                                    fontWeight = FontWeight.Black,
                                    style = MaterialTheme.typography.titleLarge
                                )
                                Text(
                                    "Avg leg ${evaluation.averageLegScore} • floor ${evaluation.weakestLegScore} • ${evaluation.uniqueGames}/${parlay.size} unique games",
                                    color = AppMuted,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }

                        Spacer(Modifier.height(7.dp))
                        Text(
                            evaluation.note,
                            color = AppSubtleText,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "Comparative model grade — not a calibrated probability.",
                            color = AppMuted,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(top = 3.dp)
                        )
                    }
                }
            }

            item {
                SleekPanel(accent = AppGreen) {
                    Column(Modifier.padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text(
                                    if (legCount == 1) "Straight HR pick" else "Suggested ${legCount}-leg HR parlay",
                                    fontWeight = FontWeight.Black,
                                    style = MaterialTheme.typography.titleLarge
                                )
                                if (legCount == 1) {
                                    val straightCount = viewModel.straightCombinedCandidates(focuses, state).size.coerceAtLeast(1)
                                    val displayed = Math.floorMod(variant * 5 + viewModel.parlayCombinedRotationOffset(focuses), straightCount) + 1
                                    Text("Rotation $displayed of $straightCount • ${viewModel.parlayCombinedLabel(focuses)}", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                                } else {
                                    Text("Generation ${variant + 1} • ${viewModel.parlayCombinedLabel(focuses)}", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            Surface(color = AppGreen.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp)) {
                                Text(
                                    "ROTATION ON",
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                                    color = AppGreen,
                                    fontWeight = FontWeight.Black,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }

                        Spacer(Modifier.height(10.dp))
                        parlay.forEachIndexed { index, candidate ->
                            if (index > 0) HorizontalDivider(color = AppOutline, modifier = Modifier.padding(vertical = 7.dp))
                            ParlayLegRow(
                                number = index + 1,
                                candidate = candidate,
                                score = viewModel.parlayCombinedScore(candidate, focuses, state),
                                reason = viewModel.parlayCombinedLegReason(candidate, focuses, state)
                            ) {
                                viewModel.openPlayerProfile(candidate.player.id)
                            }
                        }
                    }
                }
            }

            if (legCount > 1) {
                item {
                    SectionCard("How this generation works") {
                        Text("• ${viewModel.parlayCombinedDescription(focuses)}", color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall)
                        Text("• Generate Another rotates through a deeper competitive pool instead of only swapping the same top few names.", color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 5.dp))
                        Text("• Same-game and same-team repeats are penalized, and a weak individual leg drags down the card rating.", color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 5.dp))
                        Text("• The first card is the pure highest-rated build; later generations trade a small amount of model rank for meaningful variety while staying inside a quality window.", color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 5.dp))
                    }
                }
            }
        }

        item {
            Text(
                "HR outcomes are high-variance. The card rating is useful for comparing generated slips, but it is not a guaranteed hit rate or sportsbook probability.",
                style = MaterialTheme.typography.labelSmall,
                color = AppMuted
            )
        }
    }
}

@Composable
private fun ParlayFocusChip(
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = {
            Text(
                label,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        },
        modifier = modifier,
        colors = FilterChipDefaults.filterChipColors(
            containerColor = AppSurfaceRaised,
            selectedContainerColor = AppViolet.copy(alpha = 0.18f),
            selectedLabelColor = Color(0xFFC7C0FF)
        )
    )
}

@Composable
private fun ParlayLegRow(
    number: Int,
    candidate: HitterCandidate,
    score: Double,
    reason: String,
    onOpen: () -> Unit
) {
    val scoreInt = score.roundToInt()
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(vertical = 3.dp),
        verticalAlignment = Alignment.Top
    ) {
        Surface(
            modifier = Modifier.size(38.dp),
            color = scoreColor(scoreInt).copy(alpha = 0.13f),
            shape = CircleShape,
            border = BorderStroke(1.dp, scoreColor(scoreInt).copy(alpha = 0.35f))
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(number.toString(), fontWeight = FontWeight.Black, color = scoreColor(scoreInt))
            }
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                PlayerAvatar(candidate.player, candidate.team, size = 30.dp)
                Spacer(Modifier.width(8.dp))
                Text(
                    candidate.player.name,
                    fontWeight = FontWeight.Black,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Text(scoreInt.toString(), fontWeight = FontWeight.Black, color = scoreColor(scoreInt))
            }
            Text(
                "${candidate.team.abbreviation} vs ${candidate.opponent.abbreviation} • ${candidate.game.gameDate.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("h:mm a"))}",
                style = MaterialTheme.typography.labelMedium,
                color = AppMuted
            )
            Text(
                reason,
                color = Color(0xFFD3E0EA),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 3.dp)
            )
        }
    }
}

@Composable
private fun DateControls(state: AppUiState, viewModel: MainViewModel) {
    val minimumDate = LocalDate.now().minusDays(1)
    val canGoBack = state.selectedDate.isAfter(minimumDate)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = { viewModel.changeDate(-1) },
            enabled = canGoBack,
            modifier = Modifier.size(38.dp)
        ) {
            Icon(
                Icons.Default.ChevronLeft,
                "Previous day",
                tint = if (canGoBack) AppSubtleText else AppMuted.copy(alpha = 0.35f)
            )
        }

        Column(
            modifier = Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                state.selectedDate.format(DateTimeFormatter.ofPattern("EEE, MMM d")),
                fontWeight = FontWeight.Black,
                color = AppText,
                fontSize = 18.sp,
                letterSpacing = 0.15.sp
            )
            state.board?.let {
                Text(
                    "${it.games.size} GAMES",
                    color = AppPrimary,
                    fontWeight = FontWeight.Black,
                    fontSize = 9.5.sp,
                    letterSpacing = 1.25.sp,
                    modifier = Modifier.padding(top = 1.dp)
                )
            }
        }

        IconButton(
            onClick = { viewModel.changeDate(1) },
            modifier = Modifier.size(38.dp)
        ) {
            Icon(Icons.Default.ChevronRight, "Next", tint = AppSubtleText)
        }
    }
}

@Composable
private fun SimpleFilters(state: AppUiState, viewModel: MainViewModel) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 3.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FilterChip(
            selected = state.showRemainingOnly,
            onClick = { viewModel.toggleRemainingOnly() },
            label = { Text("Remaining", fontWeight = FontWeight.SemiBold) },
            shape = RoundedCornerShape(50.dp),
            colors = simpleChipColors()
        )
        FilterChip(
            selected = state.officialLineupsOnly,
            onClick = { viewModel.toggleOfficialOnly() },
            label = { Text("Official lineups", fontWeight = FontWeight.SemiBold) },
            shape = RoundedCornerShape(50.dp),
            colors = simpleChipColors()
        )
    }
}

@Composable
private fun simpleChipColors() = FilterChipDefaults.filterChipColors(
    containerColor = AppSurface,
    labelColor = AppMuted,
    selectedContainerColor = AppPrimary.copy(alpha = 0.15f),
    selectedLabelColor = AppPrimary
)

@Composable
private fun LoadState(state: AppUiState, viewModel: MainViewModel) {
    if (state.isLoading) {
        Column {
            LinearProgressIndicator(Modifier.fillMaxWidth(), color = AppPrimary, trackColor = AppSurfaceRaised)
            Text(state.progress, Modifier.padding(horizontal = 15.dp, vertical = 5.dp), color = AppMuted, style = MaterialTheme.typography.labelSmall)
        }
    }
    state.error?.let { error ->
        val hasSavedBoard = state.board?.candidates?.isNotEmpty() == true
        val accent = if (hasSavedBoard) AppAmber else AppRed
        Card(
            modifier = Modifier.padding(12.dp).fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.11f)),
            border = BorderStroke(1.dp, accent.copy(alpha = 0.32f))
        ) {
            Column(Modifier.padding(12.dp)) {
                Text(
                    if (hasSavedBoard) "Refresh issue • saved data kept" else "Could not load MLB data",
                    color = accent,
                    fontWeight = FontWeight.Black
                )
                Text(error, color = AppMuted, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(7.dp))
                Button(onClick = { viewModel.refresh() }, enabled = !state.isLoading) {
                    Text(if (hasSavedBoard) "Refresh again" else "Retry")
                }
            }
        }
    }
}

@Composable
private fun EmptyState(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = AppMuted, modifier = Modifier.padding(24.dp))
    }
}

@Composable
private fun EmptyCard(text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = AppSurface), border = BorderStroke(1.dp, AppOutline)) {
        Text(text, modifier = Modifier.padding(14.dp), color = AppMuted)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlayerProfileLoadingScreen(
    loading: Boolean,
    error: String?,
    onBack: () -> Unit
) {
    Scaffold(
        containerColor = AppBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AppBackground),
                title = {
                    Column {
                        Text("Player Profile", fontWeight = FontWeight.Black)
                        Text("Loading complete HR Chase data", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            SleekPanel(accent = if (error == null) AppPrimary else AppRed) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (loading) {
                        CircularProgressIndicator(color = AppPrimary)
                        Spacer(Modifier.height(16.dp))
                        Text("Building player profile…", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Pulling the player's full matchup, power signals, splits, pitch-arsenal fit and recent contact history.",
                            color = AppMuted,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    } else {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = AppRed, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.height(10.dp))
                        Text("Profile unavailable", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                        Text(
                            error ?: "HR Chase could not build this profile right now.",
                            color = AppMuted,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlayerDetailScreen(
    candidate: HitterCandidate,
    profileDate: LocalDate,
    pickScore: Double,
    signalScore: Double,
    signalTier: String,
    signalReasons: List<String>,
    swingMissScore: Double,
    teamDepthScore: Double,
    bvpLoading: Boolean,
    tracked: Boolean,
    onBack: () -> Unit,
    onTrack: () -> Unit
) {
    val model = remember { HrScoringModel() }
    val score = pickScore.roundToInt()
    val mustHave = remember(candidate.player.id, candidate.recentBattedBalls, candidate.seasonStats) {
        model.mustHaveMetrics(candidate.player, candidate.seasonStats, candidate.recentBattedBalls)
    }

    Scaffold(
        containerColor = AppBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AppBackground),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PlayerAvatar(candidate.player, candidate.team, size = 38.dp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(candidate.player.name, fontWeight = FontWeight.Black)
                            Text(
                                "PLAYER PROFILE • ${profileDate.format(DateTimeFormatter.ofPattern("MMM d"))}",
                                color = AppMuted,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } },
                actions = {
                    IconButton(onClick = onTrack) {
                        Icon(if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder, "Track", tint = if (tracked) AppAmber else AppMuted)
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SleekPanel(accent = scoreColor(score)) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            modifier = Modifier.size(72.dp),
                            color = scoreColor(score).copy(alpha = 0.14f),
                            shape = CircleShape,
                            border = BorderStroke(2.dp, scoreColor(score).copy(alpha = 0.40f))
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(score.toString(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = scoreColor(score))
                                    Text("PICK", style = MaterialTheme.typography.labelSmall, color = AppMuted)
                                }
                            }
                        }
                        Spacer(Modifier.width(13.dp))
                        Column {
                            Text("Why we like it", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                            Text(quickJustification(candidate), color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall)
                            Text("${candidate.team.abbreviation} • Batting #${candidate.battingOrder}", color = AppMuted, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }

            item {
                SectionCard("Power signal lens") {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = AppViolet.copy(alpha = 0.13f),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, AppViolet.copy(alpha = 0.30f))
                        ) {
                            Column(Modifier.padding(horizontal = 14.dp, vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(signalScore.roundToInt().toString(), color = AppViolet, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                                Text(signalTier, color = AppViolet, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Hitter-first convergence check", fontWeight = FontWeight.Black)
                            Text(
                                if (signalReasons.isEmpty()) "No single signal dominates this matchup." else signalReasons.joinToString(" • "),
                                color = AppSubtleText,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    ScoreBar("Recent form / pressure", candidate.score.powerPressure)
                    ScoreBar("Swing & miss", swingMissScore)
                    ScoreBar("Pitcher resistance", candidate.score.pitcherMatchup)
                    NullableScoreBar("Pitch arsenal fit", candidate.pitchArsenalMatch?.score)
                    ScoreBar("Lineup barrel depth", teamDepthScore)
                    val whiff = candidate.recentPlateDiscipline.whiffRate
                    Text(
                        if (whiff != null) "Recent whiff: ${"%.1f".format(whiff * 100)}% across ${candidate.recentPlateDiscipline.swings} swings / ${candidate.recentPlateDiscipline.totalPitches} pitches." else "Recent pitch-level swing/whiff sample unavailable; season contact is used as the fallback.",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                    Text(
                        "Independent HR Chase convergence score using hitter form, contact quality, swing-and-miss, pitcher resistance, pitch-type fit, platoon context and lineup power.",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            item {
                SectionCard("Five key signals") {
                    ScoreBar("Power Pressure", candidate.score.powerPressure)
                    ScoreBar("Pitcher matchup", candidate.score.pitcherMatchup)
                    NullableScoreBar("Pitch arsenal fit", candidate.pitchArsenalMatch?.score)
                    ScoreBar("Handedness split", candidate.score.platoon)
                    ScoreBar("Recent contact", candidate.score.recentPower)
                }
            }

            item {
                SectionCard("Pitch arsenal fit") {
                    val arsenal = candidate.pitchArsenalMatch
                    val pitcherName = candidate.opponentPitcher?.person?.name ?: "today's pitcher"
                    if (arsenal == null) {
                        Text(
                            "Pitch-type data is temporarily unavailable after both Statcast and MLB fallback checks. The ranking redistributes this weight rather than inventing a score.",
                            color = AppMuted,
                            style = MaterialTheme.typography.bodySmall
                        )
                    } else {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = scoreColor(arsenal.score.roundToInt()).copy(alpha = 0.13f),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, scoreColor(arsenal.score.roundToInt()).copy(alpha = 0.32f))
                            ) {
                                Column(
                                    Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        arsenal.score.roundToInt().toString(),
                                        color = scoreColor(arsenal.score.roundToInt()),
                                        fontWeight = FontWeight.Black,
                                        style = MaterialTheme.typography.titleLarge
                                    )
                                    Text("FIT", color = AppMuted, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("HR pitch preference vs $pitcherName", fontWeight = FontWeight.Black)
                                Text(
                                    if (arsenal.batterHrSample > 0)
                                        "${arsenal.batterHrSample} season HR pitch events • ${arsenal.batterPitchSample} pitch sample • ${(arsenal.confidence * 100).roundToInt()}% confidence"
                                    else
                                        "${arsenal.batterPitchSample} pitch sample • pitch-type damage model • ${(arsenal.confidence * 100).roundToInt()}% confidence",
                                    color = AppMuted,
                                    style = MaterialTheme.typography.labelSmall
                                )
                                Text(arsenal.source, color = AppMuted, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        arsenal.feastPitches.take(4).forEach { pitch ->
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val hitterDetail = if (pitch.homeRuns > 0) {
                                    "${pitch.name}: ${pitch.homeRuns} HR (${(pitch.share * 100).roundToInt()}%)"
                                } else {
                                    val xslg = pitch.batterXslg?.let { "xSLG ${"%.3f".format(it)}" }
                                    val slg = pitch.batterSlg?.let { "SLG ${"%.3f".format(it)}" }
                                    listOfNotNull(xslg, slg).joinToString(" • ").ifBlank { pitch.name }
                                        .let { "${pitch.name}: $it" }
                                }
                                Text(
                                    hitterDetail,
                                    color = AppSubtleText,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    "$pitcherName ${(pitch.opposingPitcherUsage * 100).roundToInt()}%",
                                    color = if (pitch.opposingPitcherUsage >= .20) AppPrimary else AppMuted,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        if (arsenal.pitcherArsenal.isNotEmpty()) {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Pitcher arsenal: " + arsenal.pitcherArsenal.take(5).joinToString(" • ") { "${it.name} ${(it.share * 100).roundToInt()}%" },
                                color = AppMuted,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                        Spacer(Modifier.height(5.dp))
                        Text(
                            "Arsenal Fit now combines direct HR pitch history, the hitter's SLG/xSLG/hard-hit results by pitch type, the starter's actual usage, and how much damage that starter allows with those pitches. It carries 12% of the daily Target Score when available, with small samples regressed toward neutral.",
                            color = AppMuted,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }

            item {
                SectionCard("Must-have power metrics") {
                    Text(
                        "Power profile ${mustHave.score.roundToInt()} • ${mustHave.battedBallCount} recent tracked BBE",
                        color = scoreColor(mustHave.score.roundToInt()),
                        fontWeight = FontWeight.Black
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatCell("Barrel%", mustHave.barrelPct?.let { "%.1f%%".format(it) } ?: "—")
                        StatCell("HH%", mustHave.hardHitPct?.let { "%.1f%%".format(it) } ?: "—")
                        StatCell("EV", mustHave.avgExitVelocity?.let { "%.1f".format(it) } ?: "—")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatCell("ISO", mustHave.iso?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                        StatCell("FB%", mustHave.flyBallPct?.let { "%.1f%%".format(it) } ?: "—")
                        StatCell("Avg Dist", mustHave.avgDistanceFt?.let { "${it.roundToInt()} ft" } ?: "—")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatCell("Pull%", mustHave.pullPct?.let { "%.1f%%".format(it) } ?: "N/A")
                        StatCell("PullBrl%", mustHave.pullBarrelPct?.let { "%.1f%%".format(it) } ?: "N/A")
                        StatCell("PullAir%", mustHave.pullAirPct?.let { "%.1f%%".format(it) } ?: "N/A")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatCell("Blast%", mustHave.blastPct?.let { "%.1f%%".format(it) } ?: "—")
                        StatCell("Profile", mustHave.score.roundToInt().toString())
                        StatCell("Conf.", "${(mustHave.confidence * 100).roundToInt()}%")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatCell("Sweet Spot%", mustHave.sweetSpotPct?.let { "%.1f%%".format(it) } ?: "—")
                        StatCell("Max EV", mustHave.maxExitVelocity?.let { "%.1f".format(it) } ?: "—")
                        StatCell("K%", if (candidate.seasonStats.plateAppearances > 0) "%.1f%%".format(candidate.seasonStats.strikeouts * 100.0 / candidate.seasonStats.plateAppearances) else "—")
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Directional coverage: ${mustHave.directionalBattedBallCount}/${mustHave.battedBallCount} recent tracked BBE",
                        color = if (mustHave.directionalBattedBallCount > 0) AppSubtleText else AppAmber,
                        style = MaterialTheme.typography.labelSmall
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Pull metrics use MLB hit locations/spray coordinates with a description fallback. Blast% is our 105+ mph / 15–35° proxy. Small recent samples are down-weighted in the daily Target Score.",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            item {
                SectionCard("Opposing pitcher") {
                    val pitcher = candidate.opponentPitcher
                    if (pitcher == null) {
                        Text("Pitcher data not available yet.", color = AppMuted)
                    } else {
                        Text(pitcher.person.name, fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(7.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("ERA", pitcher.seasonStats.era?.let { "%.2f".format(it) } ?: "—")
                            StatCell("HR/9", pitcher.seasonStats.hrPer9?.let { "%.2f".format(it) } ?: "—")
                            StatCell("WHIP", pitcher.seasonStats.whip?.let { "%.2f".format(it) } ?: "—")
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("K%", pitcher.seasonStats.strikeoutRate?.let { "%.1f%%".format(it * 100.0) } ?: "—")
                            StatCell("BB%", pitcher.seasonStats.walkRate?.let { "%.1f%%".format(it * 100.0) } ?: "—")
                            StatCell("BF", pitcher.seasonStats.battersFaced.takeIf { it > 0 }?.toString() ?: "—")
                        }
                    }
                }
            }

            item {
                SectionCard("Season split vs pitcher hand") {
                    val split = candidate.platoonStats
                    val hand = candidate.opponentPitcher?.person?.pitchHand
                    if (split == null || hand == null) {
                        Text("Handedness split data is not available for this matchup.", color = AppMuted, style = MaterialTheme.typography.bodySmall)
                    } else {
                        Text("vs ${hand}HP • ${split.plateAppearances} PA", fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("HR", split.homeRuns.toString())
                            StatCell("ISO", split.iso?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("SLG", split.slg?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("OPS", split.ops?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("AVG", split.avg?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("K%", split.strikeoutRate?.let { "%.1f%%".format(it * 100.0) } ?: "—")
                            StatCell("HR/PA", split.hrPerPa?.let { "%.1f%%".format(it * 100.0) } ?: "—")
                        }
                    }
                }
            }

            item {
                SectionCard("Career vs this pitcher") {
                    val bvp = candidate.vsPitcherStats
                    val pitcherName = candidate.opponentPitcher?.person?.name ?: "today's pitcher"
                    if (bvp == null) {
                        if (bvpLoading) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = AppPrimary
                                )
                                Spacer(Modifier.width(9.dp))
                                Text(
                                    "Loading career BvP vs $pitcherName…",
                                    color = AppMuted,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        } else {
                            Text(
                                "No MLB batter-vs-pitcher history found for $pitcherName.",
                                color = AppMuted,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    } else {
                        Text("vs $pitcherName", fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("AB", bvp.atBats.toString())
                            StatCell("H", bvp.hits.toString())
                            StatCell("HR", bvp.homeRuns.toString())
                            StatCell("K", bvp.strikeouts.toString())
                        }
                        Spacer(Modifier.height(9.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("AVG", bvp.avg?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("OBP", bvp.obp?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("SLG", bvp.slg?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("OPS", bvp.ops?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (bvp.plateAppearances < 8) "Only ${bvp.plateAppearances} PA — useful context, but too small a sample to drive the pick by itself."
                            else "${bvp.plateAppearances} career PA. BvP receives a capped, sample-size-weighted boost in the Pick/Parlay score.",
                            color = AppMuted,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }

            item {
                SectionCard("Justification") {
                    candidate.score.notes.take(5).forEach { note ->
                        Text("• $note", color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 5.dp))
                    }
                }
            }

            if (candidate.recentBattedBalls.isNotEmpty()) {
                item { Text("Recent contact", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black) }
                items(candidate.recentBattedBalls.sortedByDescending { it.gameDate }.take(12)) { ball -> BattedBallRow(ball, model) }
            }
        }
    }
}

@Composable
private fun NullableScoreBar(label: String, value: Double?) {
    if (value != null) {
        ScoreBar(label, value)
        return
    }
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = AppSubtleText)
        Text("N/A", color = AppMuted, fontWeight = FontWeight.Bold)
    }
    Text(
        "Waiting for MLB pitch-type data; this metric is excluded from scoring until available.",
        color = AppMuted,
        style = MaterialTheme.typography.labelSmall
    )
}

@Composable
private fun ScoreBar(label: String, value: Double) {
    val intValue = value.roundToInt()
    Column(Modifier.padding(top = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color(0xFFD3E0EA))
            Text(intValue.toString(), color = scoreColor(intValue), fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { (value / 100.0).toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(5.dp),
            color = scoreColor(intValue),
            trackColor = AppSurfaceRaised
        )
    }
}

@Composable
private fun BattedBallRow(ball: BattedBall, model: HrScoringModel) {
    val signal = when {
        ball.isHomeRun -> "HR"
        model.isEliteNearHomeRun(ball) -> "NEAR-HR+"
        model.isNearHomeRun(ball) -> "NEAR-HR"
        model.isBarrelProxy(ball) -> "BARREL"
        model.isHardHit(ball) -> "HARD HIT"
        else -> "CONTACT"
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, AppOutline)
    ) {
        Row(Modifier.fillMaxWidth().padding(11.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(signal, fontWeight = FontWeight.Black, color = if (signal == "HR") AppGreen else AppPrimary)
                Text(ball.gameDate.toString(), color = AppMuted, style = MaterialTheme.typography.labelSmall)
            }
            Text(
                "${ball.exitVelocity?.let { "%.1f mph".format(it) } ?: "—"} • ${ball.launchAngle?.let { "%.0f°".format(it) } ?: "—"} • ${ball.distanceFt?.let { "%.0f ft".format(it) } ?: "—"}",
                color = Color(0xFFD3E0EA),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun TrackedScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val model = remember { HrScoringModel() }
    val tracked = remember(state.tracked, state.selectedDate) { state.tracked.filter { it.date == state.selectedDate } }
    val byId = remember(state.board?.lastUpdated) { state.board?.candidates?.associateBy { it.player.id }.orEmpty() }
    val trackedKey = tracked.joinToString(separator = ",") { it.playerId.toString() }

    LaunchedEffect(state.selectedDate, trackedKey) {
        viewModel.loadTrackedLast10Stats()
    }

    Column(Modifier.fillMaxSize().padding(padding).background(Color.Transparent)) {
        DateControls(state, viewModel)
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ScreenIntro(
                eyebrow = "YOUR WATCHLIST",
                title = "Tracked picks",
                subtitle = "Review the quality of the read, not only HR or no HR.",
                modifier = Modifier.weight(1f)
            )
            if (tracked.isNotEmpty()) {
                Spacer(Modifier.width(10.dp))
                TextButton(onClick = { viewModel.clearTrackedForSelectedDate() }) {
                    Text("CLEAR", color = AppRed, fontWeight = FontWeight.Black)
                }
            }
        }

        if (tracked.isEmpty()) {
            EmptyState("Star hitters from the Games tab to track them here.")
        } else {
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(tracked, key = { "${it.date}-${it.playerId}" }, contentType = { "tracked-card" }) { pick ->
                    val c = byId[pick.playerId]
                    SleekPanel(
                        modifier = Modifier.fillMaxWidth().clickable { viewModel.openPlayerProfile(pick.playerId, pick.date) },
                        accent = AppViolet
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                c?.let { PlayerAvatar(it.player, it.team, size = 34.dp) }
                                if (c != null) Spacer(Modifier.width(9.dp))
                                Text(pick.playerName, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                            }
                            Text("Tracked at ${pick.scoreAtTrack.roundToInt()} Chase Score", style = MaterialTheme.typography.bodySmall, color = AppMuted)

                            Spacer(Modifier.height(9.dp))
                            val last10 = state.trackedLast10[pick.playerId]
                            val loadingLast10 = pick.playerId in state.trackedLast10Loading
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                color = AppSurfaceSoft,
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, AppOutline.copy(alpha = 0.85f))
                            ) {
                                Column(Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "LAST 10 COMPLETED GAMES",
                                            color = AppPrimary,
                                            fontWeight = FontWeight.Black,
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                        if (last10 != null) {
                                            Text(
                                                "${last10.gamesPlayed} G",
                                                color = AppMuted,
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        }
                                    }
                                    Spacer(Modifier.height(7.dp))
                                    when {
                                        last10 != null -> {
                                            Row(
                                                Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                HotStatPill("AVG", last10.avg?.let { "%.3f".format(it).removePrefix("0") } ?: "—", Modifier.weight(1f))
                                                HotStatPill("OPS", last10.ops?.let { "%.3f".format(it) } ?: "—", Modifier.weight(1f))
                                                HotStatPill("HR", last10.homeRuns.toString(), Modifier.weight(1f))
                                                HotStatPill("RBI", last10.rbi.toString(), Modifier.weight(1f))
                                            }
                                            Text(
                                                "${last10.hits} H • ${last10.extraBaseHits} XBH • ${last10.runs} R • ${last10.walks} BB • ${last10.strikeouts} K",
                                                color = AppMuted,
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.padding(top = 7.dp)
                                            )
                                        }
                                        loadingLast10 -> Text(
                                            "Loading recent form…",
                                            color = AppMuted,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        else -> Text(
                                            "Last-10 game log is not available yet.",
                                            color = AppMuted,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }

                            Spacer(Modifier.height(9.dp))
                            if (c == null) {
                                Text("Load this date's board to evaluate contact.", color = AppMuted, style = MaterialTheme.typography.bodySmall)
                            } else {
                                val balls = c.todayBattedBalls
                                val hrs = balls.count { it.isHomeRun }
                                val hardest = balls.mapNotNull { it.exitVelocity }.maxOrNull()
                                val grade = when {
                                    hrs > 0 -> "HR HIT"
                                    balls.any { model.isEliteNearHomeRun(it) } -> "STRONG READ • ELITE NEAR-HR"
                                    balls.any { model.isNearHomeRun(it) } -> "GOOD READ • NEAR-HR"
                                    balls.any { model.isBarrelProxy(it) } -> "BARREL CONTACT • NO HR"
                                    balls.any { model.isHardHit(it) } -> "HARD CONTACT • NO HR"
                                    c.game.status.equals("Final", true) -> "QUIET CONTACT / MISS"
                                    else -> "GAME PENDING / IN PROGRESS"
                                }
                                SignalPill(grade)
                                Text("$hrs HR • ${balls.size} tracked balls • max EV ${hardest?.let { "%.1f".format(it) } ?: "—"}", style = MaterialTheme.typography.bodySmall, color = AppMuted, modifier = Modifier.padding(top = 6.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SignalPill(text: String) {
    val color = when {
        "HR HIT" in text -> AppGreen
        "STRONG" in text || "GOOD" in text -> AppPrimary
        "BARREL" in text || "HARD" in text -> AppAmber
        else -> AppMuted
    }
    Surface(color = color.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp)) {
        Text(text, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = color, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun ScreenIntro(
    eyebrow: String,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Column(modifier.padding(horizontal = 4.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .width(22.dp)
                    .height(2.dp)
                    .background(AppPrimary)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                eyebrow,
                color = AppPrimary,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.35.sp,
                fontSize = 10.sp
            )
        }
        Text(
            title,
            color = AppText,
            fontSize = 27.sp,
            lineHeight = 30.sp,
            letterSpacing = (-0.35).sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier.padding(top = 5.dp)
        )
        Text(
            subtitle,
            color = AppMuted,
            style = MaterialTheme.typography.bodySmall,
            lineHeight = 18.sp,
            modifier = Modifier.padding(top = 5.dp, end = 8.dp)
        )
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    SleekPanel(accent = AppPrimary.copy(alpha = 0.65f)) {
        Column(Modifier.padding(16.dp)) {
            Text(title.uppercase(), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black, color = AppSubtleText, letterSpacing = 0.7.sp)
            Spacer(Modifier.height(7.dp))
            content()
        }
    }
}

@Composable
private fun StatCell(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
        Text(label, color = AppMuted, style = MaterialTheme.typography.labelSmall)
    }
}

private fun scoreColor(score: Int): Color = when {
    score >= 80 -> AppGreen
    score >= 68 -> AppPrimary
    score >= 55 -> AppAmber
    else -> AppMuted
}
