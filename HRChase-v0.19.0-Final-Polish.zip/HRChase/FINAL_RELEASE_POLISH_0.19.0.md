# HR Chase v0.19.0 — Final Release Polish

## Cleaner phone-first navigation
- Reduced the always-visible bottom navigation from eight cramped destinations to five primary destinations: Games, Picks, Ks, Parlays, and More.
- Added a new More hub for Heating Up, Hot, AAA Watch, and Tracked Picks so no feature is lost.
- Back navigation from a secondary research tool returns to the More hub before returning to Games.

## Faster daily use
- Added a refresh button directly to the main header while preserving pull-to-refresh.
- Added a last-updated timestamp to the header so stale data is easier to notice.
- The AAA screen uses its own loading state, timestamp, and refresh action.
- The date selector is now explicitly limited to Today and Yesterday; the forward arrow disables on Today.

## Less screen clutter
- Reworked slate filters into one compact horizontally scrolling filter rail instead of three stacked rows.
- Added a small active-filter count so it is obvious when the board is narrowed.
- Added Today / Yesterday context pills to the date selector.
- Increased bottom-nav label and icon readability now that only five primary items are shown.

## Visual finish
- Preserved the existing HR Chase dark analytics identity, Precision badge, and built-by-Cxaig credit.
- Refined header spacing, status-bar/navigation-bar colors, refresh treatment, and secondary tool cards for a more release-ready Android feel.

## Model/data behavior
- No scoring formulas, rankings, Pattern Engine logic, Pitcher Hunt logic, or data-source calculations were changed in this release.
- This is intentionally a UI/UX and workflow polish pass before adding the ChatGPT data-export/sync layer.
