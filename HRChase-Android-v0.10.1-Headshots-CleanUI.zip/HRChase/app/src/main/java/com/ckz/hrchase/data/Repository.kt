package com.ckz.hrchase.data

import com.ckz.hrchase.model.HrScoringModel
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

private data class CurrentGameSummary(
    val gamePk: Long,
    val awayLineup: TeamLineup?,
    val homeLineup: TeamLineup?,
    val battedBalls: List<BattedBall>,
    val weather: WeatherInfo,
    val persons: Map<Int, PersonRef>,
    val pitcherStats: Map<Int, PitchingStats>
)

private data class RecentGameSummary(
    val game: GameInfo,
    val awayLineup: TeamLineup?,
    val homeLineup: TeamLineup?,
    val battedBalls: List<BattedBall>,
    val plateDiscipline: Map<Int, PlateDisciplineSample>
)

class Repository(
    private val api: MlbApi = MlbApi(),
    private val scoringModel: HrScoringModel = HrScoringModel()
) {
    suspend fun loadBoard(
        date: LocalDate,
        weights: ScoreWeights,
        lookbackDays: Int = 5,
        onProgress: (String) -> Unit = {},
        onPartialBoard: (BoardData) -> Unit = {}
    ): BoardData = coroutineScope {
        onProgress("Loading MLB schedule…")
        val schedule = api.fetchSchedule(date)
        if (schedule.isEmpty()) {
            return@coroutineScope BoardData(date, emptyList(), emptyList(), Instant.now(), 0)
        }

        // Render the slate immediately. The expensive contact/BvP enrichment continues below,
        // but users should see today's games within the first schedule request instead of staring
        // at a blank spinner.
        onPartialBoard(BoardData(date, emptyList(), schedule, Instant.now(), 0))

        val todayTeamIds = schedule.flatMap { listOf(it.awayTeam.id, it.homeTeam.id) }.toSet()
        val semaphore = Semaphore(7)

        onProgress("Loading today's lineups and game data…")
        // Keep only compact fields from today's live feeds. Retaining 15 full MLB JSONObject trees
        // was the largest memory spike in v0.8 and could cause Android to kill the app mid-refresh.
        val currentFeeds = schedule.map { game ->
            async {
                semaphore.withPermit {
                    runCatching {
                        val feed = api.fetchGameFeed(game.gamePk)
                        val away = api.extractTeamLineup(feed, "away", game.awayTeam)
                            .takeIf { it.players.isNotEmpty() }
                        val home = api.extractTeamLineup(feed, "home", game.homeTeam)
                            .takeIf { it.players.isNotEmpty() }
                        val probableIds = listOfNotNull(
                            game.awayProbablePitcher?.id,
                            game.homeProbablePitcher?.id
                        ).distinct()
                        val persons = probableIds.mapNotNull { id ->
                            api.extractPerson(feed.root, id)?.let { id to it }
                        }.toMap()
                        val pitcherStats = probableIds.mapNotNull { id ->
                            api.extractPitchingStatsFromFeed(feed.root, id)?.let { id to it }
                        }.toMap()
                        CurrentGameSummary(
                            gamePk = game.gamePk,
                            awayLineup = away,
                            homeLineup = home,
                            battedBalls = feed.battedBalls,
                            weather = feed.weather,
                            persons = persons,
                            pitcherStats = pitcherStats
                        )
                    }.getOrNull()
                }
            }
        }.awaitAll().filterNotNull().associateBy { it.gamePk }

        val recentStart = date.minusDays(lookbackDays.toLong())
        val recentEnd = date.minusDays(1)
        onProgress("Finding recent games for contact signals…")
        val recentSchedule = if (!recentEnd.isBefore(recentStart)) {
            val allRecent = runCatching { api.fetchScheduleRange(recentStart, recentEnd) }
                .getOrDefault(emptyList())
                .asSequence()
                .filter { it.status.equals("Final", true) }
                .filter { it.awayTeam.id in todayTeamIds || it.homeTeam.id in todayTeamIds }
                .distinctBy { it.gamePk }
                .sortedByDescending { it.gameDate }
                .toList()

            // First guarantee at least one recent lineup source for every team on today's slate,
            // then fill the remaining budget with the newest games. This keeps projected lineups
            // available without going back to an unbounded 70+ feed download.
            val selected = LinkedHashMap<Long, GameInfo>()
            val coveredTeams = mutableSetOf<Int>()
            for (game in allRecent) {
                val relevant = listOf(game.awayTeam.id, game.homeTeam.id).filter { it in todayTeamIds }
                if (relevant.any { it !in coveredTeams }) {
                    selected[game.gamePk] = game
                    coveredTeams += relevant
                }
                if (coveredTeams.containsAll(todayTeamIds)) break
            }
            for (game in allRecent) {
                if (selected.size >= 30) break
                selected.putIfAbsent(game.gamePk, game)
            }
            selected.values.take(30)
        } else emptyList()

        onProgress("Loading ${recentSchedule.size} recent game feeds…")
        // IMPORTANT: do not retain the full live-feed JSON for every recent game. A five-day slate
        // can contain dozens of very large JSONObject trees and can push Android over its memory
        // limit. Extract only the compact pieces we need, then let each feed be garbage-collected.
        val recentSummaries = recentSchedule.map { game ->
            async {
                semaphore.withPermit {
                    runCatching {
                        val feed = api.fetchGameFeed(game.gamePk)
                        val away = api.extractTeamLineup(feed, "away", game.awayTeam, forceProjected = true)
                            .takeIf { it.players.isNotEmpty() }
                        val home = api.extractTeamLineup(feed, "home", game.homeTeam, forceProjected = true)
                            .takeIf { it.players.isNotEmpty() }
                        RecentGameSummary(
                            game = game,
                            awayLineup = away,
                            homeLineup = home,
                            battedBalls = feed.battedBalls,
                            plateDiscipline = feed.plateDiscipline
                        )
                    }.getOrNull()
                }
            }
        }.awaitAll().filterNotNull()

        val allRecentBalls = recentSummaries.flatMap { it.battedBalls }
        val recentBallsByBatter = allRecentBalls.groupBy { it.batterId }
        val recentBallsByPitcher = allRecentBalls.groupBy { it.pitcherId }
        val recentDisciplineByBatter = mutableMapOf<Int, PlateDisciplineSample>()
        recentSummaries.forEach { summary ->
            summary.plateDiscipline.forEach { (batterId, sample) ->
                recentDisciplineByBatter[batterId] =
                    (recentDisciplineByBatter[batterId] ?: PlateDisciplineSample()) + sample
            }
        }

        // Build a most-recent real lineup for fallback when today's lineup has not posted yet.
        val latestLineupByTeam = mutableMapOf<Int, TeamLineup>()
        recentSummaries.sortedByDescending { it.game.gameDate }.forEach { summary ->
            val game = summary.game
            if (game.awayTeam.id !in latestLineupByTeam) {
                summary.awayLineup?.let { latestLineupByTeam[game.awayTeam.id] = it }
            }
            if (game.homeTeam.id !in latestLineupByTeam) {
                summary.homeLineup?.let { latestLineupByTeam[game.homeTeam.id] = it }
            }
        }

        onProgress("Adding handedness splits…")
        val season = date.year
        val splitMaps = listOf("vr", "vl").map { code ->
            async {
                semaphore.withPermit {
                    code to runCatching { api.fetchLeagueHittingSplitStats(season, code) }.getOrDefault(emptyMap())
                }
            }
        }.awaitAll().toMap()
        val vsRightPitching = splitMaps["vr"].orEmpty()
        val vsLeftPitching = splitMaps["vl"].orEmpty()

        onProgress("Building pitcher profiles…")
        val pitcherIds = schedule.flatMap { listOfNotNull(it.awayProbablePitcher?.id, it.homeProbablePitcher?.id) }.distinct()
        val pitcherProfiles = pitcherIds.map { id ->
            async {
                semaphore.withPermit {
                    val person = currentFeeds.values.firstNotNullOfOrNull { it.persons[id] }
                    var stats = currentFeeds.values.firstNotNullOfOrNull { it.pitcherStats[id] }
                    if (stats == null || stats == PitchingStats()) {
                        stats = api.fetchPitchingStats(id, season)
                    }
                    id to PitcherProfile(
                        person = person ?: PersonRef(id, "Pitcher $id"),
                        seasonStats = stats ?: PitchingStats(),
                        recentBattedBallsAllowed = recentBallsByPitcher[id].orEmpty()
                    )
                }
            }
        }.awaitAll().toMap()

        onProgress("Scoring hitters…")
        val enrichedGames = schedule.map { game ->
            val feed = currentFeeds[game.gamePk]
            if (feed != null) game.copy(weather = feed.weather) else game
        }

        val baseCandidates = buildList {
            enrichedGames.forEach { game ->
                val current = currentFeeds[game.gamePk]
                val awayOfficial = current?.awayLineup
                val homeOfficial = current?.homeLineup
                val awayLineup = awayOfficial?.takeIf { it.players.isNotEmpty() } ?: latestLineupByTeam[game.awayTeam.id]
                val homeLineup = homeOfficial?.takeIf { it.players.isNotEmpty() } ?: latestLineupByTeam[game.homeTeam.id]

                val awayPitcherId = game.awayProbablePitcher?.id
                val homePitcherId = game.homeProbablePitcher?.id
                val awayPitcherProfile = awayPitcherId?.let { pitcherProfiles[it] }
                val homePitcherProfile = homePitcherId?.let { pitcherProfiles[it] }

                awayLineup?.players?.forEach { lp ->
                    val recent = recentBallsByBatter[lp.person.id].orEmpty().sortedBy { it.gameDate }
                    val today = current?.battedBalls?.filter { it.batterId == lp.person.id }.orEmpty()
                    val platoonStats = when (homePitcherProfile?.person?.pitchHand) {
                        "R" -> vsRightPitching[lp.person.id]
                        "L" -> vsLeftPitching[lp.person.id]
                        else -> null
                    }
                    val score = scoringModel.score(
                        player = lp.person,
                        battingOrder = lp.battingOrder,
                        lineupOfficial = awayLineup.official,
                        seasonStats = lp.seasonStats,
                        platoonStats = platoonStats,
                        recentBattedBalls = recent,
                        opponentPitcher = homePitcherProfile,
                        game = game,
                        weights = weights
                    )
                    add(
                        HitterCandidate(
                            player = lp.person,
                            team = game.awayTeam,
                            opponent = game.homeTeam,
                            game = game,
                            battingOrder = lp.battingOrder,
                            lineupOfficial = awayLineup.official,
                            seasonStats = lp.seasonStats,
                            opponentPitcher = homePitcherProfile,
                            recentBattedBalls = recent,
                            todayBattedBalls = today,
                            recentPlateDiscipline = recentDisciplineByBatter[lp.person.id] ?: PlateDisciplineSample(),
                            score = score,
                            platoonStats = platoonStats
                        )
                    )
                }

                homeLineup?.players?.forEach { lp ->
                    val recent = recentBallsByBatter[lp.person.id].orEmpty().sortedBy { it.gameDate }
                    val today = current?.battedBalls?.filter { it.batterId == lp.person.id }.orEmpty()
                    val platoonStats = when (awayPitcherProfile?.person?.pitchHand) {
                        "R" -> vsRightPitching[lp.person.id]
                        "L" -> vsLeftPitching[lp.person.id]
                        else -> null
                    }
                    val score = scoringModel.score(
                        player = lp.person,
                        battingOrder = lp.battingOrder,
                        lineupOfficial = homeLineup.official,
                        seasonStats = lp.seasonStats,
                        platoonStats = platoonStats,
                        recentBattedBalls = recent,
                        opponentPitcher = awayPitcherProfile,
                        game = game,
                        weights = weights
                    )
                    add(
                        HitterCandidate(
                            player = lp.person,
                            team = game.homeTeam,
                            opponent = game.awayTeam,
                            game = game,
                            battingOrder = lp.battingOrder,
                            lineupOfficial = homeLineup.official,
                            seasonStats = lp.seasonStats,
                            opponentPitcher = awayPitcherProfile,
                            recentBattedBalls = recent,
                            todayBattedBalls = today,
                            recentPlateDiscipline = recentDisciplineByBatter[lp.person.id] ?: PlateDisciplineSample(),
                            score = score,
                            platoonStats = platoonStats
                        )
                    )
                }
            }
        }.sortedByDescending { it.score.total }

        // At this point the board is already useful: lineups, recent power, pitcher matchup,
        // weather and all core model scores are ready. Publish it now and enrich BvP afterward so
        // the UI remains usable while the final small batch of network calls finishes.
        onPartialBoard(
            BoardData(
                date = date,
                candidates = baseCandidates,
                games = enrichedGames,
                lastUpdated = Instant.now(),
                recentGameCount = recentSummaries.size
            )
        )

        // BvP is useful, but it should never hold the whole slate hostage. v0.8 fetched up to
        // ~100 matchups (7 per game). We now fetch the top two preliminary hitters per game plus
        // the best 12 overall, usually ~30 lookups total.
        onProgress("Adding BvP context…")
        fun preliminaryRank(c: HitterCandidate): Double {
            val profile = scoringModel.mustHaveMetrics(c.player, c.seasonStats, c.recentBattedBalls)
            val profileAdjusted = profile.score * profile.confidence +
                c.score.seasonPower * (1.0 - profile.confidence)
            return profileAdjusted * 0.35 +
                c.score.powerPressure * 0.25 +
                c.score.pitcherMatchup * 0.30 +
                c.score.total * 0.10
        }

        val perGameBvp = baseCandidates
            .groupBy { it.game.gamePk }
            .values
            .flatMap { gameCandidates -> gameCandidates.sortedByDescending(::preliminaryRank).take(2) }
        val globalBvp = baseCandidates.sortedByDescending(::preliminaryRank).take(12)
        val bvpTargets = (perGameBvp + globalBvp)
            .mapNotNull { c -> c.opponentPitcher?.person?.id?.let { pitcherId -> Triple(c.player.id, pitcherId, c) } }
            .distinctBy { it.first to it.second }

        val bvpByPair = bvpTargets.map { (batterId, pitcherId, _) ->
            async {
                semaphore.withPermit {
                    val stats = runCatching { api.fetchHittingVsPitcherStats(batterId, pitcherId) }.getOrNull()
                    (batterId to pitcherId) to stats
                }
            }
        }.awaitAll().mapNotNull { (key, stats) -> stats?.let { key to it } }.toMap()

        val candidates = baseCandidates.map { candidate ->
            val pitcherId = candidate.opponentPitcher?.person?.id
            val bvp = pitcherId?.let { bvpByPair[candidate.player.id to it] }
            candidate.copy(vsPitcherStats = bvp)
        }.sortedByDescending { it.score.total }

        onProgress("Ready")
        BoardData(
            date = date,
            candidates = candidates,
            games = enrichedGames,
            lastUpdated = Instant.now(),
            recentGameCount = recentSummaries.size
        )
    }
    fun rescore(board: BoardData, weights: ScoreWeights): BoardData {
        val rescored = board.candidates.map { c ->
            c.copy(
                score = scoringModel.score(
                    player = c.player,
                    battingOrder = c.battingOrder,
                    lineupOfficial = c.lineupOfficial,
                    seasonStats = c.seasonStats,
                    platoonStats = c.platoonStats,
                    recentBattedBalls = c.recentBattedBalls,
                    opponentPitcher = c.opponentPitcher,
                    game = c.game,
                    weights = weights
                )
            )
        }.sortedByDescending { it.score.total }
        return board.copy(candidates = rescored)
    }

}
