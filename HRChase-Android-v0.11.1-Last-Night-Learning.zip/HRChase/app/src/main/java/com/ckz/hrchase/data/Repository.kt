package com.ckz.hrchase.data

import com.ckz.hrchase.model.HrScoringModel
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

private data class CurrentGameSummary(
    val gamePk: Long,
    val awayLineup: TeamLineup?,
    val homeLineup: TeamLineup?,
    val battedBalls: List<BattedBall>,
    val weather: WeatherInfo,
    val persons: Map<Int, PersonRef>,
    val pitcherStats: Map<Int, PitchingStats>
)

private data class RecentGameSummary(
    val game: GameInfo,
    val awayLineup: TeamLineup?,
    val homeLineup: TeamLineup?,
    val battedBalls: List<BattedBall>,
    val plateDiscipline: Map<Int, PlateDisciplineSample>
)

class Repository(
    private val api: MlbApi = MlbApi(),
    private val scoringModel: HrScoringModel = HrScoringModel()
) {
    suspend fun loadBoard(
        date: LocalDate,
        weights: ScoreWeights,
        lookbackDays: Int = 5,
        onProgress: (String) -> Unit = {},
        onPartialBoard: (BoardData) -> Unit = {}
    ): BoardData = coroutineScope {
        onProgress("Loading MLB schedule…")
        val schedule = api.fetchSchedule(date)
        if (schedule.isEmpty()) {
            return@coroutineScope BoardData(date, emptyList(), emptyList(), Instant.now(), 0)
        }

        // Render the slate immediately. The expensive contact/BvP enrichment continues below,
        // but users should see today's games within the first schedule request instead of staring
        // at a blank spinner.
        onPartialBoard(BoardData(date, emptyList(), schedule, Instant.now(), 0))

        val todayTeamIds = schedule.flatMap { listOf(it.awayTeam.id, it.homeTeam.id) }.toSet()
        val semaphore = Semaphore(5)

        onProgress("Loading today's lineups and game data…")
        // Keep only compact fields from today's live feeds. Retaining 15 full MLB JSONObject trees
        // was the largest memory spike in v0.8 and could cause Android to kill the app mid-refresh.
        val currentFeeds = schedule.map { game ->
            async {
                semaphore.withPermit {
                    runCatching {
                        val feedTtl = if (game.status.equals("Final", true) || date.isBefore(LocalDate.now())) {
                            8 * 60 * 60 * 1000L
                        } else {
                            45 * 1000L
                        }
                        val feed = api.fetchGameFeed(game.gamePk, feedTtl)
                        val away = api.extractTeamLineup(feed, "away", game.awayTeam)
                            .takeIf { it.players.isNotEmpty() }
                        val home = api.extractTeamLineup(feed, "home", game.homeTeam)
                            .takeIf { it.players.isNotEmpty() }
                        val probableIds = listOfNotNull(
                            game.awayProbablePitcher?.id,
                            game.homeProbablePitcher?.id
                        ).distinct()
                        val persons = probableIds.mapNotNull { id ->
                            api.extractPerson(feed.root, id)?.let { id to it }
                        }.toMap()
                        val pitcherStats = probableIds.mapNotNull { id ->
                            api.extractPitchingStatsFromFeed(feed.root, id)?.let { id to it }
                        }.toMap()
                        CurrentGameSummary(
                            gamePk = game.gamePk,
                            awayLineup = away,
                            homeLineup = home,
                            battedBalls = feed.battedBalls,
                            weather = feed.weather,
                            persons = persons,
                            pitcherStats = pitcherStats
                        )
                    }.getOrNull()
                }
            }
        }.awaitAll().filterNotNull().associateBy { it.gamePk }

        val recentStart = date.minusDays(lookbackDays.toLong())
        val recentEnd = date.minusDays(1)
        onProgress("Finding recent games for contact signals…")
        val recentSchedule = if (!recentEnd.isBefore(recentStart)) {
            val allRecent = runCatching { api.fetchScheduleRange(recentStart, recentEnd) }
                .getOrDefault(emptyList())
                .asSequence()
                .filter { it.status.equals("Final", true) }
                .filter { it.awayTeam.id in todayTeamIds || it.homeTeam.id in todayTeamIds }
                .distinctBy { it.gamePk }
                .sortedByDescending { it.gameDate }
                .toList()

            // First guarantee at least one recent lineup source for every team on today's slate,
            // then fill the remaining budget with the newest games. This keeps projected lineups
            // available without going back to an unbounded 70+ feed download.
            val selected = LinkedHashMap<Long, GameInfo>()
            val coveredTeams = mutableSetOf<Int>()
            for (game in allRecent) {
                val relevant = listOf(game.awayTeam.id, game.homeTeam.id).filter { it in todayTeamIds }
                if (relevant.any { it !in coveredTeams }) {
                    selected[game.gamePk] = game
                    coveredTeams += relevant
                }
                if (coveredTeams.containsAll(todayTeamIds)) break
            }
            for (game in allRecent) {
                if (selected.size >= 30) break
                selected.putIfAbsent(game.gamePk, game)
            }
            selected.values.take(24)
        } else emptyList()

        onProgress("Loading ${recentSchedule.size} recent game feeds…")
        // IMPORTANT: do not retain the full live-feed JSON for every recent game. A five-day slate
        // can contain dozens of very large JSONObject trees and can push Android over its memory
        // limit. Extract only the compact pieces we need, then let each feed be garbage-collected.
        val recentSummaries = recentSchedule.map { game ->
            async {
                semaphore.withPermit {
                    runCatching {
                        val feed = api.fetchGameFeed(game.gamePk, 12 * 60 * 60 * 1000L)
                        val away = api.extractTeamLineup(feed, "away", game.awayTeam, forceProjected = true)
                            .takeIf { it.players.isNotEmpty() }
                        val home = api.extractTeamLineup(feed, "home", game.homeTeam, forceProjected = true)
                            .takeIf { it.players.isNotEmpty() }
                        RecentGameSummary(
                            game = game,
                            awayLineup = away,
                            homeLineup = home,
                            battedBalls = feed.battedBalls,
                            plateDiscipline = feed.plateDiscipline
                        )
                    }.getOrNull()
                }
            }
        }.awaitAll().filterNotNull()

        // Last-night outcome feedback. Reuse any recent feeds already in memory and only fetch
        // missing games so the feature does not double the normal network work. Unlike the recent
        // contact window, this intentionally covers the entire MLB slate so the displayed HR count
        // is a true league-wide total, including teams that are off today.
        val previousNightDate = date.minusDays(1)
        onProgress("Checking last night's home runs…")
        val recentByGamePk = recentSummaries.associateBy { it.game.gamePk }
        val previousNightSchedule = runCatching { api.fetchSchedule(previousNightDate) }
            .getOrDefault(emptyList())
            .filter { it.status.equals("Final", true) }
        val previousNightSummaries = previousNightSchedule.map { game ->
            async {
                recentByGamePk[game.gamePk] ?: semaphore.withPermit {
                    runCatching {
                        val feed = api.fetchGameFeed(game.gamePk, 12 * 60 * 60 * 1000L)
                        RecentGameSummary(
                            game = game,
                            awayLineup = api.extractTeamLineup(feed, "away", game.awayTeam, forceProjected = true)
                                .takeIf { it.players.isNotEmpty() },
                            homeLineup = api.extractTeamLineup(feed, "home", game.homeTeam, forceProjected = true)
                                .takeIf { it.players.isNotEmpty() },
                            battedBalls = feed.battedBalls,
                            plateDiscipline = feed.plateDiscipline
                        )
                    }.getOrNull()
                }
            }
        }.awaitAll().filterNotNull()

        fun teamForBatter(summary: RecentGameSummary, batterId: Int): TeamRef? = when {
            summary.awayLineup?.players?.any { it.person.id == batterId } == true -> summary.game.awayTeam
            summary.homeLineup?.players?.any { it.person.id == batterId } == true -> summary.game.homeTeam
            else -> null
        }

        val previousNightHrBalls = previousNightSummaries.flatMap { summary ->
            summary.battedBalls.filter { it.isHomeRun }.map { ball -> summary to ball }
        }
        val previousNightHomers = previousNightHrBalls
            .groupBy { (_, ball) -> ball.batterId }
            .map { (batterId, rows) ->
                val balls = rows.map { it.second }
                val firstSummary = rows.first().first
                PreviousNightHomer(
                    playerId = batterId,
                    playerName = balls.firstOrNull()?.batterName ?: "Player $batterId",
                    team = rows.firstNotNullOfOrNull { (summary, _) -> teamForBatter(summary, batterId) },
                    gamePk = firstSummary.game.gamePk,
                    homeRuns = balls.size,
                    maxExitVelocity = balls.mapNotNull { it.exitVelocity }.maxOrNull(),
                    longestDistanceFt = balls.mapNotNull { it.distanceFt }.maxOrNull(),
                    launchAngles = balls.mapNotNull { it.launchAngle },
                    pitchTypes = balls.mapNotNull { it.pitchType }.distinct()
                )
            }
            .sortedWith(compareByDescending<PreviousNightHomer> { it.homeRuns }.thenByDescending { it.maxExitVelocity ?: 0.0 })

        val previousNight = PreviousNightSummary(
            date = previousNightDate,
            totalHomeRuns = previousNightHrBalls.size,
            uniqueHitters = previousNightHomers.size,
            finalGames = previousNightSummaries.size,
            homers = previousNightHomers
        )

        val allRecentBalls = recentSummaries.flatMap { it.battedBalls }
        val recentBallsByBatter = allRecentBalls.groupBy { it.batterId }
        val recentBallsByPitcher = allRecentBalls.groupBy { it.pitcherId }
        val recentDisciplineByBatter = mutableMapOf<Int, PlateDisciplineSample>()
        val last3DisciplineByBatter = mutableMapOf<Int, PlateDisciplineSample>()
        val last3Start = date.minusDays(3)
        val last3End = date.minusDays(1)
        recentSummaries.forEach { summary ->
            val gameLocalDate = summary.game.gameDate.atZone(ZoneId.of("America/New_York")).toLocalDate()
            summary.plateDiscipline.forEach { (batterId, sample) ->
                recentDisciplineByBatter[batterId] =
                    (recentDisciplineByBatter[batterId] ?: PlateDisciplineSample()) + sample
                if (!gameLocalDate.isBefore(last3Start) && !gameLocalDate.isAfter(last3End)) {
                    last3DisciplineByBatter[batterId] =
                        (last3DisciplineByBatter[batterId] ?: PlateDisciplineSample()) + sample
                }
            }
        }

        // Build a most-recent real lineup for fallback when today's lineup has not posted yet.
        val latestLineupByTeam = mutableMapOf<Int, TeamLineup>()
        recentSummaries.sortedByDescending { it.game.gameDate }.forEach { summary ->
            val game = summary.game
            if (game.awayTeam.id !in latestLineupByTeam) {
                summary.awayLineup?.let { latestLineupByTeam[game.awayTeam.id] = it }
            }
            if (game.homeTeam.id !in latestLineupByTeam) {
                summary.homeLineup?.let { latestLineupByTeam[game.homeTeam.id] = it }
            }
        }

        onProgress("Loading recent hitter form…")
        val recentFormMaps = listOf(
            "week" to (date.minusDays(7) to date.minusDays(1)),
            "three" to (date.minusDays(3) to date.minusDays(1))
        ).map { (key, range) ->
            async {
                semaphore.withPermit {
                    key to api.fetchLeagueHittingDateRangeStats(range.first, range.second)
                }
            }
        }.awaitAll().toMap()
        val recentWeekStats = recentFormMaps["week"].orEmpty()
        val recentThreeDayStats = recentFormMaps["three"].orEmpty()

        onProgress("Adding handedness splits…")
        val season = date.year
        val splitMaps = listOf("vr", "vl").map { code ->
            async {
                semaphore.withPermit {
                    code to runCatching { api.fetchLeagueHittingSplitStats(season, code) }.getOrDefault(emptyMap())
                }
            }
        }.awaitAll().toMap()
        val vsRightPitching = splitMaps["vr"].orEmpty()
        val vsLeftPitching = splitMaps["vl"].orEmpty()

        val pitcherIds = schedule.flatMap { listOfNotNull(it.awayProbablePitcher?.id, it.homeProbablePitcher?.id) }.distinct()
        val pitchTypes = commonPitchTypes()

        // Build the core slate first. Pitch arsenals are a secondary enrichment and must never
        // prevent games/players from appearing if MLB's metrics endpoint is slow or unavailable.
        onProgress("Building pitcher profiles…")
        val pitcherProfiles = pitcherIds.map { id ->
            async {
                semaphore.withPermit {
                    val person = currentFeeds.values.firstNotNullOfOrNull { it.persons[id] }
                    var stats = currentFeeds.values.firstNotNullOfOrNull { it.pitcherStats[id] }
                    if (stats == null || stats == PitchingStats()) {
                        stats = api.fetchPitchingStats(id, season)
                    }
                    id to PitcherProfile(
                        person = person ?: PersonRef(id, "Pitcher $id"),
                        seasonStats = stats ?: PitchingStats(),
                        recentBattedBallsAllowed = recentBallsByPitcher[id].orEmpty(),
                        seasonPitchArsenal = emptyList()
                    )
                }
            }
        }.awaitAll().toMap()

        onProgress("Scoring hitters…")
        val enrichedGames = schedule.map { game ->
            val feed = currentFeeds[game.gamePk]
            if (feed != null) game.copy(weather = feed.weather) else game
        }

        val baseCandidates = buildList {
            enrichedGames.forEach { game ->
                val current = currentFeeds[game.gamePk]
                val awayOfficial = current?.awayLineup
                val homeOfficial = current?.homeLineup
                val awayLineup = awayOfficial?.takeIf { it.players.isNotEmpty() } ?: latestLineupByTeam[game.awayTeam.id]
                val homeLineup = homeOfficial?.takeIf { it.players.isNotEmpty() } ?: latestLineupByTeam[game.homeTeam.id]

                val awayPitcherId = game.awayProbablePitcher?.id
                val homePitcherId = game.homeProbablePitcher?.id
                val awayPitcherProfile = awayPitcherId?.let { pitcherProfiles[it] }
                val homePitcherProfile = homePitcherId?.let { pitcherProfiles[it] }

                awayLineup?.players?.forEach { lp ->
                    val recent = recentBallsByBatter[lp.person.id].orEmpty().sortedBy { it.gameDate }
                    val today = current?.battedBalls?.filter { it.batterId == lp.person.id }.orEmpty()
                    val platoonStats = when (homePitcherProfile?.person?.pitchHand) {
                        "R" -> vsRightPitching[lp.person.id]
                        "L" -> vsLeftPitching[lp.person.id]
                        else -> null
                    }
                    val score = scoringModel.score(
                        player = lp.person,
                        battingOrder = lp.battingOrder,
                        lineupOfficial = awayLineup.official,
                        seasonStats = lp.seasonStats,
                        platoonStats = platoonStats,
                        recentBattedBalls = recent,
                        opponentPitcher = homePitcherProfile,
                        game = game,
                        weights = weights
                    )
                    add(
                        HitterCandidate(
                            player = lp.person,
                            team = game.awayTeam,
                            opponent = game.homeTeam,
                            game = game,
                            battingOrder = lp.battingOrder,
                            lineupOfficial = awayLineup.official,
                            seasonStats = lp.seasonStats,
                            opponentPitcher = homePitcherProfile,
                            recentBattedBalls = recent,
                            todayBattedBalls = today,
                            recentPlateDiscipline = recentDisciplineByBatter[lp.person.id] ?: PlateDisciplineSample(),
                            last3PlateDiscipline = last3DisciplineByBatter[lp.person.id] ?: PlateDisciplineSample(),
                            score = score,
                            platoonStats = platoonStats
                        )
                    )
                }

                homeLineup?.players?.forEach { lp ->
                    val recent = recentBallsByBatter[lp.person.id].orEmpty().sortedBy { it.gameDate }
                    val today = current?.battedBalls?.filter { it.batterId == lp.person.id }.orEmpty()
                    val platoonStats = when (awayPitcherProfile?.person?.pitchHand) {
                        "R" -> vsRightPitching[lp.person.id]
                        "L" -> vsLeftPitching[lp.person.id]
                        else -> null
                    }
                    val score = scoringModel.score(
                        player = lp.person,
                        battingOrder = lp.battingOrder,
                        lineupOfficial = homeLineup.official,
                        seasonStats = lp.seasonStats,
                        platoonStats = platoonStats,
                        recentBattedBalls = recent,
                        opponentPitcher = awayPitcherProfile,
                        game = game,
                        weights = weights
                    )
                    add(
                        HitterCandidate(
                            player = lp.person,
                            team = game.homeTeam,
                            opponent = game.awayTeam,
                            game = game,
                            battingOrder = lp.battingOrder,
                            lineupOfficial = homeLineup.official,
                            seasonStats = lp.seasonStats,
                            opponentPitcher = awayPitcherProfile,
                            recentBattedBalls = recent,
                            todayBattedBalls = today,
                            recentPlateDiscipline = recentDisciplineByBatter[lp.person.id] ?: PlateDisciplineSample(),
                            last3PlateDiscipline = last3DisciplineByBatter[lp.person.id] ?: PlateDisciplineSample(),
                            score = score,
                            platoonStats = platoonStats
                        )
                    )
                }
            }
        }.sortedByDescending { it.score.total }

        // At this point the board is already useful: lineups, recent power, pitcher matchup,
        // weather and all core model scores are ready. Publish it now and enrich BvP afterward so
        // the UI remains usable while the final small batch of network calls finishes.
        onPartialBoard(
            BoardData(
                date = date,
                candidates = baseCandidates,
                games = enrichedGames,
                lastUpdated = Instant.now(),
                recentGameCount = recentSummaries.size,
                recentWeekStats = recentWeekStats,
                recentThreeDayStats = recentThreeDayStats,
                previousNight = previousNight
            )
        )

        // Pitch Arsenal Fit v2: use Baseball Savant's purpose-built pitch-arsenal leaderboards
        // instead of relying on StatsAPI metricAverages, which frequently returned empty maps.
        // Three bulk requests cover the whole slate: batter pitch results, pitcher pitch usage/
        // results, and direct HR-ending pitch types for today's hitters. The core board is already
        // visible, so a slow Savant response never blocks games from loading.
        onProgress("Adding Statcast pitch arsenal fit…")
        val arsenalBatterIds = baseCandidates.map { it.player.id }.distinct()
        val savantBatterDeferred = async {
            withTimeoutOrNull(24_000) { api.fetchSavantPitchArsenalStats(season, "batter") }.orEmpty()
        }
        val savantPitcherDeferred = async {
            withTimeoutOrNull(24_000) { api.fetchSavantPitchArsenalStats(season, "pitcher") }.orEmpty()
        }
        val hrPitchDeferred = async {
            withTimeoutOrNull(28_000) { api.fetchSavantHomeRunPitchCounts(arsenalBatterIds, season) }.orEmpty()
        }

        val savantBatterRows = savantBatterDeferred.await()
        val savantPitcherRows = savantPitcherDeferred.await()
        val savantHrPitchCounts = hrPitchDeferred.await()

        // If Savant is temporarily unavailable, retain the old StatsAPI pitch-count path as a
        // fallback for pitcher usage. It is no longer the primary source.
        val fallbackPitcherArsenalById: Map<Int, List<PitchTypeUsage>> = if (savantPitcherRows.isEmpty()) {
            val arsenalSemaphore = Semaphore(3)
            suspend fun fallbackOccurrences(code: String): Map<Int, Int> {
                repeat(2) { attempt ->
                    val result = arsenalSemaphore.withPermit {
                        withTimeoutOrNull(12_000) {
                            api.fetchPitchTypeOccurrences(pitcherIds, season, code, "pitching")
                        }.orEmpty()
                    }
                    if (result.isNotEmpty()) return result
                    if (attempt == 0) delay(350)
                }
                return emptyMap()
            }
            val byType = pitchTypes.map { code -> async { code to fallbackOccurrences(code) } }.awaitAll().toMap()
            pitcherIds.associateWith { pitcherId ->
                buildPitchArsenal(pitchTypes.associateWith { code -> byType[code]?.get(pitcherId) ?: 0 })
            }
        } else emptyMap()

        val pitcherArsenalById = pitcherIds.associateWith { pitcherId ->
            val rows = savantPitcherRows[pitcherId].orEmpty()
            if (rows.isNotEmpty()) buildPitchArsenal(rows) else fallbackPitcherArsenalById[pitcherId].orEmpty()
        }
        val candidatesWithPitcherArsenal = baseCandidates.map { candidate ->
            val profile = candidate.opponentPitcher
            val pitcherId = profile?.person?.id
            if (profile == null || pitcherId == null) candidate
            else candidate.copy(
                opponentPitcher = profile.copy(seasonPitchArsenal = pitcherArsenalById[pitcherId].orEmpty())
            )
        }

        // Recent feed HR pitches provide a second fallback for direct HR-pitch history. This is
        // intentionally only a fallback; season-long Savant HR data is preferred whenever present.
        val recentHrPitchCounts = recentBallsByBatter.mapValues { (_, balls) ->
            balls.asSequence()
                .filter { it.isHomeRun && !it.pitchType.isNullOrBlank() }
                .groupingBy { it.pitchType!! }
                .eachCount()
        }

        val arsenalCandidates = candidatesWithPitcherArsenal.map { candidate ->
            val pitcherId = candidate.opponentPitcher?.person?.id
            val pitcherArsenal = candidate.opponentPitcher?.seasonPitchArsenal.orEmpty()
            if (pitcherId == null || pitcherArsenal.isEmpty()) return@map candidate

            val directHrCounts = savantHrPitchCounts[candidate.player.id]
                ?.takeIf { it.values.sum() > 0 }
                ?: recentHrPitchCounts[candidate.player.id].orEmpty()
            val batterRows = savantBatterRows[candidate.player.id].orEmpty()
            val pitcherRows = savantPitcherRows[pitcherId].orEmpty()
            val match = buildPitchArsenalMatch(
                hitterHrCounts = directHrCounts,
                pitcherArsenal = pitcherArsenal,
                batterPitchRows = batterRows,
                pitcherPitchRows = pitcherRows,
                source = when {
                    batterRows.isNotEmpty() && pitcherRows.isNotEmpty() && directHrCounts.isNotEmpty() -> "Baseball Savant Statcast"
                    batterRows.isNotEmpty() && pitcherRows.isNotEmpty() -> "Savant pitch results"
                    else -> "MLB pitch data fallback"
                }
            )
            if (match == null) candidate else candidate.copy(pitchArsenalMatch = match)
        }

        onPartialBoard(
            BoardData(
                date = date,
                candidates = arsenalCandidates,
                games = enrichedGames,
                lastUpdated = Instant.now(),
                recentGameCount = recentSummaries.size,
                recentWeekStats = recentWeekStats,
                recentThreeDayStats = recentThreeDayStats,
                previousNight = previousNight
            )
        )

        // BvP is useful, but it should never hold the whole slate hostage. v0.8 fetched up to
        // ~100 matchups (7 per game). We now fetch the top two preliminary hitters per game plus
        // the best 12 overall, usually ~30 lookups total.
        onProgress("Adding BvP context…")
        fun preliminaryRank(c: HitterCandidate): Double {
            val profile = scoringModel.mustHaveMetrics(c.player, c.seasonStats, c.recentBattedBalls)
            val profileAdjusted = profile.score * profile.confidence +
                c.score.seasonPower * (1.0 - profile.confidence)
            return profileAdjusted * 0.35 +
                c.score.powerPressure * 0.25 +
                c.score.pitcherMatchup * 0.30 +
                c.score.total * 0.10
        }

        val perGameBvp = arsenalCandidates
            .groupBy { it.game.gamePk }
            .values
            .flatMap { gameCandidates -> gameCandidates.sortedByDescending(::preliminaryRank).take(2) }
        val globalBvp = arsenalCandidates.sortedByDescending(::preliminaryRank).take(12)
        val bvpTargets = (perGameBvp + globalBvp)
            .mapNotNull { c -> c.opponentPitcher?.person?.id?.let { pitcherId -> Triple(c.player.id, pitcherId, c) } }
            .distinctBy { it.first to it.second }

        val bvpByPair = bvpTargets.map { (batterId, pitcherId, _) ->
            async {
                semaphore.withPermit {
                    val stats = runCatching { api.fetchHittingVsPitcherStats(batterId, pitcherId) }.getOrNull()
                    (batterId to pitcherId) to stats
                }
            }
        }.awaitAll().mapNotNull { (key, stats) -> stats?.let { key to it } }.toMap()

        val candidates = arsenalCandidates.map { candidate ->
            val pitcherId = candidate.opponentPitcher?.person?.id
            val bvp = pitcherId?.let { bvpByPair[candidate.player.id to it] }
            candidate.copy(vsPitcherStats = bvp)
        }.sortedByDescending { it.score.total }

        onProgress("Ready")
        BoardData(
            date = date,
            candidates = candidates,
            games = enrichedGames,
            lastUpdated = Instant.now(),
            recentGameCount = recentSummaries.size,
            recentWeekStats = recentWeekStats,
            recentThreeDayStats = recentThreeDayStats,
            previousNight = previousNight
        )
    }
    private fun commonPitchTypes(): List<String> = listOf(
        "FF", "SI", "FC", "SL", "ST", "SV", "CU", "KC", "CS",
        "CH", "FS", "FO", "SC", "KN", "EP", "FA"
    )

    private fun buildPitchArsenal(counts: Map<String, Int>): List<PitchTypeUsage> {
        val total = counts.values.sum()
        if (total <= 0) return emptyList()
        return counts.entries
            .filter { it.value > 0 }
            .map { (code, count) ->
                PitchTypeUsage(
                    code = code,
                    name = api.pitchTypeName(code),
                    count = count,
                    share = count.toDouble() / total
                )
            }
            .sortedByDescending { it.share }
    }

    private fun buildPitchArsenal(rows: List<SavantPitchArsenalRow>): List<PitchTypeUsage> {
        val valid = rows.filter { it.pitches > 0 }
        val total = valid.sumOf { it.pitches }
        if (total <= 0) return emptyList()
        return valid
            .groupBy { it.code }
            .map { (code, pitchRows) ->
                val count = pitchRows.sumOf { it.pitches }
                PitchTypeUsage(
                    code = code,
                    name = pitchRows.firstOrNull()?.name ?: api.pitchTypeName(code),
                    count = count,
                    share = count.toDouble() / total
                )
            }
            .filter { it.count > 0 }
            .sortedByDescending { it.share }
    }

    private fun arsenalScale(value: Double?, low: Double, high: Double): Double {
        if (value == null || value.isNaN()) return 50.0
        if (high <= low) return 50.0
        return (((value - low) / (high - low)) * 100.0).coerceIn(0.0, 100.0)
    }

    /**
     * Pitch Arsenal Fit v2. This is no longer just a cosine comparison of HR pitch labels.
     * It combines four independent questions:
     *  1) Does today's pitcher throw the pitches behind this hitter's season HRs?
     *  2) How concentrated is exposure to the hitter's best HR pitch types?
     *  3) Has the hitter actually produced SLG/xSLG/hard contact against those pitch types?
     *  4) Has today's pitcher allowed damage with those same pitches?
     *
     * Direct HR-pitch history is preferred, but if that feed is unavailable we can still score
     * a real matchup from Savant's batter/pitcher pitch-type leaderboards instead of showing N/A.
     */
    private fun buildPitchArsenalMatch(
        hitterHrCounts: Map<String, Int>,
        pitcherArsenal: List<PitchTypeUsage>,
        batterPitchRows: List<SavantPitchArsenalRow> = emptyList(),
        pitcherPitchRows: List<SavantPitchArsenalRow> = emptyList(),
        source: String = "MLB Statcast"
    ): PitchArsenalMatch? {
        val pitchTotal = pitcherArsenal.sumOf { it.count }
        if (pitchTotal <= 0) return null

        val arsenalShares = pitcherArsenal.associate { it.code to it.share }
        val batterByCode = batterPitchRows.associateBy { it.code }
        val pitcherByCode = pitcherPitchRows.associateBy { it.code }
        val codes = commonPitchTypes().filter { (arsenalShares[it] ?: 0.0) > 0.0 }
        if (codes.isEmpty()) return null

        val batterPitchSample = batterPitchRows.sumOf { it.pitches }
        val hrTotal = hitterHrCounts.values.sum()
        val hrShares = if (hrTotal > 0) hitterHrCounts.mapValues { (_, n) -> n.toDouble() / hrTotal } else emptyMap()

        // Direct HR alignment: cosine rewards similar shape; exposure rewards the pitcher actually
        // leaning on the hitter's most frequently homered-off pitch types.
        val hrAlignmentScore: Double? = if (hrTotal > 0) {
            val dot = codes.sumOf { (hrShares[it] ?: 0.0) * (arsenalShares[it] ?: 0.0) }
            val hrNorm = kotlin.math.sqrt(commonPitchTypes().sumOf { val v = hrShares[it] ?: 0.0; v * v })
            val pitchNorm = kotlin.math.sqrt(commonPitchTypes().sumOf { val v = arsenalShares[it] ?: 0.0; v * v })
            if (hrNorm > 0.0 && pitchNorm > 0.0) (dot / (hrNorm * pitchNorm)).coerceIn(0.0, 1.0) * 100.0 else null
        } else null

        val topHrCodes = hitterHrCounts.entries
            .filter { it.value > 0 }
            .sortedByDescending { it.value }
            .take(3)
            .map { it.key }
        val feastExposure = if (topHrCodes.isNotEmpty()) topHrCodes.sumOf { arsenalShares[it] ?: 0.0 } else 0.0
        val exposureScore: Double? = if (topHrCodes.isNotEmpty())
            arsenalScale(feastExposure, 0.12, 0.72) else null

        // Weighted damage across the pitches today's starter actually throws. xSLG gets the most
        // weight because it is less result-dependent than raw SLG; hard-hit and wOBA add support.
        var batterDamageWeighted = 0.0
        var batterCoveredUsage = 0.0
        var pitcherVulnerabilityWeighted = 0.0
        var pitcherCoveredUsage = 0.0
        codes.forEach { code ->
            val usage = arsenalShares[code] ?: 0.0
            batterByCode[code]?.let { row ->
                val damage =
                    arsenalScale(row.xslg, .260, .650) * .42 +
                    arsenalScale(row.slg, .250, .620) * .25 +
                    arsenalScale(row.xwoba ?: row.woba, .250, .420) * .13 +
                    arsenalScale(row.hardHitPct, 25.0, 55.0) * .20
                batterDamageWeighted += damage * usage
                batterCoveredUsage += usage
            }
            pitcherByCode[code]?.let { row ->
                val vulnerability =
                    arsenalScale(row.xslg, .260, .620) * .45 +
                    arsenalScale(row.slg, .240, .600) * .25 +
                    arsenalScale(row.xwoba ?: row.woba, .245, .410) * .12 +
                    arsenalScale(row.hardHitPct, 25.0, 52.0) * .18
                pitcherVulnerabilityWeighted += vulnerability * usage
                pitcherCoveredUsage += usage
            }
        }
        val batterDamageScore = if (batterCoveredUsage >= .12) batterDamageWeighted / batterCoveredUsage else null
        val pitcherVulnerabilityScore = if (pitcherCoveredUsage >= .12) pitcherVulnerabilityWeighted / pitcherCoveredUsage else null

        val components = mutableListOf<Pair<Double, Double>>()
        if (hrAlignmentScore != null) components += hrAlignmentScore to .30
        if (exposureScore != null) components += exposureScore to .18
        if (batterDamageScore != null) components += batterDamageScore to .34
        if (pitcherVulnerabilityScore != null) components += pitcherVulnerabilityScore to .18
        if (components.isEmpty()) return null
        val totalWeight = components.sumOf { it.second }
        val raw = components.sumOf { it.first * it.second } / totalWeight

        val hrConfidence = if (hrTotal > 0) (hrTotal / 10.0).coerceIn(.22, 1.0) else .0
        val batterConfidence = if (batterPitchSample > 0) (batterPitchSample / 650.0).coerceIn(.25, 1.0) else .0
        val pitcherConfidence = (pitchTotal / 900.0).coerceIn(.35, 1.0)
        val coverageConfidence = ((batterCoveredUsage + pitcherCoveredUsage) / 2.0).coerceIn(.20, 1.0)
        val confidence = if (hrTotal > 0) {
            (hrConfidence * .35 + batterConfidence * .25 + pitcherConfidence * .25 + coverageConfidence * .15)
        } else {
            // Even without direct HR-event rows, season pitch-type damage + opponent usage is a
            // real measured matchup. Keep confidence lower so it cannot overpower better data.
            (batterConfidence * .42 + pitcherConfidence * .38 + coverageConfidence * .20) * .82
        }.coerceIn(.18, 1.0)

        val score = (50.0 * (1.0 - confidence) + raw * confidence).coerceIn(0.0, 100.0)

        val feastOrder = if (hrTotal > 0) {
            hitterHrCounts.entries.filter { it.value > 0 }.sortedByDescending { it.value }.map { it.key }
        } else {
            batterPitchRows.sortedByDescending { row ->
                (row.xslg ?: row.slg ?: 0.0) * (arsenalShares[row.code] ?: 0.0)
            }.map { it.code }
        }
        val feastPitches = feastOrder.distinct().take(4).map { code ->
            val count = hitterHrCounts[code] ?: 0
            val batterRow = batterByCode[code]
            PitchHrTendency(
                code = code,
                name = batterRow?.name ?: api.pitchTypeName(code),
                homeRuns = count,
                share = if (hrTotal > 0) count.toDouble() / hrTotal else 0.0,
                opposingPitcherUsage = arsenalShares[code] ?: 0.0,
                batterSlg = batterRow?.slg,
                batterXslg = batterRow?.xslg,
                batterHardHitPct = batterRow?.hardHitPct,
                pitcherXslgAllowed = pitcherByCode[code]?.xslg
            )
        }

        return PitchArsenalMatch(
            score = score,
            confidence = confidence,
            batterHrSample = hrTotal,
            batterPitchSample = batterPitchSample,
            pitcherPitchSample = pitchTotal,
            feastPitches = feastPitches,
            pitcherArsenal = pitcherArsenal.take(6),
            source = source
        )
    }

    suspend fun fetchPlayerGameStats(
        playerId: Int,
        date: LocalDate
    ): RecentHittingStats? = api.fetchPlayerStatsOnDate(playerId, date)

    suspend fun fetchPlayerLast10Stats(
        playerId: Int,
        throughDate: LocalDate
    ): RecentHittingStats? = api.fetchPlayerLastGamesStats(
        playerId = playerId,
        season = throughDate.year,
        throughDate = throughDate,
        gameCount = 10
    )

    fun rescore(board: BoardData, weights: ScoreWeights): BoardData {
        val rescored = board.candidates.map { c ->
            c.copy(
                score = scoringModel.score(
                    player = c.player,
                    battingOrder = c.battingOrder,
                    lineupOfficial = c.lineupOfficial,
                    seasonStats = c.seasonStats,
                    platoonStats = c.platoonStats,
                    recentBattedBalls = c.recentBattedBalls,
                    opponentPitcher = c.opponentPitcher,
                    game = c.game,
                    weights = weights
                )
            )
        }.sortedByDescending { it.score.total }
        return board.copy(candidates = rescored)
    }

}
