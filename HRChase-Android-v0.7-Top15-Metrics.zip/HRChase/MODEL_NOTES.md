# Model notes — v0.1

The model is intentionally transparent so each assumption can be tested later.

## Recent Contact
Uses the prior five days of MLB game-feed hitData for the hitter.

Inputs:
- hard-hit rate (95+ mph),
- barrel-proxy rate,
- average EV,
- max EV,
- recent HR per tracked batted ball.

## Power Pressure
Designed to catch hitters whose contact may be ahead of their HR results.

Inputs:
- most recent game's strongest non-HR contact,
- number of near-HRs,
- elite near-HRs,
- unrewarded barrel-proxy contacts,
- EV trend from the most recent five tracked balls vs the prior five.

## Pitcher Matchup
Inputs:
- season HR/9,
- season ERA,
- recent hard-hit rate allowed,
- recent barrel-proxy rate allowed,
- simple batter/pitcher handedness advantage.

## Environment
Inputs:
- v0.1 venue HR friendliness,
- temperature from the MLB game feed,
- MLB feed wind text (out = boost; in = penalty),
- closed roof neutralizes weather.

## Season Power
Inputs:
- HR/AB,
- SLG,
- OPS.

## Lineup
Top four lineup positions get the maximum PA-opportunity score, then decline through the order. Projected/fallback lineups receive a small penalty.

## Why no 'model HR probability' yet?
A score should not be labeled a probability until it has been calibrated against a meaningful historical sample. The Results/Tracked workflow is the start of gathering those observations. A future backtest can convert scores into empirically calibrated HR rates.

## v0.4 recommendation / parlay layer
The underlying Chase components are unchanged. v0.4 adds a presentation-level recommendation score:

- 55% Pressure + Matchup Attack Score
- 30% overall Chase Score
- 10% Environment
- 5% Lineup opportunity

The parlay generator uses this score as its starting point, then applies penalties for repeating the same game/team and for very poor environment scores. This is designed to combine the best daily reads rather than maximize payout or select random long shots.

Game warnings are informational overlays, not new model components. High-quality starter warnings use season ERA/HR9 thresholds when a meaningful innings sample is available. Weather warnings use MLB game-feed condition, wind, temperature, and roof data when available.


## v0.6 BvP adjustment
Batter-vs-pitcher history is contextual, not a primary signal. The app ignores BvP for scoring below 5 PA, scales the impact by sample size, and caps the adjustment at +8 / -4 points. This prevents a tiny 2-for-3 history from overpowering recent contact, power pressure, and pitcher quality.


## v0.7 Must-Have Power Profile / Daily Target Score

The new power-profile layer is designed to capture the batted-ball shape most associated with home-run upside while staying transparent about which inputs are exact and which are proxies.

### Must-Have inputs
- Barrel%: EV/LA barrel proxy from tracked MLB batted balls.
- PullBrl%: pulled barrel-proxy contacts as a share of tracked batted balls.
- PullAir%: pulled air contacts as a share of tracked batted balls.
- HH%: 95+ mph hard-hit rate.
- Avg Distance: average MLB-feed batted-ball distance when available.
- EV: average exit velocity.
- ISO: season isolated power from MLB batting stats.
- Fly Ball%: MLB trajectory when available, with launch-angle fallback.
- Pull%: directional pull proxy from play description + hitter batting side.
- Blast%: proxy defined as 105+ mph at a 15–35° launch angle.

Pull and Blast values are intentionally labeled as proxies in the UI. The app does not claim they are Baseball Savant's exact proprietary classifications.

### Power-profile score weights
- Barrel%: 16%
- PullBrl%: 10%
- PullAir%: 8%
- HH%: 13%
- Avg Distance: 8%
- EV: 13%
- ISO: 10%
- Fly Ball%: 7%
- Pull%: 7%
- Blast%: 8%

Unavailable metrics are omitted rather than forced to zero. Recent BBE sample size creates a confidence weight; small samples are blended toward the existing Season Power score.

### Daily Target Score
- 40% sample-adjusted Must-Have Power Profile
- 20% Power Pressure
- 22% Pitcher Matchup
- 8% overall Chase Score
- 5% Environment
- 5% Lineup opportunity
- plus the existing capped BvP adjustment

The Targets tab ranks the top 15 eligible hitters by this score. Games and parlays also use the same Target Score as their base recommendation score so the new metrics affect the entire app consistently.
