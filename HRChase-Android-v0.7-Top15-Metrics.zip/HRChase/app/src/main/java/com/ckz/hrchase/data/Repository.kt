package com.ckz.hrchase.data

import com.ckz.hrchase.model.HrScoringModel
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class Repository(
    private val api: MlbApi = MlbApi(),
    private val scoringModel: HrScoringModel = HrScoringModel()
) {
    suspend fun loadBoard(
        date: LocalDate,
        weights: ScoreWeights,
        lookbackDays: Int = 5,
        onProgress: (String) -> Unit = {}
    ): BoardData = coroutineScope {
        onProgress("Loading MLB schedule…")
        val schedule = api.fetchSchedule(date)
        if (schedule.isEmpty()) {
            return@coroutineScope BoardData(date, emptyList(), emptyList(), Instant.now(), 0)
        }

        val todayTeamIds = schedule.flatMap { listOf(it.awayTeam.id, it.homeTeam.id) }.toSet()
        val semaphore = Semaphore(7)

        onProgress("Loading today's lineups and game data…")
        val currentFeeds = schedule.map { game ->
            async {
                semaphore.withPermit {
                    runCatching { api.fetchGameFeed(game.gamePk) }.getOrNull()
                }
            }
        }.awaitAll().filterNotNull().associateBy { it.gamePk }

        val recentStart = date.minusDays(lookbackDays.toLong())
        val recentEnd = date.minusDays(1)
        onProgress("Finding recent games for contact signals…")
        val recentSchedule = if (!recentEnd.isBefore(recentStart)) {
            api.fetchScheduleRange(recentStart, recentEnd)
                .filter { it.status.equals("Final", true) }
                .filter { it.awayTeam.id in todayTeamIds || it.homeTeam.id in todayTeamIds }
                .distinctBy { it.gamePk }
        } else emptyList()

        onProgress("Loading ${recentSchedule.size} recent game feeds…")
        val recentFeedsList = recentSchedule.mapIndexed { index, game ->
            async {
                semaphore.withPermit {
                    runCatching { api.fetchGameFeed(game.gamePk) }.getOrNull()
                }
            }
        }.awaitAll().filterNotNull()
        val recentFeeds = recentFeedsList.associateBy { it.gamePk }

        val allRecentBalls = recentFeedsList.flatMap { it.battedBalls }
        val recentBallsByBatter = allRecentBalls.groupBy { it.batterId }
        val recentBallsByPitcher = allRecentBalls.groupBy { it.pitcherId }

        // Build a most-recent real lineup for fallback when tonight's lineup has not posted yet.
        val latestLineupByTeam = mutableMapOf<Int, TeamLineup>()
        recentSchedule.sortedByDescending { it.gameDate }.forEach { game ->
            val feed = recentFeeds[game.gamePk] ?: return@forEach
            if (game.awayTeam.id !in latestLineupByTeam) {
                val l = api.extractTeamLineup(feed, "away", game.awayTeam, forceProjected = true)
                if (l.players.isNotEmpty()) latestLineupByTeam[game.awayTeam.id] = l
            }
            if (game.homeTeam.id !in latestLineupByTeam) {
                val l = api.extractTeamLineup(feed, "home", game.homeTeam, forceProjected = true)
                if (l.players.isNotEmpty()) latestLineupByTeam[game.homeTeam.id] = l
            }
        }

        onProgress("Building pitcher profiles…")
        val season = date.year
        val pitcherIds = schedule.flatMap { listOfNotNull(it.awayProbablePitcher?.id, it.homeProbablePitcher?.id) }.distinct()
        val currentRoots = currentFeeds.values.map { it.root }
        val pitcherProfiles = pitcherIds.map { id ->
            async {
                semaphore.withPermit {
                    var person: PersonRef? = null
                    var stats: PitchingStats? = null
                    for (root in currentRoots) {
                        if (person == null) person = api.extractPerson(root, id)
                        if (stats == null) stats = api.extractPitchingStatsFromFeed(root, id)
                        if (person != null && stats != null) break
                    }
                    if (stats == null || stats == PitchingStats()) {
                        stats = api.fetchPitchingStats(id, season)
                    }
                    id to PitcherProfile(
                        person = person ?: PersonRef(id, "Pitcher $id"),
                        seasonStats = stats ?: PitchingStats(),
                        recentBattedBallsAllowed = recentBallsByPitcher[id].orEmpty()
                    )
                }
            }
        }.awaitAll().toMap()

        onProgress("Scoring hitters…")
        val enrichedGames = schedule.map { game ->
            val feed = currentFeeds[game.gamePk]
            if (feed != null) game.copy(weather = feed.weather) else game
        }

        val baseCandidates = buildList {
            enrichedGames.forEach { game ->
                val current = currentFeeds[game.gamePk]
                val awayOfficial = current?.let { api.extractTeamLineup(it, "away", game.awayTeam) }
                val homeOfficial = current?.let { api.extractTeamLineup(it, "home", game.homeTeam) }
                val awayLineup = awayOfficial?.takeIf { it.players.isNotEmpty() } ?: latestLineupByTeam[game.awayTeam.id]
                val homeLineup = homeOfficial?.takeIf { it.players.isNotEmpty() } ?: latestLineupByTeam[game.homeTeam.id]

                val awayPitcherId = game.awayProbablePitcher?.id
                val homePitcherId = game.homeProbablePitcher?.id
                val awayPitcherProfile = awayPitcherId?.let { pitcherProfiles[it] }?.let { profile ->
                    val enriched = current?.let { api.extractPerson(it.root, profile.person.id) }
                    if (enriched != null) profile.copy(person = enriched) else profile
                }
                val homePitcherProfile = homePitcherId?.let { pitcherProfiles[it] }?.let { profile ->
                    val enriched = current?.let { api.extractPerson(it.root, profile.person.id) }
                    if (enriched != null) profile.copy(person = enriched) else profile
                }

                awayLineup?.players?.forEach { lp ->
                    val recent = recentBallsByBatter[lp.person.id].orEmpty().sortedBy { it.gameDate }
                    val today = current?.battedBalls?.filter { it.batterId == lp.person.id }.orEmpty()
                    val score = scoringModel.score(
                        player = lp.person,
                        battingOrder = lp.battingOrder,
                        lineupOfficial = awayLineup.official,
                        seasonStats = lp.seasonStats,
                        recentBattedBalls = recent,
                        opponentPitcher = homePitcherProfile,
                        game = game,
                        weights = weights
                    )
                    add(
                        HitterCandidate(
                            player = lp.person,
                            team = game.awayTeam,
                            opponent = game.homeTeam,
                            game = game,
                            battingOrder = lp.battingOrder,
                            lineupOfficial = awayLineup.official,
                            seasonStats = lp.seasonStats,
                            opponentPitcher = homePitcherProfile,
                            recentBattedBalls = recent,
                            todayBattedBalls = today,
                            score = score
                        )
                    )
                }

                homeLineup?.players?.forEach { lp ->
                    val recent = recentBallsByBatter[lp.person.id].orEmpty().sortedBy { it.gameDate }
                    val today = current?.battedBalls?.filter { it.batterId == lp.person.id }.orEmpty()
                    val score = scoringModel.score(
                        player = lp.person,
                        battingOrder = lp.battingOrder,
                        lineupOfficial = homeLineup.official,
                        seasonStats = lp.seasonStats,
                        recentBattedBalls = recent,
                        opponentPitcher = awayPitcherProfile,
                        game = game,
                        weights = weights
                    )
                    add(
                        HitterCandidate(
                            player = lp.person,
                            team = game.homeTeam,
                            opponent = game.awayTeam,
                            game = game,
                            battingOrder = lp.battingOrder,
                            lineupOfficial = homeLineup.official,
                            seasonStats = lp.seasonStats,
                            opponentPitcher = awayPitcherProfile,
                            recentBattedBalls = recent,
                            todayBattedBalls = today,
                            score = score
                        )
                    )
                }
            }
        }.sortedByDescending { it.score.total }

        // BvP is useful, but small samples can be noisy. To keep refreshes fast we request it for
        // the six strongest preliminary candidates in each game (up to ~90 lookups on a full slate).
        // Those are the hitters most likely to appear in Top HR Looks or the parlay generator.
        onProgress("Checking batter vs pitcher history…")
        val bvpTargets = baseCandidates
            .groupBy { it.game.gamePk }
            .values
            .flatMap { gameCandidates ->
                gameCandidates.sortedByDescending { c ->
                    val profile = scoringModel.mustHaveMetrics(c.player, c.seasonStats, c.recentBattedBalls)
                    val profileAdjusted = profile.score * profile.confidence +
                        c.score.seasonPower * (1.0 - profile.confidence)
                    profileAdjusted * 0.35 +
                        c.score.powerPressure * 0.25 +
                        c.score.pitcherMatchup * 0.30 +
                        c.score.total * 0.10
                }.take(7)
            }
            .mapNotNull { c -> c.opponentPitcher?.person?.id?.let { pitcherId -> Triple(c.player.id, pitcherId, c) } }
            .distinctBy { it.first to it.second }

        val bvpByPair = bvpTargets.map { (batterId, pitcherId, _) ->
            async {
                semaphore.withPermit {
                    val stats = runCatching { api.fetchHittingVsPitcherStats(batterId, pitcherId) }.getOrNull()
                    (batterId to pitcherId) to stats
                }
            }
        }.awaitAll().mapNotNull { (key, stats) -> stats?.let { key to it } }.toMap()

        val candidates = baseCandidates.map { candidate ->
            val pitcherId = candidate.opponentPitcher?.person?.id
            val bvp = pitcherId?.let { bvpByPair[candidate.player.id to it] }
            candidate.copy(vsPitcherStats = bvp)
        }.sortedByDescending { it.score.total }

        onProgress("Ready")
        BoardData(
            date = date,
            candidates = candidates,
            games = enrichedGames,
            lastUpdated = Instant.now(),
            recentGameCount = recentFeedsList.size
        )
    }
    fun rescore(board: BoardData, weights: ScoreWeights): BoardData {
        val rescored = board.candidates.map { c ->
            c.copy(
                score = scoringModel.score(
                    player = c.player,
                    battingOrder = c.battingOrder,
                    lineupOfficial = c.lineupOfficial,
                    seasonStats = c.seasonStats,
                    recentBattedBalls = c.recentBattedBalls,
                    opponentPitcher = c.opponentPitcher,
                    game = c.game,
                    weights = weights
                )
            )
        }.sortedByDescending { it.score.total }
        return board.copy(candidates = rescored)
    }

}
