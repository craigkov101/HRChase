package com.ckz.hrchase.data

import java.time.Instant
import java.time.LocalDate


data class TeamRef(
    val id: Int,
    val name: String,
    val abbreviation: String = name.take(3).uppercase()
)

data class PersonRef(
    val id: Int,
    val name: String,
    val batSide: String? = null,
    val pitchHand: String? = null
)

data class WeatherInfo(
    val temperatureF: Int? = null,
    val wind: String? = null,
    val condition: String? = null,
    val roofType: String? = null
)

data class GameInfo(
    val gamePk: Long,
    val gameDate: Instant,
    val status: String,
    val detailedStatus: String,
    val awayTeam: TeamRef,
    val homeTeam: TeamRef,
    val venueName: String,
    val awayProbablePitcher: PersonRef? = null,
    val homeProbablePitcher: PersonRef? = null,
    val weather: WeatherInfo = WeatherInfo()
)

data class HittingStats(
    val atBats: Int = 0,
    val plateAppearances: Int = 0,
    val hits: Int = 0,
    val doubles: Int = 0,
    val triples: Int = 0,
    val homeRuns: Int = 0,
    val avg: Double? = null,
    val slg: Double? = null,
    val ops: Double? = null
)


data class BatterVsPitcherStats(
    val atBats: Int = 0,
    val plateAppearances: Int = 0,
    val hits: Int = 0,
    val doubles: Int = 0,
    val triples: Int = 0,
    val homeRuns: Int = 0,
    val walks: Int = 0,
    val strikeouts: Int = 0,
    val hitByPitch: Int = 0,
    val sacFlies: Int = 0,
    val avg: Double? = null,
    val obp: Double? = null,
    val slg: Double? = null,
    val ops: Double? = null
)

data class PitchingStats(
    val inningsPitched: Double = 0.0,
    val homeRunsAllowed: Int = 0,
    val era: Double? = null,
    val whip: Double? = null
) {
    val hrPer9: Double?
        get() = if (inningsPitched > 0.0) homeRunsAllowed * 9.0 / inningsPitched else null
}

data class BattedBall(
    val gamePk: Long,
    val gameDate: LocalDate,
    val batterId: Int,
    val pitcherId: Int,
    val batterName: String,
    val pitcherName: String,
    val exitVelocity: Double?,
    val launchAngle: Double?,
    val distanceFt: Double?,
    val trajectory: String? = null,
    val eventType: String,
    val isHomeRun: Boolean,
    val isOut: Boolean,
    val description: String? = null
)

data class MustHaveMetrics(
    val barrelPct: Double? = null,
    val pullBarrelPct: Double? = null,
    val pullAirPct: Double? = null,
    val hardHitPct: Double? = null,
    val avgDistanceFt: Double? = null,
    val avgExitVelocity: Double? = null,
    val iso: Double? = null,
    val flyBallPct: Double? = null,
    val pullPct: Double? = null,
    val blastPct: Double? = null,
    val battedBallCount: Int = 0,
    val directionalBattedBallCount: Int = 0,
    val score: Double = 50.0,
    val confidence: Double = 0.0
)

data class LineupPlayer(
    val person: PersonRef,
    val battingOrder: Int,
    val seasonStats: HittingStats,
    val official: Boolean,
    val sourceGamePk: Long
)

data class TeamLineup(
    val team: TeamRef,
    val players: List<LineupPlayer>,
    val official: Boolean
)

data class PitcherProfile(
    val person: PersonRef,
    val seasonStats: PitchingStats,
    val recentBattedBallsAllowed: List<BattedBall>
)

data class ScoreWeights(
    val recentPower: Float = 25f,
    val powerPressure: Float = 20f,
    val pitcherMatchup: Float = 25f,
    val environment: Float = 10f,
    val seasonPower: Float = 15f,
    val lineup: Float = 5f
) {
    val total: Float get() = recentPower + powerPressure + pitcherMatchup + environment + seasonPower + lineup
}

data class ScoreBreakdown(
    val recentPower: Double,
    val powerPressure: Double,
    val pitcherMatchup: Double,
    val environment: Double,
    val seasonPower: Double,
    val lineup: Double,
    val total: Double,
    val tags: List<String>,
    val notes: List<String>
)

data class HitterCandidate(
    val player: PersonRef,
    val team: TeamRef,
    val opponent: TeamRef,
    val game: GameInfo,
    val battingOrder: Int,
    val lineupOfficial: Boolean,
    val seasonStats: HittingStats,
    val opponentPitcher: PitcherProfile?,
    val recentBattedBalls: List<BattedBall>,
    val todayBattedBalls: List<BattedBall>,
    val score: ScoreBreakdown,
    val vsPitcherStats: BatterVsPitcherStats? = null
)

data class BoardData(
    val date: LocalDate,
    val candidates: List<HitterCandidate>,
    val games: List<GameInfo>,
    val lastUpdated: Instant,
    val recentGameCount: Int
)

data class TrackedPick(
    val playerId: Int,
    val playerName: String,
    val teamName: String,
    val date: LocalDate,
    val scoreAtTrack: Double,
    val trackedAt: Instant
)
