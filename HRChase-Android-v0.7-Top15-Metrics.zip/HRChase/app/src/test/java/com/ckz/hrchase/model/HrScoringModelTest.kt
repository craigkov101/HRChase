package com.ckz.hrchase.model

import com.ckz.hrchase.data.BattedBall
import com.ckz.hrchase.data.HittingStats
import com.ckz.hrchase.data.PersonRef
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class HrScoringModelTest {
    private val model = HrScoringModel()

    @Test
    fun eliteNearHrDetectsBohmStyleContact() {
        val ball = BattedBall(
            gamePk = 1,
            gameDate = LocalDate.of(2026, 8, 20),
            batterId = 1,
            pitcherId = 2,
            batterName = "Test Hitter",
            pitcherName = "Test Pitcher",
            exitVelocity = 106.4,
            launchAngle = 29.0,
            distanceFt = 397.0,
            eventType = "field_out",
            isHomeRun = false,
            isOut = true
        )
        assertTrue(model.isNearHomeRun(ball))
        assertTrue(model.isEliteNearHomeRun(ball))
    }

    @Test
    fun actualHomeRunIsNotNearHr() {
        val ball = BattedBall(
            gamePk = 1,
            gameDate = LocalDate.of(2026, 8, 20),
            batterId = 1,
            pitcherId = 2,
            batterName = "Test Hitter",
            pitcherName = "Test Pitcher",
            exitVelocity = 108.0,
            launchAngle = 28.0,
            distanceFt = 420.0,
            eventType = "home_run",
            isHomeRun = true,
            isOut = false
        )
        assertFalse(model.isNearHomeRun(ball))
    }

    @Test
    fun mustHaveProfileCapturesPulledPowerContact() {
        val player = PersonRef(id = 10, name = "Power Hitter", batSide = "R")
        val balls = listOf(
            BattedBall(
                gamePk = 1,
                gameDate = LocalDate.of(2026, 8, 20),
                batterId = 10,
                pitcherId = 20,
                batterName = "Power Hitter",
                pitcherName = "Pitcher",
                exitVelocity = 108.0,
                launchAngle = 27.0,
                distanceFt = 405.0,
                trajectory = "fly_ball",
                eventType = "field_out",
                isHomeRun = false,
                isOut = true,
                description = "Power Hitter flies out sharply to left fielder"
            ),
            BattedBall(
                gamePk = 2,
                gameDate = LocalDate.of(2026, 8, 21),
                batterId = 10,
                pitcherId = 21,
                batterName = "Power Hitter",
                pitcherName = "Pitcher",
                exitVelocity = 103.0,
                launchAngle = 24.0,
                distanceFt = 385.0,
                trajectory = "line_drive",
                eventType = "double",
                isHomeRun = false,
                isOut = false,
                description = "Power Hitter doubles to left field"
            )
        )
        val stats = HittingStats(
            atBats = 400,
            hits = 110,
            doubles = 22,
            triples = 2,
            homeRuns = 28,
            avg = .275,
            slg = .520,
            ops = .860
        )

        val metrics = model.mustHaveMetrics(player, stats, balls)

        assertTrue((metrics.barrelPct ?: 0.0) > 0.0)
        assertTrue((metrics.pullPct ?: 0.0) >= 99.0)
        assertTrue((metrics.iso ?: 0.0) > .200)
        assertTrue((metrics.blastPct ?: 0.0) > 0.0)
    }
}
