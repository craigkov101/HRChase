package com.ckz.hrchase.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ckz.hrchase.AppUiState
import com.ckz.hrchase.MainViewModel
import com.ckz.hrchase.SortMode
import com.ckz.hrchase.data.BattedBall
import com.ckz.hrchase.data.HitterCandidate
import com.ckz.hrchase.data.ScoreWeights
import com.ckz.hrchase.model.HrScoringModel
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

private val AppBackground = Color(0xFF07111F)
private val AppSurface = Color(0xFF0D1B2A)
private val AppSurfaceRaised = Color(0xFF122338)
private val AppOutline = Color(0xFF22364B)
private val AppPrimary = Color(0xFF38BDF8)
private val AppGreen = Color(0xFF34D399)
private val AppAmber = Color(0xFFFBBF24)
private val AppRed = Color(0xFFFB7185)
private val AppMuted = Color(0xFF8EA4B8)
private val AppText = Color(0xFFF4F8FC)

private val HrChaseColors = darkColorScheme(
    primary = AppPrimary,
    onPrimary = Color(0xFF03131E),
    secondary = AppGreen,
    tertiary = AppAmber,
    background = AppBackground,
    onBackground = AppText,
    surface = AppSurface,
    onSurface = AppText,
    surfaceVariant = AppSurfaceRaised,
    onSurfaceVariant = Color(0xFFC4D2DF),
    outline = AppOutline,
    error = AppRed
)

private enum class Tab { BOARD, TRACKED, SETTINGS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HrChaseApp(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    val selected = state.selectedPlayerId?.let { id -> state.board?.candidates?.firstOrNull { it.player.id == id } }

    MaterialTheme(colorScheme = HrChaseColors) {
        Surface(modifier = Modifier.fillMaxSize(), color = AppBackground) {
            if (selected != null) {
                PlayerDetailScreen(
                    candidate = selected,
                    tracked = state.tracked.any { it.playerId == selected.player.id && it.date == state.selectedDate },
                    onBack = { viewModel.selectPlayer(null) },
                    onTrack = { viewModel.toggleTracked(selected) }
                )
            } else {
                Scaffold(
                    containerColor = AppBackground,
                    topBar = {
                        TopAppBar(
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = AppBackground,
                                titleContentColor = AppText,
                                actionIconContentColor = AppText
                            ),
                            title = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        color = AppPrimary.copy(alpha = 0.16f),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, AppPrimary.copy(alpha = 0.35f))
                                    ) {
                                        Text(
                                            "HR",
                                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
                                            color = AppPrimary,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    Column {
                                        Text("HR Chase", fontWeight = FontWeight.Black)
                                        Text("POWER SIGNAL MODEL", style = MaterialTheme.typography.labelSmall, color = AppMuted)
                                    }
                                }
                            },
                            actions = {
                                IconButton(onClick = { viewModel.refresh() }) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Refresh data")
                                }
                            }
                        )
                    },
                    bottomBar = {
                        NavigationBar(containerColor = Color(0xFF091522), tonalElevation = 0.dp) {
                            NavigationBarItem(
                                selected = tab == 0,
                                onClick = { tab = 0 },
                                icon = { Icon(Icons.Default.Home, null) },
                                label = { Text("Board") },
                                colors = navColors()
                            )
                            NavigationBarItem(
                                selected = tab == 1,
                                onClick = { tab = 1 },
                                icon = { Icon(Icons.Default.Star, null) },
                                label = { Text("Tracked") },
                                colors = navColors()
                            )
                            NavigationBarItem(
                                selected = tab == 2,
                                onClick = { tab = 2 },
                                icon = { Icon(Icons.Default.Settings, null) },
                                label = { Text("Model") },
                                colors = navColors()
                            )
                        }
                    }
                ) { padding ->
                    when (tab) {
                        0 -> BoardScreen(state, viewModel, padding)
                        1 -> TrackedScreen(state, viewModel, padding)
                        else -> SettingsScreen(state, viewModel, padding)
                    }
                }
            }
        }
    }
}

@Composable
private fun navColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = AppPrimary,
    selectedTextColor = AppPrimary,
    indicatorColor = AppPrimary.copy(alpha = 0.14f),
    unselectedIconColor = AppMuted,
    unselectedTextColor = AppMuted
)

@Composable
private fun BoardScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val candidates = viewModel.visibleCandidates(state)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .background(AppBackground)
    ) {
        DateControls(state, viewModel)

        if (state.isLoading) {
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth(),
                color = AppPrimary,
                trackColor = AppSurfaceRaised
            )
            Text(
                state.progress,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp),
                style = MaterialTheme.typography.labelMedium,
                color = AppMuted
            )
        }

        state.error?.let {
            Card(
                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AppRed.copy(alpha = 0.12f)),
                border = BorderStroke(1.dp, AppRed.copy(alpha = 0.35f))
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("Could not load MLB data", fontWeight = FontWeight.Bold, color = AppRed)
                    Text(it, style = MaterialTheme.typography.bodySmall, color = AppText)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { viewModel.refresh() }) { Text("Retry") }
                }
            }
        }

        FilterControls(state, viewModel)

        val board = state.board
        if (!state.isLoading && board != null && candidates.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "No hitters match these filters. Try turning off Official lineups only.",
                    modifier = Modifier.padding(24.dp),
                    color = AppMuted
                )
            }
        } else if (board == null && state.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AppPrimary)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Tonight's board", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                            Text("Ranked by ${sortLabel(state.sortMode)}", style = MaterialTheme.typography.labelMedium, color = AppMuted)
                        }
                        Surface(color = AppSurfaceRaised, shape = RoundedCornerShape(50.dp)) {
                            Text(
                                "${candidates.size} hitters",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                style = MaterialTheme.typography.labelMedium,
                                color = AppMuted
                            )
                        }
                    }
                }

                itemsIndexed(candidates, key = { _, item -> "${item.game.gamePk}-${item.player.id}" }) { index, candidate ->
                    CandidateCard(
                        rank = index + 1,
                        candidate = candidate,
                        tracked = state.tracked.any { it.playerId == candidate.player.id && it.date == state.selectedDate },
                        onClick = { viewModel.selectPlayer(candidate.player.id) },
                        onTrack = { viewModel.toggleTracked(candidate) }
                    )
                }

                item {
                    Text(
                        "Chase Score is a research ranking, not a home-run probability. HR results remain high variance.",
                        style = MaterialTheme.typography.labelSmall,
                        color = AppMuted,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }
    }
}

private fun sortLabel(sortMode: SortMode): String = when (sortMode) {
    SortMode.SCORE -> "overall Chase Score"
    SortMode.POWER_PRESSURE -> "Power Pressure"
    SortMode.RECENT_POWER -> "recent contact"
    SortMode.MATCHUP -> "pitcher matchup"
}

@Composable
private fun DateControls(state: AppUiState, viewModel: MainViewModel) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        color = AppSurface,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, AppOutline)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = { viewModel.changeDate(-1) }) {
                Icon(Icons.Default.ChevronLeft, "Previous day", tint = AppMuted)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    state.selectedDate.format(DateTimeFormatter.ofPattern("EEE, MMM d")),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black
                )
                state.board?.let {
                    Text(
                        "${it.candidates.size} hitters  •  ${it.recentGameCount} recent games",
                        style = MaterialTheme.typography.labelSmall,
                        color = AppMuted
                    )
                }
            }
            IconButton(onClick = { viewModel.changeDate(1) }) {
                Icon(Icons.Default.ChevronRight, "Next day", tint = AppMuted)
            }
        }
    }
}

@Composable
private fun FilterControls(state: AppUiState, viewModel: MainViewModel) {
    Column(Modifier.padding(horizontal = 12.dp, vertical = 5.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AppFilterChip(
                label = "Remaining",
                selected = state.showRemainingOnly,
                onClick = { viewModel.toggleRemainingOnly() }
            )
            AppFilterChip(
                label = "Official lineups",
                selected = state.officialLineupsOnly,
                onClick = { viewModel.toggleOfficialOnly() }
            )
        }
        Spacer(Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SortChip("Overall", state.sortMode == SortMode.SCORE) { viewModel.setSortMode(SortMode.SCORE) }
            SortChip("Power Pressure", state.sortMode == SortMode.POWER_PRESSURE) { viewModel.setSortMode(SortMode.POWER_PRESSURE) }
            SortChip("Recent Contact", state.sortMode == SortMode.RECENT_POWER) { viewModel.setSortMode(SortMode.RECENT_POWER) }
            SortChip("Matchup", state.sortMode == SortMode.MATCHUP) { viewModel.setSortMode(SortMode.MATCHUP) }
        }
    }
}

@Composable
private fun AppFilterChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium) },
        colors = FilterChipDefaults.filterChipColors(
            containerColor = AppSurface,
            labelColor = AppMuted,
            selectedContainerColor = AppPrimary.copy(alpha = 0.15f),
            selectedLabelColor = AppPrimary
        ),
        border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = selected,
            borderColor = AppOutline,
            selectedBorderColor = AppPrimary.copy(alpha = 0.45f)
        )
    )
}

@Composable
private fun SortChip(label: String, selected: Boolean, onClick: () -> Unit) {
    AppFilterChip(label, selected, onClick)
}

@Composable
private fun CandidateCard(rank: Int, candidate: HitterCandidate, tracked: Boolean, onClick: () -> Unit, onTrack: () -> Unit) {
    val gameTime = candidate.game.gameDate.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("h:mm a"))
    val score = candidate.score.total.roundToInt()
    val scoreColor = scoreColor(score)

    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, AppOutline),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(62.dp),
                    color = scoreColor.copy(alpha = 0.13f),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, scoreColor.copy(alpha = 0.38f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(score.toString(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = scoreColor)
                            Text("SCORE", style = MaterialTheme.typography.labelSmall, color = AppMuted)
                        }
                    }
                }

                Spacer(Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            candidate.player.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Text("#$rank", style = MaterialTheme.typography.labelMedium, color = AppMuted)
                    }
                    Text(
                        "${candidate.team.abbreviation}  •  Batting #${candidate.battingOrder}  •  ${candidate.opponent.abbreviation}",
                        style = MaterialTheme.typography.bodySmall,
                        color = AppMuted
                    )
                    Text(
                        "${candidate.game.venueName}  •  $gameTime",
                        style = MaterialTheme.typography.labelSmall,
                        color = AppMuted
                    )
                }

                IconButton(onClick = onTrack) {
                    Icon(
                        if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder,
                        if (tracked) "Untrack" else "Track",
                        tint = if (tracked) AppAmber else AppMuted
                    )
                }
            }

            candidate.opponentPitcher?.let { pitcher ->
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    color = AppSurfaceRaised,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("vs ${pitcher.person.name}", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                            Text("Opposing starter", style = MaterialTheme.typography.labelSmall, color = AppMuted)
                        }
                        pitcher.seasonStats.hrPer9?.let {
                            Column(horizontalAlignment = Alignment.End) {
                                Text("${"%.2f".format(it)}", fontWeight = FontWeight.Black, color = if (it >= 1.3) AppAmber else AppText)
                                Text("HR/9", style = MaterialTheme.typography.labelSmall, color = AppMuted)
                            }
                        }
                    }
                }
            }

            if (candidate.score.tags.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    candidate.score.tags.forEach { tag -> SignalPill(tag) }
                    if (!candidate.lineupOfficial) SignalPill("PROJECTED")
                }
            } else if (!candidate.lineupOfficial) {
                Row(modifier = Modifier.padding(top = 10.dp)) { SignalPill("PROJECTED") }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 11.dp), color = AppOutline)

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                MetricTile("Pressure", candidate.score.powerPressure, Modifier.weight(1f))
                MetricTile("Contact", candidate.score.recentPower, Modifier.weight(1f))
                MetricTile("Matchup", candidate.score.pitcherMatchup, Modifier.weight(1f))
                MetricTile("Env", candidate.score.environment, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun SignalPill(tag: String) {
    val upper = tag.uppercase()
    val accent = when {
        "NEAR-HR" in upper -> AppAmber
        "HOT" in upper -> AppRed
        "PITCHER" in upper || "TARGET" in upper -> AppGreen
        "PROJECTED" in upper -> AppMuted
        "BARREL" in upper -> AppPrimary
        else -> AppPrimary
    }
    Surface(
        color = accent.copy(alpha = 0.12f),
        shape = RoundedCornerShape(50.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.30f))
    ) {
        Text(
            tag.replace("PROJECTED LINEUP", "PROJECTED"),
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = accent
        )
    }
}

@Composable
private fun MetricTile(label: String, value: Double, modifier: Modifier = Modifier) {
    val valueInt = value.roundToInt()
    val color = scoreColor(valueInt)
    Column(modifier = modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = AppMuted, maxLines = 1)
            Text(valueInt.toString(), fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelLarge, color = color)
        }
        Spacer(Modifier.height(5.dp))
        LinearProgressIndicator(
            progress = { (value / 100.0).toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(4.dp),
            color = color,
            trackColor = AppSurfaceRaised
        )
    }
}

private fun scoreColor(score: Int): Color = when {
    score >= 80 -> AppGreen
    score >= 68 -> AppPrimary
    score >= 55 -> AppAmber
    else -> AppMuted
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlayerDetailScreen(candidate: HitterCandidate, tracked: Boolean, onBack: () -> Unit, onTrack: () -> Unit) {
    val model = remember { HrScoringModel() }
    val score = candidate.score.total.roundToInt()
    val scoreColor = scoreColor(score)

    Scaffold(
        containerColor = AppBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AppBackground),
                title = { Text(candidate.player.name, fontWeight = FontWeight.Black) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } },
                actions = {
                    IconButton(onClick = onTrack) {
                        Icon(
                            if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder,
                            "Track",
                            tint = if (tracked) AppAmber else AppMuted
                        )
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = AppSurface),
                    shape = RoundedCornerShape(22.dp),
                    border = BorderStroke(1.dp, AppOutline)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                modifier = Modifier.size(82.dp),
                                color = scoreColor.copy(alpha = 0.14f),
                                shape = CircleShape,
                                border = BorderStroke(2.dp, scoreColor.copy(alpha = 0.45f))
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(score.toString(), style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Black, color = scoreColor)
                                        Text("CHASE", style = MaterialTheme.typography.labelSmall, color = AppMuted)
                                    }
                                }
                            }
                            Spacer(Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("HR Chase Score", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                                Text(
                                    "${candidate.team.abbreviation} • #${candidate.battingOrder} vs ${candidate.opponent.abbreviation}",
                                    color = AppMuted,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Spacer(Modifier.height(7.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                    candidate.score.tags.take(2).forEach { SignalPill(it) }
                                }
                            }
                        }
                    }
                }
            }

            item {
                SectionCard("Matchup") {
                    val pitcher = candidate.opponentPitcher
                    if (pitcher == null) {
                        Text("Probable pitcher data is not available yet.", color = AppMuted)
                    } else {
                        Text("${pitcher.person.name} (${pitcher.person.pitchHand ?: "?"})", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            StatCell("ERA", pitcher.seasonStats.era?.let { "%.2f".format(it) } ?: "—")
                            StatCell("HR/9", pitcher.seasonStats.hrPer9?.let { "%.2f".format(it) } ?: "—")
                            StatCell("WHIP", pitcher.seasonStats.whip?.let { "%.2f".format(it) } ?: "—")
                            StatCell("Hand", pitcher.person.pitchHand ?: "—")
                        }
                    }
                }
            }

            item {
                SectionCard("Model breakdown") {
                    ScoreBar("Recent contact", candidate.score.recentPower)
                    ScoreBar("Power Pressure", candidate.score.powerPressure)
                    ScoreBar("Pitcher matchup", candidate.score.pitcherMatchup)
                    ScoreBar("Park / weather", candidate.score.environment)
                    ScoreBar("Season power", candidate.score.seasonPower)
                    ScoreBar("Lineup opportunity", candidate.score.lineup)
                }
            }

            item {
                SectionCard("Why it scored this way") {
                    candidate.score.notes.forEach { note ->
                        Row(modifier = Modifier.padding(top = 6.dp), verticalAlignment = Alignment.Top) {
                            Box(Modifier.padding(top = 7.dp).size(5.dp).background(AppPrimary, CircleShape))
                            Spacer(Modifier.width(9.dp))
                            Text(note, style = MaterialTheme.typography.bodyMedium, color = Color(0xFFD6E1EA))
                        }
                    }
                }
            }

            item {
                SectionCard("Season profile") {
                    val s = candidate.seasonStats
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        StatCell("HR", s.homeRuns.toString())
                        StatCell("AVG", s.avg?.let { "%.3f".format(it) } ?: "—")
                        StatCell("SLG", s.slg?.let { "%.3f".format(it) } ?: "—")
                        StatCell("OPS", s.ops?.let { "%.3f".format(it) } ?: "—")
                    }
                }
            }

            if (candidate.todayBattedBalls.isNotEmpty()) {
                item { SectionTitle("Today's contact") }
                items(candidate.todayBattedBalls.reversed()) { ball -> BattedBallRow(ball, model) }
            }

            item { SectionTitle("Recent contact • ${candidate.recentBattedBalls.size} balls") }
            if (candidate.recentBattedBalls.isEmpty()) {
                item { Text("No recent batted-ball data is available in the lookback window.", color = AppMuted) }
            } else {
                items(candidate.recentBattedBalls.sortedByDescending { it.gameDate }.take(20)) { ball -> BattedBallRow(ball, model) }
            }

            item {
                Text(
                    "Near-HR and barrel signals are model heuristics built from MLB game-feed exit velocity, launch angle and distance. They are not official Statcast barrel labels or betting probabilities.",
                    style = MaterialTheme.typography.labelSmall,
                    color = AppMuted
                )
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 4.dp))
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, AppOutline)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(4.dp))
            content()
        }
    }
}

@Composable
private fun StatCell(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
        Text(label, color = AppMuted, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun ScoreBar(label: String, value: Double) {
    val valueInt = value.roundToInt()
    val color = scoreColor(valueInt)
    Column(Modifier.padding(top = 9.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color(0xFFD6E1EA))
            Text(valueInt.toString(), fontWeight = FontWeight.Black, color = color)
        }
        Spacer(Modifier.height(5.dp))
        LinearProgressIndicator(
            progress = { (value / 100.0).toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(6.dp),
            color = color,
            trackColor = AppSurfaceRaised
        )
    }
}

@Composable
private fun BattedBallRow(ball: BattedBall, model: HrScoringModel) {
    val signal = when {
        ball.isHomeRun -> "HR"
        model.isEliteNearHomeRun(ball) -> "NEAR-HR+"
        model.isNearHomeRun(ball) -> "NEAR-HR"
        model.isBarrelProxy(ball) -> "BARREL"
        model.isHardHit(ball) -> "HARD HIT"
        else -> "CONTACT"
    }
    val accent = when (signal) {
        "HR" -> AppGreen
        "NEAR-HR+", "NEAR-HR" -> AppAmber
        "BARREL" -> AppPrimary
        "HARD HIT" -> AppRed
        else -> AppMuted
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, AppOutline)
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(ball.gameDate.toString(), style = MaterialTheme.typography.labelMedium, color = AppMuted)
                Surface(color = accent.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp)) {
                    Text(signal, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontWeight = FontWeight.Bold, color = accent, style = MaterialTheme.typography.labelSmall)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                StatCell("EV", ball.exitVelocity?.let { "%.1f".format(it) } ?: "—")
                StatCell("LA", ball.launchAngle?.let { "%.0f°".format(it) } ?: "—")
                StatCell("DIST", ball.distanceFt?.let { "%.0fft".format(it) } ?: "—")
            }
            Spacer(Modifier.height(8.dp))
            Text(ball.description ?: ball.eventType.replace('_', ' '), style = MaterialTheme.typography.bodySmall, color = AppMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun TrackedScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val model = remember { HrScoringModel() }
    val tracked = state.tracked.filter { it.date == state.selectedDate }
    val byId = state.board?.candidates?.associateBy { it.player.id }.orEmpty()

    Column(Modifier.fillMaxSize().padding(padding).background(AppBackground)) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("Tracked picks", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                Text(state.selectedDate.format(DateTimeFormatter.ofPattern("EEE, MMM d")), style = MaterialTheme.typography.bodySmall, color = AppMuted)
            }
            if (tracked.isNotEmpty()) {
                Button(
                    onClick = { viewModel.clearTrackedForSelectedDate() },
                    colors = ButtonDefaults.buttonColors(containerColor = AppSurfaceRaised, contentColor = AppText)
                ) { Text("Clear") }
            }
        }

        if (tracked.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(28.dp)) {
                    Icon(Icons.Outlined.StarBorder, null, tint = AppMuted, modifier = Modifier.size(42.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("Nothing tracked yet", fontWeight = FontWeight.Black)
                    Text("Tap the star on a hitter to follow the read after first pitch.", color = AppMuted, style = MaterialTheme.typography.bodySmall)
                }
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(tracked, key = { "${it.date}-${it.playerId}" }) { pick ->
                    val c = byId[pick.playerId]
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable(enabled = c != null) { c?.let { viewModel.selectPlayer(it.player.id) } },
                        colors = CardDefaults.cardColors(containerColor = AppSurface),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, AppOutline)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text(pick.playerName, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                                    Text("Tracked at ${pick.scoreAtTrack.roundToInt()} Chase Score", style = MaterialTheme.typography.bodySmall, color = AppMuted)
                                }
                                c?.let { Text(it.game.detailedStatus, style = MaterialTheme.typography.labelMedium, color = AppPrimary) }
                            }
                            Spacer(Modifier.height(8.dp))
                            if (c == null) {
                                Text("Load this date's board to evaluate live contact.", style = MaterialTheme.typography.bodySmall, color = AppMuted)
                            } else {
                                val balls = c.todayBattedBalls
                                val hrs = balls.count { it.isHomeRun }
                                val hardest = balls.mapNotNull { it.exitVelocity }.maxOrNull()
                                val grade = when {
                                    hrs > 0 -> "HR HIT"
                                    balls.any { model.isEliteNearHomeRun(it) } -> "STRONG READ • ELITE NEAR-HR"
                                    balls.any { model.isNearHomeRun(it) } -> "GOOD READ • NEAR-HR"
                                    balls.any { model.isBarrelProxy(it) } -> "BARREL CONTACT • NO HR"
                                    balls.any { model.isHardHit(it) } -> "HARD CONTACT • NO HR"
                                    c.game.status.equals("Final", true) -> "QUIET CONTACT / MISS"
                                    else -> "GAME PENDING / IN PROGRESS"
                                }
                                SignalPill(grade)
                                Spacer(Modifier.height(8.dp))
                                Text("$hrs HR  •  ${balls.size} tracked balls  •  max EV ${hardest?.let { "%.1f".format(it) } ?: "—"}", style = MaterialTheme.typography.bodySmall, color = AppMuted)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    var recent by remember(state.weights) { mutableFloatStateOf(state.weights.recentPower) }
    var pressure by remember(state.weights) { mutableFloatStateOf(state.weights.powerPressure) }
    var matchup by remember(state.weights) { mutableFloatStateOf(state.weights.pitcherMatchup) }
    var environment by remember(state.weights) { mutableFloatStateOf(state.weights.environment) }
    var season by remember(state.weights) { mutableFloatStateOf(state.weights.seasonPower) }
    var lineup by remember(state.weights) { mutableFloatStateOf(state.weights.lineup) }
    val total = recent + pressure + matchup + environment + season + lineup

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding).background(AppBackground),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Model Lab", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            Text("Tune the signal weights and instantly re-rank the slate.", color = AppMuted)
        }
        item { WeightSlider("Recent contact", recent) { recent = it } }
        item { WeightSlider("Power Pressure / near-HR", pressure) { pressure = it } }
        item { WeightSlider("Pitcher matchup", matchup) { matchup = it } }
        item { WeightSlider("Park / weather", environment) { environment = it } }
        item { WeightSlider("Season power", season) { season = it } }
        item { WeightSlider("Lineup opportunity", lineup) { lineup = it } }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AppSurface),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, AppOutline)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Weight total", fontWeight = FontWeight.Bold)
                        Text(total.roundToInt().toString(), fontWeight = FontWeight.Black, color = AppPrimary)
                    }
                    Text("Weights are normalized automatically, so they do not need to total 100.", style = MaterialTheme.typography.bodySmall, color = AppMuted)
                    Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            viewModel.updateWeights(ScoreWeights(recent, pressure, matchup, environment, season, lineup))
                        }) { Text("Save & re-rank") }
                        Button(
                            onClick = { viewModel.resetWeights() },
                            colors = ButtonDefaults.buttonColors(containerColor = AppSurfaceRaised, contentColor = AppText)
                        ) { Text("Reset") }
                    }
                }
            }
        }
        item {
            SectionCard("Data pipeline") {
                Text("MLB schedule, probable pitchers and lineups", color = AppMuted)
                Text("Game-feed exit velocity, launch angle and distance", color = AppMuted)
                Text("3-day recent-contact lookback", color = AppMuted)
                Text("Weather when available", color = AppMuted)
                Text("Local tracked-pick results", color = AppMuted)
            }
        }
        item {
            Text(
                "Research/entertainment tool only. Chase Score is a ranking heuristic, not a predicted probability or guarantee.",
                style = MaterialTheme.typography.labelMedium,
                color = AppMuted
            )
        }
    }
}

@Composable
private fun WeightSlider(label: String, value: Float, onChange: (Float) -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, AppOutline)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(label, fontWeight = FontWeight.SemiBold)
                Surface(color = AppPrimary.copy(alpha = 0.13f), shape = RoundedCornerShape(8.dp)) {
                    Text(value.roundToInt().toString(), modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontWeight = FontWeight.Black, color = AppPrimary)
                }
            }
            Slider(
                value = value,
                onValueChange = onChange,
                valueRange = 0f..50f,
                steps = 49,
                colors = SliderDefaults.colors(
                    thumbColor = AppPrimary,
                    activeTrackColor = AppPrimary,
                    inactiveTrackColor = AppSurfaceRaised
                )
            )
        }
    }
}
