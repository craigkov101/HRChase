# HR Chase v0.15.0 — Dual Prediction Engine

## Major redesign
HR Chase now has two separate prediction engines under the Picks tab:

1. **HOME RUN** — Pattern Engine v2 + Arsenal/Handedness Convergence, now stabilized with a slower 14-day power-form component so 3-day noise has less authority.
2. **H + R + RBI** — a new offensive-production model built specifically for total game production rather than power alone.

## H+R+RBI inputs
- Season AVG / OBP / SLG / OPS and H, R, RBI rates per PA
- Rolling 14-day, 7-day, and 3-day production
- Strikeout/contact floor
- Batting-order position and estimated PA opportunity
- Teammate OBP ahead of the hitter and OPS behind the hitter
- Opposing pitcher K%, BB%, WHIP and ERA
- Handedness context
- Recent contact-quality support

The model outputs separate Hit, Run, RBI, Matchup, Lineup Context, Opportunity, Form and Contact grades plus an overall Production Score and expected H+R+RBI estimate.

## Outcome learning / calibration
Pregame snapshots now store the production score and expected H+R+RBI. After the slate is final, one league-wide MLB StatsAPI date-range call resolves each player's actual H, R and RBI. Players with no plate appearance are removed from the learning set so scratches are not recorded as misses.

The Picks screen reports calibration buckets showing actual average H+R+RBI and 2+/3+ rates by Production Score band once enough outcomes are available.

## Tracking
Tracked picks now preserve the wager/model type: HOME RUN or H+R+RBI. A player can be tracked separately in both models on the same day.
