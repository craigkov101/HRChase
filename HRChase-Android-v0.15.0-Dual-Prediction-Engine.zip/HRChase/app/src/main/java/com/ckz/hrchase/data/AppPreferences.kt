package com.ckz.hrchase.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate

class AppPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("hr_chase_prefs", Context.MODE_PRIVATE)

    fun loadWeights(): ScoreWeights = ScoreWeights(
        recentPower = prefs.getFloat("w_recent", 20f),
        powerPressure = prefs.getFloat("w_pressure", 15f),
        pitcherMatchup = prefs.getFloat("w_matchup", 28f),
        environment = prefs.getFloat("w_environment", 8f),
        seasonPower = prefs.getFloat("w_season", 24f),
        lineup = prefs.getFloat("w_lineup", 5f)
    )

    fun saveWeights(w: ScoreWeights) {
        prefs.edit()
            .putFloat("w_recent", w.recentPower)
            .putFloat("w_pressure", w.powerPressure)
            .putFloat("w_matchup", w.pitcherMatchup)
            .putFloat("w_environment", w.environment)
            .putFloat("w_season", w.seasonPower)
            .putFloat("w_lineup", w.lineup)
            .apply()
    }

    fun loadTracked(): List<TrackedPick> {
        val raw = prefs.getString("tracked", null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val o = array.optJSONObject(i) ?: continue
                    add(
                        TrackedPick(
                            playerId = o.optInt("playerId"),
                            playerName = o.optString("playerName"),
                            teamName = o.optString("teamName"),
                            date = LocalDate.parse(o.optString("date")),
                            scoreAtTrack = o.optDouble("scoreAtTrack"),
                            trackedAt = Instant.parse(o.optString("trackedAt")),
                            pickType = runCatching { PickType.valueOf(o.optString("pickType", PickType.HOME_RUN.name)) }.getOrDefault(PickType.HOME_RUN),
                            expectedHrrAtTrack = if (o.has("expectedHrrAtTrack") && !o.isNull("expectedHrrAtTrack")) o.optDouble("expectedHrrAtTrack") else null
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun saveTracked(picks: List<TrackedPick>) {
        val array = JSONArray()
        picks.forEach { p ->
            array.put(
                JSONObject()
                    .put("playerId", p.playerId)
                    .put("playerName", p.playerName)
                    .put("teamName", p.teamName)
                    .put("date", p.date.toString())
                    .put("scoreAtTrack", p.scoreAtTrack)
                    .put("trackedAt", p.trackedAt.toString())
                    .put("pickType", p.pickType.name)
                    .apply { if (p.expectedHrrAtTrack != null) put("expectedHrrAtTrack", p.expectedHrrAtTrack) }
            )
        }
        prefs.edit().putString("tracked", array.toString()).apply()
    }

    fun loadSignalSnapshots(): List<DailySignalSnapshot> {
        val raw = prefs.getString("signal_snapshots_v1", null) ?: return emptyList()
        return runCatching {
            val days = JSONArray(raw)
            buildList {
                for (i in 0 until days.length()) {
                    val day = days.optJSONObject(i) ?: continue
                    val date = runCatching { LocalDate.parse(day.optString("date")) }.getOrNull() ?: continue
                    val savedAt = runCatching { Instant.parse(day.optString("savedAt")) }.getOrDefault(Instant.EPOCH)
                    val hittersJson = day.optJSONArray("hitters") ?: JSONArray()
                    val hitters = buildList {
                        for (j in 0 until hittersJson.length()) {
                            val h = hittersJson.optJSONObject(j) ?: continue
                            add(
                                HitterSignalSnapshot(
                                    date = date,
                                    playerId = h.optInt("playerId"),
                                    recentPower = h.optDouble("recentPower", 50.0),
                                    powerPressure = h.optDouble("powerPressure", 50.0),
                                    pitcherMatchup = h.optDouble("pitcherMatchup", 50.0),
                                    environment = h.optDouble("environment", 50.0),
                                    seasonPower = h.optDouble("seasonPower", 50.0),
                                    platoon = h.optDouble("platoon", 50.0),
                                    contactProfile = h.optDouble("contactProfile", 50.0),
                                    pitchArsenalFit = if (h.has("pitchArsenalFit") && !h.isNull("pitchArsenalFit")) h.optDouble("pitchArsenalFit") else null,
                                    pitchArsenalConfidence = if (h.has("pitchArsenalConfidence") && !h.isNull("pitchArsenalConfidence")) h.optDouble("pitchArsenalConfidence") else null,
                                    productionScore = if (h.has("productionScore") && !h.isNull("productionScore")) h.optDouble("productionScore") else null,
                                    expectedHrr = if (h.has("expectedHrr") && !h.isNull("expectedHrr")) h.optDouble("expectedHrr") else null,
                                    outcomeHomeRun = if (h.has("outcomeHomeRun") && !h.isNull("outcomeHomeRun")) h.optBoolean("outcomeHomeRun") else null,
                                    outcomeHits = if (h.has("outcomeHits") && !h.isNull("outcomeHits")) h.optInt("outcomeHits") else null,
                                    outcomeRuns = if (h.has("outcomeRuns") && !h.isNull("outcomeRuns")) h.optInt("outcomeRuns") else null,
                                    outcomeRbi = if (h.has("outcomeRbi") && !h.isNull("outcomeRbi")) h.optInt("outcomeRbi") else null
                                )
                            )
                        }
                    }
                    add(DailySignalSnapshot(date = date, savedAt = savedAt, hitters = hitters))
                }
            }
        }.getOrDefault(emptyList())
    }

    fun saveSignalSnapshotIfAbsent(snapshot: DailySignalSnapshot) {
        val existing = loadSignalSnapshots().toMutableList()
        if (existing.any { it.date == snapshot.date }) return
        existing += snapshot
        saveSignalSnapshots(existing)
    }

    /**
     * Keeps the learning set genuinely pregame. Morning refreshes are allowed to improve today's
     * snapshot as lineups, probable pitchers and arsenal data arrive, but once a player's game has
     * started their earlier row is frozen. A player first seen after first pitch is not added.
     * This fixes the old "first refresh of the morning wins forever" problem without introducing
     * postgame leakage.
     */
    fun mergePregameSignalSnapshot(snapshot: DailySignalSnapshot, lockedPlayerIds: Set<Int>) {
        val existing = loadSignalSnapshots().toMutableList()
        val index = existing.indexOfFirst { it.date == snapshot.date }
        if (index < 0) {
            existing += snapshot.copy(
                hitters = snapshot.hitters.filterNot { it.playerId in lockedPlayerIds }
            )
            saveSignalSnapshots(existing)
            return
        }

        val current = existing[index]
        if (current.hitters.any { it.outcomeHomeRun != null || it.outcomeHrr != null }) return
        val currentById = current.hitters.associateBy { it.playerId }
        val incomingById = snapshot.hitters.associateBy { it.playerId }
        val ids = (currentById.keys + incomingById.keys).toSet()
        val merged = ids.mapNotNull { playerId ->
            val old = currentById[playerId]
            val fresh = incomingById[playerId]
            when {
                playerId in lockedPlayerIds -> old
                fresh != null -> fresh
                else -> old
            }
        }
        existing[index] = snapshot.copy(
            savedAt = snapshot.savedAt,
            hitters = merged
        )
        saveSignalSnapshots(existing)
    }

    fun resolveSignalSnapshot(date: LocalDate, homerIds: Set<Int>) {
        val existing = loadSignalSnapshots().toMutableList()
        val index = existing.indexOfFirst { it.date == date }
        if (index < 0) return
        val current = existing[index]
        if (current.hitters.isEmpty() || current.hitters.all { it.outcomeHomeRun != null }) return
        existing[index] = current.copy(
            hitters = current.hitters.map { it.copy(outcomeHomeRun = it.playerId in homerIds) }
        )
        saveSignalSnapshots(existing)
    }

    /** Resolve full offensive outcomes. Players with no PA are removed so scratches never become false misses. */
    fun resolveProductionOutcomes(date: LocalDate, outcomes: Map<Int, RecentHittingStats>) {
        val existing = loadSignalSnapshots().toMutableList()
        val index = existing.indexOfFirst { it.date == date }
        if (index < 0) return
        val current = existing[index]
        if (current.hitters.isEmpty()) return
        val resolved = current.hitters.mapNotNull { row ->
            val result = outcomes[row.playerId] ?: return@mapNotNull null
            if (result.plateAppearances <= 0) return@mapNotNull null
            row.copy(
                outcomeHomeRun = result.homeRuns > 0,
                outcomeHits = result.hits,
                outcomeRuns = result.runs,
                outcomeRbi = result.rbi
            )
        }
        if (resolved.isEmpty()) return
        existing[index] = current.copy(hitters = resolved)
        saveSignalSnapshots(existing)
    }

    private fun saveSignalSnapshots(snapshots: List<DailySignalSnapshot>) {
        val cutoff = LocalDate.now().minusDays(28)
        val kept = snapshots
            .filter { !it.date.isBefore(cutoff) }
            .distinctBy { it.date }
            .sortedBy { it.date }
            .takeLast(28)
        val days = JSONArray()
        kept.forEach { snapshot ->
            val hitters = JSONArray()
            snapshot.hitters.forEach { h ->
                val obj = JSONObject()
                    .put("playerId", h.playerId)
                    .put("recentPower", h.recentPower)
                    .put("powerPressure", h.powerPressure)
                    .put("pitcherMatchup", h.pitcherMatchup)
                    .put("environment", h.environment)
                    .put("seasonPower", h.seasonPower)
                    .put("platoon", h.platoon)
                    .put("contactProfile", h.contactProfile)
                if (h.pitchArsenalFit != null) obj.put("pitchArsenalFit", h.pitchArsenalFit)
                if (h.pitchArsenalConfidence != null) obj.put("pitchArsenalConfidence", h.pitchArsenalConfidence)
                if (h.productionScore != null) obj.put("productionScore", h.productionScore)
                if (h.expectedHrr != null) obj.put("expectedHrr", h.expectedHrr)
                if (h.outcomeHomeRun != null) obj.put("outcomeHomeRun", h.outcomeHomeRun)
                if (h.outcomeHits != null) obj.put("outcomeHits", h.outcomeHits)
                if (h.outcomeRuns != null) obj.put("outcomeRuns", h.outcomeRuns)
                if (h.outcomeRbi != null) obj.put("outcomeRbi", h.outcomeRbi)
                hitters.put(obj)
            }
            days.put(
                JSONObject()
                    .put("date", snapshot.date.toString())
                    .put("savedAt", snapshot.savedAt.toString())
                    .put("hitters", hitters)
            )
        }
        prefs.edit().putString("signal_snapshots_v1", days.toString()).apply()
    }

}
