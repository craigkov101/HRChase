package com.ckz.hrchase.model

import com.ckz.hrchase.data.HitterCandidate
import com.ckz.hrchase.data.ProductionBreakdown
import com.ckz.hrchase.data.RecentHittingStats
import kotlin.math.exp

/**
 * Separate H+R+RBI model. This deliberately does not reuse the HR Target Score because offensive
 * production is driven much more by contact, on-base skill, lineup slot, teammate quality and PA
 * opportunity than by pure barrel/HR traits.
 */
class ProductionScoringModel {

    data class Context(
        val season: RecentHittingStats?,
        val last14: RecentHittingStats?,
        val last7: RecentHittingStats?,
        val last3: RecentHittingStats?,
        val teammates: List<Pair<Int, RecentHittingStats>> = emptyList(),
        val contactQuality: Double = 50.0
    )

    fun score(candidate: HitterCandidate, context: Context): ProductionBreakdown {
        val season = context.season
        val d14 = context.last14
        val d7 = context.last7
        val d3 = context.last3

        val seasonPa = season?.plateAppearances ?: candidate.seasonStats.plateAppearances
        val seasonAvg = season?.avg ?: candidate.seasonStats.avg
        val seasonOps = season?.ops ?: candidate.seasonStats.ops
        val seasonObp = season?.obp
        val seasonSlg = season?.slg ?: candidate.seasonStats.slg
        val seasonK = season?.strikeoutRate ?: candidate.seasonStats.plateAppearances.takeIf { it > 0 }?.let {
            candidate.seasonStats.strikeouts.toDouble() / it
        }

        val expectedPa = when (candidate.battingOrder) {
            1 -> 4.72
            2 -> 4.62
            3 -> 4.54
            4 -> 4.46
            5 -> 4.35
            6 -> 4.22
            7 -> 4.10
            8 -> 3.98
            else -> 3.88
        }

        val seasonHitRate = when {
            season != null && season.plateAppearances > 0 -> season.hits.toDouble() / season.plateAppearances
            candidate.seasonStats.plateAppearances > 0 -> candidate.seasonStats.hits.toDouble() / candidate.seasonStats.plateAppearances
            else -> .205
        }
        val seasonRunRate = season?.takeIf { it.plateAppearances > 0 }?.let { it.runs.toDouble() / it.plateAppearances } ?: .105
        val seasonRbiRate = season?.takeIf { it.plateAppearances > 0 }?.let { it.rbi.toDouble() / it.plateAppearances } ?: .105

        val contact = weightedScore(
            scoreRate(seasonAvg, .205, .320) to .34,
            inverseRate(seasonK, .15, .31) to .26,
            scoreRate(seasonObp, .285, .390) to .22,
            context.contactQuality to .18
        )

        val form14 = recentProductionForm(d14)
        val form7 = recentProductionForm(d7)
        val form3 = recentProductionForm(d3)
        val form = shrinkByPa(weightedScore(form14 to .50, form7 to .32, form3 to .18), d14?.plateAppearances ?: 0, 36)

        val pitcher = candidate.opponentPitcher?.seasonStats
        val pitcherK = pitcher?.strikeoutRate
        val pitcherBb = pitcher?.walkRate
        val pitcherWhip = pitcher?.whip
        val pitcherEra = pitcher?.era
        val split = candidate.platoonStats
        val splitProduction = if (split != null && split.plateAppearances >= 20) {
            weightedScore(
                scoreRate(split.avg, .205, .320) to .31,
                scoreRate(split.obp, .285, .400) to .24,
                scoreRate(split.ops, .630, .930) to .28,
                inverseRate(split.strikeoutRate, .15, .33) to .17
            )
        } else candidate.score.platoon
        val arsenalSupport = candidate.pitchArsenalMatch
            ?.takeIf { it.confidence >= .28 }
            ?.score ?: 50.0
        val matchup = weightedScore(
            inverseRate(pitcherK, .17, .31) to .27,
            scoreRate(pitcherBb, .055, .115) to .14,
            scoreRate(pitcherWhip, 1.00, 1.52) to .23,
            scoreRate(pitcherEra, 2.75, 5.40) to .15,
            splitProduction to .16,
            arsenalSupport to .05
        )

        val ahead = context.teammates.filter { it.first < candidate.battingOrder }.map { it.second }
        val behind = context.teammates.filter { it.first > candidate.battingOrder }.map { it.second }
        val aheadObp = weightedTeamRate(ahead) { it.obp }
        val behindOps = weightedTeamRate(behind) { it.ops }
        val teamOps = weightedTeamRate(context.teammates.map { it.second }) { it.ops }

        val lineupContext = weightedScore(
            scoreRate(aheadObp, .295, .370) to .34,
            scoreRate(behindOps, .650, .850) to .36,
            scoreRate(teamOps, .650, .835) to .30
        )

        val opportunity = when (candidate.battingOrder) {
            1 -> 96.0
            2 -> 94.0
            3 -> 91.0
            4 -> 87.0
            5 -> 80.0
            6 -> 70.0
            7 -> 61.0
            8 -> 53.0
            else -> 46.0
        }

        val hitScore = weightedScore(
            contact to .46,
            matchup to .22,
            form to .18,
            opportunity to .14
        )

        val runScore = weightedScore(
            scoreRate(seasonObp, .285, .390) to .28,
            lineupContext to .28,
            opportunity to .23,
            matchup to .12,
            form to .09
        )

        val rbiScore = weightedScore(
            scoreRate(seasonSlg, .340, .550) to .25,
            scoreRate(seasonOps, .650, .900) to .18,
            scoreRate(aheadObp, .295, .375) to .24,
            matchup to .18,
            form to .15
        )

        var total = weightedScore(
            hitScore to .30,
            runScore to .19,
            rbiScore to .23,
            matchup to .10,
            lineupContext to .08,
            opportunity to .06,
            form to .04
        )

        // Hard guards against a noisy small recent sample manufacturing a "best" production play.
        if (seasonPa < 45) total = 50.0 + (total - 50.0) * .72
        if ((seasonK ?: .22) >= .32 && hitScore < 55.0) total -= 4.0
        if (candidate.battingOrder >= 8 && total < 78.0) total -= 3.0
        total = total.coerceIn(0.0, 100.0)

        // Keep raw expectation adjustments deliberately conservative until the calibration sample grows.
        val matchupFactor = (0.88 + matchup / 600.0).coerceIn(.92, 1.06)
        val lineupFactor = (0.92 + lineupContext / 800.0).coerceIn(.95, 1.05)
        val formFactor = (0.94 + form / 1000.0).coerceIn(.96, 1.04)

        val expectedHits = (seasonHitRate * expectedPa * matchupFactor * formFactor).coerceIn(.25, 1.85)
        val expectedRuns = (seasonRunRate * expectedPa * matchupFactor * lineupFactor * formFactor).coerceIn(.12, 1.45)
        val expectedRbi = (seasonRbiRate * expectedPa * matchupFactor * lineupFactor * formFactor).coerceIn(.12, 1.65)
        val expectedHrr = (expectedHits + expectedRuns + expectedRbi).coerceIn(.55, 4.35)

        val confidence = confidence(seasonPa, d14?.plateAppearances ?: 0, candidate.lineupOfficial, pitcher != null)
        val tags = buildList {
            if (hitScore >= 74) add("HIT FLOOR")
            if (runScore >= 72) add("RUN SETUP")
            if (rbiScore >= 72) add("RBI SPOT")
            if (matchup >= 70) add("PITCHER EDGE")
            if (lineupContext >= 70) add("LINEUP SUPPORT")
            if (form >= 72) add("FORM")
            if (opportunity >= 87) add("TOP ORDER")
        }.take(4)
        val notes = buildList {
            if (seasonAvg != null) add("Season AVG %.3f".format(seasonAvg))
            if (seasonObp != null) add("OBP %.3f".format(seasonObp))
            if (d14 != null && d14.plateAppearances > 0) add("14-day ${d14.hits} H • ${d14.runs} R • ${d14.rbi} RBI")
            if (candidate.battingOrder <= 4) add("Batting ${candidate.battingOrder} with strong PA opportunity")
            if (aheadObp != null && candidate.battingOrder in 3..6) add("Runners-on-base context %.3f OBP ahead".format(aheadObp))
            if (pitcherK != null) add("Opposing pitcher K%% %.1f".format(pitcherK * 100.0))
        }

        return ProductionBreakdown(
            hitScore = hitScore,
            runScore = runScore,
            rbiScore = rbiScore,
            matchupScore = matchup,
            lineupContextScore = lineupContext,
            opportunityScore = opportunity,
            formScore = form,
            contactQualityScore = contact,
            total = total,
            expectedHrr = expectedHrr,
            expectedHits = expectedHits,
            expectedRuns = expectedRuns,
            expectedRbi = expectedRbi,
            confidence = confidence,
            tags = tags,
            notes = notes
        )
    }

    private fun recentProductionForm(stats: RecentHittingStats?): Double {
        if (stats == null || stats.plateAppearances <= 0) return 50.0
        val hitRate = stats.hits.toDouble() / stats.plateAppearances
        val runRate = stats.runs.toDouble() / stats.plateAppearances
        val rbiRate = stats.rbi.toDouble() / stats.plateAppearances
        return weightedScore(
            scoreRate(hitRate, .15, .31) to .34,
            scoreRate(stats.avg, .180, .380) to .20,
            scoreRate(stats.obp, .260, .450) to .16,
            scoreRate(runRate, .055, .205) to .14,
            scoreRate(rbiRate, .055, .215) to .16
        )
    }

    private fun shrinkByPa(score: Double, pa: Int, fullPa: Int): Double {
        val c = (pa.toDouble() / fullPa).coerceIn(.18, 1.0)
        return 50.0 * (1.0 - c) + score * c
    }

    private fun confidence(seasonPa: Int, recentPa: Int, official: Boolean, pitcherKnown: Boolean): Double {
        val season = (seasonPa / 180.0).coerceIn(.25, 1.0)
        val recent = (recentPa / 36.0).coerceIn(.20, 1.0)
        val lineup = if (official) 1.0 else .76
        val pitcher = if (pitcherKnown) 1.0 else .70
        return (season * .36 + recent * .22 + lineup * .22 + pitcher * .20).coerceIn(.20, 1.0)
    }

    private fun weightedTeamRate(stats: List<RecentHittingStats>, getter: (RecentHittingStats) -> Double?): Double? {
        val values = stats.mapNotNull { s -> getter(s)?.let { it to s.plateAppearances.coerceAtLeast(1) } }
        if (values.isEmpty()) return null
        val weight = values.sumOf { it.second }
        return values.sumOf { it.first * it.second } / weight
    }

    private fun weightedScore(vararg parts: Pair<Double, Double>): Double {
        val totalWeight = parts.sumOf { it.second }.takeIf { it > 0.0 } ?: return 50.0
        return (parts.sumOf { it.first.coerceIn(0.0, 100.0) * it.second } / totalWeight).coerceIn(0.0, 100.0)
    }

    private fun scoreRate(value: Double?, low: Double, high: Double): Double {
        if (value == null || !value.isFinite() || high <= low) return 50.0
        return (((value - low) / (high - low)) * 100.0).coerceIn(0.0, 100.0)
    }

    private fun inverseRate(value: Double?, good: Double, bad: Double): Double {
        if (value == null || !value.isFinite() || bad <= good) return 50.0
        return (100.0 - ((value - good) / (bad - good)) * 100.0).coerceIn(0.0, 100.0)
    }
}
