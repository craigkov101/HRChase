package com.ckz.hrchase.data

import com.ckz.hrchase.model.HrScoringModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.roundToInt

private data class CurrentGameSummary(
    val gamePk: Long,
    val awayLineup: TeamLineup?,
    val homeLineup: TeamLineup?,
    val battedBalls: List<BattedBall>,
    val weather: WeatherInfo,
    val persons: Map<Int, PersonRef>,
    val pitcherStats: Map<Int, PitchingStats>
)


private data class AaaWatchSeed(
    val name: String,
    val position: String,
    val mlbOrg: String,
    val callupBase: Int,
    val reason: String
)

private val aaaWatchSeeds = listOf(
    AaaWatchSeed("Ralphy Velazquez", "1B/OF", "CLE", 97, "Elite left-handed power is forcing the issue, and Cleveland has a direct need for more first-base/DH offense."),
    AaaWatchSeed("Franklin Arias", "SS/2B", "BOS", 94, "Young for Triple-A with impact power, strong contact skills and a clear path to help Boston's infield."),
    AaaWatchSeed("Walker Jenkins", "OF", "MIN", 93, "Healthy again and producing at Triple-A; his all-around offensive profile could provide an immediate late-season jolt."),
    AaaWatchSeed("Sean Keys", "1B/3B", "TOR", 91, "Already tasted the Majors and returned to Triple-A with power; a September bench/power role is realistic."),
    AaaWatchSeed("Michael Arroyo", "2B/OF", "SEA", 89, "Advanced bat-to-ball skills with real barrel impact at Triple-A give Seattle another near-ready offensive option."),
    AaaWatchSeed("Lazaro Montes", "OF", "SEA", 87, "One of the loudest raw-power bats in the Minors; Triple-A exit velocity and home-run production make him impossible to ignore."),
    AaaWatchSeed("Seaver King", "SS/2B", "WSH", 86, "Recent Triple-A power surge plus defensive versatility gives Washington a plausible late-season audition candidate."),
    AaaWatchSeed("Charlie Condon", "1B/OF", "COL", 84, "Triple-A power has returned in a major way and Coors Field offers an obvious place to test whether it carries to the Majors."),
    AaaWatchSeed("Owen Ayers", "C/1B", "CHC", 82, "Right-handed power, on-base skill and multi-position utility create a possible stretch-run bench fit."),
    AaaWatchSeed("Leo Bernal", "C/1B", "STL", 80, "Career-best Triple-A power with solid contact and swing decisions keeps him on the edge of a Major League opportunity."),
    AaaWatchSeed("Cooper Ingle", "C/OF", "CLE", 78, "Versatility and legitimate Triple-A pop give Cleveland another bat worth watching if roster needs change."),
    AaaWatchSeed("Cam Cannarella", "OF", "MIA", 76, "Top-100 contact skills with enough game power and a quick climb to Triple-A make him a realistic late-season outfield audition." )
)

private data class RecentGameSummary(
    val game: GameInfo,
    val awayLineup: TeamLineup?,
    val homeLineup: TeamLineup?,
    val battedBalls: List<BattedBall>,
    val plateDiscipline: Map<Int, PlateDisciplineSample>
)

class Repository(
    private val api: MlbApi = MlbApi(),
    private val scoringModel: HrScoringModel = HrScoringModel()
) {
    /** Optional enrichments must never cancel or erase an otherwise usable slate. */
    private suspend fun <T> safe(default: T, block: suspend () -> T): T = try {
        block()
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (_: Throwable) {
        default
    }

    private suspend fun <T> safeOrNull(block: suspend () -> T): T? = try {
        block()
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (_: Throwable) {
        null
    }

    /**
     * Backfills outcomes for saved pregame learning snapshots when the app was not opened on the
     * immediately following day. Returns null when the date cannot be verified as a completed MLB
     * slate, preventing an outage from being recorded as a zero-HR day.
     */
    suspend fun fetchHomeRunHitterIds(date: LocalDate): Set<Int>? = coroutineScope {
        val schedule = safeOrNull { api.fetchSchedule(date) } ?: return@coroutineScope null
        if (schedule.isEmpty()) return@coroutineScope null
        val completed = schedule.filter { it.status.equals("Final", true) }
        if (completed.size < schedule.size) return@coroutineScope null
        val gate = Semaphore(4)
        val feeds = completed.map { game ->
            async {
                gate.withPermit { safeOrNull { api.fetchGameFeed(game.gamePk, 12 * 60 * 60 * 1000L) } }
            }
        }.awaitAll()
        if (feeds.any { it == null }) return@coroutineScope null
        feeds.filterNotNull()
            .flatMap { it.battedBalls }
            .filter { it.isHomeRun }
            .map { it.batterId }
            .filter { it > 0 }
            .toSet()
    }

    /** One bulk StatsAPI call resolves H/R/RBI outcomes for production-model learning. */
    suspend fun fetchDailyHittingOutcomes(date: LocalDate): Map<Int, RecentHittingStats>? = coroutineScope {
        val schedule = safeOrNull { api.fetchSchedule(date) } ?: return@coroutineScope null
        if (schedule.isEmpty() || schedule.any { !it.status.equals("Final", true) }) return@coroutineScope null
        safeOrNull { api.fetchLeagueHittingDateRangeStats(date, date) }?.takeIf { it.size >= 30 }
    }

    private fun cleanLineup(lineup: TeamLineup?): TeamLineup? {
        lineup ?: return null
        val players = lineup.players
            .asSequence()
            .filter { it.person.id > 0 && it.battingOrder in 1..9 }
            .distinctBy { it.person.id }
            .distinctBy { it.battingOrder }
            .sortedBy { it.battingOrder }
            .take(9)
            .toList()
        if (players.isEmpty()) return null
        return lineup.copy(players = players)
    }

    /**
     * MLB occasionally exposes a partially populated battingOrder for a few seconds while lineups
     * are posting. Never shrink a game to 2-6 hitters. Merge missing slots from the most recent real
     * lineup and mark the result projected until all nine current slots are present.
     */
    private fun chooseLineup(current: TeamLineup?, fallback: TeamLineup?): TeamLineup? {
        val live = cleanLineup(current)
        val prior = cleanLineup(fallback)
        if (live != null && live.players.size >= 9) return live.copy(official = true)
        if (live == null) return prior?.copy(
            official = false,
            players = prior.players.map { it.copy(official = false) }
        )
        if (prior == null) return live.copy(
            official = false,
            players = live.players.map { it.copy(official = false) }
        )

        val byOrder = prior.players.associateBy { it.battingOrder }.toMutableMap()
        live.players.forEach { byOrder[it.battingOrder] = it }
        val merged = byOrder.values
            .sortedBy { it.battingOrder }
            .distinctBy { it.person.id }
            .take(9)
            .map { it.copy(official = false) }
        return TeamLineup(team = live.team, players = merged, official = false)
    }

    private fun sanitizeCandidates(candidates: List<HitterCandidate>, games: List<GameInfo>): List<HitterCandidate> {
        val validGames = games.associateBy { it.gamePk }
        return candidates.asSequence()
            .filter { c ->
                val game = validGames[c.game.gamePk]
                game != null && c.player.id > 0 && c.battingOrder in 1..9 &&
                    c.team.id != c.opponent.id &&
                    c.team.id in setOf(game.awayTeam.id, game.homeTeam.id) &&
                    c.opponent.id in setOf(game.awayTeam.id, game.homeTeam.id) &&
                    c.score.total.isFinite()
            }
            .distinctBy { it.game.gamePk to it.player.id }
            .sortedByDescending { it.score.total }
            .toList()
    }
    suspend fun loadBoard(
        date: LocalDate,
        weights: ScoreWeights,
        lookbackDays: Int = 5,
        onProgress: (String) -> Unit = {},
        onPartialBoard: (BoardData) -> Unit = {}
    ): BoardData = coroutineScope {
        onProgress("Loading MLB schedule…")
        val schedule = api.fetchSchedule(date)
        if (schedule.isEmpty()) {
            return@coroutineScope BoardData(date, emptyList(), emptyList(), Instant.now(), 0)
        }

        // Render the slate immediately. The expensive contact/BvP enrichment continues below,
        // but users should see today's games within the first schedule request instead of staring
        // at a blank spinner.
        onPartialBoard(BoardData(date, emptyList(), schedule, Instant.now(), 0))

        val todayTeamIds = schedule.flatMap { listOf(it.awayTeam.id, it.homeTeam.id) }.toSet()
        val semaphore = Semaphore(5)

        onProgress("Loading today's lineups and game data…")
        // Keep only compact fields from today's live feeds. Retaining 15 full MLB JSONObject trees
        // was the largest memory spike in v0.8 and could cause Android to kill the app mid-refresh.
        val currentFeeds = schedule.map { game ->
            async {
                semaphore.withPermit {
                    safeOrNull {
                        val feedTtl = if (game.status.equals("Final", true) || date.isBefore(LocalDate.now())) {
                            8 * 60 * 60 * 1000L
                        } else {
                            45 * 1000L
                        }
                        val feed = api.fetchGameFeed(game.gamePk, feedTtl)
                        val away = api.extractTeamLineup(feed, "away", game.awayTeam)
                            .takeIf { it.players.isNotEmpty() }
                        val home = api.extractTeamLineup(feed, "home", game.homeTeam)
                            .takeIf { it.players.isNotEmpty() }
                        val probableIds = listOfNotNull(
                            game.awayProbablePitcher?.id,
                            game.homeProbablePitcher?.id
                        ).distinct()
                        val persons = probableIds.mapNotNull { id ->
                            api.extractPerson(feed.root, id)?.let { id to it }
                        }.toMap()
                        val pitcherStats = probableIds.mapNotNull { id ->
                            api.extractPitchingStatsFromFeed(feed.root, id)?.let { id to it }
                        }.toMap()
                        CurrentGameSummary(
                            gamePk = game.gamePk,
                            awayLineup = away,
                            homeLineup = home,
                            battedBalls = feed.battedBalls,
                            weather = feed.weather,
                            persons = persons,
                            pitcherStats = pitcherStats
                        )
                    }
                }
            }
        }.awaitAll().filterNotNull().associateBy { it.gamePk }

        val recentStart = date.minusDays(lookbackDays.toLong())
        val recentEnd = date.minusDays(1)
        onProgress("Finding recent games for contact signals…")
        val recentSchedule = if (!recentEnd.isBefore(recentStart)) {
            val allRecent = safe(emptyList()) { api.fetchScheduleRange(recentStart, recentEnd) }
                .asSequence()
                .filter { it.status.equals("Final", true) }
                .filter { it.awayTeam.id in todayTeamIds || it.homeTeam.id in todayTeamIds }
                .distinctBy { it.gamePk }
                .sortedByDescending { it.gameDate }
                .toList()

            // First guarantee at least one recent lineup source for every team on today's slate,
            // then fill the remaining budget with the newest games. This keeps projected lineups
            // available without going back to an unbounded 70+ feed download.
            val selected = LinkedHashMap<Long, GameInfo>()
            val coveredTeams = mutableSetOf<Int>()
            for (game in allRecent) {
                val relevant = listOf(game.awayTeam.id, game.homeTeam.id).filter { it in todayTeamIds }
                if (relevant.any { it !in coveredTeams }) {
                    selected[game.gamePk] = game
                    coveredTeams += relevant
                }
                if (coveredTeams.containsAll(todayTeamIds)) break
            }
            for (game in allRecent) {
                if (selected.size >= 30) break
                selected.putIfAbsent(game.gamePk, game)
            }
            selected.values.take(24)
        } else emptyList()

        onProgress("Loading ${recentSchedule.size} recent game feeds…")
        // IMPORTANT: do not retain the full live-feed JSON for every recent game. A five-day slate
        // can contain dozens of very large JSONObject trees and can push Android over its memory
        // limit. Extract only the compact pieces we need, then let each feed be garbage-collected.
        val recentSummaries = recentSchedule.map { game ->
            async {
                semaphore.withPermit {
                    safeOrNull {
                        val feed = api.fetchGameFeed(game.gamePk, 12 * 60 * 60 * 1000L)
                        val away = api.extractTeamLineup(feed, "away", game.awayTeam, forceProjected = true)
                            .takeIf { it.players.isNotEmpty() }
                        val home = api.extractTeamLineup(feed, "home", game.homeTeam, forceProjected = true)
                            .takeIf { it.players.isNotEmpty() }
                        RecentGameSummary(
                            game = game,
                            awayLineup = away,
                            homeLineup = home,
                            battedBalls = feed.battedBalls,
                            plateDiscipline = feed.plateDiscipline
                        )
                    }
                }
            }
        }.awaitAll().filterNotNull()

        // Last-night outcome feedback. Reuse any recent feeds already in memory and only fetch
        // missing games so the feature does not double the normal network work. Unlike the recent
        // contact window, this intentionally covers the entire MLB slate so the displayed HR count
        // is a true league-wide total, including teams that are off today.
        val previousNightDate = date.minusDays(1)
        onProgress("Checking last night's home runs…")
        val recentByGamePk = recentSummaries.associateBy { it.game.gamePk }
        val previousNightSchedule = safe(emptyList()) { api.fetchSchedule(previousNightDate) }
            .filter { it.status.equals("Final", true) }
        val previousNightSummaries = previousNightSchedule.map { game ->
            async {
                recentByGamePk[game.gamePk] ?: semaphore.withPermit {
                    safeOrNull {
                        val feed = api.fetchGameFeed(game.gamePk, 12 * 60 * 60 * 1000L)
                        RecentGameSummary(
                            game = game,
                            awayLineup = api.extractTeamLineup(feed, "away", game.awayTeam, forceProjected = true)
                                .takeIf { it.players.isNotEmpty() },
                            homeLineup = api.extractTeamLineup(feed, "home", game.homeTeam, forceProjected = true)
                                .takeIf { it.players.isNotEmpty() },
                            battedBalls = feed.battedBalls,
                            plateDiscipline = feed.plateDiscipline
                        )
                    }
                }
            }
        }.awaitAll().filterNotNull()

        fun teamForBatter(summary: RecentGameSummary, batterId: Int): TeamRef? = when {
            summary.awayLineup?.players?.any { it.person.id == batterId } == true -> summary.game.awayTeam
            summary.homeLineup?.players?.any { it.person.id == batterId } == true -> summary.game.homeTeam
            else -> null
        }

        val previousNightHrBalls = previousNightSummaries.flatMap { summary ->
            summary.battedBalls.filter { it.isHomeRun }.map { ball -> summary to ball }
        }
        val previousNightHomers = previousNightHrBalls
            .groupBy { (_, ball) -> ball.batterId }
            .map { (batterId, rows) ->
                val balls = rows.map { it.second }
                val firstSummary = rows.first().first
                PreviousNightHomer(
                    playerId = batterId,
                    playerName = balls.firstOrNull()?.batterName ?: "Player $batterId",
                    team = rows.firstNotNullOfOrNull { (summary, _) -> teamForBatter(summary, batterId) },
                    gamePk = firstSummary.game.gamePk,
                    homeRuns = balls.size,
                    maxExitVelocity = balls.mapNotNull { it.exitVelocity }.maxOrNull(),
                    longestDistanceFt = balls.mapNotNull { it.distanceFt }.maxOrNull(),
                    launchAngles = balls.mapNotNull { it.launchAngle },
                    pitchTypes = balls.mapNotNull { it.pitchType }.distinct()
                )
            }
            .sortedWith(compareByDescending<PreviousNightHomer> { it.homeRuns }.thenByDescending { it.maxExitVelocity ?: 0.0 })

        val previousNight = PreviousNightSummary(
            date = previousNightDate,
            totalHomeRuns = previousNightHrBalls.size,
            uniqueHitters = previousNightHomers.size,
            finalGames = previousNightSummaries.size,
            homers = previousNightHomers
        )

        val allRecentBalls = recentSummaries.flatMap { it.battedBalls }
        val recentBallsByBatter = allRecentBalls.groupBy { it.batterId }
        val recentBallsByPitcher = allRecentBalls.groupBy { it.pitcherId }
        val recentDisciplineByBatter = mutableMapOf<Int, PlateDisciplineSample>()
        val last3DisciplineByBatter = mutableMapOf<Int, PlateDisciplineSample>()
        val last3Start = date.minusDays(3)
        val last3End = date.minusDays(1)
        recentSummaries.forEach { summary ->
            val gameLocalDate = summary.game.gameDate.atZone(ZoneId.of("America/New_York")).toLocalDate()
            summary.plateDiscipline.forEach { (batterId, sample) ->
                recentDisciplineByBatter[batterId] =
                    (recentDisciplineByBatter[batterId] ?: PlateDisciplineSample()) + sample
                if (!gameLocalDate.isBefore(last3Start) && !gameLocalDate.isAfter(last3End)) {
                    last3DisciplineByBatter[batterId] =
                        (last3DisciplineByBatter[batterId] ?: PlateDisciplineSample()) + sample
                }
            }
        }

        // Build a most-recent real lineup for fallback when today's lineup has not posted yet.
        val latestLineupByTeam = mutableMapOf<Int, TeamLineup>()
        recentSummaries.sortedByDescending { it.game.gameDate }.forEach { summary ->
            val game = summary.game
            if (game.awayTeam.id !in latestLineupByTeam) {
                summary.awayLineup?.let { latestLineupByTeam[game.awayTeam.id] = it }
            }
            if (game.homeTeam.id !in latestLineupByTeam) {
                summary.homeLineup?.let { latestLineupByTeam[game.homeTeam.id] = it }
            }
        }

        onProgress("Loading recent hitter form…")
        val seasonProductionStart = LocalDate.of(date.year, 3, 1)
        val recentFormMaps = listOf(
            "week" to (date.minusDays(7) to date.minusDays(1)),
            "three" to (date.minusDays(3) to date.minusDays(1)),
            "fourteen" to (date.minusDays(14) to date.minusDays(1)),
            "seasonProduction" to (seasonProductionStart to date.minusDays(1))
        ).map { (key, range) ->
            async {
                semaphore.withPermit {
                    key to safe(emptyMap()) { api.fetchLeagueHittingDateRangeStats(range.first, range.second) }
                }
            }
        }.awaitAll().toMap()
        val recentWeekStats = recentFormMaps["week"].orEmpty()
        val recentThreeDayStats = recentFormMaps["three"].orEmpty()
        val recentFourteenDayStats = recentFormMaps["fourteen"].orEmpty()
        val seasonProductionStats = recentFormMaps["seasonProduction"].orEmpty()

        onProgress("Adding handedness splits…")
        val season = date.year
        val splitMaps = listOf("vr", "vl").map { code ->
            async {
                semaphore.withPermit {
                    code to safe(emptyMap()) { api.fetchLeagueHittingSplitStats(season, code) }
                }
            }
        }.awaitAll().toMap()
        val vsRightPitching = splitMaps["vr"].orEmpty()
        val vsLeftPitching = splitMaps["vl"].orEmpty()

        val pitcherIds = schedule.flatMap { listOfNotNull(it.awayProbablePitcher?.id, it.homeProbablePitcher?.id) }.distinct()
        val pitchTypes = commonPitchTypes()

        // Build the core slate first. Pitch arsenals are a secondary enrichment and must never
        // prevent games/players from appearing if MLB's metrics endpoint is slow or unavailable.
        onProgress("Building pitcher profiles…")
        val pitcherProfiles = pitcherIds.map { id ->
            async {
                semaphore.withPermit {
                    val person = currentFeeds.values.firstNotNullOfOrNull { it.persons[id] }
                    var stats = currentFeeds.values.firstNotNullOfOrNull { it.pitcherStats[id] }
                    if (stats == null || stats == PitchingStats()) {
                        stats = safeOrNull { api.fetchPitchingStats(id, season) }
                    }
                    id to PitcherProfile(
                        person = person ?: PersonRef(id, "Pitcher $id"),
                        seasonStats = stats ?: PitchingStats(),
                        recentBattedBallsAllowed = recentBallsByPitcher[id].orEmpty(),
                        seasonPitchArsenal = emptyList()
                    )
                }
            }
        }.awaitAll().toMap()

        onProgress("Scoring hitters…")
        val enrichedGames = schedule.map { game ->
            val feed = currentFeeds[game.gamePk]
            if (feed != null) game.copy(weather = feed.weather) else game
        }

        val rawBaseCandidates = buildList {
            enrichedGames.forEach { game ->
                val current = currentFeeds[game.gamePk]
                val awayOfficial = current?.awayLineup
                val homeOfficial = current?.homeLineup
                val awayLineup = chooseLineup(awayOfficial, latestLineupByTeam[game.awayTeam.id])
                val homeLineup = chooseLineup(homeOfficial, latestLineupByTeam[game.homeTeam.id])

                val awayPitcherId = game.awayProbablePitcher?.id
                val homePitcherId = game.homeProbablePitcher?.id
                val awayPitcherProfile = awayPitcherId?.let { pitcherProfiles[it] }
                val homePitcherProfile = homePitcherId?.let { pitcherProfiles[it] }

                awayLineup?.players?.forEach { lp ->
                    val recent = recentBallsByBatter[lp.person.id].orEmpty().sortedBy { it.gameDate }
                    val today = current?.battedBalls?.filter { it.batterId == lp.person.id }.orEmpty()
                    val platoonStats = when (homePitcherProfile?.person?.pitchHand) {
                        "R" -> vsRightPitching[lp.person.id]
                        "L" -> vsLeftPitching[lp.person.id]
                        else -> null
                    }
                    val score = scoringModel.score(
                        player = lp.person,
                        battingOrder = lp.battingOrder,
                        lineupOfficial = awayLineup.official,
                        seasonStats = lp.seasonStats,
                        platoonStats = platoonStats,
                        recentBattedBalls = recent,
                        opponentPitcher = homePitcherProfile,
                        game = game,
                        weights = weights
                    )
                    add(
                        HitterCandidate(
                            player = lp.person,
                            team = game.awayTeam,
                            opponent = game.homeTeam,
                            game = game,
                            battingOrder = lp.battingOrder,
                            lineupOfficial = awayLineup.official,
                            seasonStats = lp.seasonStats,
                            opponentPitcher = homePitcherProfile,
                            recentBattedBalls = recent,
                            todayBattedBalls = today,
                            recentPlateDiscipline = recentDisciplineByBatter[lp.person.id] ?: PlateDisciplineSample(),
                            last3PlateDiscipline = last3DisciplineByBatter[lp.person.id] ?: PlateDisciplineSample(),
                            score = score,
                            platoonStats = platoonStats
                        )
                    )
                }

                homeLineup?.players?.forEach { lp ->
                    val recent = recentBallsByBatter[lp.person.id].orEmpty().sortedBy { it.gameDate }
                    val today = current?.battedBalls?.filter { it.batterId == lp.person.id }.orEmpty()
                    val platoonStats = when (awayPitcherProfile?.person?.pitchHand) {
                        "R" -> vsRightPitching[lp.person.id]
                        "L" -> vsLeftPitching[lp.person.id]
                        else -> null
                    }
                    val score = scoringModel.score(
                        player = lp.person,
                        battingOrder = lp.battingOrder,
                        lineupOfficial = homeLineup.official,
                        seasonStats = lp.seasonStats,
                        platoonStats = platoonStats,
                        recentBattedBalls = recent,
                        opponentPitcher = awayPitcherProfile,
                        game = game,
                        weights = weights
                    )
                    add(
                        HitterCandidate(
                            player = lp.person,
                            team = game.homeTeam,
                            opponent = game.awayTeam,
                            game = game,
                            battingOrder = lp.battingOrder,
                            lineupOfficial = homeLineup.official,
                            seasonStats = lp.seasonStats,
                            opponentPitcher = awayPitcherProfile,
                            recentBattedBalls = recent,
                            todayBattedBalls = today,
                            recentPlateDiscipline = recentDisciplineByBatter[lp.person.id] ?: PlateDisciplineSample(),
                            last3PlateDiscipline = last3DisciplineByBatter[lp.person.id] ?: PlateDisciplineSample(),
                            score = score,
                            platoonStats = platoonStats
                        )
                    )
                }
            }
        }.sortedByDescending { it.score.total }
        val baseCandidates = sanitizeCandidates(rawBaseCandidates, enrichedGames)

        // At this point the board is already useful: lineups, recent power, pitcher matchup,
        // weather and all core model scores are ready. Publish it now and enrich BvP afterward so
        // the UI remains usable while the final small batch of network calls finishes.
        onPartialBoard(
            BoardData(
                date = date,
                candidates = baseCandidates,
                games = enrichedGames,
                lastUpdated = Instant.now(),
                recentGameCount = recentSummaries.size,
                recentWeekStats = recentWeekStats,
                recentThreeDayStats = recentThreeDayStats,
                recentFourteenDayStats = recentFourteenDayStats,
                seasonProductionStats = seasonProductionStats,
                previousNight = previousNight
            )
        )

        // Pitch Arsenal Fit v2: use Baseball Savant's purpose-built pitch-arsenal leaderboards
        // instead of relying on StatsAPI metricAverages, which frequently returned empty maps.
        // Three bulk requests cover the whole slate: batter pitch results, pitcher pitch usage/
        // results, and direct HR-ending pitch types for today's hitters. The core board is already
        // visible, so a slow Savant response never blocks games from loading.
        onProgress("Adding Statcast pitch arsenal fit…")
        val arsenalBatterIds = baseCandidates.map { it.player.id }.distinct()
        val savantBatterDeferred = async {
            safe(emptyMap()) { withTimeoutOrNull(24_000) { api.fetchSavantPitchArsenalStats(season, "batter") }.orEmpty() }
        }
        val savantPitcherDeferred = async {
            safe(emptyMap()) { withTimeoutOrNull(24_000) { api.fetchSavantPitchArsenalStats(season, "pitcher") }.orEmpty() }
        }
        val hrPitchDeferred = async {
            safe(emptyMap()) { withTimeoutOrNull(28_000) { api.fetchSavantHomeRunPitchCounts(arsenalBatterIds, season) }.orEmpty() }
        }

        val savantBatterRows = savantBatterDeferred.await()
        val savantPitcherRows = savantPitcherDeferred.await()
        val savantHrPitchCounts = hrPitchDeferred.await()

        // If Savant is temporarily unavailable, retain the old StatsAPI pitch-count path as a
        // fallback for pitcher usage. It is no longer the primary source.
        val fallbackPitcherArsenalById: Map<Int, List<PitchTypeUsage>> = if (savantPitcherRows.isEmpty()) {
            val arsenalSemaphore = Semaphore(3)
            suspend fun fallbackOccurrences(code: String): Map<Int, Int> {
                repeat(2) { attempt ->
                    val result = arsenalSemaphore.withPermit {
                        safe(emptyMap()) {
                            withTimeoutOrNull(12_000) {
                                api.fetchPitchTypeOccurrences(pitcherIds, season, code, "pitching")
                            }.orEmpty()
                        }
                    }
                    if (result.isNotEmpty()) return result
                    if (attempt == 0) delay(350)
                }
                return emptyMap()
            }
            val byType = pitchTypes.map { code -> async { code to fallbackOccurrences(code) } }.awaitAll().toMap()
            pitcherIds.associateWith { pitcherId ->
                buildPitchArsenal(pitchTypes.associateWith { code -> byType[code]?.get(pitcherId) ?: 0 })
            }
        } else emptyMap()

        val pitcherArsenalById = pitcherIds.associateWith { pitcherId ->
            val rows = savantPitcherRows[pitcherId].orEmpty()
            if (rows.isNotEmpty()) buildPitchArsenal(rows) else fallbackPitcherArsenalById[pitcherId].orEmpty()
        }
        val candidatesWithPitcherArsenal = baseCandidates.map { candidate ->
            val profile = candidate.opponentPitcher
            val pitcherId = profile?.person?.id
            if (profile == null || pitcherId == null) candidate
            else candidate.copy(
                opponentPitcher = profile.copy(seasonPitchArsenal = pitcherArsenalById[pitcherId].orEmpty())
            )
        }

        // Recent feed HR pitches provide a second fallback for direct HR-pitch history. This is
        // intentionally only a fallback; season-long Savant HR data is preferred whenever present.
        val recentHrPitchCounts = recentBallsByBatter.mapValues { (_, balls) ->
            balls.asSequence()
                .filter { it.isHomeRun && !it.pitchType.isNullOrBlank() }
                .groupingBy { it.pitchType!! }
                .eachCount()
        }

        val arsenalCandidates = candidatesWithPitcherArsenal.map { candidate ->
            val pitcherId = candidate.opponentPitcher?.person?.id
            val pitcherArsenal = candidate.opponentPitcher?.seasonPitchArsenal.orEmpty()
            if (pitcherId == null || pitcherArsenal.isEmpty()) return@map candidate

            val directHrCounts = savantHrPitchCounts[candidate.player.id]
                ?.takeIf { it.values.sum() > 0 }
                ?: recentHrPitchCounts[candidate.player.id].orEmpty()
            val batterRows = savantBatterRows[candidate.player.id].orEmpty()
            val pitcherRows = savantPitcherRows[pitcherId].orEmpty()
            val match = buildPitchArsenalMatch(
                hitterHrCounts = directHrCounts,
                pitcherArsenal = pitcherArsenal,
                batterPitchRows = batterRows,
                pitcherPitchRows = pitcherRows,
                source = when {
                    batterRows.isNotEmpty() && pitcherRows.isNotEmpty() && directHrCounts.isNotEmpty() -> "Baseball Savant Statcast"
                    batterRows.isNotEmpty() && pitcherRows.isNotEmpty() -> "Savant pitch results"
                    else -> "MLB pitch data fallback"
                }
            )
            if (match == null) candidate else candidate.copy(pitchArsenalMatch = match)
        }

        onPartialBoard(
            BoardData(
                date = date,
                candidates = arsenalCandidates,
                games = enrichedGames,
                lastUpdated = Instant.now(),
                recentGameCount = recentSummaries.size,
                recentWeekStats = recentWeekStats,
                recentThreeDayStats = recentThreeDayStats,
                recentFourteenDayStats = recentFourteenDayStats,
                seasonProductionStats = seasonProductionStats,
                previousNight = previousNight
            )
        )

        // BvP is useful, but it should never hold the whole slate hostage. v0.8 fetched up to
        // ~100 matchups (7 per game). We now fetch the top two preliminary hitters per game plus
        // the best 12 overall, usually ~30 lookups total.
        onProgress("Adding BvP context…")
        fun preliminaryRank(c: HitterCandidate): Double {
            val profile = scoringModel.mustHaveMetrics(c.player, c.seasonStats, c.recentBattedBalls)
            val profileAdjusted = profile.score * profile.confidence +
                c.score.seasonPower * (1.0 - profile.confidence)
            return profileAdjusted * 0.35 +
                c.score.powerPressure * 0.25 +
                c.score.pitcherMatchup * 0.30 +
                c.score.total * 0.10
        }

        val perGameBvp = arsenalCandidates
            .groupBy { it.game.gamePk }
            .values
            .flatMap { gameCandidates -> gameCandidates.sortedByDescending(::preliminaryRank).take(2) }
        val globalBvp = arsenalCandidates.sortedByDescending(::preliminaryRank).take(12)
        val bvpTargets = (perGameBvp + globalBvp)
            .mapNotNull { c -> c.opponentPitcher?.person?.id?.let { pitcherId -> Triple(c.player.id, pitcherId, c) } }
            .distinctBy { it.first to it.second }

        val bvpByPair = bvpTargets.map { (batterId, pitcherId, _) ->
            async {
                semaphore.withPermit {
                    val stats = safeOrNull { api.fetchHittingVsPitcherStats(batterId, pitcherId) }
                    (batterId to pitcherId) to stats
                }
            }
        }.awaitAll().mapNotNull { (key, stats) -> stats?.let { key to it } }.toMap()

        val enrichedCandidates = arsenalCandidates.map { candidate ->
            val pitcherId = candidate.opponentPitcher?.person?.id
            val bvp = pitcherId?.let { bvpByPair[candidate.player.id to it] }
            candidate.copy(vsPitcherStats = bvp)
        }.sortedByDescending { it.score.total }
        val candidates = sanitizeCandidates(enrichedCandidates, enrichedGames)

        onProgress("Ready")
        BoardData(
            date = date,
            candidates = candidates,
            games = enrichedGames,
            lastUpdated = Instant.now(),
            recentGameCount = recentSummaries.size,
            recentWeekStats = recentWeekStats,
            recentThreeDayStats = recentThreeDayStats,
            recentFourteenDayStats = recentFourteenDayStats,
            seasonProductionStats = seasonProductionStats,
            previousNight = previousNight
        )
    }
    private fun commonPitchTypes(): List<String> = listOf(
        "FF", "SI", "FC", "SL", "ST", "SV", "CU", "KC", "CS",
        "CH", "FS", "FO", "SC", "KN", "EP", "FA"
    )

    private fun buildPitchArsenal(counts: Map<String, Int>): List<PitchTypeUsage> {
        val total = counts.values.sum()
        if (total <= 0) return emptyList()
        return counts.entries
            .filter { it.value > 0 }
            .map { (code, count) ->
                PitchTypeUsage(
                    code = code,
                    name = api.pitchTypeName(code),
                    count = count,
                    share = count.toDouble() / total
                )
            }
            .sortedByDescending { it.share }
    }

    private fun buildPitchArsenal(rows: List<SavantPitchArsenalRow>): List<PitchTypeUsage> {
        val valid = rows.filter { it.pitches > 0 }
        val total = valid.sumOf { it.pitches }
        if (total <= 0) return emptyList()
        return valid
            .groupBy { it.code }
            .map { (code, pitchRows) ->
                val count = pitchRows.sumOf { it.pitches }
                PitchTypeUsage(
                    code = code,
                    name = pitchRows.firstOrNull()?.name ?: api.pitchTypeName(code),
                    count = count,
                    share = count.toDouble() / total
                )
            }
            .filter { it.count > 0 }
            .sortedByDescending { it.share }
    }

    private fun arsenalScale(value: Double?, low: Double, high: Double): Double {
        if (value == null || value.isNaN()) return 50.0
        if (high <= low) return 50.0
        return (((value - low) / (high - low)) * 100.0).coerceIn(0.0, 100.0)
    }

    /**
     * Pitch Arsenal Fit v2. This is no longer just a cosine comparison of HR pitch labels.
     * It combines four independent questions:
     *  1) Does today's pitcher throw the pitches behind this hitter's season HRs?
     *  2) How concentrated is exposure to the hitter's best HR pitch types?
     *  3) Has the hitter actually produced SLG/xSLG/hard contact against those pitch types?
     *  4) Has today's pitcher allowed damage with those same pitches?
     *
     * Direct HR-pitch history is preferred, but if that feed is unavailable we can still score
     * a real matchup from Savant's batter/pitcher pitch-type leaderboards instead of showing N/A.
     */
    private fun buildPitchArsenalMatch(
        hitterHrCounts: Map<String, Int>,
        pitcherArsenal: List<PitchTypeUsage>,
        batterPitchRows: List<SavantPitchArsenalRow> = emptyList(),
        pitcherPitchRows: List<SavantPitchArsenalRow> = emptyList(),
        source: String = "MLB Statcast"
    ): PitchArsenalMatch? {
        val pitchTotal = pitcherArsenal.sumOf { it.count }
        if (pitchTotal <= 0) return null

        val arsenalShares = pitcherArsenal.associate { it.code to it.share }
        val batterByCode = batterPitchRows.associateBy { it.code }
        val pitcherByCode = pitcherPitchRows.associateBy { it.code }
        val codes = commonPitchTypes().filter { (arsenalShares[it] ?: 0.0) > 0.0 }
        if (codes.isEmpty()) return null

        val batterPitchSample = batterPitchRows.sumOf { it.pitches }
        val hrTotal = hitterHrCounts.values.sum()
        val hrShares = if (hrTotal > 0) hitterHrCounts.mapValues { (_, n) -> n.toDouble() / hrTotal } else emptyMap()

        // Direct HR alignment: cosine rewards similar shape; exposure rewards the pitcher actually
        // leaning on the hitter's most frequently homered-off pitch types.
        val hrAlignmentScore: Double? = if (hrTotal > 0) {
            val dot = codes.sumOf { (hrShares[it] ?: 0.0) * (arsenalShares[it] ?: 0.0) }
            val hrNorm = kotlin.math.sqrt(commonPitchTypes().sumOf { val v = hrShares[it] ?: 0.0; v * v })
            val pitchNorm = kotlin.math.sqrt(commonPitchTypes().sumOf { val v = arsenalShares[it] ?: 0.0; v * v })
            if (hrNorm > 0.0 && pitchNorm > 0.0) (dot / (hrNorm * pitchNorm)).coerceIn(0.0, 1.0) * 100.0 else null
        } else null

        val topHrCodes = hitterHrCounts.entries
            .filter { it.value > 0 }
            .sortedByDescending { it.value }
            .take(3)
            .map { it.key }
        val feastExposure = if (topHrCodes.isNotEmpty()) topHrCodes.sumOf { arsenalShares[it] ?: 0.0 } else 0.0
        val exposureScore: Double? = if (topHrCodes.isNotEmpty())
            arsenalScale(feastExposure, 0.12, 0.72) else null

        // Weighted damage across the pitches today's starter actually throws. xSLG gets the most
        // weight because it is less result-dependent than raw SLG; hard-hit and wOBA add support.
        var batterDamageWeighted = 0.0
        var batterCoveredUsage = 0.0
        var pitcherVulnerabilityWeighted = 0.0
        var pitcherCoveredUsage = 0.0
        codes.forEach { code ->
            val usage = arsenalShares[code] ?: 0.0
            batterByCode[code]?.let { row ->
                val damage =
                    arsenalScale(row.xslg, .260, .650) * .42 +
                    arsenalScale(row.slg, .250, .620) * .25 +
                    arsenalScale(row.xwoba ?: row.woba, .250, .420) * .13 +
                    arsenalScale(row.hardHitPct, 25.0, 55.0) * .20
                batterDamageWeighted += damage * usage
                batterCoveredUsage += usage
            }
            pitcherByCode[code]?.let { row ->
                val vulnerability =
                    arsenalScale(row.xslg, .260, .620) * .45 +
                    arsenalScale(row.slg, .240, .600) * .25 +
                    arsenalScale(row.xwoba ?: row.woba, .245, .410) * .12 +
                    arsenalScale(row.hardHitPct, 25.0, 52.0) * .18
                pitcherVulnerabilityWeighted += vulnerability * usage
                pitcherCoveredUsage += usage
            }
        }
        val batterDamageScore = if (batterCoveredUsage >= .12) batterDamageWeighted / batterCoveredUsage else null
        val pitcherVulnerabilityScore = if (pitcherCoveredUsage >= .12) pitcherVulnerabilityWeighted / pitcherCoveredUsage else null

        val components = mutableListOf<Pair<Double, Double>>()
        if (hrAlignmentScore != null) components += hrAlignmentScore to .30
        if (exposureScore != null) components += exposureScore to .18
        if (batterDamageScore != null) components += batterDamageScore to .34
        if (pitcherVulnerabilityScore != null) components += pitcherVulnerabilityScore to .18
        if (components.isEmpty()) return null
        val totalWeight = components.sumOf { it.second }
        val raw = components.sumOf { it.first * it.second } / totalWeight

        val hrConfidence = if (hrTotal > 0) (hrTotal / 10.0).coerceIn(.22, 1.0) else .0
        val batterConfidence = if (batterPitchSample > 0) (batterPitchSample / 650.0).coerceIn(.25, 1.0) else .0
        val pitcherConfidence = (pitchTotal / 900.0).coerceIn(.35, 1.0)
        val coverageConfidence = ((batterCoveredUsage + pitcherCoveredUsage) / 2.0).coerceIn(.20, 1.0)
        val confidence = if (hrTotal > 0) {
            (hrConfidence * .35 + batterConfidence * .25 + pitcherConfidence * .25 + coverageConfidence * .15)
        } else {
            // Even without direct HR-event rows, season pitch-type damage + opponent usage is a
            // real measured matchup. Keep confidence lower so it cannot overpower better data.
            (batterConfidence * .42 + pitcherConfidence * .38 + coverageConfidence * .20) * .82
        }.coerceIn(.18, 1.0)

        val score = (50.0 * (1.0 - confidence) + raw * confidence).coerceIn(0.0, 100.0)

        val feastOrder = if (hrTotal > 0) {
            hitterHrCounts.entries.filter { it.value > 0 }.sortedByDescending { it.value }.map { it.key }
        } else {
            batterPitchRows.sortedByDescending { row ->
                (row.xslg ?: row.slg ?: 0.0) * (arsenalShares[row.code] ?: 0.0)
            }.map { it.code }
        }
        val feastPitches = feastOrder.distinct().take(4).map { code ->
            val count = hitterHrCounts[code] ?: 0
            val batterRow = batterByCode[code]
            PitchHrTendency(
                code = code,
                name = batterRow?.name ?: api.pitchTypeName(code),
                homeRuns = count,
                share = if (hrTotal > 0) count.toDouble() / hrTotal else 0.0,
                opposingPitcherUsage = arsenalShares[code] ?: 0.0,
                batterSlg = batterRow?.slg,
                batterXslg = batterRow?.xslg,
                batterHardHitPct = batterRow?.hardHitPct,
                pitcherXslgAllowed = pitcherByCode[code]?.xslg
            )
        }

        return PitchArsenalMatch(
            score = score,
            confidence = confidence,
            batterHrSample = hrTotal,
            batterPitchSample = batterPitchSample,
            pitcherPitchSample = pitchTotal,
            feastPitches = feastPitches,
            pitcherArsenal = pitcherArsenal.take(6),
            source = source
        )
    }


    /**
     * Small, curated Triple-A slugger board. MLB/MiLB stats refresh from StatsAPI while the
     * call-up prior remains intentionally editorial and transparent. This avoids flooding the app
     * with veteran Triple-A hitters who have big numbers but are not realistic promotion targets.
     */
    suspend fun loadAaaSluggerWatch(date: LocalDate): List<AaaSluggerProspect> = coroutineScope {
        val recentStart = date.minusDays(20)
        val seasonDeferred = async { safe(emptyList()) { api.fetchTripleAHittingStats(date.year) } }
        val recentDeferred = async { safe(emptyList()) { api.fetchTripleAHittingStats(date.year, recentStart, date) } }
        val seasonLines = seasonDeferred.await()
        val recentLines = recentDeferred.await()
        val seasonByName = seasonLines.associateBy { normalizeProspectName(it.player.name) }
        val recentByName = recentLines.associateBy { normalizeProspectName(it.player.name) }

        val matched = aaaWatchSeeds.mapNotNull { seed ->
            seasonByName[normalizeProspectName(seed.name)]?.let { seed to it }
        }
        val watchedPlayerIds = matched.map { it.second.player.id }.toSet()
        val watchedTeamIds = matched.mapNotNull { it.second.team?.id }.toSet()

        // v0.12.0 contact layer: pull a bounded sample of recent Triple-A live feeds only for the
        // organizations represented on this small watchlist. StatsAPI MiLB feeds sometimes include
        // hitData.launchSpeed / launchAngle / distance and sometimes do not. Missing fields are never
        // invented or treated as zero; they simply drop out of the batted-ball component.
        val ballsByPlayer: Map<Int, List<BattedBall>> = if (watchedPlayerIds.isEmpty() || watchedTeamIds.isEmpty()) {
            emptyMap()
        } else {
            val schedule = safe(emptyList()) {
                api.fetchTripleAScheduleRange(date.minusDays(11), date)
            }

            val gamesPerTeam = mutableMapOf<Int, Int>()
            val selectedGames = mutableListOf<GameInfo>()
            for (game in schedule
                .asSequence()
                .filter { it.status.equals("Final", true) || it.status.equals("Live", true) }
                .sortedByDescending { it.gameDate }
            ) {
                val relevantTeams = listOf(game.awayTeam.id, game.homeTeam.id)
                    .filter { it in watchedTeamIds }
                    .distinct()
                if (relevantTeams.isEmpty()) continue
                if (relevantTeams.any { gamesPerTeam.getOrDefault(it, 0) < 4 }) {
                    selectedGames += game
                    relevantTeams.forEach { id ->
                        gamesPerTeam[id] = gamesPerTeam.getOrDefault(id, 0) + 1
                    }
                }
                if (selectedGames.size >= 30 || watchedTeamIds.all { gamesPerTeam.getOrDefault(it, 0) >= 4 }) break
            }

            val semaphore = Semaphore(5)
            selectedGames.map { game ->
                async {
                    semaphore.withPermit {
                        safe(emptyList()) {
                            val ttl = if (game.status.equals("Final", true) || date.isAfter(game.gameDate.atZone(ZoneId.systemDefault()).toLocalDate())) {
                                8 * 60 * 60 * 1000L
                            } else {
                                45 * 1000L
                            }
                            api.fetchGameFeed(game.gamePk, ttl).battedBalls
                                .filter { it.batterId in watchedPlayerIds }
                        }
                    }
                }
            }.awaitAll()
                .flatten()
                .groupBy { it.batterId }
                .mapValues { (_, balls) ->
                    balls.sortedWith(compareByDescending<BattedBall> { it.gameDate }.thenByDescending { it.gamePk })
                }
        }

        matched.map { (seed, seasonLine) ->
            val key = normalizeProspectName(seed.name)
            val recent = recentByName[key]?.stats
            val season = seasonLine.stats
            val recentBalls = ballsByPlayer[seasonLine.player.id].orEmpty()
            val trackedBalls = recentBalls.filter { it.exitVelocity != null && it.launchAngle != null }
            val contactMetrics = if (trackedBalls.isNotEmpty()) {
                scoringModel.mustHaveMetrics(
                    player = seasonLine.player,
                    seasonStats = aaaToHittingStats(season),
                    balls = recentBalls
                )
            } else null
            // Sample-confidence regression keeps one or two tracked balls from swinging the board.
            val contactGrade = contactMetrics?.let { metrics ->
                (50.0 + (metrics.score - 50.0) * metrics.confidence).coerceIn(0.0, 100.0)
            }

            val power = aaaPowerScore(season)
            val recentPower = recent?.let(::aaaPowerScore) ?: 45.0
            val readiness = aaaReadinessScore(season, recent)
            val callup = (
                seed.callupBase * 0.66 +
                    recentPower * 0.14 +
                    readiness * 0.10 +
                    power * 0.10
                ).coerceIn(0.0, 100.0)

            // The original AAA score weights are preserved exactly when batted-ball tracking is
            // unavailable. When it is available, 20% of the grade comes from contact quality and
            // the other four components shrink proportionally.
            val baseWeighted = power * 0.336 + recentPower * 0.224 + readiness * 0.096 + callup * 0.144
            val slugger = if (contactGrade != null) {
                (baseWeighted + contactGrade * 0.20).coerceIn(0.0, 100.0)
            } else {
                (baseWeighted / 0.80).coerceIn(0.0, 100.0)
            }

            val label = when {
                callup >= 90 -> "CALL-UP WATCH • HIGH"
                callup >= 84 -> "VERY CLOSE"
                callup >= 76 -> "ON DECK"
                else -> "AAA WATCH"
            }

            AaaSluggerProspect(
                player = seasonLine.player,
                aaaTeam = seasonLine.team,
                mlbOrg = seed.mlbOrg,
                position = seasonLine.primaryPosition ?: seed.position,
                seasonStats = season,
                recentStats = recent,
                recentBattedBalls = recentBalls,
                contactMetrics = contactMetrics,
                contactScore = contactGrade?.roundToInt(),
                contactSourceGames = trackedBalls.map { it.gamePk }.distinct().size,
                powerScore = power.roundToInt(),
                recentPowerScore = recentPower.roundToInt(),
                readinessScore = readiness.roundToInt(),
                callupWatchScore = callup.roundToInt(),
                sluggerScore = slugger.roundToInt(),
                watchLabel = label,
                watchReason = seed.reason,
                sourceNote = "Curated Triple-A call-up watch with live MiLB season/recent stats and recent tracked batted-ball quality when supplied by game feeds. Scores are comparative grades, not probabilities."
            )
        }.sortedWith(
            compareByDescending<AaaSluggerProspect> { it.sluggerScore }
                .thenByDescending { it.callupWatchScore }
        )
    }

    private fun aaaToHittingStats(stats: RecentHittingStats): HittingStats = HittingStats(
        atBats = stats.atBats,
        plateAppearances = stats.plateAppearances,
        hits = stats.hits,
        doubles = stats.doubles,
        triples = stats.triples,
        homeRuns = stats.homeRuns,
        walks = stats.walks,
        strikeouts = stats.strikeouts,
        avg = stats.avg,
        slg = stats.slg,
        ops = stats.ops
    )

    private fun normalizeProspectName(name: String): String =
        name.lowercase().filter { it.isLetterOrDigit() }

    private fun aaaPowerScore(stats: RecentHittingStats): Double {
        if (stats.plateAppearances <= 0 && stats.atBats <= 0) return 35.0
        val pa = maxOf(stats.plateAppearances, stats.atBats).coerceAtLeast(1)
        val hrRate = stats.homeRuns.toDouble() / pa
        val iso = stats.iso ?: 0.0
        val slg = stats.slg ?: 0.0
        val ops = stats.ops ?: 0.0
        fun scale(value: Double, low: Double, high: Double): Double =
            ((value - low) / (high - low) * 100.0).coerceIn(0.0, 100.0)
        return (
            scale(hrRate, 0.015, 0.075) * 0.34 +
                scale(iso, 0.100, 0.300) * 0.30 +
                scale(slg, 0.350, 0.600) * 0.20 +
                scale(ops, 0.650, 1.000) * 0.16
            ).coerceIn(0.0, 100.0)
    }

    private fun aaaReadinessScore(
        season: RecentHittingStats,
        recent: RecentHittingStats?
    ): Double {
        val source = recent?.takeIf { it.plateAppearances >= 20 } ?: season
        val pa = maxOf(source.plateAppearances, source.atBats).coerceAtLeast(1)
        val kRate = source.strikeouts.toDouble() / pa
        val bbRate = source.walks.toDouble() / pa
        val contact = ((0.34 - kRate) / 0.22 * 100.0).coerceIn(0.0, 100.0)
        val discipline = ((bbRate - 0.035) / 0.115 * 100.0).coerceIn(0.0, 100.0)
        val sample = (pa / 120.0 * 100.0).coerceIn(30.0, 100.0)
        return (contact * 0.54 + discipline * 0.26 + sample * 0.20).coerceIn(0.0, 100.0)
    }

    /** Load career batter-vs-pitcher context for a profile that was not part of the slate's
     * preloaded BvP shortlist. This keeps the main slate fast while still allowing every hitter's
     * Player Profile to fill the BvP card on demand. */
    suspend fun enrichPlayerProfile(candidate: HitterCandidate): HitterCandidate {
        if (candidate.vsPitcherStats != null) return candidate
        val pitcherId = candidate.opponentPitcher?.person?.id ?: return candidate
        val bvp = safeOrNull { api.fetchHittingVsPitcherStats(candidate.player.id, pitcherId) }
        return candidate.copy(vsPitcherStats = bvp)
    }

    suspend fun fetchPlayerGameStats(
        playerId: Int,
        date: LocalDate
    ): RecentHittingStats? = api.fetchPlayerStatsOnDate(playerId, date)

    suspend fun fetchPlayerLast10Stats(
        playerId: Int,
        throughDate: LocalDate
    ): RecentHittingStats? = api.fetchPlayerLastGamesStats(
        playerId = playerId,
        season = throughDate.year,
        throughDate = throughDate,
        gameCount = 10
    )

    fun rescore(board: BoardData, weights: ScoreWeights): BoardData {
        val rescored = board.candidates.map { c ->
            c.copy(
                score = scoringModel.score(
                    player = c.player,
                    battingOrder = c.battingOrder,
                    lineupOfficial = c.lineupOfficial,
                    seasonStats = c.seasonStats,
                    platoonStats = c.platoonStats,
                    recentBattedBalls = c.recentBattedBalls,
                    opponentPitcher = c.opponentPitcher,
                    game = c.game,
                    weights = weights
                )
            )
        }.sortedByDescending { it.score.total }
        return board.copy(candidates = rescored)
    }

}
