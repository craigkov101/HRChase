package com.ckz.hrchase.model

import com.ckz.hrchase.data.*
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant

class ProductionScoringModelTest {
    @Test
    fun strongTopOrderContactProfileBeatsWeakBottomOrderProfile() {
        val model = ProductionScoringModel()
        val strong = candidate(2, .302, .880, 78, 500, .20, 1.42)
        val weak = candidate(8, .218, .650, 150, 500, .31, 1.03)
        val strongSeason = stats(500, 145, 78, 76, .302, .380, .500, .880, 78)
        val weakSeason = stats(500, 103, 42, 43, .218, .285, .365, .650, 150)

        val strongScore = model.score(
            strong,
            ProductionScoringModel.Context(
                season = strongSeason,
                last14 = stats(55, 18, 11, 12, .327, .405, .545, .950, 8),
                last7 = stats(28, 10, 7, 7, .357, .430, .570, 1.00, 4),
                last3 = stats(12, 5, 3, 4, .417, .470, .650, 1.12, 1),
                contactQuality = 76.0
            )
        )
        val weakScore = model.score(
            weak,
            ProductionScoringModel.Context(
                season = weakSeason,
                last14 = stats(52, 9, 4, 4, .173, .240, .250, .490, 19),
                last7 = stats(27, 4, 2, 2, .148, .210, .220, .430, 11),
                last3 = stats(10, 1, 0, 0, .100, .180, .100, .280, 5),
                contactQuality = 42.0
            )
        )

        assertTrue(strongScore.total > weakScore.total)
        assertTrue(strongScore.expectedHrr > weakScore.expectedHrr)
    }

    private fun candidate(order: Int, avg: Double, ops: Double, k: Int, pa: Int, pitcherK: Double, whip: Double): HitterCandidate {
        val team = TeamRef(1, "A", "A")
        val opponent = TeamRef(2, "B", "B")
        val game = GameInfo(1, Instant.now(), "Preview", "Scheduled", team, opponent, "Park")
        val pitcher = PitcherProfile(
            PersonRef(9, "Pitcher", pitchHand = "R"),
            PitchingStats(100.0, 15, (pitcherK * 400).toInt(), 35, 400, 4.60, whip),
            emptyList()
        )
        return HitterCandidate(
            player = PersonRef(order, "H$order", batSide = "L"),
            team = team,
            opponent = opponent,
            game = game,
            battingOrder = order,
            lineupOfficial = true,
            seasonStats = HittingStats(400, pa, (avg * 400).toInt(), homeRuns = 20, strikeouts = k, avg = avg, slg = .500, ops = ops),
            opponentPitcher = pitcher,
            recentBattedBalls = emptyList(),
            todayBattedBalls = emptyList(),
            score = ScoreBreakdown(60.0, 60.0, 70.0, 55.0, 70.0, 90.0, 70.0, emptyList(), emptyList(), 70.0)
        )
    }

    private fun stats(pa: Int, h: Int, r: Int, rbi: Int, avg: Double, obp: Double, slg: Double, ops: Double, k: Int) =
        RecentHittingStats(20, pa, pa, r, h, homeRuns = 4, rbi = rbi, strikeouts = k, avg = avg, obp = obp, slg = slg, ops = ops)
}
