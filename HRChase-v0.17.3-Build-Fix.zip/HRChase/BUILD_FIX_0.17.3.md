# HR Chase v0.17.3 — Build Fix

- Fixes Kotlin compile errors in `PlayerDetailScreen` introduced by the simplified Attack Zone UI.
- Attack Zone label, confidence label and simple reason are now computed at the parent screen where `MainViewModel` is in scope and passed into `PlayerDetailScreen` explicitly.
- No scoring/model behavior was changed from v0.17.2.
