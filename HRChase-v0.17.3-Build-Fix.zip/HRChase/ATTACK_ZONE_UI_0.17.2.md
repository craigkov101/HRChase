# HR Chase v0.17.2 — Attack Zone UI Simplification

## Goal
Make Attack Zone Fit immediately understandable and make the best zone matches easy to find.

## Top Zone mode
The new **Top Zone** filter ranks the best measured Attack Zone matches on the slate. It does not impose a hard score cutoff. Any hitter with a real pitcher-location sample and a real located-batted-ball sample can be ranked.

Ranking order:
1. Attack Zone score
2. Attack Zone confidence
3. HR Target Score
4. Power Profile

Top Zone and Top Arsenal are mutually exclusive ranking modes to keep the meaning of the board clear.

## Simple labels
- 70+ = GREAT MATCH
- 62–69 = GOOD MATCH
- 55–61 = SLIGHT EDGE
- 48–54 = NEUTRAL
- below 48 = TOUGH FIT

Confidence remains separate:
- 60%+ = HIGH
- 35–59% = MEDIUM
- below 35% = LOW

A matchup can therefore be a GREAT MATCH with LOW confidence; that is intentionally different from a GREAT MATCH with HIGH confidence.

## UI changes
- Picks screen shows a Top Zone filter alongside Top Arsenal.
- When Top Zone is selected, the top five matches are summarized at the top of the board.
- Target cards show a dedicated Zone Match strip with the simple label, numeric score, and confidence.
- Player Profile explains the Zone Match in plain English and lists only the three strongest overlap areas.
