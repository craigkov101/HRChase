package com.ckz.hrchase.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

class MlbApi {
    private val base = "https://statsapi.mlb.com"

    suspend fun fetchSchedule(date: LocalDate): List<GameInfo> {
        val url = "$base/api/v1/schedule?sportId=1&date=$date&hydrate=probablePitcher,team,linescore"
        val root = JSONObject(get(url))
        val dates = root.optJSONArray("dates") ?: return emptyList()
        if (dates.length() == 0) return emptyList()
        val games = dates.optJSONObject(0)?.optJSONArray("games") ?: return emptyList()
        return buildList {
            for (i in 0 until games.length()) {
                val g = games.optJSONObject(i) ?: continue
                val teams = g.optJSONObject("teams") ?: continue
                val awayObj = teams.optJSONObject("away") ?: continue
                val homeObj = teams.optJSONObject("home") ?: continue
                val awayTeamObj = awayObj.optJSONObject("team") ?: continue
                val homeTeamObj = homeObj.optJSONObject("team") ?: continue
                val statusObj = g.optJSONObject("status")
                val venueObj = g.optJSONObject("venue")

                add(
                    GameInfo(
                        gamePk = g.optLong("gamePk"),
                        gameDate = parseInstant(g.optString("gameDate")),
                        status = statusObj?.optString("abstractGameState") ?: "Preview",
                        detailedStatus = statusObj?.optString("detailedState") ?: "Scheduled",
                        awayTeam = parseTeam(awayTeamObj),
                        homeTeam = parseTeam(homeTeamObj),
                        venueName = venueObj?.optString("name") ?: "Unknown park",
                        awayProbablePitcher = awayObj.optJSONObject("probablePitcher")?.let(::parsePerson),
                        homeProbablePitcher = homeObj.optJSONObject("probablePitcher")?.let(::parsePerson)
                    )
                )
            }
        }
    }

    suspend fun fetchScheduleRange(startDate: LocalDate, endDate: LocalDate): List<GameInfo> {
        val url = "$base/api/v1/schedule?sportId=1&startDate=$startDate&endDate=$endDate&gameType=R&hydrate=probablePitcher,team"
        val root = JSONObject(get(url))
        val dates = root.optJSONArray("dates") ?: return emptyList()
        return buildList {
            for (d in 0 until dates.length()) {
                val dateObj = dates.optJSONObject(d) ?: continue
                val games = dateObj.optJSONArray("games") ?: continue
                for (i in 0 until games.length()) {
                    val g = games.optJSONObject(i) ?: continue
                    val teams = g.optJSONObject("teams") ?: continue
                    val awayObj = teams.optJSONObject("away") ?: continue
                    val homeObj = teams.optJSONObject("home") ?: continue
                    val awayTeamObj = awayObj.optJSONObject("team") ?: continue
                    val homeTeamObj = homeObj.optJSONObject("team") ?: continue
                    val statusObj = g.optJSONObject("status")
                    val venueObj = g.optJSONObject("venue")
                    add(
                        GameInfo(
                            gamePk = g.optLong("gamePk"),
                            gameDate = parseInstant(g.optString("gameDate")),
                            status = statusObj?.optString("abstractGameState") ?: "Preview",
                            detailedStatus = statusObj?.optString("detailedState") ?: "Scheduled",
                            awayTeam = parseTeam(awayTeamObj),
                            homeTeam = parseTeam(homeTeamObj),
                            venueName = venueObj?.optString("name") ?: "Unknown park",
                            awayProbablePitcher = awayObj.optJSONObject("probablePitcher")?.let(::parsePerson),
                            homeProbablePitcher = homeObj.optJSONObject("probablePitcher")?.let(::parsePerson)
                        )
                    )
                }
            }
        }
    }

    suspend fun fetchGameFeed(gamePk: Long): GameFeedSnapshot {
        val root = JSONObject(get("$base/api/v1.1/game/$gamePk/feed/live"))
        val officialDate = root.optJSONObject("gameData")
            ?.optJSONObject("datetime")
            ?.optString("officialDate")
            ?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            ?: Instant.now().atZone(ZoneOffset.UTC).toLocalDate()

        return GameFeedSnapshot(
            gamePk = gamePk,
            officialDate = officialDate,
            root = root,
            awayLineupIds = extractBattingOrder(root, "away"),
            homeLineupIds = extractBattingOrder(root, "home"),
            battedBalls = extractBattedBalls(root, gamePk, officialDate),
            plateDiscipline = extractPlateDiscipline(root),
            weather = extractWeather(root)
        )
    }


    /**
     * Career batter-vs-pitcher results from MLB StatsAPI's vsPlayer stat type.
     * MLB can return more than one stat block/split, so we aggregate each block and keep
     * the one with the largest plate-appearance sample (normally the career-total block).
     */
    suspend fun fetchHittingVsPitcherStats(batterId: Int, pitcherId: Int): BatterVsPitcherStats? {
        val url = "$base/api/v1/people/$batterId/stats?stats=vsPlayer&group=hitting&opposingPlayerId=$pitcherId&sportId=1"
        return runCatching {
            val root = JSONObject(get(url))
            val blocks = root.optJSONArray("stats") ?: return@runCatching null
            val parsed = buildList {
                for (i in 0 until blocks.length()) {
                    val block = blocks.optJSONObject(i) ?: continue
                    val splits = block.optJSONArray("splits") ?: continue
                    val rows = buildList {
                        for (j in 0 until splits.length()) {
                            val stat = splits.optJSONObject(j)?.optJSONObject("stat") ?: continue
                            add(parseBatterVsPitcherRow(stat))
                        }
                    }
                    if (rows.isNotEmpty()) add(aggregateBatterVsPitcher(rows))
                }
            }
            parsed.maxByOrNull { maxOf(it.plateAppearances, it.atBats) }
                ?.takeIf { it.plateAppearances > 0 || it.atBats > 0 }
        }.getOrNull()
    }

    private fun parseBatterVsPitcherRow(obj: JSONObject): BatterVsPitcherStats = BatterVsPitcherStats(
        atBats = obj.optIntOrNull("atBats") ?: 0,
        plateAppearances = obj.optIntOrNull("plateAppearances") ?: 0,
        hits = obj.optIntOrNull("hits") ?: 0,
        doubles = obj.optIntOrNull("doubles") ?: 0,
        triples = obj.optIntOrNull("triples") ?: 0,
        homeRuns = obj.optIntOrNull("homeRuns") ?: 0,
        walks = obj.optIntOrNull("baseOnBalls") ?: obj.optIntOrNull("walks") ?: 0,
        strikeouts = obj.optIntOrNull("strikeOuts") ?: 0,
        hitByPitch = obj.optIntOrNull("hitByPitch") ?: 0,
        sacFlies = obj.optIntOrNull("sacFlies") ?: 0,
        avg = obj.optDoubleOrNull("avg"),
        obp = obj.optDoubleOrNull("obp"),
        slg = obj.optDoubleOrNull("slg"),
        ops = obj.optDoubleOrNull("ops")
    )

    private fun aggregateBatterVsPitcher(rows: List<BatterVsPitcherStats>): BatterVsPitcherStats {
        val ab = rows.sumOf { it.atBats }
        val paRaw = rows.sumOf { it.plateAppearances }
        val hits = rows.sumOf { it.hits }
        val doubles = rows.sumOf { it.doubles }
        val triples = rows.sumOf { it.triples }
        val hrs = rows.sumOf { it.homeRuns }
        val walks = rows.sumOf { it.walks }
        val ks = rows.sumOf { it.strikeouts }
        val hbp = rows.sumOf { it.hitByPitch }
        val sf = rows.sumOf { it.sacFlies }
        val pa = if (paRaw > 0) paRaw else ab + walks + hbp + sf
        val avg = if (ab > 0) hits.toDouble() / ab else null
        val totalBases = hits + doubles + 2 * triples + 3 * hrs
        val slg = if (ab > 0) totalBases.toDouble() / ab else null
        val obpDenom = ab + walks + hbp + sf
        val obp = if (obpDenom > 0) (hits + walks + hbp).toDouble() / obpDenom else null
        val ops = if (obp != null && slg != null) obp + slg else null
        return BatterVsPitcherStats(
            atBats = ab, plateAppearances = pa, hits = hits, doubles = doubles, triples = triples,
            homeRuns = hrs, walks = walks, strikeouts = ks, hitByPitch = hbp, sacFlies = sf,
            avg = avg, obp = obp, slg = slg, ops = ops
        )
    }


    /**
     * Statcast occurrence counts for a specific pitch type. For hitters, eventType can be
     * "homeRun" to answer which pitches their HRs came against. For pitchers, omit eventType
     * and the same endpoint provides how often they throw that pitch type. MLB's metricAverages
     * response exposes numOccurrences on each player split, so we only need counts here.
     */
    suspend fun fetchPitchTypeOccurrences(
        playerIds: List<Int>,
        season: Int,
        pitchType: String,
        group: String,
        eventType: String? = null
    ): Map<Int, Int> {
        if (playerIds.isEmpty()) return emptyMap()
        val ids = playerIds.distinct().joinToString(",")
        val metric = if (group.equals("pitching", true)) "effectiveSpeed" else "launchSpeed"
        val event = eventType?.let { "&eventType=${URLEncoder.encode(it, StandardCharsets.UTF_8.name())}" }.orEmpty()
        val url = "$base/api/v1/stats/metrics?personIds=$ids&group=$group&stats=metricAverages&metrics=$metric&season=$season&pitchType=$pitchType$event&limit=5000"
        return runCatching {
            val root = JSONObject(get(url))
            val blocks = root.optJSONArray("stats") ?: return@runCatching emptyMap()
            val out = mutableMapOf<Int, Int>()
            for (i in 0 until blocks.length()) {
                val block = blocks.optJSONObject(i) ?: continue
                val blockPlayerId = block.optJSONObject("player")?.optInt("id")?.takeIf { it > 0 }
                val splits = block.optJSONArray("splits") ?: continue
                for (j in 0 until splits.length()) {
                    val split = splits.optJSONObject(j) ?: continue
                    val playerId = split.optJSONObject("player")?.optInt("id")?.takeIf { it > 0 }
                        ?: blockPlayerId
                        ?: continue
                    val count = split.optIntOrNull("numOccurrences")
                        ?: split.optJSONObject("stat")?.optIntOrNull("count")
                        ?: 0
                    if (count > 0) out[playerId] = (out[playerId] ?: 0) + count
                }
            }
            out
        }.getOrDefault(emptyMap())
    }

    fun pitchTypeName(code: String): String = when (code.uppercase()) {
        "FF" -> "4-Seam"
        "SI" -> "Sinker"
        "FC" -> "Cutter"
        "SL" -> "Slider"
        "ST" -> "Sweeper"
        "CU" -> "Curve"
        "KC" -> "Knuckle Curve"
        "CH" -> "Changeup"
        "FS" -> "Splitter"
        else -> code.uppercase()
    }

    /**
     * Season hitting splits versus a pitcher handedness for the entire MLB player pool.
     * One league-wide request is much faster than one request per hitter. sitCode `vr` means
     * versus right-handed pitchers and `vl` means versus left-handed pitchers.
     */
    suspend fun fetchLeagueHittingSplitStats(season: Int, sitCode: String): Map<Int, HittingSplitStats> {
        val safeCode = if (sitCode == "vl") "vl" else "vr"
        val url = "$base/api/v1/stats?stats=statSplits&sportId=1&season=$season&group=hitting&playerPool=All&sitCodes=$safeCode&limit=5000"
        return runCatching {
            val root = JSONObject(get(url))
            val blocks = root.optJSONArray("stats") ?: return@runCatching emptyMap()
            val out = mutableMapOf<Int, HittingSplitStats>()
            for (i in 0 until blocks.length()) {
                val splits = blocks.optJSONObject(i)?.optJSONArray("splits") ?: continue
                for (j in 0 until splits.length()) {
                    val split = splits.optJSONObject(j) ?: continue
                    val player = split.optJSONObject("player") ?: split.optJSONObject("person") ?: continue
                    val playerId = player.optInt("id")
                    if (playerId <= 0) continue
                    val stat = split.optJSONObject("stat") ?: continue
                    val parsed = parseHittingSplitStats(stat)
                    val current = out[playerId]
                    if (current == null || parsed.plateAppearances > current.plateAppearances) {
                        out[playerId] = parsed
                    }
                }
            }
            out.toMap()
        }.getOrDefault(emptyMap())
    }

    /**
     * One league-wide date-range request for the previous seven days of offense. This is far
     * cheaper than requesting each hitter individually and powers the Hot tab without adding a
     * large number of network calls.
     */
    suspend fun fetchLeagueHittingDateRangeStats(
        startDate: LocalDate,
        endDate: LocalDate
    ): Map<Int, RecentHittingStats> {
        val url = "$base/api/v1/stats?stats=byDateRange&group=hitting&sportIds=1&gameType=R&season=${startDate.year}&playerPool=All&startDate=$startDate&endDate=$endDate&limit=5000"
        return runCatching {
            val root = JSONObject(get(url))
            val blocks = root.optJSONArray("stats") ?: return@runCatching emptyMap()
            val out = mutableMapOf<Int, RecentHittingStats>()
            for (i in 0 until blocks.length()) {
                val splits = blocks.optJSONObject(i)?.optJSONArray("splits") ?: continue
                for (j in 0 until splits.length()) {
                    val split = splits.optJSONObject(j) ?: continue
                    val player = split.optJSONObject("player") ?: split.optJSONObject("person") ?: continue
                    val playerId = player.optInt("id")
                    if (playerId <= 0) continue
                    val stat = split.optJSONObject("stat") ?: continue
                    val parsed = parseRecentHittingStats(stat)
                    val current = out[playerId]
                    if (current == null || parsed.plateAppearances > current.plateAppearances) {
                        out[playerId] = parsed
                    }
                }
            }
            out.toMap()
        }.getOrDefault(emptyMap())
    }

    /**
     * Aggregate the player's last N completed games through a specific date. This powers the
     * Tracked tab without loading full game feeds. The gameLog endpoint returns one split per game;
     * we filter by date, take the newest requested games, and aggregate the counting/rate stats.
     */
    suspend fun fetchPlayerLastGamesStats(
        playerId: Int,
        season: Int,
        throughDate: LocalDate,
        gameCount: Int = 10
    ): RecentHittingStats? {
        val safeCount = gameCount.coerceIn(1, 30)
        val url = "$base/api/v1/people/$playerId/stats?stats=gameLog&group=hitting&season=$season&gameType=R"
        return runCatching {
            val root = JSONObject(get(url))
            val blocks = root.optJSONArray("stats") ?: return@runCatching null
            val datedRows = mutableListOf<Pair<LocalDate, RecentHittingStats>>()
            for (i in 0 until blocks.length()) {
                val splits = blocks.optJSONObject(i)?.optJSONArray("splits") ?: continue
                for (j in 0 until splits.length()) {
                    val split = splits.optJSONObject(j) ?: continue
                    val date = runCatching { LocalDate.parse(split.optString("date")) }.getOrNull() ?: continue
                    if (date.isAfter(throughDate)) continue
                    val stat = split.optJSONObject("stat") ?: continue
                    datedRows += date to parseRecentHittingStats(stat)
                }
            }
            val rows = datedRows
                .sortedByDescending { it.first }
                .take(safeCount)
                .map { it.second }
            if (rows.isEmpty()) null else aggregateRecentHittingStats(rows)
        }.getOrNull()
    }

    private fun aggregateRecentHittingStats(rows: List<RecentHittingStats>): RecentHittingStats {
        val ab = rows.sumOf { it.atBats }
        val pa = rows.sumOf { it.plateAppearances }
        val runs = rows.sumOf { it.runs }
        val hits = rows.sumOf { it.hits }
        val doubles = rows.sumOf { it.doubles }
        val triples = rows.sumOf { it.triples }
        val hrs = rows.sumOf { it.homeRuns }
        val rbi = rows.sumOf { it.rbi }
        val walks = rows.sumOf { it.walks }
        val strikeouts = rows.sumOf { it.strikeouts }
        val hitByPitch = rows.sumOf { it.hitByPitch }
        val sacFlies = rows.sumOf { it.sacFlies }
        val avg = if (ab > 0) hits.toDouble() / ab else null
        val totalBases = hits + doubles + 2 * triples + 3 * hrs
        val slg = if (ab > 0) totalBases.toDouble() / ab else null
        val obpDenom = ab + walks + hitByPitch + sacFlies
        val obp = if (obpDenom > 0) (hits + walks + hitByPitch).toDouble() / obpDenom else null
        val ops = if (obp != null && slg != null) obp + slg else null
        return RecentHittingStats(
            gamesPlayed = rows.size,
            atBats = ab,
            plateAppearances = pa,
            runs = runs,
            hits = hits,
            doubles = doubles,
            triples = triples,
            homeRuns = hrs,
            rbi = rbi,
            walks = walks,
            strikeouts = strikeouts,
            hitByPitch = hitByPitch,
            sacFlies = sacFlies,
            avg = avg,
            obp = obp,
            slg = slg,
            ops = ops
        )
    }

    private fun parseRecentHittingStats(obj: JSONObject): RecentHittingStats = RecentHittingStats(
        gamesPlayed = obj.optIntOrNull("gamesPlayed") ?: obj.optIntOrNull("games") ?: 0,
        atBats = obj.optIntOrNull("atBats") ?: 0,
        plateAppearances = obj.optIntOrNull("plateAppearances") ?: 0,
        runs = obj.optIntOrNull("runs") ?: 0,
        hits = obj.optIntOrNull("hits") ?: 0,
        doubles = obj.optIntOrNull("doubles") ?: 0,
        triples = obj.optIntOrNull("triples") ?: 0,
        homeRuns = obj.optIntOrNull("homeRuns") ?: 0,
        rbi = obj.optIntOrNull("rbi") ?: obj.optIntOrNull("runsBattedIn") ?: 0,
        walks = obj.optIntOrNull("baseOnBalls") ?: obj.optIntOrNull("walks") ?: 0,
        strikeouts = obj.optIntOrNull("strikeOuts") ?: 0,
        hitByPitch = obj.optIntOrNull("hitByPitch") ?: 0,
        sacFlies = obj.optIntOrNull("sacFlies") ?: 0,
        avg = obj.optDoubleOrNull("avg"),
        obp = obj.optDoubleOrNull("obp"),
        slg = obj.optDoubleOrNull("slg"),
        ops = obj.optDoubleOrNull("ops")
    )

    private fun parseHittingSplitStats(obj: JSONObject): HittingSplitStats = HittingSplitStats(
        atBats = obj.optIntOrNull("atBats") ?: 0,
        plateAppearances = obj.optIntOrNull("plateAppearances") ?: 0,
        hits = obj.optIntOrNull("hits") ?: 0,
        doubles = obj.optIntOrNull("doubles") ?: 0,
        triples = obj.optIntOrNull("triples") ?: 0,
        homeRuns = obj.optIntOrNull("homeRuns") ?: 0,
        walks = obj.optIntOrNull("baseOnBalls") ?: obj.optIntOrNull("walks") ?: 0,
        strikeouts = obj.optIntOrNull("strikeOuts") ?: 0,
        avg = obj.optDoubleOrNull("avg"),
        obp = obj.optDoubleOrNull("obp"),
        slg = obj.optDoubleOrNull("slg"),
        ops = obj.optDoubleOrNull("ops")
    )

    suspend fun fetchPitchingStats(playerId: Int, season: Int): PitchingStats {
        val url = "$base/api/v1/people/$playerId/stats?stats=season&group=pitching&season=$season"
        return runCatching {
            val root = JSONObject(get(url))
            val stats = root.optJSONArray("stats")?.optJSONObject(0)
                ?.optJSONArray("splits")?.optJSONObject(0)
                ?.optJSONObject("stat")
            parsePitchingStats(stats)
        }.getOrDefault(PitchingStats())
    }

    fun extractTeamLineup(
        snapshot: GameFeedSnapshot,
        side: String,
        team: TeamRef,
        forceProjected: Boolean = false
    ): TeamLineup {
        val ids = if (side == "away") snapshot.awayLineupIds else snapshot.homeLineupIds
        if (ids.isEmpty()) return TeamLineup(team, emptyList(), official = false)

        val boxTeam = snapshot.root.optJSONObject("liveData")
            ?.optJSONObject("boxscore")
            ?.optJSONObject("teams")
            ?.optJSONObject(side)
        val playersObj = boxTeam?.optJSONObject("players")

        val players = ids.mapIndexedNotNull { index, id ->
            val person = extractPerson(snapshot.root, id) ?: run {
                val pObj = playersObj?.optJSONObject("ID$id")?.optJSONObject("person")
                pObj?.let(::parsePerson)
            } ?: return@mapIndexedNotNull null

            val pBox = playersObj?.optJSONObject("ID$id")
            val battingStats = parseHittingStats(
                pBox?.optJSONObject("seasonStats")?.optJSONObject("batting")
            )
            LineupPlayer(
                person = person,
                battingOrder = index + 1,
                seasonStats = battingStats,
                official = !forceProjected,
                sourceGamePk = snapshot.gamePk
            )
        }
        return TeamLineup(team, players, official = !forceProjected)
    }

    fun extractPerson(root: JSONObject, id: Int): PersonRef? {
        val p = root.optJSONObject("gameData")
            ?.optJSONObject("players")
            ?.optJSONObject("ID$id") ?: return null
        return PersonRef(
            id = id,
            name = p.optString("fullName", p.optString("nameFirstLast", "Player $id")),
            batSide = p.optJSONObject("batSide")?.optString("code")?.takeIf { it.isNotBlank() },
            pitchHand = p.optJSONObject("pitchHand")?.optString("code")?.takeIf { it.isNotBlank() }
        )
    }

    fun extractPitchingStatsFromFeed(root: JSONObject, playerId: Int): PitchingStats? {
        val teams = root.optJSONObject("liveData")?.optJSONObject("boxscore")?.optJSONObject("teams") ?: return null
        for (side in listOf("away", "home")) {
            val stats = teams.optJSONObject(side)
                ?.optJSONObject("players")
                ?.optJSONObject("ID$playerId")
                ?.optJSONObject("seasonStats")
                ?.optJSONObject("pitching")
            if (stats != null) return parsePitchingStats(stats)
        }
        return null
    }

    private fun extractBattingOrder(root: JSONObject, side: String): List<Int> {
        val teamObj = root.optJSONObject("liveData")
            ?.optJSONObject("boxscore")
            ?.optJSONObject("teams")
            ?.optJSONObject(side) ?: return emptyList()

        val direct = teamObj.optJSONArray("battingOrder")?.ints().orEmpty()
        if (direct.isNotEmpty()) return direct

        val players = teamObj.optJSONObject("players") ?: return emptyList()
        val ordered = mutableListOf<Pair<Int, Int>>()
        val keys = players.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val player = players.optJSONObject(key) ?: continue
            val personId = player.optJSONObject("person")?.optInt("id") ?: continue
            val orderRaw = when (val raw = player.opt("battingOrder")) {
                is Number -> raw.toInt()
                is String -> raw.toIntOrNull()
                else -> null
            } ?: continue
            if (orderRaw > 0) ordered += orderRaw to personId
        }
        return ordered.sortedBy { it.first }.map { it.second }.distinct().take(9)
    }

    /**
     * Lightweight recent swing-and-miss sample by batter. Recent HR research commonly
     * discuss swing-and-miss alongside barrels/hard contact, so we derive a recent whiff rate
     * directly from MLB Gameday pitch descriptions without adding another network request.
     */
    private fun extractPlateDiscipline(root: JSONObject): Map<Int, PlateDisciplineSample> {
        val plays = root.optJSONObject("liveData")?.optJSONObject("plays")?.optJSONArray("allPlays")
            ?: return emptyMap()
        val out = mutableMapOf<Int, PlateDisciplineSample>()
        for (i in 0 until plays.length()) {
            val play = plays.optJSONObject(i) ?: continue
            val batterId = play.optJSONObject("matchup")?.optJSONObject("batter")?.optInt("id") ?: 0
            if (batterId == 0) continue
            val events = play.optJSONArray("playEvents") ?: continue
            var pitches = 0
            var swings = 0
            var whiffs = 0
            for (e in 0 until events.length()) {
                val event = events.optJSONObject(e) ?: continue
                val details = event.optJSONObject("details") ?: continue
                val isPitch = details.optBoolean("isPitch", false) || event.optBoolean("isPitch", false)
                if (!isPitch) continue
                pitches++
                val description = details.optString("description").lowercase()
                val whiff = description.contains("swinging strike") ||
                    description.contains("missed bunt") ||
                    description.contains("swinging pitchout")
                val swing = whiff ||
                    description.contains("foul") ||
                    description.contains("in play") ||
                    description.contains("hit into play")
                if (swing) swings++
                if (whiff) whiffs++
            }
            if (pitches > 0 || swings > 0) {
                val add = PlateDisciplineSample(totalPitches = pitches, swings = swings, whiffs = whiffs)
                out[batterId] = (out[batterId] ?: PlateDisciplineSample()) + add
            }
        }
        return out
    }

    private fun extractWeather(root: JSONObject): WeatherInfo {
        val gameData = root.optJSONObject("gameData")
        val weather = gameData?.optJSONObject("weather")
        val roof = gameData?.optJSONObject("venue")
            ?.optJSONObject("fieldInfo")
            ?.optString("roofType")
            ?.takeIf { it.isNotBlank() }
        return WeatherInfo(
            temperatureF = weather?.optIntOrNull("temp"),
            wind = weather?.optString("wind")?.takeIf { it.isNotBlank() },
            condition = weather?.optString("condition")?.takeIf { it.isNotBlank() },
            roofType = roof
        )
    }

    private fun extractBattedBalls(root: JSONObject, gamePk: Long, gameDate: LocalDate): List<BattedBall> {
        val plays = root.optJSONObject("liveData")?.optJSONObject("plays")?.optJSONArray("allPlays") ?: return emptyList()
        return buildList {
            for (i in 0 until plays.length()) {
                val play = plays.optJSONObject(i) ?: continue
                val matchup = play.optJSONObject("matchup") ?: continue
                val batterObj = matchup.optJSONObject("batter") ?: continue
                val pitcherObj = matchup.optJSONObject("pitcher") ?: continue
                val batterId = batterObj.optInt("id")
                val pitcherId = pitcherObj.optInt("id")
                if (batterId == 0 || pitcherId == 0) continue
                // matchup.batSide is the side actually used for this plate appearance. This is
                // important for switch hitters, whose roster batSide is "S" and previously made
                // recent pull-direction metrics impossible to classify.
                val batterSide = matchup.optJSONObject("batSide")
                    ?.optString("code")
                    ?.takeIf { it == "R" || it == "L" }
                val result = play.optJSONObject("result")
                val primaryEvent = result?.optString("eventType").orEmpty()
                val fallbackEvent = result?.optString("event").orEmpty()
                val eventType = primaryEvent.ifBlank { fallbackEvent }.ifBlank { "unknown" }
                val resultDescription = result?.optString("description")?.takeIf { it.isNotBlank() }
                val events = play.optJSONArray("playEvents") ?: continue
                var chosen: JSONObject? = null
                for (e in 0 until events.length()) {
                    val event = events.optJSONObject(e) ?: continue
                    if (event.optJSONObject("hitData") != null) chosen = event
                }
                val hitData = chosen?.optJSONObject("hitData") ?: continue
                val coordinates = hitData.optJSONObject("coordinates")
                val fieldLocation = hitData.optString("location")
                    .trim()
                    .toIntOrNull()
                val eventDescription = chosen?.optJSONObject("details")
                    ?.optString("description")
                    ?.takeIf { it.isNotBlank() }
                val description = resultDescription ?: eventDescription
                val isHr = eventType.equals("home_run", true) || eventType.equals("Home Run", true)
                add(
                    BattedBall(
                        gamePk = gamePk,
                        gameDate = gameDate,
                        batterId = batterId,
                        pitcherId = pitcherId,
                        batterName = batterObj.optString("fullName", "Player $batterId"),
                        pitcherName = pitcherObj.optString("fullName", "Pitcher $pitcherId"),
                        batterSide = batterSide,
                        exitVelocity = hitData.optDoubleOrNull("launchSpeed"),
                        launchAngle = hitData.optDoubleOrNull("launchAngle"),
                        distanceFt = hitData.optDoubleOrNull("totalDistance"),
                        trajectory = hitData.optString("trajectory").takeIf { it.isNotBlank() },
                        fieldLocation = fieldLocation,
                        sprayX = coordinates?.optDoubleOrNull("coordX"),
                        sprayY = coordinates?.optDoubleOrNull("coordY"),
                        eventType = eventType,
                        isHomeRun = isHr,
                        isOut = isOutEvent(eventType),
                        description = description
                    )
                )
            }
        }
    }

    private fun parseTeam(obj: JSONObject): TeamRef {
        val id = obj.optInt("id")
        val name = obj.optString("name", "Unknown Team")
        val abbreviation = obj.optString("abbreviation").takeIf { it.isNotBlank() }
            ?: teamAbbreviation(id)
            ?: obj.optString("teamCode").takeIf { it.isNotBlank() }?.uppercase()
            ?: name.take(3).uppercase()
        return TeamRef(id = id, name = name, abbreviation = abbreviation)
    }

    private fun teamAbbreviation(id: Int): String? = when (id) {
        108 -> "LAA"
        109 -> "ARI"
        110 -> "BAL"
        111 -> "BOS"
        112 -> "CHC"
        113 -> "CIN"
        114 -> "CLE"
        115 -> "COL"
        116 -> "DET"
        117 -> "HOU"
        118 -> "KC"
        119 -> "LAD"
        120 -> "WSH"
        121 -> "NYM"
        133 -> "ATH"
        134 -> "PIT"
        135 -> "SD"
        136 -> "SEA"
        137 -> "SF"
        138 -> "STL"
        139 -> "TB"
        140 -> "TEX"
        141 -> "TOR"
        142 -> "MIN"
        143 -> "PHI"
        144 -> "ATL"
        145 -> "CWS"
        146 -> "MIA"
        147 -> "NYY"
        158 -> "MIL"
        else -> null
    }

    private fun parsePerson(obj: JSONObject): PersonRef = PersonRef(
        id = obj.optInt("id"),
        name = obj.optString("fullName", "Unknown")
    )

    private fun parseHittingStats(obj: JSONObject?): HittingStats {
        if (obj == null) return HittingStats()
        return HittingStats(
            atBats = obj.optIntOrNull("atBats") ?: 0,
            plateAppearances = obj.optIntOrNull("plateAppearances") ?: 0,
            hits = obj.optIntOrNull("hits") ?: 0,
            doubles = obj.optIntOrNull("doubles") ?: 0,
            triples = obj.optIntOrNull("triples") ?: 0,
            homeRuns = obj.optIntOrNull("homeRuns") ?: 0,
            walks = obj.optIntOrNull("baseOnBalls") ?: obj.optIntOrNull("walks") ?: 0,
            strikeouts = obj.optIntOrNull("strikeOuts") ?: 0,
            avg = obj.optDoubleOrNull("avg"),
            slg = obj.optDoubleOrNull("slg"),
            ops = obj.optDoubleOrNull("ops")
        )
    }

    private fun parsePitchingStats(obj: JSONObject?): PitchingStats {
        if (obj == null) return PitchingStats()
        return PitchingStats(
            inningsPitched = parseBaseballInnings(obj.optString("inningsPitched", "0")),
            homeRunsAllowed = obj.optIntOrNull("homeRuns") ?: 0,
            strikeouts = obj.optIntOrNull("strikeOuts") ?: 0,
            walks = obj.optIntOrNull("baseOnBalls") ?: obj.optIntOrNull("walks") ?: 0,
            battersFaced = obj.optIntOrNull("battersFaced") ?: 0,
            era = obj.optDoubleOrNull("era"),
            whip = obj.optDoubleOrNull("whip")
        )
    }

    private fun parseBaseballInnings(raw: String): Double {
        val parts = raw.split('.')
        val full = parts.getOrNull(0)?.toIntOrNull() ?: 0
        val outs = parts.getOrNull(1)?.firstOrNull()?.digitToIntOrNull()?.coerceIn(0, 2) ?: 0
        return full + outs / 3.0
    }

    private fun isOutEvent(event: String): Boolean {
        val e = event.lowercase()
        return e.contains("out") || e.contains("double_play") || e.contains("sac_fly") || e.contains("sac_bunt")
    }

    private fun parseInstant(raw: String): Instant = runCatching { Instant.parse(raw) }.getOrElse { Instant.now() }

    private suspend fun get(url: String): String = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 7_000
            conn.readTimeout = 12_000
            conn.requestMethod = "GET"
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("User-Agent", "HRChase/0.10 Android")
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = BufferedReader(InputStreamReader(stream, StandardCharsets.UTF_8)).use { it.readText() }
            if (code !in 200..299) error("MLB API HTTP $code: ${body.take(180)}")
            body
        } finally {
            conn?.disconnect()
        }
    }
}

data class GameFeedSnapshot(
    val gamePk: Long,
    val officialDate: LocalDate,
    val root: JSONObject,
    val awayLineupIds: List<Int>,
    val homeLineupIds: List<Int>,
    val battedBalls: List<BattedBall>,
    val plateDiscipline: Map<Int, PlateDisciplineSample>,
    val weather: WeatherInfo
)
