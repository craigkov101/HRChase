package com.ckz.hrchase.data

import com.ckz.hrchase.model.HrScoringModel
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

private data class CurrentGameSummary(
    val gamePk: Long,
    val awayLineup: TeamLineup?,
    val homeLineup: TeamLineup?,
    val battedBalls: List<BattedBall>,
    val weather: WeatherInfo,
    val persons: Map<Int, PersonRef>,
    val pitcherStats: Map<Int, PitchingStats>
)

private data class RecentGameSummary(
    val game: GameInfo,
    val awayLineup: TeamLineup?,
    val homeLineup: TeamLineup?,
    val battedBalls: List<BattedBall>,
    val plateDiscipline: Map<Int, PlateDisciplineSample>
)

class Repository(
    private val api: MlbApi = MlbApi(),
    private val scoringModel: HrScoringModel = HrScoringModel()
) {
    suspend fun loadBoard(
        date: LocalDate,
        weights: ScoreWeights,
        lookbackDays: Int = 5,
        onProgress: (String) -> Unit = {},
        onPartialBoard: (BoardData) -> Unit = {}
    ): BoardData = coroutineScope {
        onProgress("Loading MLB schedule…")
        val schedule = api.fetchSchedule(date)
        if (schedule.isEmpty()) {
            return@coroutineScope BoardData(date, emptyList(), emptyList(), Instant.now(), 0)
        }

        // Render the slate immediately. The expensive contact/BvP enrichment continues below,
        // but users should see today's games within the first schedule request instead of staring
        // at a blank spinner.
        onPartialBoard(BoardData(date, emptyList(), schedule, Instant.now(), 0))

        val todayTeamIds = schedule.flatMap { listOf(it.awayTeam.id, it.homeTeam.id) }.toSet()
        val semaphore = Semaphore(7)

        onProgress("Loading today's lineups and game data…")
        // Keep only compact fields from today's live feeds. Retaining 15 full MLB JSONObject trees
        // was the largest memory spike in v0.8 and could cause Android to kill the app mid-refresh.
        val currentFeeds = schedule.map { game ->
            async {
                semaphore.withPermit {
                    runCatching {
                        val feed = api.fetchGameFeed(game.gamePk)
                        val away = api.extractTeamLineup(feed, "away", game.awayTeam)
                            .takeIf { it.players.isNotEmpty() }
                        val home = api.extractTeamLineup(feed, "home", game.homeTeam)
                            .takeIf { it.players.isNotEmpty() }
                        val probableIds = listOfNotNull(
                            game.awayProbablePitcher?.id,
                            game.homeProbablePitcher?.id
                        ).distinct()
                        val persons = probableIds.mapNotNull { id ->
                            api.extractPerson(feed.root, id)?.let { id to it }
                        }.toMap()
                        val pitcherStats = probableIds.mapNotNull { id ->
                            api.extractPitchingStatsFromFeed(feed.root, id)?.let { id to it }
                        }.toMap()
                        CurrentGameSummary(
                            gamePk = game.gamePk,
                            awayLineup = away,
                            homeLineup = home,
                            battedBalls = feed.battedBalls,
                            weather = feed.weather,
                            persons = persons,
                            pitcherStats = pitcherStats
                        )
                    }.getOrNull()
                }
            }
        }.awaitAll().filterNotNull().associateBy { it.gamePk }

        val recentStart = date.minusDays(lookbackDays.toLong())
        val recentEnd = date.minusDays(1)
        onProgress("Finding recent games for contact signals…")
        val recentSchedule = if (!recentEnd.isBefore(recentStart)) {
            val allRecent = runCatching { api.fetchScheduleRange(recentStart, recentEnd) }
                .getOrDefault(emptyList())
                .asSequence()
                .filter { it.status.equals("Final", true) }
                .filter { it.awayTeam.id in todayTeamIds || it.homeTeam.id in todayTeamIds }
                .distinctBy { it.gamePk }
                .sortedByDescending { it.gameDate }
                .toList()

            // First guarantee at least one recent lineup source for every team on today's slate,
            // then fill the remaining budget with the newest games. This keeps projected lineups
            // available without going back to an unbounded 70+ feed download.
            val selected = LinkedHashMap<Long, GameInfo>()
            val coveredTeams = mutableSetOf<Int>()
            for (game in allRecent) {
                val relevant = listOf(game.awayTeam.id, game.homeTeam.id).filter { it in todayTeamIds }
                if (relevant.any { it !in coveredTeams }) {
                    selected[game.gamePk] = game
                    coveredTeams += relevant
                }
                if (coveredTeams.containsAll(todayTeamIds)) break
            }
            for (game in allRecent) {
                if (selected.size >= 30) break
                selected.putIfAbsent(game.gamePk, game)
            }
            selected.values.take(30)
        } else emptyList()

        onProgress("Loading ${recentSchedule.size} recent game feeds…")
        // IMPORTANT: do not retain the full live-feed JSON for every recent game. A five-day slate
        // can contain dozens of very large JSONObject trees and can push Android over its memory
        // limit. Extract only the compact pieces we need, then let each feed be garbage-collected.
        val recentSummaries = recentSchedule.map { game ->
            async {
                semaphore.withPermit {
                    runCatching {
                        val feed = api.fetchGameFeed(game.gamePk)
                        val away = api.extractTeamLineup(feed, "away", game.awayTeam, forceProjected = true)
                            .takeIf { it.players.isNotEmpty() }
                        val home = api.extractTeamLineup(feed, "home", game.homeTeam, forceProjected = true)
                            .takeIf { it.players.isNotEmpty() }
                        RecentGameSummary(
                            game = game,
                            awayLineup = away,
                            homeLineup = home,
                            battedBalls = feed.battedBalls,
                            plateDiscipline = feed.plateDiscipline
                        )
                    }.getOrNull()
                }
            }
        }.awaitAll().filterNotNull()

        val allRecentBalls = recentSummaries.flatMap { it.battedBalls }
        val recentBallsByBatter = allRecentBalls.groupBy { it.batterId }
        val recentBallsByPitcher = allRecentBalls.groupBy { it.pitcherId }
        val recentDisciplineByBatter = mutableMapOf<Int, PlateDisciplineSample>()
        val last3DisciplineByBatter = mutableMapOf<Int, PlateDisciplineSample>()
        val last3Start = date.minusDays(3)
        val last3End = date.minusDays(1)
        recentSummaries.forEach { summary ->
            val gameLocalDate = summary.game.gameDate.atZone(ZoneId.of("America/New_York")).toLocalDate()
            summary.plateDiscipline.forEach { (batterId, sample) ->
                recentDisciplineByBatter[batterId] =
                    (recentDisciplineByBatter[batterId] ?: PlateDisciplineSample()) + sample
                if (!gameLocalDate.isBefore(last3Start) && !gameLocalDate.isAfter(last3End)) {
                    last3DisciplineByBatter[batterId] =
                        (last3DisciplineByBatter[batterId] ?: PlateDisciplineSample()) + sample
                }
            }
        }

        // Build a most-recent real lineup for fallback when today's lineup has not posted yet.
        val latestLineupByTeam = mutableMapOf<Int, TeamLineup>()
        recentSummaries.sortedByDescending { it.game.gameDate }.forEach { summary ->
            val game = summary.game
            if (game.awayTeam.id !in latestLineupByTeam) {
                summary.awayLineup?.let { latestLineupByTeam[game.awayTeam.id] = it }
            }
            if (game.homeTeam.id !in latestLineupByTeam) {
                summary.homeLineup?.let { latestLineupByTeam[game.homeTeam.id] = it }
            }
        }

        onProgress("Loading recent hitter form…")
        val recentFormMaps = listOf(
            "week" to (date.minusDays(7) to date.minusDays(1)),
            "three" to (date.minusDays(3) to date.minusDays(1))
        ).map { (key, range) ->
            async {
                semaphore.withPermit {
                    key to api.fetchLeagueHittingDateRangeStats(range.first, range.second)
                }
            }
        }.awaitAll().toMap()
        val recentWeekStats = recentFormMaps["week"].orEmpty()
        val recentThreeDayStats = recentFormMaps["three"].orEmpty()

        onProgress("Adding handedness splits…")
        val season = date.year
        val splitMaps = listOf("vr", "vl").map { code ->
            async {
                semaphore.withPermit {
                    code to runCatching { api.fetchLeagueHittingSplitStats(season, code) }.getOrDefault(emptyMap())
                }
            }
        }.awaitAll().toMap()
        val vsRightPitching = splitMaps["vr"].orEmpty()
        val vsLeftPitching = splitMaps["vl"].orEmpty()

        val pitcherIds = schedule.flatMap { listOfNotNull(it.awayProbablePitcher?.id, it.homeProbablePitcher?.id) }.distinct()
        onProgress("Loading pitcher arsenals…")
        val pitchTypes = commonPitchTypes()
        val pitcherPitchCountsByType = pitchTypes.map { code ->
            async {
                semaphore.withPermit {
                    code to api.fetchPitchTypeOccurrences(
                        playerIds = pitcherIds,
                        season = season,
                        pitchType = code,
                        group = "pitching"
                    )
                }
            }
        }.awaitAll().toMap()
        val pitcherArsenalById = pitcherIds.associateWith { pitcherId ->
            buildPitchArsenal(
                pitchTypes.associateWith { code -> pitcherPitchCountsByType[code]?.get(pitcherId) ?: 0 }
            )
        }

        onProgress("Building pitcher profiles…")
        val pitcherProfiles = pitcherIds.map { id ->
            async {
                semaphore.withPermit {
                    val person = currentFeeds.values.firstNotNullOfOrNull { it.persons[id] }
                    var stats = currentFeeds.values.firstNotNullOfOrNull { it.pitcherStats[id] }
                    if (stats == null || stats == PitchingStats()) {
                        stats = api.fetchPitchingStats(id, season)
                    }
                    id to PitcherProfile(
                        person = person ?: PersonRef(id, "Pitcher $id"),
                        seasonStats = stats ?: PitchingStats(),
                        recentBattedBallsAllowed = recentBallsByPitcher[id].orEmpty(),
                        seasonPitchArsenal = pitcherArsenalById[id].orEmpty()
                    )
                }
            }
        }.awaitAll().toMap()

        onProgress("Scoring hitters…")
        val enrichedGames = schedule.map { game ->
            val feed = currentFeeds[game.gamePk]
            if (feed != null) game.copy(weather = feed.weather) else game
        }

        val baseCandidates = buildList {
            enrichedGames.forEach { game ->
                val current = currentFeeds[game.gamePk]
                val awayOfficial = current?.awayLineup
                val homeOfficial = current?.homeLineup
                val awayLineup = awayOfficial?.takeIf { it.players.isNotEmpty() } ?: latestLineupByTeam[game.awayTeam.id]
                val homeLineup = homeOfficial?.takeIf { it.players.isNotEmpty() } ?: latestLineupByTeam[game.homeTeam.id]

                val awayPitcherId = game.awayProbablePitcher?.id
                val homePitcherId = game.homeProbablePitcher?.id
                val awayPitcherProfile = awayPitcherId?.let { pitcherProfiles[it] }
                val homePitcherProfile = homePitcherId?.let { pitcherProfiles[it] }

                awayLineup?.players?.forEach { lp ->
                    val recent = recentBallsByBatter[lp.person.id].orEmpty().sortedBy { it.gameDate }
                    val today = current?.battedBalls?.filter { it.batterId == lp.person.id }.orEmpty()
                    val platoonStats = when (homePitcherProfile?.person?.pitchHand) {
                        "R" -> vsRightPitching[lp.person.id]
                        "L" -> vsLeftPitching[lp.person.id]
                        else -> null
                    }
                    val score = scoringModel.score(
                        player = lp.person,
                        battingOrder = lp.battingOrder,
                        lineupOfficial = awayLineup.official,
                        seasonStats = lp.seasonStats,
                        platoonStats = platoonStats,
                        recentBattedBalls = recent,
                        opponentPitcher = homePitcherProfile,
                        game = game,
                        weights = weights
                    )
                    add(
                        HitterCandidate(
                            player = lp.person,
                            team = game.awayTeam,
                            opponent = game.homeTeam,
                            game = game,
                            battingOrder = lp.battingOrder,
                            lineupOfficial = awayLineup.official,
                            seasonStats = lp.seasonStats,
                            opponentPitcher = homePitcherProfile,
                            recentBattedBalls = recent,
                            todayBattedBalls = today,
                            recentPlateDiscipline = recentDisciplineByBatter[lp.person.id] ?: PlateDisciplineSample(),
                            last3PlateDiscipline = last3DisciplineByBatter[lp.person.id] ?: PlateDisciplineSample(),
                            score = score,
                            platoonStats = platoonStats
                        )
                    )
                }

                homeLineup?.players?.forEach { lp ->
                    val recent = recentBallsByBatter[lp.person.id].orEmpty().sortedBy { it.gameDate }
                    val today = current?.battedBalls?.filter { it.batterId == lp.person.id }.orEmpty()
                    val platoonStats = when (awayPitcherProfile?.person?.pitchHand) {
                        "R" -> vsRightPitching[lp.person.id]
                        "L" -> vsLeftPitching[lp.person.id]
                        else -> null
                    }
                    val score = scoringModel.score(
                        player = lp.person,
                        battingOrder = lp.battingOrder,
                        lineupOfficial = homeLineup.official,
                        seasonStats = lp.seasonStats,
                        platoonStats = platoonStats,
                        recentBattedBalls = recent,
                        opponentPitcher = awayPitcherProfile,
                        game = game,
                        weights = weights
                    )
                    add(
                        HitterCandidate(
                            player = lp.person,
                            team = game.homeTeam,
                            opponent = game.awayTeam,
                            game = game,
                            battingOrder = lp.battingOrder,
                            lineupOfficial = homeLineup.official,
                            seasonStats = lp.seasonStats,
                            opponentPitcher = awayPitcherProfile,
                            recentBattedBalls = recent,
                            todayBattedBalls = today,
                            recentPlateDiscipline = recentDisciplineByBatter[lp.person.id] ?: PlateDisciplineSample(),
                            last3PlateDiscipline = last3DisciplineByBatter[lp.person.id] ?: PlateDisciplineSample(),
                            score = score,
                            platoonStats = platoonStats
                        )
                    )
                }
            }
        }.sortedByDescending { it.score.total }

        // At this point the board is already useful: lineups, recent power, pitcher matchup,
        // weather and all core model scores are ready. Publish it now and enrich BvP afterward so
        // the UI remains usable while the final small batch of network calls finishes.
        onPartialBoard(
            BoardData(
                date = date,
                candidates = baseCandidates,
                games = enrichedGames,
                lastUpdated = Instant.now(),
                recentGameCount = recentSummaries.size,
                recentWeekStats = recentWeekStats,
                recentThreeDayStats = recentThreeDayStats
            )
        )

        // Pitch-type fit is a secondary enrichment. We calculate it for the strongest six
        // preliminary hitters in each game plus the best 20 overall. This keeps the network work
        // bounded while covering the players users are most likely to research or add to parlays.
        onProgress("Matching HR pitch preferences to pitcher arsenals…")
        fun preliminaryArsenalRank(c: HitterCandidate): Double {
            val profile = scoringModel.mustHaveMetrics(c.player, c.seasonStats, c.recentBattedBalls)
            val profileAdjusted = profile.score * profile.confidence +
                c.score.seasonPower * (1.0 - profile.confidence)
            return profileAdjusted * 0.36 +
                c.score.powerPressure * 0.24 +
                c.score.pitcherMatchup * 0.30 +
                c.score.total * 0.10
        }
        val arsenalTargets = (
            baseCandidates.groupBy { it.game.gamePk }.values.flatMap { it.sortedByDescending(::preliminaryArsenalRank).take(6) } +
                baseCandidates.sortedByDescending(::preliminaryArsenalRank).take(20)
            ).distinctBy { it.player.id }
        val arsenalBatterIds = arsenalTargets.map { it.player.id }
        val hitterHrCountsByType = pitchTypes.map { code ->
            async {
                semaphore.withPermit {
                    code to api.fetchPitchTypeOccurrences(
                        playerIds = arsenalBatterIds,
                        season = season,
                        pitchType = code,
                        group = "hitting",
                        eventType = "homeRun"
                    )
                }
            }
        }.awaitAll().toMap()

        val hrPitchCountsByBatter = arsenalBatterIds.associateWith { batterId ->
            pitchTypes.associateWith { code -> hitterHrCountsByType[code]?.get(batterId) ?: 0 }
        }
        val arsenalCandidates = baseCandidates.map { candidate ->
            val pitcherArsenal = candidate.opponentPitcher?.seasonPitchArsenal.orEmpty()
            val hrCounts = hrPitchCountsByBatter[candidate.player.id]
            if (hrCounts == null || pitcherArsenal.isEmpty()) candidate
            else candidate.copy(pitchArsenalMatch = buildPitchArsenalMatch(hrCounts, pitcherArsenal))
        }

        // BvP is useful, but it should never hold the whole slate hostage. v0.8 fetched up to
        // ~100 matchups (7 per game). We now fetch the top two preliminary hitters per game plus
        // the best 12 overall, usually ~30 lookups total.
        onProgress("Adding BvP context…")
        fun preliminaryRank(c: HitterCandidate): Double {
            val profile = scoringModel.mustHaveMetrics(c.player, c.seasonStats, c.recentBattedBalls)
            val profileAdjusted = profile.score * profile.confidence +
                c.score.seasonPower * (1.0 - profile.confidence)
            return profileAdjusted * 0.35 +
                c.score.powerPressure * 0.25 +
                c.score.pitcherMatchup * 0.30 +
                c.score.total * 0.10
        }

        val perGameBvp = arsenalCandidates
            .groupBy { it.game.gamePk }
            .values
            .flatMap { gameCandidates -> gameCandidates.sortedByDescending(::preliminaryRank).take(2) }
        val globalBvp = arsenalCandidates.sortedByDescending(::preliminaryRank).take(12)
        val bvpTargets = (perGameBvp + globalBvp)
            .mapNotNull { c -> c.opponentPitcher?.person?.id?.let { pitcherId -> Triple(c.player.id, pitcherId, c) } }
            .distinctBy { it.first to it.second }

        val bvpByPair = bvpTargets.map { (batterId, pitcherId, _) ->
            async {
                semaphore.withPermit {
                    val stats = runCatching { api.fetchHittingVsPitcherStats(batterId, pitcherId) }.getOrNull()
                    (batterId to pitcherId) to stats
                }
            }
        }.awaitAll().mapNotNull { (key, stats) -> stats?.let { key to it } }.toMap()

        val candidates = arsenalCandidates.map { candidate ->
            val pitcherId = candidate.opponentPitcher?.person?.id
            val bvp = pitcherId?.let { bvpByPair[candidate.player.id to it] }
            candidate.copy(vsPitcherStats = bvp)
        }.sortedByDescending { it.score.total }

        onProgress("Ready")
        BoardData(
            date = date,
            candidates = candidates,
            games = enrichedGames,
            lastUpdated = Instant.now(),
            recentGameCount = recentSummaries.size,
            recentWeekStats = recentWeekStats,
            recentThreeDayStats = recentThreeDayStats
        )
    }
    private fun commonPitchTypes(): List<String> = listOf(
        "FF", "SI", "FC", "SL", "ST", "CU", "KC", "CH", "FS"
    )

    private fun buildPitchArsenal(counts: Map<String, Int>): List<PitchTypeUsage> {
        val total = counts.values.sum()
        if (total <= 0) return emptyList()
        return counts.entries
            .filter { it.value > 0 }
            .map { (code, count) ->
                PitchTypeUsage(
                    code = code,
                    name = api.pitchTypeName(code),
                    count = count,
                    share = count.toDouble() / total
                )
            }
            .sortedByDescending { it.share }
    }

    private fun buildPitchArsenalMatch(
        hitterHrCounts: Map<String, Int>,
        pitcherArsenal: List<PitchTypeUsage>
    ): PitchArsenalMatch? {
        val hrTotal = hitterHrCounts.values.sum()
        val pitchTotal = pitcherArsenal.sumOf { it.count }
        if (hrTotal <= 0 || pitchTotal <= 0) return null

        val hrShares = hitterHrCounts.mapValues { (_, count) -> count.toDouble() / hrTotal }
        val arsenalShares = pitcherArsenal.associate { it.code to it.share }
        val codes = commonPitchTypes()
        val dot = codes.sumOf { (hrShares[it] ?: 0.0) * (arsenalShares[it] ?: 0.0) }
        val hrNorm = kotlin.math.sqrt(codes.sumOf { val v = hrShares[it] ?: 0.0; v * v })
        val pitchNorm = kotlin.math.sqrt(codes.sumOf { val v = arsenalShares[it] ?: 0.0; v * v })
        val cosine = if (hrNorm > 0.0 && pitchNorm > 0.0) (dot / (hrNorm * pitchNorm)).coerceIn(0.0, 1.0) else 0.5

        val topHrCodes = hitterHrCounts.entries.filter { it.value > 0 }.sortedByDescending { it.value }.take(2).map { it.key }
        val feastExposure = topHrCodes.sumOf { arsenalShares[it] ?: 0.0 }
        val exposureScore = ((feastExposure - 0.15) / (0.65 - 0.15) * 100.0).coerceIn(0.0, 100.0)
        val raw = cosine * 100.0 * 0.68 + exposureScore * 0.32

        val hrConfidence = (hrTotal / 8.0).coerceIn(0.18, 1.0)
        val arsenalConfidence = (pitchTotal / 400.0).coerceIn(0.35, 1.0)
        val confidence = (hrConfidence * arsenalConfidence).coerceIn(0.12, 1.0)
        val score = (50.0 * (1.0 - confidence) + raw * confidence).coerceIn(0.0, 100.0)

        val feastPitches = hitterHrCounts.entries
            .filter { it.value > 0 }
            .sortedByDescending { it.value }
            .take(4)
            .map { (code, count) ->
                PitchHrTendency(
                    code = code,
                    name = api.pitchTypeName(code),
                    homeRuns = count,
                    share = count.toDouble() / hrTotal,
                    opposingPitcherUsage = arsenalShares[code] ?: 0.0
                )
            }

        return PitchArsenalMatch(
            score = score,
            confidence = confidence,
            batterHrSample = hrTotal,
            pitcherPitchSample = pitchTotal,
            feastPitches = feastPitches,
            pitcherArsenal = pitcherArsenal.take(5)
        )
    }

    suspend fun fetchPlayerLast10Stats(
        playerId: Int,
        throughDate: LocalDate
    ): RecentHittingStats? = api.fetchPlayerLastGamesStats(
        playerId = playerId,
        season = throughDate.year,
        throughDate = throughDate,
        gameCount = 10
    )

    fun rescore(board: BoardData, weights: ScoreWeights): BoardData {
        val rescored = board.candidates.map { c ->
            c.copy(
                score = scoringModel.score(
                    player = c.player,
                    battingOrder = c.battingOrder,
                    lineupOfficial = c.lineupOfficial,
                    seasonStats = c.seasonStats,
                    platoonStats = c.platoonStats,
                    recentBattedBalls = c.recentBattedBalls,
                    opponentPitcher = c.opponentPitcher,
                    game = c.game,
                    weights = weights
                )
            )
        }.sortedByDescending { it.score.total }
        return board.copy(candidates = rescored)
    }

}
