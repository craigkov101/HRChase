# HR Chase v0.8

A polished Android home-run research app focused on daily MLB target discovery, game-by-game matchup context, BvP history, must-have power metrics, and quality-first parlay generation.

## v0.8 redesign
- Premium dark visual system with cyan/violet accents
- Branded HR CHASE header and cleaner refresh state
- Elevated floating bottom navigation
- Cleaner date/filter controls
- Redesigned matchup cards and team badges
- Premium Top 15 target presentation
- More focused parlay generator controls
- Retains the v0.7.1 stability/memory fixes

# HR Chase — Android MVP (v0.7.1)

A native Android app for ranking MLB hitters by a transparent home-run **Chase Score**. This version is intentionally functional-first: live data, model logic, player drill-downs, tracking, and editable weights before visual polish.


## v0.5 generator fixes

- 1-leg straight picks now cycle through a ranked pool of up to 12 strong candidates instead of repeating the same top hitter.
- Multi-leg generation rotates its anchor and nearby top-ranked options while still preferring different games and teams.
- The parlay score gives an extra boost to hitters who grade well in both Power Pressure and Matchup.
- Weak environment and poor-matchup legs receive additional penalties.
- Pitcher warnings now identify which team's hitters face the tough pitcher.

## What works now

- Native Android app written in **Kotlin + Jetpack Compose**.
- Loads the selected day's MLB schedule from the public MLB Stats API.
- Pulls posted batting orders; if a lineup is not posted, it falls back to that team's most recent real lineup and clearly labels it **PROJECTED LINEUP**.
- Pulls probable pitchers and season pitching stats.
- Reads MLB live game feeds for recent batted-ball contact including exit velocity, launch angle, projected distance, result and game date.
- Looks back **5 days** to build recent-contact and must-have power-profile signals.
- Detects the "Bohm signal" discussed during development:
  - high-EV near-home-run outs/contact,
  - unrewarded barrel-like contact,
  - recent hard-hit frequency,
  - rising exit-velocity trend.
- Builds a **Power Pressure** score specifically for hitters whose HR-quality contact may be running ahead of their actual HR results.
- Scores opposing pitcher vulnerability with HR/9, ERA and recent contact allowed.
- Uses MLB game-feed weather plus a simple v0.1 park model.
- Ranks hitters by an editable 0–100 **HR Chase Score**.
- Lets you sort by Overall, Power Pressure, Recent Contact or Matchup.
- Lets you star/track hitters you actually play.
- The Tracked tab grades the day's process as games progress: HR, elite near-HR, near-HR, barrel-quality contact, hard contact, or quiet contact.
- The Model tab lets you change weights and re-rank the slate instantly without re-downloading data.
- No API key, paid service, account or backend server is required for v0.1.

## Default model weights

| Component | Weight |
|---|---:|
| Recent contact | 25 |
| Power Pressure / near-HR | 20 |
| Pitcher matchup | 25 |
| Park / weather | 10 |
| Season power | 15 |
| Lineup opportunity | 5 |

The app normalizes weights automatically, so they do not have to total 100.

## Power Pressure v0.1

This is the first implementation of the near-HR idea. A recent batted ball gets elevated when it has combinations such as:

- 100+ mph exit velocity,
- roughly 20–36° launch angle,
- 350+ ft projected distance when distance is available,
- or a barrel-like EV/LA combination that did not result in a HR.

An **elite near-HR** currently means 105+ mph, 20–35° and 370+ ft without being a home run.

The barrel calculation in v0.1 is explicitly a transparent **barrel proxy**, not MLB's official Statcast barrel classification. The player screen labels it that way.

## Data sources

The app makes HTTPS requests directly from the phone to MLB endpoints:

- `https://statsapi.mlb.com/api/v1/schedule`
- `https://statsapi.mlb.com/api/v1.1/game/{gamePk}/feed/live`
- `https://statsapi.mlb.com/api/v1/people/{playerId}/stats`

MLB/Statcast definitions for EV, launch angle, hard hit and barrels are documented at Baseball Savant:
`https://baseballsavant.mlb.com/csv-docs`

## Build it in Android Studio

### Requirements

- Android Studio with Android SDK 35 installed
- JDK 17 (Android Studio's bundled JDK is fine)
- Internet access for the first Gradle sync

### Steps

1. Unzip this project.
2. Open the **HRChase** folder in Android Studio.
3. Allow Gradle sync to finish.
4. If Android Studio asks for an SDK, install/select **Android SDK 35**.
5. Connect an Android phone with USB debugging enabled, or use an emulator.
6. Press **Run**.

The package ID is `com.ckz.hrchase` and the app name is **HR Chase**.

## Build an APK

From the project folder:

### Windows

```bat
build-debug.bat
```

### macOS/Linux

```sh
./build-debug.sh
```

The debug APK will be created at:

`app/build/outputs/apk/debug/app-debug.apk`

The included `gradlew`/`gradlew.bat` are lightweight bootstrap scripts that download Gradle 8.10.2 if needed. They are not the standard binary Gradle wrapper, because this generated bundle intentionally contains no opaque wrapper JAR.

## How to use the app

### Board

- Hit refresh to pull the latest schedule, lineups and game data.
- **Remaining only** hides finished games on today's slate.
- **Official lineups** hides fallback/projected lineups.
- Sort by **Power Pressure** when specifically hunting the next-HR/near-miss signal.
- Tap any hitter for the full breakdown.
- Tap the star to track a pick.

### Player detail

Shows:

- total Chase Score,
- Recent Contact score,
- Power Pressure score,
- Pitcher Matchup score,
- Park/Weather score,
- Season Power score,
- Lineup score,
- opposing pitcher ERA and HR/9,
- season hitter stats,
- recent batted-ball EV / LA / distance,
- Near-HR / Near-HR+ / Barrel-Proxy / Hard-Hit labels,
- the model's human-readable reasoning.

### Tracked

Star the hitters you actually bet or want to study. During/after the game, refresh the app and it evaluates today's contact instead of reducing everything to a simple win/loss.

### Model Lab

Adjust any component from 0 to 50 and tap **Save & re-rank**. This is the experiment layer for learning which metrics are actually useful over time.

## Important v0.1 limitations

This is a real working MVP, but several things are deliberately left for later versions:

- No sportsbook HR odds feed yet. Reliable odds APIs normally require an API key/paid service.
- No automatic X/Twitter sentiment ingestion inside the app yet.
- No pitch-type-specific batter-vs-pitch model yet.
- No official Statcast barrel flag; current barrel signal is a documented proxy from EV + LA.
- Foul-ball near-HRs are usually not available with the same hitData fields in the MLB game feed, so v0.1 focuses on tracked balls in play.
- Park scoring is a simple internal v0.1 ranking, not a licensed real-time park-factor feed.
- The current lookback is fixed at 5 days.
- No cloud account/sync; tracked picks and model weights are stored locally on the phone.

## Next upgrades worth building

1. Persistent results database so every daily prediction and outcome is stored automatically.
2. Backtesting screen showing HR rate / barrel rate by Chase Score bucket.
3. Exact previous-game near-HR weighting and longer 5/10/15-game windows.
4. Pitch-mix matchup: hitter damage vs FF/SI/SL/CH/etc. against the opposing pitcher's usage.
5. Handedness splits for both hitter and pitcher.
6. Real park factors and wind orientation.
7. Sportsbook odds + implied probability + model-vs-market value score.
8. Round-robin/slip builder with exposure warnings.
9. Automatic postgame model report: what hit, what missed, what was a good read despite the result.
10. Only after the model/data is stable: visual redesign, animations and branding.

## Research disclaimer

The Chase Score is a ranking heuristic for research/entertainment. It is **not** a home-run probability, guarantee, or claim of betting profitability. Home-run outcomes are high variance.

## v0.2 UI refresh
- Dark sports-dashboard visual system.
- Clear score hierarchy and player ranking on the board.
- Compact signal pills for near-HR, hot contact, pitcher targets and lineup status.
- Visual factor bars for Pressure, Contact, Matchup and Environment.
- Redesigned player detail, tracked-picks and Model Lab screens.
- No changes to the underlying scoring/data pipeline from v0.1.


## v0.3 – Pressure + Matchup Combo
- Added a dedicated **Pressure + Matchup** ranking mode.
- Attack Score = 45% Power Pressure + 45% Pitcher Matchup + 10% Recent Contact.
- When the combo is active, player cards display the Attack Score as the primary ranking number.
- Optional **Both 65+** filter only shows hitters with Power Pressure >= 65 and Matchup >= 65.
- Existing Overall, Power Pressure, Matchup, and Recent Contact views remain available.

## v0.4 – Game-first simplification + Parlay Generator
- Replaced the crowded multi-sort board with a simpler **Games** tab.
- Each MLB game now shows the model's **top four HR candidates from that game**.
- Every candidate includes a short plain-English justification plus the strongest underlying note.
- Added game-level **Pitcher Warning** alerts for high-quality starters.
- Added **Weather Warning**, **Wind Warning**, and **Cold-weather Warning** alerts when MLB game-feed conditions are unfavorable.
- Added a compact HR environment badge for each game.
- Added a dedicated **Parlays** tab with 1-, 2-, 3-, 4-, and 5-leg generation.
- The generator prioritizes Pressure + Matchup, overall Chase Score, environment, and lineup opportunity.
- Multi-leg generation prefers hitters from different games and teams to avoid unnecessary correlation.
- "Generate another" creates a different high-quality combination without randomly diving into weak plays.
- The main navigation is now **Games / Parlays / Tracked**. Model tuning was removed from the primary UI to reduce clutter; the underlying transparent model remains intact.


## v0.6 — Batter vs Pitcher
- Adds career MLB batter-vs-pitcher history for leading candidates in each game.
- Game cards show H-for-AB, AVG, HR and OPS against the scheduled opposing pitcher.
- Player detail adds a full BvP card with AB/H/HR/K and AVG/OBP/SLG/OPS.
- Strong BvP can add a small, capped boost to Pick/Parlay ranking only when the sample is meaningful; tiny samples are labeled and do not affect the score.
- To avoid hundreds of network calls, BvP is preloaded for the seven strongest preliminary candidates in each game.


## v0.7.1 — Top 15 Targets + Must-Have Power Profile
- Adds a dedicated **Targets** tab with the model's top 15 HR hitters for the selected day.
- Adds a new transparent **Must-Have Power Profile** built from:
  - Barrel%
  - PullBrl%
  - PullAir%
  - Hard-Hit%
  - Avg Distance
  - Average EV
  - ISO
  - Fly Ball%
  - Pull%
  - Blast%
- Barrel%, hard-hit rate, EV, distance, and fly-ball rate come from recent MLB tracked batted balls.
- ISO comes from MLB season batting stats.
- Pull-based metrics are directional proxies inferred from MLB play descriptions plus batter side.
- Blast% is a transparent proxy for 105+ mph contact at 15–35° launch angle.
- Small recent samples are automatically blended toward season power so 1–2 batted balls cannot dominate the ranking.
- The **Daily Target Score** weights the new power profile most heavily, then Power Pressure, pitcher matchup, overall model, environment, lineup opportunity, and capped BvP context.
- Game rankings and the parlay generator now inherit the new Target Score, so these metrics influence more than just the new tab.
- The recent batted-ball lookback increases from 3 to 5 days for a more stable daily power profile.

## v0.8.1 performance pass

- Publishes the schedule to the UI immediately while enrichment continues.
- Publishes a usable scored board before optional BvP enrichment completes.
- Stops retaining full live-feed JSON for all of today's games.
- Caps recent live-feed history at 30 relevant completed games.
- Reduces BvP requests from up to ~100 per slate to roughly 30 while preserving top-game and top-overall candidates.
- Groups game candidates once in Compose instead of repeatedly scanning the whole slate for each card.
- Uses lighter scrolling-card elevation/shadows and shorter network timeouts.
- Adds a defensive larger Android heap while the data pipeline is still being hardened.
