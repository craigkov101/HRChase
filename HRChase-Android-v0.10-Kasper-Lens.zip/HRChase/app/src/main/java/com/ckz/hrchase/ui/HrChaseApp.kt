package com.ckz.hrchase.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Casino
import androidx.compose.material.icons.outlined.SportsBaseball
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.ckz.hrchase.AppUiState
import com.ckz.hrchase.MainViewModel
import com.ckz.hrchase.data.BattedBall
import com.ckz.hrchase.data.BatterVsPitcherStats
import com.ckz.hrchase.data.GameInfo
import com.ckz.hrchase.data.HitterCandidate
import com.ckz.hrchase.data.MustHaveMetrics
import com.ckz.hrchase.data.PitcherProfile
import com.ckz.hrchase.data.TeamRef
import com.ckz.hrchase.model.HrScoringModel
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

private val AppBackground = Color(0xFF050A12)
private val AppBackgroundTop = Color(0xFF07111F)
private val AppSurface = Color(0xFF0B1320)
private val AppSurfaceRaised = Color(0xFF101C2D)
private val AppSurfaceSoft = Color(0xFF0D1726)
private val AppOutline = Color(0xFF1C2B3D)
private val AppPrimary = Color(0xFF49C8FF)
private val AppViolet = Color(0xFF8B7CFF)
private val AppGreen = Color(0xFF2FE6A6)
private val AppAmber = Color(0xFFFFB547)
private val AppRed = Color(0xFFFF637D)
private val AppMuted = Color(0xFF8194AA)
private val AppText = Color(0xFFF6FAFF)
private val AppSubtleText = Color(0xFFC7D4E2)

private val HrChaseColors = darkColorScheme(
    primary = AppPrimary,
    onPrimary = Color(0xFF03131E),
    secondary = AppViolet,
    tertiary = AppGreen,
    background = AppBackground,
    onBackground = AppText,
    surface = AppSurface,
    onSurface = AppText,
    surfaceVariant = AppSurfaceRaised,
    onSurfaceVariant = Color(0xFFC4D2DF),
    outline = AppOutline,
    error = AppRed
)

private enum class Tab { GAMES, TARGETS, PARLAYS, TRACKED }

private data class GameAlert(
    val title: String,
    val detail: String,
    val color: Color
)


private data class PowerMetricSignal(
    val label: String,
    val display: String,
    val quality: Double
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HrChaseApp(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    val selected = state.selectedPlayerId?.let { id ->
        state.board?.candidates?.firstOrNull { it.player.id == id }
    }

    MaterialTheme(colorScheme = HrChaseColors) {
        CompositionLocalProvider(LocalContentColor provides AppText) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(AppBackgroundTop, AppBackground)))
            ) {
                if (selected != null) {
                PlayerDetailScreen(
                    candidate = selected,
                    pickScore = viewModel.pickScore(selected),
                    kasperScore = viewModel.kasperLensScore(selected),
                    kasperTier = viewModel.kasperTier(selected),
                    kasperReasons = viewModel.kasperReasons(selected),
                    swingMissScore = viewModel.swingMissScore(selected),
                    teamDepthScore = viewModel.teamBarrelDepthScore(selected),
                    tracked = state.tracked.any { it.playerId == selected.player.id && it.date == state.selectedDate },
                    onBack = { viewModel.selectPlayer(null) },
                    onTrack = { viewModel.toggleTracked(selected) }
                )
                } else {
                    Scaffold(
                        containerColor = Color.Transparent,
                        topBar = { PremiumHeader(isLoading = state.isLoading, onRefresh = { viewModel.refresh() }) },
                        bottomBar = {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .navigationBarsPadding()
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                Surface(
                                    color = Color(0xFF091523).copy(alpha = 0.98f),
                                    shape = RoundedCornerShape(28.dp),
                                    shadowElevation = 10.dp,
                                    border = BorderStroke(1.dp, AppOutline.copy(alpha = 0.95f))
                                ) {
                                    NavigationBar(
                                        containerColor = Color.Transparent,
                                        tonalElevation = 0.dp,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(72.dp)
                                    ) {
                                NavigationBarItem(
                                    selected = tab == 0,
                                    onClick = { tab = 0 },
                                    icon = { Icon(Icons.Outlined.SportsBaseball, null) },
                                    label = { Text("Games", fontWeight = FontWeight.SemiBold) },
                                    colors = navColors()
                                )
                                NavigationBarItem(
                                    selected = tab == 1,
                                    onClick = { tab = 1 },
                                    icon = { Icon(Icons.Default.Star, null) },
                                    label = { Text("Targets", fontWeight = FontWeight.SemiBold) },
                                    colors = navColors()
                                )
                                NavigationBarItem(
                                    selected = tab == 2,
                                    onClick = { tab = 2 },
                                    icon = { Icon(Icons.Outlined.Casino, null) },
                                    label = { Text("Parlays", fontWeight = FontWeight.SemiBold) },
                                    colors = navColors()
                                )
                                NavigationBarItem(
                                    selected = tab == 3,
                                    onClick = { tab = 3 },
                                    icon = { Icon(Icons.Outlined.StarBorder, null) },
                                    label = { Text("Tracked", fontWeight = FontWeight.SemiBold) },
                                    colors = navColors()
                                )
                                    }
                                }
                            }
                        }
                    ) { padding ->
                        when (tab) {
                            0 -> GamesScreen(state, viewModel, padding)
                            1 -> TargetsScreen(state, viewModel, padding)
                            2 -> ParlaysScreen(state, viewModel, padding)
                            else -> TrackedScreen(state, viewModel, padding)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PremiumHeader(isLoading: Boolean, onRefresh: () -> Unit) {
    Surface(color = Color.Transparent) {
        Row(
            Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(start = 18.dp, end = 12.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(44.dp),
                shape = RoundedCornerShape(15.dp),
                color = AppPrimary.copy(alpha = 0.12f),
                border = BorderStroke(1.dp, AppPrimary.copy(alpha = 0.30f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.SportsBaseball, null, tint = AppPrimary, modifier = Modifier.size(25.dp))
                }
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "HR CHASE",
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.1.sp,
                        color = AppText,
                        style = MaterialTheme.typography.titleLarge
                    )
                    Spacer(Modifier.width(8.dp))
                    Surface(
                        color = AppViolet.copy(alpha = 0.13f),
                        shape = RoundedCornerShape(50.dp),
                        border = BorderStroke(1.dp, AppViolet.copy(alpha = 0.28f))
                    ) {
                        Text(
                            "MODEL",
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                            color = AppViolet,
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
                Text("Daily home-run intelligence", style = MaterialTheme.typography.labelMedium, color = AppSubtleText)
            }
            Surface(
                modifier = Modifier
                    .size(42.dp)
                    .clickable(enabled = !isLoading, onClick = onRefresh),
                color = AppSurfaceRaised,
                shape = CircleShape,
                border = BorderStroke(1.dp, if (isLoading) AppPrimary.copy(alpha = 0.45f) else AppOutline)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    if (isLoading) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = AppPrimary)
                    } else {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = AppText, modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun navColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = AppPrimary,
    selectedTextColor = AppText,
    indicatorColor = AppPrimary.copy(alpha = 0.14f),
    unselectedIconColor = AppMuted,
    unselectedTextColor = AppMuted
)

@Composable
private fun GamesScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val board = state.board
    val eligible = viewModel.eligibleCandidates(state)
    val candidatesByGame = remember(eligible) { eligible.groupBy { it.game.gamePk } }
    val candidateGameIds = candidatesByGame.keys
    val games = board?.games.orEmpty()
        .filter { game -> state.isLoading || game.gamePk in candidateGameIds }
        .sortedBy { it.gameDate }

    Column(
        Modifier
            .fillMaxSize()
            .padding(padding)
            .background(Color.Transparent)
    ) {
        DateControls(state, viewModel)
        SimpleFilters(state, viewModel)
        LoadState(state, viewModel)

        if (!state.isLoading && board != null && games.isEmpty()) {
            EmptyState("No games match the current lineup filters.")
        } else if (board == null && state.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AppPrimary)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    ScreenIntro(
                        eyebrow = "TODAY'S SLATE",
                        title = "Best HR spots by game",
                        subtitle = "Fast matchup view with model-ranked hitters, pitcher alerts and weather context."
                    )
                }

                items(games, key = { it.gamePk }) { game ->
                    val gameCandidates = candidatesByGame[game.gamePk].orEmpty()
                    val top = gameCandidates.sortedByDescending(viewModel::pickScore).take(4)
                    GameCard(
                        game = game,
                        candidates = gameCandidates,
                        topHitters = top,
                        viewModel = viewModel,
                        state = state
                    )
                }

                item {
                    Text(
                        "Rankings are research signals, not guarantees. Home runs remain high-variance events.",
                        style = MaterialTheme.typography.labelSmall,
                        color = AppMuted,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun GameCard(
    game: GameInfo,
    candidates: List<HitterCandidate>,
    topHitters: List<HitterCandidate>,
    viewModel: MainViewModel,
    state: AppUiState
) {
    val time = game.gameDate.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("h:mm a"))
    val alerts = remember(game, candidates) { gameAlerts(game, candidates) }
    val avgEnvironment = candidates.map { it.score.environment }.average().takeUnless { it.isNaN() } ?: 50.0

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = AppSurface.copy(alpha = 0.98f)),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, AppOutline.copy(alpha = 0.85f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TeamBadge(game.awayTeam)
                Text("@", color = AppMuted, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp))
                TeamBadge(game.homeTeam)
                Spacer(Modifier.weight(1f))
                EnvironmentBadge(avgEnvironment)
            }

            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(time, color = AppText, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                Text(
                    game.venueName,
                    color = AppMuted,
                    style = MaterialTheme.typography.labelMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).padding(start = 12.dp)
                )
            }

            if (alerts.isNotEmpty()) {
                Spacer(Modifier.height(11.dp))
                alerts.forEach { alert -> AlertRow(alert) }
            }

            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("TOP HR LOOKS", fontWeight = FontWeight.Black, color = AppText, letterSpacing = 0.7.sp, style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.width(8.dp))
                Surface(color = AppPrimary.copy(alpha = 0.10f), shape = RoundedCornerShape(50.dp)) {
                    Text(
                        "${topHitters.size}",
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                        color = AppPrimary,
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
            Spacer(Modifier.height(6.dp))

            if (topHitters.isEmpty()) {
                Text("Lineup data is not available yet.", color = AppMuted, style = MaterialTheme.typography.bodySmall)
            } else {
                topHitters.forEachIndexed { index, candidate ->
                    if (index > 0) HorizontalDivider(color = AppOutline.copy(alpha = 0.55f), modifier = Modifier.padding(vertical = 4.dp))
                    GameHitterRow(
                        rank = index + 1,
                        candidate = candidate,
                        score = viewModel.pickScore(candidate),
                        tracked = state.tracked.any { it.playerId == candidate.player.id && it.date == state.selectedDate },
                        onOpen = { viewModel.selectPlayer(candidate.player.id) },
                        onTrack = { viewModel.toggleTracked(candidate) }
                    )
                }
            }
        }
    }
}

@Composable
private fun TeamBadge(team: TeamRef) {
    Surface(
        color = AppSurfaceRaised,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, AppOutline)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TeamLogo(team = team, size = 24.dp)
            Spacer(Modifier.width(7.dp))
            Text(
                team.abbreviation,
                fontWeight = FontWeight.Black,
                color = AppText,
                style = MaterialTheme.typography.titleMedium
            )
        }
    }
}

@Composable
private fun TeamLogo(
    team: TeamRef,
    size: androidx.compose.ui.unit.Dp = 22.dp,
    container: Boolean = false
) {
    val logoUrl = "https://www.mlbstatic.com/team-logos/${team.id}.svg"
    val shape = RoundedCornerShape((size.value * 0.30f).dp)
    Box(
        modifier = Modifier
            .size(size)
            .then(
                if (container) {
                    Modifier
                        .clip(shape)
                        .background(AppSurfaceRaised.copy(alpha = 0.72f))
                        .padding(1.dp)
                } else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = logoUrl,
            contentDescription = "${team.name} logo",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Fit
        )
    }
}

@Composable
private fun GameHitterRow(
    rank: Int,
    candidate: HitterCandidate,
    score: Double,
    tracked: Boolean,
    onOpen: () -> Unit,
    onTrack: () -> Unit
) {
    val scoreInt = score.roundToInt()
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
            .padding(vertical = 5.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                modifier = Modifier.size(46.dp),
                shape = RoundedCornerShape(13.dp),
                color = scoreColor(scoreInt).copy(alpha = 0.13f),
                border = BorderStroke(1.dp, scoreColor(scoreInt).copy(alpha = 0.35f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(scoreInt.toString(), fontWeight = FontWeight.Black, color = scoreColor(scoreInt))
                        Text("PICK", style = MaterialTheme.typography.labelSmall, color = AppMuted)
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TeamLogo(candidate.team, size = 22.dp)
                    Spacer(Modifier.width(7.dp))
                    Text(
                        "#$rank  ${candidate.player.name}",
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                }
                Text(
                    "${candidate.team.abbreviation} • Batting #${candidate.battingOrder} • vs ${candidate.opponentPitcher?.person?.name ?: "TBD"}",
                    color = AppMuted,
                    style = MaterialTheme.typography.labelMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onTrack) {
                Icon(
                    if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder,
                    contentDescription = "Track",
                    tint = if (tracked) AppAmber else AppMuted
                )
            }
        }

        Text(
            quickJustification(candidate),
            modifier = Modifier.padding(start = 56.dp, end = 4.dp),
            color = Color(0xFFD3E0EA),
            style = MaterialTheme.typography.bodySmall
        )
        candidate.vsPitcherStats?.let { bvp ->
            Text(
                bvpSummary(bvp),
                modifier = Modifier.padding(start = 56.dp, end = 4.dp, top = 3.dp),
                color = bvpColor(bvp),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold
            )
        }
        candidate.score.notes.firstOrNull()?.let { note ->
            Text(
                note,
                modifier = Modifier.padding(start = 56.dp, end = 4.dp, top = 2.dp),
                color = AppMuted,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun EnvironmentBadge(value: Double) {
    val label = when {
        value >= 72 -> "HR+"
        value < 40 -> "HR−"
        else -> "NEUTRAL"
    }
    val color = when {
        value >= 72 -> AppGreen
        value < 40 -> AppAmber
        else -> AppMuted
    }
    Surface(color = color.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp), border = BorderStroke(1.dp, color.copy(alpha = 0.30f))) {
        Text(label, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = color, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun AlertRow(alert: GameAlert) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(bottom = 5.dp),
        color = alert.color.copy(alpha = 0.09f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, alert.color.copy(alpha = 0.24f))
    ) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Warning, null, tint = alert.color, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Column {
                Text(alert.title, color = alert.color, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                Text(alert.detail, color = Color(0xFFD3E0EA), style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

private fun gameAlerts(game: GameInfo, candidates: List<HitterCandidate>): List<GameAlert> = buildList {
    val pitchers = candidates.mapNotNull { it.opponentPitcher }.distinctBy { it.person.id }
    pitchers.filter(::isTopPitcher).forEach { pitcher ->
        val bits = listOfNotNull(
            pitcher.seasonStats.era?.let { "${"%.2f".format(it)} ERA" },
            pitcher.seasonStats.hrPer9?.let { "${"%.2f".format(it)} HR/9" }
        ).joinToString(" • ")
        val affectedTeam = candidates.firstOrNull { it.opponentPitcher?.person?.id == pitcher.person.id }?.team?.abbreviation
        val title = affectedTeam?.let { "Tough matchup for $it hitters" } ?: "Pitcher warning"
        add(GameAlert(title, "${pitcher.person.name}${if (bits.isNotBlank()) " • $bits" else ""}", AppAmber))
    }

    val weather = game.weather
    val roofClosed = weather.roofType?.contains("closed", true) == true || weather.condition?.contains("dome", true) == true
    if (!roofClosed) {
        val condition = weather.condition.orEmpty()
        val badCondition = listOf("rain", "storm", "shower", "drizzle", "snow").any { condition.contains(it, true) }
        if (badCondition) {
            add(GameAlert("Weather warning", condition.ifBlank { "Possible precipitation" }, AppRed))
        }

        val wind = weather.wind.orEmpty()
        val mph = Regex("(\\d+)\\s*mph", RegexOption.IGNORE_CASE).find(wind)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
        if (wind.contains("in", true) && mph >= 10) {
            add(GameAlert("Wind warning", "$wind may suppress carry", AppAmber))
        }
        weather.temperatureF?.let { temp ->
            if (temp <= 52) add(GameAlert("Cold-weather warning", "$temp°F can reduce home-run carry", AppAmber))
        }
    }
}

private fun isTopPitcher(pitcher: PitcherProfile): Boolean {
    val stats = pitcher.seasonStats
    if (stats.inningsPitched in 0.0..<20.0) return false
    val era = stats.era
    val hr9 = stats.hrPer9
    return (era != null && hr9 != null && era <= 3.25 && hr9 <= 1.10) ||
        (era != null && era <= 2.80) ||
        (hr9 != null && hr9 <= 0.75)
}

private fun quickJustification(candidate: HitterCandidate): String {
    val p = candidate.score.powerPressure.roundToInt()
    val m = candidate.score.pitcherMatchup.roundToInt()
    val c = candidate.score.recentPower.roundToInt()
    val e = candidate.score.environment.roundToInt()
    val bvp = candidate.vsPitcherStats
    return when {
        bvp != null && bvp.plateAppearances >= 8 && ((bvp.ops ?: 0.0) >= .900 || bvp.homeRuns >= 2) ->
            "BvP edge plus current form: ${bvp.hits}-for-${bvp.atBats}, ${bvp.homeRuns} HR vs this pitcher. Pressure $p • Matchup $m."
        candidate.platoonStats != null && candidate.platoonStats.plateAppearances >= 35 && candidate.score.platoon >= 70 -> {
            val hand = candidate.opponentPitcher?.person?.pitchHand ?: "?"
            val splitIso = candidate.platoonStats.iso?.let { String.format("%.3f", it).removePrefix("0") } ?: "—"
            "Strong vs ${hand}HP split: $splitIso ISO • ${candidate.platoonStats.homeRuns} HR in ${candidate.platoonStats.plateAppearances} PA. Matchup $m."
        }
        p >= 72 && m >= 72 -> "Best combo: Power Pressure $p + Matchup $m."
        p >= 75 -> "Power Pressure $p: recent HR-quality contact is building. Matchup $m."
        m >= 75 -> "Matchup $m: favorable opposing-pitcher profile. Recent contact $c."
        c >= 75 -> "Recent contact $c is hot; matchup $m keeps him in play."
        e >= 75 -> "Strong park/weather spot ($e) with a balanced hitter profile."
        else -> "Balanced profile: Pressure $p • Matchup $m • Contact $c."
    }
}

private fun bvpSummary(bvp: BatterVsPitcherStats): String {
    val avg = bvp.avg?.let { String.format("%.3f", it).removePrefix("0") } ?: "—"
    val ops = bvp.ops?.let { String.format("%.3f", it).removePrefix("0") } ?: "—"
    val sample = if (bvp.plateAppearances < 8) " • small sample" else ""
    return "BvP: ${bvp.hits}-for-${bvp.atBats} ($avg) • ${bvp.homeRuns} HR • $ops OPS$sample"
}

private fun bvpColor(bvp: BatterVsPitcherStats): Color = when {
    bvp.plateAppearances < 5 -> AppMuted
    bvp.homeRuns >= 2 || (bvp.ops ?: 0.0) >= .950 -> AppGreen
    (bvp.ops ?: 0.0) < .600 && bvp.plateAppearances >= 8 -> AppAmber
    else -> Color(0xFFD3E0EA)
}

@Composable
private fun TargetsScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val board = state.board
    val targets = viewModel.topTargets(15, state)

    Column(
        Modifier
            .fillMaxSize()
            .padding(padding)
            .background(Color.Transparent)
    ) {
        DateControls(state, viewModel)
        SimpleFilters(state, viewModel)
        LoadState(state, viewModel)

        if (board == null && state.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AppPrimary)
            }
        } else if (!state.isLoading && board != null && targets.isEmpty()) {
            EmptyState("No eligible hitters are available for the current filters.")
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    ScreenIntro(
                        eyebrow = "DAILY TARGET BOARD",
                        title = "Top 15 HR targets",
                        subtitle = "The strongest power profiles on the slate, filtered through matchup, pressure, environment and BvP context."
                    )
                }

                item {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(22.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(AppPrimary.copy(alpha = 0.16f), AppViolet.copy(alpha = 0.11f), AppSurface)
                                )
                            )
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = AppPrimary.copy(alpha = 0.14f),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, AppPrimary.copy(alpha = 0.28f))
                                ) {
                                    Text("10", modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp), color = AppPrimary, fontWeight = FontWeight.Black)
                                }
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text("Power Profile", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                                    Text("Ten must-have HR signals", color = AppMuted, style = MaterialTheme.typography.labelMedium)
                                }
                            }
                            Text(
                                "Barrel • Pull Barrel • Pull Air • Hard Hit • Distance • EV • ISO • Fly Ball • Pull • Blast",
                                color = AppSubtleText,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(top = 11.dp)
                            )
                        }
                    }
                }

                item {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(AppViolet.copy(alpha = 0.09f))
                            .border(1.dp, AppViolet.copy(alpha = 0.24f), RoundedCornerShape(20.dp))
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text("KASPER-INSPIRED LENS", color = AppViolet, fontWeight = FontWeight.Black, letterSpacing = 0.8.sp, style = MaterialTheme.typography.labelLarge)
                            Text(
                                "Hitter-first form • barrel/hard-hit/air quality • recent swing-and-miss • pitcher resistance • platoon edge • lineup barrel depth.",
                                color = AppSubtleText,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(top = 5.dp)
                            )
                            Text(
                                "This is our transparent interpretation of public Kasper breakdown themes — not his proprietary KHR formula or an official Kasper product.",
                                color = AppMuted,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(top = 5.dp)
                            )
                        }
                    }
                }

                items(targets, key = { "target-${it.game.gamePk}-${it.player.id}" }) { candidate ->
                    val rank = targets.indexOf(candidate) + 1
                    val metrics = viewModel.mustHaveMetrics(candidate)
                    TargetCard(
                        rank = rank,
                        candidate = candidate,
                        targetScore = viewModel.targetScore(candidate),
                        powerProfileScore = viewModel.mustHavePowerScore(candidate),
                        kasperScore = viewModel.kasperLensScore(candidate),
                        kasperTier = viewModel.kasperTier(candidate),
                        kasperReasons = viewModel.kasperReasons(candidate),
                        whiffRate = viewModel.recentWhiffRate(candidate),
                        swingSample = candidate.recentPlateDiscipline.swings,
                        metrics = metrics,
                        tracked = state.tracked.any { it.playerId == candidate.player.id && it.date == state.selectedDate },
                        onOpen = { viewModel.selectPlayer(candidate.player.id) },
                        onTrack = { viewModel.toggleTracked(candidate) }
                    )
                }

                item {
                    Text(
                        "Power metrics use recent MLB tracked batted balls plus season ISO. Pull-based rates use MLB hit locations/spray coordinates (description fallback), and Blast% is a 105+ mph / 15–35° proxy. Small samples are automatically blended toward season power.",
                        style = MaterialTheme.typography.labelSmall,
                        color = AppMuted,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun TargetCard(
    rank: Int,
    candidate: HitterCandidate,
    targetScore: Double,
    powerProfileScore: Double,
    kasperScore: Double,
    kasperTier: String,
    kasperReasons: List<String>,
    whiffRate: Double?,
    swingSample: Int,
    metrics: MustHaveMetrics,
    tracked: Boolean,
    onOpen: () -> Unit,
    onTrack: () -> Unit
) {
    val target = targetScore.roundToInt()
    val profile = powerProfileScore.roundToInt()
    val kasper = kasperScore.roundToInt()
    val signals = powerMetricSignals(metrics).take(3)

    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        colors = CardDefaults.cardColors(containerColor = AppSurface.copy(alpha = 0.98f)),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(
            1.dp,
            if (rank <= 3) scoreColor(target).copy(alpha = 0.48f) else AppOutline.copy(alpha = 0.85f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (rank <= 3) 4.dp else 2.dp)
    ) {
        Column(Modifier.padding(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    color = scoreColor(target).copy(alpha = 0.13f),
                    border = BorderStroke(1.dp, scoreColor(target).copy(alpha = 0.35f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(target.toString(), fontWeight = FontWeight.Black, color = scoreColor(target))
                            Text("TARGET", style = MaterialTheme.typography.labelSmall, color = AppMuted)
                        }
                    }
                }

                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TeamLogo(candidate.team, size = 23.dp)
                        Spacer(Modifier.width(7.dp))
                        Text(
                            "#$rank  ${candidate.player.name}",
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        if (rank <= 3) {
                            Surface(color = AppViolet.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp)) {
                                Text("ELITE", modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp), color = AppViolet, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                    Text(
                        "${candidate.team.abbreviation} • Batting #${candidate.battingOrder} • vs ${candidate.opponentPitcher?.person?.name ?: "TBD"}",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onTrack) {
                    Icon(
                        if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder,
                        contentDescription = "Track",
                        tint = if (tracked) AppAmber else AppMuted
                    )
                }
            }

            Spacer(Modifier.height(7.dp))
            Text(
                targetReason(candidate, profile),
                color = Color(0xFFD3E0EA),
                style = MaterialTheme.typography.bodySmall
            )

            Row(
                modifier = Modifier.padding(top = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Surface(color = AppViolet.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp), border = BorderStroke(1.dp, AppViolet.copy(alpha = 0.28f))) {
                    Text("KASPER $kasper • $kasperTier", modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp), color = AppViolet, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
                }
                if (whiffRate != null && swingSample >= 6) {
                    Text("Whiff ${"%.1f".format(whiffRate * 100)}% ($swingSample swings)", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                }
            }
            if (kasperReasons.isNotEmpty()) {
                Text(
                    kasperReasons.joinToString("  •  "),
                    color = AppSubtleText,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 5.dp)
                )
            }

            Spacer(Modifier.height(7.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                MiniScorePill("POWER", profile, Modifier.weight(1f))
                MiniScorePill("PRESSURE", candidate.score.powerPressure.roundToInt(), Modifier.weight(1f))
                MiniScorePill("MATCHUP", candidate.score.pitcherMatchup.roundToInt(), Modifier.weight(1f))
            }

            if (signals.isNotEmpty()) {
                Text(
                    signals.joinToString("  •  ") { "${it.label} ${it.display}" },
                    color = AppPrimary,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            val sampleText = buildString {
                append("${metrics.battedBallCount} recent tracked BBE")
                if (metrics.directionalBattedBallCount > 0) append(" • ${metrics.directionalBattedBallCount} directional")
                append(" • ${(metrics.confidence * 100).roundToInt()}% profile confidence")
            }
            Text(sampleText, color = AppMuted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 4.dp))

            candidate.vsPitcherStats?.let { bvp ->
                if (bvp.plateAppearances >= 5) {
                    Text(
                        bvpSummary(bvp),
                        color = bvpColor(bvp),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun MiniScorePill(label: String, score: Int, modifier: Modifier = Modifier) {
    val color = scoreColor(score)
    Surface(
        modifier = modifier,
        color = color.copy(alpha = 0.10f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.24f))
    ) {
        Column(Modifier.padding(horizontal = 7.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(score.toString(), color = color, fontWeight = FontWeight.Black)
            Text(label, color = AppMuted, style = MaterialTheme.typography.labelSmall, maxLines = 1)
        }
    }
}

private fun targetReason(candidate: HitterCandidate, powerProfile: Int): String {
    val pressure = candidate.score.powerPressure.roundToInt()
    val matchup = candidate.score.pitcherMatchup.roundToInt()
    val bvp = candidate.vsPitcherStats
    return when {
        powerProfile >= 75 && pressure >= 70 && matchup >= 70 ->
            "Complete HR profile: must-have power metrics are strong and both Pressure + Matchup clear 70."
        powerProfile >= 78 && matchup >= 68 ->
            "Power-profile standout ($powerProfile) with a supportive pitcher matchup ($matchup)."
        powerProfile >= 75 ->
            "Must-have power profile is carrying the case ($powerProfile), with Pressure $pressure and Matchup $matchup."
        pressure >= 75 && matchup >= 75 ->
            "Pressure + Matchup is the hook ($pressure / $matchup), backed by a playable power profile ($powerProfile)."
        bvp != null && bvp.plateAppearances >= 8 && ((bvp.ops ?: 0.0) >= .900 || bvp.homeRuns >= 2) ->
            "Good current profile plus a meaningful BvP edge: ${bvp.hits}-for-${bvp.atBats}, ${bvp.homeRuns} HR."
        else ->
            "Balanced daily target: Power $powerProfile • Pressure $pressure • Matchup $matchup."
    }
}

private fun powerMetricSignals(metrics: MustHaveMetrics): List<PowerMetricSignal> = buildList {
    fun quality(value: Double, low: Double, high: Double): Double =
        if (high <= low) 50.0 else (((value - low) / (high - low)) * 100.0).coerceIn(0.0, 100.0)

    metrics.barrelPct?.let { add(PowerMetricSignal("Barrel", "${"%.1f".format(it)}%", quality(it, 4.0, 20.0))) }
    metrics.pullBarrelPct?.let { add(PowerMetricSignal("PullBrl", "${"%.1f".format(it)}%", quality(it, 1.0, 10.0))) }
    metrics.pullAirPct?.let { add(PowerMetricSignal("PullAir", "${"%.1f".format(it)}%", quality(it, 6.0, 28.0))) }
    metrics.hardHitPct?.let { add(PowerMetricSignal("HH", "${"%.1f".format(it)}%", quality(it, 28.0, 62.0))) }
    metrics.avgDistanceFt?.let { add(PowerMetricSignal("Dist", "${it.roundToInt()} ft", quality(it, 145.0, 285.0))) }
    metrics.avgExitVelocity?.let { add(PowerMetricSignal("EV", "${"%.1f".format(it)}", quality(it, 84.0, 95.0))) }
    metrics.iso?.let { add(PowerMetricSignal("ISO", String.format("%.3f", it).removePrefix("0"), quality(it, .110, .300))) }
    metrics.flyBallPct?.let { add(PowerMetricSignal("FB", "${"%.1f".format(it)}%", quality(it, 22.0, 48.0))) }
    metrics.pullPct?.let { add(PowerMetricSignal("Pull", "${"%.1f".format(it)}%", quality(it, 28.0, 52.0))) }
    metrics.blastPct?.let { add(PowerMetricSignal("Blast", "${"%.1f".format(it)}%", quality(it, 1.5, 12.0))) }
}.sortedByDescending { it.quality }

@Composable
private fun ParlaysScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    var legCount by remember { mutableIntStateOf(2) }
    var variant by remember { mutableIntStateOf(0) }
    val parlay = remember(
        state.board?.lastUpdated,
        state.selectedDate,
        state.showRemainingOnly,
        state.officialLineupsOnly,
        legCount,
        variant
    ) {
        viewModel.generateParlay(legCount, variant, state)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding).background(Color.Transparent),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ScreenIntro(
                eyebrow = "BUILD A CARD",
                title = "Parlay generator",
                subtitle = "Quality-first combinations built from the day's strongest target profiles."
            )
        }

        item {
            DateControls(state, viewModel)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AppSurface.copy(alpha = 0.98f)),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, AppOutline.copy(alpha = 0.85f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("PARLAY SIZE", color = AppMuted, fontWeight = FontWeight.Black, letterSpacing = 0.7.sp, style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        (1..5).forEach { legs ->
                            FilterChip(
                                selected = legCount == legs,
                                onClick = { legCount = legs; variant = 0 },
                                label = { Text(legs.toString(), fontWeight = FontWeight.Bold) },
                                modifier = Modifier.weight(1f),
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = AppSurfaceRaised,
                                    selectedContainerColor = AppPrimary.copy(alpha = 0.18f),
                                    selectedLabelColor = AppPrimary
                                )
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { variant += 1 },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(15.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AppPrimary, contentColor = Color(0xFF04131D))
                    ) {
                        Icon(Icons.Outlined.Casino, null)
                        Spacer(Modifier.width(7.dp))
                        Text(if (legCount == 1) "NEXT STRAIGHT PICK" else "GENERATE ${legCount}-LEG", fontWeight = FontWeight.Black, letterSpacing = 0.4.sp)
                    }
                }
            }
        }

        if (state.isLoading) {
            item { LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = AppPrimary, trackColor = AppSurfaceRaised) }
        }

        if (!state.isLoading && parlay.isEmpty()) {
            item { EmptyCard("Not enough eligible hitters yet. Try again after lineups post.") }
        } else {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = AppSurface),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, AppPrimary.copy(alpha = 0.35f))
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(if (legCount == 1) "Straight HR pick" else "Suggested ${legCount}-leg HR parlay", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                                if (legCount == 1) {
                                    val straightCount = viewModel.straightCandidates(state).size.coerceAtLeast(1)
                                    Text("Ranked option ${(variant % straightCount) + 1} of $straightCount", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                                } else {
                                    Text("Model-generated • option ${variant + 1}", color = AppMuted, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            Surface(color = AppGreen.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp)) {
                                Text("QUALITY FIRST", modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = AppGreen, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        Spacer(Modifier.height(10.dp))
                        parlay.forEachIndexed { index, candidate ->
                            if (index > 0) HorizontalDivider(color = AppOutline, modifier = Modifier.padding(vertical = 7.dp))
                            ParlayLegRow(index + 1, candidate, viewModel.parlayScore(candidate)) {
                                viewModel.selectPlayer(candidate.player.id)
                            }
                        }
                    }
                }
            }

            if (legCount > 1) {
                item {
                    SectionCard("Why these players were paired") {
                        Text("• The generator starts from the Top Target score, so the must-have power metrics now influence every leg.", color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall)
                        Text("• It prefers different games and teams before repeating one, reducing unnecessary correlation.", color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 5.dp))
                        Text("• Generate another rotates the anchor and nearby top options instead of recycling the same slip.", color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 5.dp))
                    }
                }
            }
        }

        item {
            Text(
                "Longer HR parlays are increasingly unlikely even with strong individual picks. The generator ranks combinations; it does not predict a guaranteed outcome.",
                style = MaterialTheme.typography.labelSmall,
                color = AppMuted
            )
        }
    }
}

@Composable
private fun ParlayLegRow(number: Int, candidate: HitterCandidate, score: Double, onOpen: () -> Unit) {
    val scoreInt = score.roundToInt()
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(vertical = 3.dp),
        verticalAlignment = Alignment.Top
    ) {
        Surface(
            modifier = Modifier.size(38.dp),
            color = scoreColor(scoreInt).copy(alpha = 0.13f),
            shape = CircleShape,
            border = BorderStroke(1.dp, scoreColor(scoreInt).copy(alpha = 0.35f))
        ) {
            Box(contentAlignment = Alignment.Center) { Text(number.toString(), fontWeight = FontWeight.Black, color = scoreColor(scoreInt)) }
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TeamLogo(candidate.team, size = 21.dp)
                Spacer(Modifier.width(7.dp))
                Text(
                    candidate.player.name,
                    fontWeight = FontWeight.Black,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Text(scoreInt.toString(), fontWeight = FontWeight.Black, color = scoreColor(scoreInt))
            }
            Text(
                "${candidate.team.abbreviation} vs ${candidate.opponent.abbreviation} • ${candidate.game.gameDate.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("h:mm a"))}",
                style = MaterialTheme.typography.labelMedium,
                color = AppMuted
            )
            Text(quickJustification(candidate), color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 3.dp))
        }
    }
}

@Composable
private fun DateControls(state: AppUiState, viewModel: MainViewModel) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 5.dp),
        color = Color(0xFF0E1B2C).copy(alpha = 0.98f),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, AppOutline.copy(alpha = 0.9f)),
        shadowElevation = 3.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Surface(
                modifier = Modifier.size(38.dp).clickable { viewModel.changeDate(-1) },
                color = AppSurfaceRaised,
                shape = CircleShape
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.ChevronLeft, "Previous", tint = AppSubtleText)
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    state.selectedDate.format(DateTimeFormatter.ofPattern("EEE, MMM d")),
                    fontWeight = FontWeight.Black,
                    color = AppText,
                    style = MaterialTheme.typography.titleMedium
                )
                state.board?.let {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = AppPrimary.copy(alpha = 0.11f), shape = RoundedCornerShape(50.dp)) {
                            Text(
                                "${it.games.size} GAMES",
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = AppPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
            Surface(
                modifier = Modifier.size(38.dp).clickable { viewModel.changeDate(1) },
                color = AppSurfaceRaised,
                shape = CircleShape
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.ChevronRight, "Next", tint = AppSubtleText)
                }
            }
        }
    }
}

@Composable
private fun SimpleFilters(state: AppUiState, viewModel: MainViewModel) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 3.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FilterChip(
            selected = state.showRemainingOnly,
            onClick = { viewModel.toggleRemainingOnly() },
            label = { Text("Remaining", fontWeight = FontWeight.SemiBold) },
            shape = RoundedCornerShape(50.dp),
            colors = simpleChipColors()
        )
        FilterChip(
            selected = state.officialLineupsOnly,
            onClick = { viewModel.toggleOfficialOnly() },
            label = { Text("Official lineups", fontWeight = FontWeight.SemiBold) },
            shape = RoundedCornerShape(50.dp),
            colors = simpleChipColors()
        )
    }
}

@Composable
private fun simpleChipColors() = FilterChipDefaults.filterChipColors(
    containerColor = AppSurface,
    labelColor = AppMuted,
    selectedContainerColor = AppPrimary.copy(alpha = 0.15f),
    selectedLabelColor = AppPrimary
)

@Composable
private fun LoadState(state: AppUiState, viewModel: MainViewModel) {
    if (state.isLoading) {
        Column {
            LinearProgressIndicator(Modifier.fillMaxWidth(), color = AppPrimary, trackColor = AppSurfaceRaised)
            Text(state.progress, Modifier.padding(horizontal = 15.dp, vertical = 5.dp), color = AppMuted, style = MaterialTheme.typography.labelSmall)
        }
    }
    state.error?.let { error ->
        Card(
            modifier = Modifier.padding(12.dp).fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = AppRed.copy(alpha = 0.11f)),
            border = BorderStroke(1.dp, AppRed.copy(alpha = 0.32f))
        ) {
            Column(Modifier.padding(12.dp)) {
                Text("Could not load MLB data", color = AppRed, fontWeight = FontWeight.Black)
                Text(error, color = AppMuted, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(7.dp))
                Button(onClick = { viewModel.refresh() }) { Text("Retry") }
            }
        }
    }
}

@Composable
private fun EmptyState(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = AppMuted, modifier = Modifier.padding(24.dp))
    }
}

@Composable
private fun EmptyCard(text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = AppSurface), border = BorderStroke(1.dp, AppOutline)) {
        Text(text, modifier = Modifier.padding(14.dp), color = AppMuted)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlayerDetailScreen(
    candidate: HitterCandidate,
    pickScore: Double,
    kasperScore: Double,
    kasperTier: String,
    kasperReasons: List<String>,
    swingMissScore: Double,
    teamDepthScore: Double,
    tracked: Boolean,
    onBack: () -> Unit,
    onTrack: () -> Unit
) {
    val model = remember { HrScoringModel() }
    val score = pickScore.roundToInt()
    val mustHave = remember(candidate.player.id, candidate.recentBattedBalls, candidate.seasonStats) {
        model.mustHaveMetrics(candidate.player, candidate.seasonStats, candidate.recentBattedBalls)
    }

    Scaffold(
        containerColor = AppBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AppBackground),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TeamLogo(candidate.team, size = 26.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(candidate.player.name, fontWeight = FontWeight.Black)
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } },
                actions = {
                    IconButton(onClick = onTrack) {
                        Icon(if (tracked) Icons.Default.Star else Icons.Outlined.StarBorder, "Track", tint = if (tracked) AppAmber else AppMuted)
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = AppSurface),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, AppOutline)
                ) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            modifier = Modifier.size(72.dp),
                            color = scoreColor(score).copy(alpha = 0.14f),
                            shape = CircleShape,
                            border = BorderStroke(2.dp, scoreColor(score).copy(alpha = 0.40f))
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(score.toString(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = scoreColor(score))
                                    Text("PICK", style = MaterialTheme.typography.labelSmall, color = AppMuted)
                                }
                            }
                        }
                        Spacer(Modifier.width(13.dp))
                        Column {
                            Text("Why we like it", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                            Text(quickJustification(candidate), color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall)
                            Text("${candidate.team.abbreviation} • Batting #${candidate.battingOrder}", color = AppMuted, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }

            item {
                SectionCard("Kasper-inspired lens") {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = AppViolet.copy(alpha = 0.13f),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, AppViolet.copy(alpha = 0.30f))
                        ) {
                            Column(Modifier.padding(horizontal = 14.dp, vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(kasperScore.roundToInt().toString(), color = AppViolet, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                                Text(kasperTier, color = AppViolet, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Hitter-first convergence check", fontWeight = FontWeight.Black)
                            Text(
                                if (kasperReasons.isEmpty()) "No single public-Kasper signal dominates this matchup." else kasperReasons.joinToString(" • "),
                                color = AppSubtleText,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    ScoreBar("Recent form / pressure", candidate.score.powerPressure)
                    ScoreBar("Swing & miss", swingMissScore)
                    ScoreBar("Pitcher resistance", candidate.score.pitcherMatchup)
                    ScoreBar("Lineup barrel depth", teamDepthScore)
                    val whiff = candidate.recentPlateDiscipline.whiffRate
                    Text(
                        if (whiff != null) "Recent whiff: ${"%.1f".format(whiff * 100)}% across ${candidate.recentPlateDiscipline.swings} swings / ${candidate.recentPlateDiscipline.totalPitches} pitches." else "Recent pitch-level swing/whiff sample unavailable; season contact is used as the fallback.",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                    Text(
                        "Inspired by themes repeatedly discussed in Kasper's public MLB breakdowns. It is not his proprietary KHR formula and is not affiliated or endorsed.",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            item {
                SectionCard("Four key signals") {
                    ScoreBar("Power Pressure", candidate.score.powerPressure)
                    ScoreBar("Pitcher matchup", candidate.score.pitcherMatchup)
                    ScoreBar("Handedness split", candidate.score.platoon)
                    ScoreBar("Recent contact", candidate.score.recentPower)
                }
            }

            item {
                SectionCard("Must-have power metrics") {
                    Text(
                        "Power profile ${mustHave.score.roundToInt()} • ${mustHave.battedBallCount} recent tracked BBE",
                        color = scoreColor(mustHave.score.roundToInt()),
                        fontWeight = FontWeight.Black
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatCell("Barrel%", mustHave.barrelPct?.let { "%.1f%%".format(it) } ?: "—")
                        StatCell("HH%", mustHave.hardHitPct?.let { "%.1f%%".format(it) } ?: "—")
                        StatCell("EV", mustHave.avgExitVelocity?.let { "%.1f".format(it) } ?: "—")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatCell("ISO", mustHave.iso?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                        StatCell("FB%", mustHave.flyBallPct?.let { "%.1f%%".format(it) } ?: "—")
                        StatCell("Avg Dist", mustHave.avgDistanceFt?.let { "${it.roundToInt()} ft" } ?: "—")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatCell("Pull%", mustHave.pullPct?.let { "%.1f%%".format(it) } ?: "N/A")
                        StatCell("PullBrl%", mustHave.pullBarrelPct?.let { "%.1f%%".format(it) } ?: "N/A")
                        StatCell("PullAir%", mustHave.pullAirPct?.let { "%.1f%%".format(it) } ?: "N/A")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatCell("Blast%", mustHave.blastPct?.let { "%.1f%%".format(it) } ?: "—")
                        StatCell("Profile", mustHave.score.roundToInt().toString())
                        StatCell("Conf.", "${(mustHave.confidence * 100).roundToInt()}%")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatCell("Sweet Spot%", mustHave.sweetSpotPct?.let { "%.1f%%".format(it) } ?: "—")
                        StatCell("Max EV", mustHave.maxExitVelocity?.let { "%.1f".format(it) } ?: "—")
                        StatCell("K%", if (candidate.seasonStats.plateAppearances > 0) "%.1f%%".format(candidate.seasonStats.strikeouts * 100.0 / candidate.seasonStats.plateAppearances) else "—")
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Directional coverage: ${mustHave.directionalBattedBallCount}/${mustHave.battedBallCount} recent tracked BBE",
                        color = if (mustHave.directionalBattedBallCount > 0) AppSubtleText else AppAmber,
                        style = MaterialTheme.typography.labelSmall
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Pull metrics use MLB hit locations/spray coordinates with a description fallback. Blast% is our 105+ mph / 15–35° proxy. Small recent samples are down-weighted in the daily Target Score.",
                        color = AppMuted,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            item {
                SectionCard("Opposing pitcher") {
                    val pitcher = candidate.opponentPitcher
                    if (pitcher == null) {
                        Text("Pitcher data not available yet.", color = AppMuted)
                    } else {
                        Text(pitcher.person.name, fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(7.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("ERA", pitcher.seasonStats.era?.let { "%.2f".format(it) } ?: "—")
                            StatCell("HR/9", pitcher.seasonStats.hrPer9?.let { "%.2f".format(it) } ?: "—")
                            StatCell("WHIP", pitcher.seasonStats.whip?.let { "%.2f".format(it) } ?: "—")
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("K%", pitcher.seasonStats.strikeoutRate?.let { "%.1f%%".format(it * 100.0) } ?: "—")
                            StatCell("BB%", pitcher.seasonStats.walkRate?.let { "%.1f%%".format(it * 100.0) } ?: "—")
                            StatCell("BF", pitcher.seasonStats.battersFaced.takeIf { it > 0 }?.toString() ?: "—")
                        }
                    }
                }
            }

            item {
                SectionCard("Season split vs pitcher hand") {
                    val split = candidate.platoonStats
                    val hand = candidate.opponentPitcher?.person?.pitchHand
                    if (split == null || hand == null) {
                        Text("Handedness split data is not available for this matchup.", color = AppMuted, style = MaterialTheme.typography.bodySmall)
                    } else {
                        Text("vs ${hand}HP • ${split.plateAppearances} PA", fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("HR", split.homeRuns.toString())
                            StatCell("ISO", split.iso?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("SLG", split.slg?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("OPS", split.ops?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("AVG", split.avg?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("K%", split.strikeoutRate?.let { "%.1f%%".format(it * 100.0) } ?: "—")
                            StatCell("HR/PA", split.hrPerPa?.let { "%.1f%%".format(it * 100.0) } ?: "—")
                        }
                    }
                }
            }

            item {
                SectionCard("Career vs this pitcher") {
                    val bvp = candidate.vsPitcherStats
                    val pitcherName = candidate.opponentPitcher?.person?.name ?: "today's pitcher"
                    if (bvp == null) {
                        Text("No MLB batter-vs-pitcher history found for $pitcherName, or this matchup was outside the pregame BvP lookup pool.", color = AppMuted, style = MaterialTheme.typography.bodySmall)
                    } else {
                        Text("vs $pitcherName", fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("AB", bvp.atBats.toString())
                            StatCell("H", bvp.hits.toString())
                            StatCell("HR", bvp.homeRuns.toString())
                            StatCell("K", bvp.strikeouts.toString())
                        }
                        Spacer(Modifier.height(9.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            StatCell("AVG", bvp.avg?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("OBP", bvp.obp?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("SLG", bvp.slg?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                            StatCell("OPS", bvp.ops?.let { String.format("%.3f", it).removePrefix("0") } ?: "—")
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (bvp.plateAppearances < 8) "Only ${bvp.plateAppearances} PA — useful context, but too small a sample to drive the pick by itself."
                            else "${bvp.plateAppearances} career PA. BvP receives a capped, sample-size-weighted boost in the Pick/Parlay score.",
                            color = AppMuted,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }

            item {
                SectionCard("Justification") {
                    candidate.score.notes.take(5).forEach { note ->
                        Text("• $note", color = Color(0xFFD3E0EA), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 5.dp))
                    }
                }
            }

            if (candidate.recentBattedBalls.isNotEmpty()) {
                item { Text("Recent contact", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black) }
                items(candidate.recentBattedBalls.sortedByDescending { it.gameDate }.take(12)) { ball -> BattedBallRow(ball, model) }
            }
        }
    }
}

@Composable
private fun ScoreBar(label: String, value: Double) {
    val intValue = value.roundToInt()
    Column(Modifier.padding(top = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color(0xFFD3E0EA))
            Text(intValue.toString(), color = scoreColor(intValue), fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { (value / 100.0).toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(5.dp),
            color = scoreColor(intValue),
            trackColor = AppSurfaceRaised
        )
    }
}

@Composable
private fun BattedBallRow(ball: BattedBall, model: HrScoringModel) {
    val signal = when {
        ball.isHomeRun -> "HR"
        model.isEliteNearHomeRun(ball) -> "NEAR-HR+"
        model.isNearHomeRun(ball) -> "NEAR-HR"
        model.isBarrelProxy(ball) -> "BARREL"
        model.isHardHit(ball) -> "HARD HIT"
        else -> "CONTACT"
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, AppOutline)
    ) {
        Row(Modifier.fillMaxWidth().padding(11.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(signal, fontWeight = FontWeight.Black, color = if (signal == "HR") AppGreen else AppPrimary)
                Text(ball.gameDate.toString(), color = AppMuted, style = MaterialTheme.typography.labelSmall)
            }
            Text(
                "${ball.exitVelocity?.let { "%.1f mph".format(it) } ?: "—"} • ${ball.launchAngle?.let { "%.0f°".format(it) } ?: "—"} • ${ball.distanceFt?.let { "%.0f ft".format(it) } ?: "—"}",
                color = Color(0xFFD3E0EA),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun TrackedScreen(state: AppUiState, viewModel: MainViewModel, padding: PaddingValues) {
    val model = remember { HrScoringModel() }
    val tracked = state.tracked.filter { it.date == state.selectedDate }
    val byId = state.board?.candidates?.associateBy { it.player.id }.orEmpty()

    Column(Modifier.fillMaxSize().padding(padding).background(Color.Transparent)) {
        DateControls(state, viewModel)
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ScreenIntro(
                eyebrow = "YOUR WATCHLIST",
                title = "Tracked picks",
                subtitle = "Review the quality of the read, not only HR or no HR.",
                modifier = Modifier.weight(1f)
            )
            if (tracked.isNotEmpty()) {
                Spacer(Modifier.width(10.dp))
                TextButton(onClick = { viewModel.clearTrackedForSelectedDate() }) {
                    Text("CLEAR", color = AppRed, fontWeight = FontWeight.Black)
                }
            }
        }

        if (tracked.isEmpty()) {
            EmptyState("Star hitters from the Games tab to track them here.")
        } else {
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(tracked, key = { "${it.date}-${it.playerId}" }) { pick ->
                    val c = byId[pick.playerId]
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable(enabled = c != null) { c?.let { viewModel.selectPlayer(it.player.id) } },
                        colors = CardDefaults.cardColors(containerColor = AppSurface),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, AppOutline)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                c?.let { TeamLogo(it.team, size = 22.dp) }
                                if (c != null) Spacer(Modifier.width(7.dp))
                                Text(pick.playerName, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                            }
                            Text("Tracked at ${pick.scoreAtTrack.roundToInt()} Chase Score", style = MaterialTheme.typography.bodySmall, color = AppMuted)
                            Spacer(Modifier.height(7.dp))
                            if (c == null) {
                                Text("Load this date's board to evaluate contact.", color = AppMuted, style = MaterialTheme.typography.bodySmall)
                            } else {
                                val balls = c.todayBattedBalls
                                val hrs = balls.count { it.isHomeRun }
                                val hardest = balls.mapNotNull { it.exitVelocity }.maxOrNull()
                                val grade = when {
                                    hrs > 0 -> "HR HIT"
                                    balls.any { model.isEliteNearHomeRun(it) } -> "STRONG READ • ELITE NEAR-HR"
                                    balls.any { model.isNearHomeRun(it) } -> "GOOD READ • NEAR-HR"
                                    balls.any { model.isBarrelProxy(it) } -> "BARREL CONTACT • NO HR"
                                    balls.any { model.isHardHit(it) } -> "HARD CONTACT • NO HR"
                                    c.game.status.equals("Final", true) -> "QUIET CONTACT / MISS"
                                    else -> "GAME PENDING / IN PROGRESS"
                                }
                                SignalPill(grade)
                                Text("$hrs HR • ${balls.size} tracked balls • max EV ${hardest?.let { "%.1f".format(it) } ?: "—"}", style = MaterialTheme.typography.bodySmall, color = AppMuted, modifier = Modifier.padding(top = 6.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SignalPill(text: String) {
    val color = when {
        "HR HIT" in text -> AppGreen
        "STRONG" in text || "GOOD" in text -> AppPrimary
        "BARREL" in text || "HARD" in text -> AppAmber
        else -> AppMuted
    }
    Surface(color = color.copy(alpha = 0.12f), shape = RoundedCornerShape(50.dp)) {
        Text(text, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = color, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun ScreenIntro(
    eyebrow: String,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Column(modifier.padding(horizontal = 2.dp, vertical = 4.dp)) {
        Text(
            eyebrow,
            color = AppPrimary,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.0.sp,
            style = MaterialTheme.typography.labelSmall
        )
        Text(
            title,
            color = AppText,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Black,
            modifier = Modifier.padding(top = 3.dp)
        )
        Text(
            subtitle,
            color = AppMuted,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 3.dp)
        )
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = AppSurface.copy(alpha = 0.98f)),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, AppOutline.copy(alpha = 0.85f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title.uppercase(), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black, color = AppSubtleText, letterSpacing = 0.7.sp)
            Spacer(Modifier.height(7.dp))
            content()
        }
    }
}

@Composable
private fun StatCell(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
        Text(label, color = AppMuted, style = MaterialTheme.typography.labelSmall)
    }
}

private fun scoreColor(score: Int): Color = when {
    score >= 80 -> AppGreen
    score >= 68 -> AppPrimary
    score >= 55 -> AppAmber
    else -> AppMuted
}
