package com.ckz.hrchase.model

import com.ckz.hrchase.data.BattedBall
import com.ckz.hrchase.data.GameInfo
import com.ckz.hrchase.data.HittingStats
import com.ckz.hrchase.data.HittingSplitStats
import com.ckz.hrchase.data.MustHaveMetrics
import com.ckz.hrchase.data.PersonRef
import com.ckz.hrchase.data.PitcherProfile
import com.ckz.hrchase.data.ScoreBreakdown
import com.ckz.hrchase.data.ScoreWeights
import kotlin.math.max
import kotlin.math.min

class HrScoringModel {
    fun score(
        player: PersonRef,
        battingOrder: Int,
        lineupOfficial: Boolean,
        seasonStats: HittingStats,
        platoonStats: HittingSplitStats? = null,
        recentBattedBalls: List<BattedBall>,
        opponentPitcher: PitcherProfile?,
        game: GameInfo,
        weights: ScoreWeights
    ): ScoreBreakdown {
        val recentPower = recentPowerScore(recentBattedBalls)
        val pressure = powerPressureScore(recentBattedBalls)
        val platoon = platoonSplitScore(platoonStats)
        val baseMatchup = pitcherMatchupScore(player, opponentPitcher)
        val matchup = weighted(baseMatchup to .82, platoon to .18)
        val environment = environmentScore(game)
        val seasonPower = seasonPowerScore(seasonStats)
        val lineup = lineupScore(battingOrder, lineupOfficial)

        val safeTotal = weights.total.takeIf { it > 0f } ?: 100f
        val total = (
            recentPower * weights.recentPower +
                pressure * weights.powerPressure +
                matchup * weights.pitcherMatchup +
                environment * weights.environment +
                seasonPower * weights.seasonPower +
                lineup * weights.lineup
            ) / safeTotal

        val tags = buildTags(recentBattedBalls, pressure, recentPower, matchup, environment, lineupOfficial)
        val notes = buildNotes(player, recentBattedBalls, opponentPitcher, game, battingOrder, lineupOfficial)

        return ScoreBreakdown(
            recentPower = recentPower,
            powerPressure = pressure,
            pitcherMatchup = matchup,
            environment = environment,
            seasonPower = seasonPower,
            lineup = lineup,
            total = total.coerceIn(0.0, 100.0),
            tags = tags,
            notes = notes,
            platoon = platoon
        )
    }

    fun isHardHit(ball: BattedBall): Boolean = (ball.exitVelocity ?: 0.0) >= 95.0

    fun isBarrelProxy(ball: BattedBall): Boolean {
        val ev = ball.exitVelocity ?: return false
        val la = ball.launchAngle ?: return false
        if (ev < 98.0) return false
        val mphOver = ev - 98.0
        val lower = max(8.0, 26.0 - mphOver * 1.5)
        val upper = min(50.0, 30.0 + mphOver)
        return la in lower..upper
    }

    fun isNearHomeRun(ball: BattedBall): Boolean {
        if (ball.isHomeRun) return false
        val ev = ball.exitVelocity ?: return false
        val la = ball.launchAngle ?: return false
        val dist = ball.distanceFt
        val direct = ev >= 100.0 && la in 20.0..36.0 && (dist == null || dist >= 350.0)
        val barrelish = isBarrelProxy(ball) && (dist == null || dist >= 340.0)
        return direct || barrelish
    }

    fun isEliteNearHomeRun(ball: BattedBall): Boolean {
        if (ball.isHomeRun) return false
        val ev = ball.exitVelocity ?: return false
        val la = ball.launchAngle ?: return false
        val dist = ball.distanceFt ?: 0.0
        return ev >= 105.0 && la in 20.0..35.0 && dist >= 370.0
    }


    /**
     * The "must-have" power profile used by the Top Targets tab.
     *
     * The MLB live feed gives us launch speed, launch angle, distance and trajectory for recent
     * batted balls. Barrel%, HH%, EV, distance and fly-ball rate are derived directly from those
     * tracked contacts. Pull-based metrics are estimated from MLB hit location / spray coordinates plus the
     * hitter's batting side, so they are treated as proxies rather than exact Baseball Savant
     * directional classifications. Blast% is also a transparent proxy: 105+ mph at 15-35 degrees.
     * ISO is season ISO from MLB batting stats.
     */
    fun mustHaveMetrics(
        player: PersonRef,
        seasonStats: HittingStats,
        balls: List<BattedBall>
    ): MustHaveMetrics {
        val tracked = balls.filter { it.exitVelocity != null && it.launchAngle != null }
        val count = tracked.size
        val directional = tracked.filter {
            directionBucket(it) != null && (it.batterSide ?: player.batSide) in setOf("R", "L")
        }
        val pulled = directional.filter { isPulledBall(player, it) }

        fun pct(numerator: Int, denominator: Int): Double? =
            if (denominator > 0) numerator.toDouble() * 100.0 / denominator else null

        val barrelPct = pct(tracked.count(::isBarrelProxy), count)
        val hardHitPct = pct(tracked.count(::isHardHit), count)
        val flyBallPct = pct(tracked.count(::isFlyBall), count)
        val blastPct = pct(tracked.count(::isBlastProxy), count)
        val sweetSpotPct = pct(tracked.count(::isSweetSpot), count)
        val maxEv = tracked.mapNotNull { it.exitVelocity }.maxOrNull()
        val pullPct = pct(pulled.size, directional.size)
        val pullBarrelPct = pct(pulled.count(::isBarrelProxy), count)
        val pullAirPct = pct(pulled.count(::isAirBall), count)
        val avgEv = tracked.mapNotNull { it.exitVelocity }.takeIf { it.isNotEmpty() }?.average()
        val distances = tracked.mapNotNull { it.distanceFt }.filter { it >= 0.0 }
        val avgDistance = distances.takeIf { it.isNotEmpty() }?.average()
        val iso = when {
            seasonStats.slg != null && seasonStats.avg != null ->
                (seasonStats.slg - seasonStats.avg).coerceAtLeast(0.0)
            seasonStats.atBats > 0 ->
                (seasonStats.doubles + 2 * seasonStats.triples + 3 * seasonStats.homeRuns).toDouble() / seasonStats.atBats
            else -> null
        }

        val score = weightedAvailable(
            barrelPct?.let { scale(it, 4.0, 20.0) } to .16,
            pullBarrelPct?.let { scale(it, 1.0, 10.0) } to .10,
            pullAirPct?.let { scale(it, 6.0, 28.0) } to .08,
            hardHitPct?.let { scale(it, 28.0, 62.0) } to .13,
            avgDistance?.let { scale(it, 145.0, 285.0) } to .08,
            avgEv?.let { scale(it, 84.0, 95.0) } to .13,
            iso?.let { scale(it, .110, .300) } to .10,
            flyBallPct?.let { scale(it, 22.0, 48.0) } to .07,
            pullPct?.let { scale(it, 28.0, 52.0) } to .07,
            blastPct?.let { scale(it, 1.5, 12.0) } to .08
        )

        val confidence = when {
            count >= 12 -> 1.0
            count > 0 -> (0.30 + (count / 12.0) * 0.70).coerceIn(0.30, 1.0)
            iso != null -> 0.25
            else -> 0.0
        }

        return MustHaveMetrics(
            barrelPct = barrelPct,
            pullBarrelPct = pullBarrelPct,
            pullAirPct = pullAirPct,
            hardHitPct = hardHitPct,
            avgDistanceFt = avgDistance,
            avgExitVelocity = avgEv,
            iso = iso,
            flyBallPct = flyBallPct,
            pullPct = pullPct,
            blastPct = blastPct,
            sweetSpotPct = sweetSpotPct,
            maxExitVelocity = maxEv,
            battedBallCount = count,
            directionalBattedBallCount = directional.size,
            score = score,
            confidence = confidence
        )
    }

    fun isFlyBall(ball: BattedBall): Boolean {
        val trajectory = ball.trajectory.orEmpty().lowercase()
        if ("fly" in trajectory) return true
        if ("ground" in trajectory || "line" in trajectory) return false
        return (ball.launchAngle ?: return false) >= 25.0
    }

    fun isAirBall(ball: BattedBall): Boolean {
        val trajectory = ball.trajectory.orEmpty().lowercase()
        if ("ground" in trajectory) return false
        if ("fly" in trajectory || "line" in trajectory || "popup" in trajectory || "pop_up" in trajectory) return true
        return (ball.launchAngle ?: return false) >= 10.0
    }

    fun isBlastProxy(ball: BattedBall): Boolean {
        val ev = ball.exitVelocity ?: return false
        val la = ball.launchAngle ?: return false
        return ev >= 105.0 && la in 15.0..35.0
    }

    fun isSweetSpot(ball: BattedBall): Boolean {
        val la = ball.launchAngle ?: return false
        return la in 8.0..32.0
    }

    fun isPulledBall(player: PersonRef, ball: BattedBall): Boolean {
        // Prefer the side actually used in that plate appearance. This correctly handles switch
        // hitters and is more precise than the player's roster-level batting-side designation.
        val side = ball.batterSide ?: player.batSide ?: return false
        val direction = directionBucket(ball) ?: return false
        return when (side) {
            "R" -> direction == "LEFT"
            "L" -> direction == "RIGHT"
            else -> false
        }
    }

    private fun directionBucket(ball: BattedBall): String? {
        // MLB's hitData.location is the most reliable lightweight direction source available in the
        // live feed. It uses standard fielder/location numbers: 7/5/6 are left-side contact,
        // 8/1/2 are middle, and 9/3/4 are right-side contact.
        when (ball.fieldLocation) {
            5, 6, 7 -> return "LEFT"
            1, 2, 8 -> return "CENTER"
            3, 4, 9 -> return "RIGHT"
        }

        // Some plays omit location but still include Gameday spray coordinates. On MLB's field
        // coordinate system, roughly 125 is straightaway center; use broad bands so only clearly
        // directional balls are classified as left/right.
        ball.sprayX?.let { x ->
            if (x < 110.0) return "LEFT"
            if (x > 140.0) return "RIGHT"
            return "CENTER"
        }

        // Final fallback for older/partial feeds.
        val text = ball.description.orEmpty().lowercase()
        if (text.isBlank()) return null
        return when {
            "left field" in text || "left fielder" in text || "third baseman" in text || "shortstop" in text -> "LEFT"
            "right field" in text || "right fielder" in text || "first baseman" in text || "second baseman" in text -> "RIGHT"
            "center field" in text || "center fielder" in text -> "CENTER"
            else -> null
        }
    }

    private fun recentPowerScore(balls: List<BattedBall>): Double {
        val tracked = balls.filter { it.exitVelocity != null && it.launchAngle != null }
        if (tracked.isEmpty()) return 35.0
        val hardHitPct = tracked.count(::isHardHit).toDouble() / tracked.size
        val barrelPct = tracked.count(::isBarrelProxy).toDouble() / tracked.size
        val avgEv = tracked.mapNotNull { it.exitVelocity }.average()
        val maxEv = tracked.mapNotNull { it.exitVelocity }.maxOrNull() ?: 0.0
        val hrRate = tracked.count { it.isHomeRun }.toDouble() / tracked.size

        val hard = scale(hardHitPct, 0.20, 0.60)
        val barrels = scale(barrelPct, 0.02, 0.20)
        val avg = scale(avgEv, 84.0, 95.0)
        val max = scale(maxEv, 98.0, 114.0)
        val hr = scale(hrRate, 0.0, 0.16)
        return weighted(hard to .25, barrels to .25, avg to .20, max to .20, hr to .10)
    }

    private fun powerPressureScore(balls: List<BattedBall>): Double {
        val tracked = balls.filter { it.exitVelocity != null && it.launchAngle != null }
        if (tracked.isEmpty()) return 20.0
        val near = tracked.count(::isNearHomeRun)
        val elite = tracked.count(::isEliteNearHomeRun)
        val unrewardedBarrels = tracked.count { isBarrelProxy(it) && !it.isHomeRun }

        val mostRecentDate = tracked.maxOfOrNull { it.gameDate }
        val recentGameBalls = if (mostRecentDate != null) tracked.filter { it.gameDate == mostRecentDate } else emptyList()
        val recentGameSignal = when {
            recentGameBalls.any(::isEliteNearHomeRun) -> 100.0
            recentGameBalls.any(::isNearHomeRun) -> 85.0
            recentGameBalls.any { isBarrelProxy(it) && !it.isHomeRun } -> 70.0
            recentGameBalls.any(::isHardHit) -> 45.0
            else -> 20.0
        }

        val chronological = tracked.sortedWith(compareBy<BattedBall> { it.gameDate }.thenBy { it.gamePk })
        val lastFive = chronological.takeLast(5).mapNotNull { it.exitVelocity }
        val priorFive = chronological.dropLast(lastFive.size).takeLast(5).mapNotNull { it.exitVelocity }
        val evTrend = if (lastFive.isNotEmpty() && priorFive.isNotEmpty()) lastFive.average() - priorFive.average() else 0.0

        val nearScore = scale(near.toDouble(), 0.0, 2.0)
        val eliteScore = scale(elite.toDouble(), 0.0, 1.0)
        val unrewardedScore = scale(unrewardedBarrels.toDouble(), 0.0, 2.0)
        val trendScore = scale(evTrend, -4.0, 5.0)

        return weighted(
            recentGameSignal to .35,
            nearScore to .25,
            eliteScore to .15,
            unrewardedScore to .15,
            trendScore to .10
        )
    }

    private fun pitcherMatchupScore(player: PersonRef, pitcher: PitcherProfile?): Double {
        if (pitcher == null) return 45.0
        val stats = pitcher.seasonStats
        val recent = pitcher.recentBattedBallsAllowed.filter { it.exitVelocity != null && it.launchAngle != null }

        val hr9 = stats.hrPer9?.let { scale(it, 0.55, 1.85) } ?: 50.0
        val whip = stats.whip?.let { scale(it, 0.95, 1.55) } ?: 50.0
        val contactOpportunity = stats.strikeoutRate?.let { kRate ->
            // High-K pitchers suppress HR opportunities because fewer plate appearances reach contact.
            100.0 - scale(kRate, .16, .32)
        } ?: 50.0
        val recentHard = if (recent.isNotEmpty()) {
            scale(recent.count(::isHardHit).toDouble() / recent.size, .28, .58)
        } else 50.0
        val recentBarrel = if (recent.isNotEmpty()) {
            scale(recent.count(::isBarrelProxy).toDouble() / recent.size, .04, .20)
        } else 50.0
        val recentSweet = if (recent.isNotEmpty()) {
            scale(recent.count(::isSweetSpot).toDouble() / recent.size, .20, .45)
        } else 50.0
        val recentAir = if (recent.isNotEmpty()) {
            // Kasper regularly differentiates pitchers who keep the ball on the ground from arms
            // allowing a lot of air contact. More fly/air contact creates more HR opportunity.
            scale(recent.count(::isAirBall).toDouble() / recent.size, .32, .62)
        } else 50.0

        val batterSide = player.batSide
        val pitcherHand = pitcher.person.pitchHand
        val rawHandedness = when {
            batterSide == "S" -> 62.0
            batterSide == null || pitcherHand == null -> 50.0
            batterSide != pitcherHand -> 60.0
            else -> 45.0
        }

        return weighted(
            hr9 to .25,
            contactOpportunity to .17,
            recentHard to .17,
            recentBarrel to .14,
            recentSweet to .09,
            recentAir to .08,
            whip to .05,
            rawHandedness to .05
        )
    }

    private fun platoonSplitScore(stats: HittingSplitStats?): Double {
        if (stats == null || stats.plateAppearances <= 0) return 50.0
        val pa = stats.plateAppearances
        val hrPa = stats.hrPerPa?.let { scale(it, .012, .080) } ?: 50.0
        val iso = stats.iso?.let { scale(it, .100, .320) } ?: 50.0
        val slg = stats.slg?.let { scale(it, .330, .620) } ?: 50.0
        val ops = stats.ops?.let { scale(it, .620, 1.020) } ?: 50.0
        val contact = stats.strikeoutRate?.let { kRate -> 100.0 - scale(kRate, .13, .32) } ?: 50.0
        val raw = weighted(hrPa to .30, iso to .25, slg to .18, ops to .12, contact to .15)
        val confidence = (pa / 90.0).coerceIn(.20, 1.0)
        return 50.0 * (1.0 - confidence) + raw * confidence
    }

    private fun environmentScore(game: GameInfo): Double {
        val park = parkScore(game.venueName)
        val weather = game.weather
        val roofClosed = weather.roofType?.contains("closed", true) == true ||
            weather.condition?.contains("dome", true) == true
        val temp = if (roofClosed) 50.0 else weather.temperatureF?.let { scale(it.toDouble(), 55.0, 92.0) } ?: 50.0
        val wind = if (roofClosed) 50.0 else windScore(weather.wind)
        return weighted(park to .50, temp to .30, wind to .20)
    }

    private fun seasonPowerScore(stats: HittingStats): Double {
        val pa = stats.plateAppearances.takeIf { it > 0 } ?: stats.atBats
        if (pa <= 0) return 40.0
        val hrRate = stats.homeRuns.toDouble() / pa
        val iso = when {
            stats.slg != null && stats.avg != null -> (stats.slg - stats.avg).coerceAtLeast(0.0)
            stats.atBats > 0 -> (stats.doubles + 2 * stats.triples + 3 * stats.homeRuns).toDouble() / stats.atBats
            else -> null
        }
        val kRate = if (stats.plateAppearances > 0) stats.strikeouts.toDouble() / stats.plateAppearances else null
        val hr = scale(hrRate, .012, .070)
        val slg = stats.slg?.let { scale(it, .330, .600) } ?: 45.0
        val ops = stats.ops?.let { scale(it, .620, 1.000) } ?: 45.0
        val isoScore = iso?.let { scale(it, .100, .300) } ?: 45.0
        val contact = kRate?.let { scale(it, .33, .14) } ?: 50.0
        return weighted(hr to .35, slg to .22, ops to .13, isoScore to .18, contact to .12)
    }

    private fun lineupScore(order: Int, official: Boolean): Double {
        val base = when (order) {
            1, 2, 3, 4 -> 100.0
            5 -> 88.0
            6 -> 78.0
            7 -> 65.0
            8 -> 55.0
            9 -> 45.0
            else -> 50.0
        }
        return (base - if (official) 0.0 else 7.0).coerceAtLeast(0.0)
    }

    private fun buildTags(
        balls: List<BattedBall>,
        pressure: Double,
        recentPower: Double,
        matchup: Double,
        environment: Double,
        official: Boolean
    ): List<String> = buildList {
        val latestDate = balls.maxOfOrNull { it.gameDate }
        val latest = latestDate?.let { d -> balls.filter { it.gameDate == d } }.orEmpty()
        if (latest.any(::isEliteNearHomeRun)) add("NEAR-HR+")
        else if (latest.any(::isNearHomeRun)) add("NEAR-HR")
        if (pressure >= 75) add("POWER PRESSURE")
        if (recentPower >= 75) add("HOT CONTACT")
        if (matchup >= 75) add("PITCHER TARGET")
        if (environment >= 75) add("PARK/WEATHER")
        if (!official) add("PROJECTED LINEUP")
    }.distinct().take(4)

    private fun buildNotes(
        player: PersonRef,
        balls: List<BattedBall>,
        pitcher: PitcherProfile?,
        game: GameInfo,
        battingOrder: Int,
        official: Boolean
    ): List<String> = buildList {
        val tracked = balls.filter { it.exitVelocity != null }
        val hardest = tracked.maxByOrNull { it.exitVelocity ?: 0.0 }
        val near = tracked.filter(::isNearHomeRun)
        val barrels = tracked.count(::isBarrelProxy)
        val hardHits = tracked.count(::isHardHit)

        hardest?.let {
            val la = it.launchAngle?.let { a -> " / ${"%.0f".format(a)}°" } ?: ""
            val dist = it.distanceFt?.let { d -> " / ${"%.0f".format(d)} ft" } ?: ""
            add("Recent max EV ${"%.1f".format(it.exitVelocity)} mph$la$dist")
        }
        if (near.isNotEmpty()) add("${near.size} recent HR-quality near miss${if (near.size == 1) "" else "es"}")
        if (tracked.isNotEmpty()) add("$hardHits hard-hit balls and $barrels barrel-proxy contacts in ${tracked.size} tracked balls")
        pitcher?.let {
            val hr9 = it.seasonStats.hrPer9
            val era = it.seasonStats.era
            if (hr9 != null || era != null) {
                val bits = buildList {
                    hr9?.let { v -> add("${"%.2f".format(v)} HR/9") }
                    era?.let { v -> add("${"%.2f".format(v)} ERA") }
                }
                add("Faces ${it.person.name}: ${bits.joinToString(" • ")}")
            } else add("Faces ${it.person.name}")
        }
        val weatherText = listOfNotNull(
            game.weather.temperatureF?.let { "$it°F" },
            game.weather.wind,
            game.weather.condition
        ).joinToString(" • ")
        if (weatherText.isNotBlank()) add("${game.venueName}: $weatherText")
        add("Batting #$battingOrder${if (official) " (official lineup)" else " (projected from most recent lineup)"}")
    }

    private fun windScore(raw: String?): Double {
        if (raw.isNullOrBlank()) return 50.0
        val lower = raw.lowercase()
        val mph = Regex("(\\d+)\\s*mph").find(lower)?.groupValues?.getOrNull(1)?.toDoubleOrNull() ?: 0.0
        val direction = when {
            "out" in lower -> 70.0 + min(30.0, mph * 2.0)
            "in" in lower -> 35.0 - min(25.0, mph * 1.5)
            else -> 50.0
        }
        return direction.coerceIn(0.0, 100.0)
    }

    private fun parkScore(venue: String): Double {
        val v = venue.lowercase()
        return when {
            "coors" in v -> 100.0
            "great american" in v -> 92.0
            "yankee" in v -> 88.0
            "citizens bank" in v -> 86.0
            "fenway" in v -> 80.0
            "camden" in v -> 77.0
            "sutter health" in v -> 75.0
            "globe life" in v -> 73.0
            "rogers centre" in v || "rogers center" in v -> 70.0
            "rate field" in v || "guaranteed rate" in v -> 69.0
            "dodger" in v -> 67.0
            "truist" in v -> 66.0
            "daikin" in v || "minute maid" in v -> 65.0
            "wrigley" in v -> 65.0
            "american family" in v -> 64.0
            "chase field" in v -> 63.0
            "angel stadium" in v -> 62.0
            "target field" in v -> 60.0
            "nationals park" in v -> 58.0
            "progressive" in v -> 58.0
            "busch" in v -> 56.0
            "citi field" in v -> 52.0
            "loanDepot".lowercase() in v -> 48.0
            "kauffman" in v -> 47.0
            "pnc park" in v -> 47.0
            "comerica" in v -> 45.0
            "petco" in v -> 42.0
            "t-mobile" in v -> 40.0
            "oracle" in v -> 38.0
            else -> 55.0
        }
    }

    private fun scale(value: Double, low: Double, high: Double): Double {
        if (high <= low) return 50.0
        return (((value - low) / (high - low)) * 100.0).coerceIn(0.0, 100.0)
    }

    private fun weightedAvailable(vararg values: Pair<Double?, Double>): Double {
        val available = values.filter { it.first != null }
        if (available.isEmpty()) return 50.0
        val totalWeight = available.sumOf { it.second }
        if (totalWeight <= 0.0) return 50.0
        return available.sumOf { (it.first ?: 50.0) * it.second } / totalWeight
    }

    private fun weighted(vararg values: Pair<Double, Double>): Double {
        val totalWeight = values.sumOf { it.second }
        if (totalWeight <= 0) return 0.0
        return values.sumOf { it.first * it.second } / totalWeight
    }
}
