# HR Chase v0.10 — Kasper-inspired research lens

This build adds a transparent, independent interpretation of themes repeatedly visible in Kasper (@KasperMLB) public slate breakdowns. It is **not** Kasper's proprietary KHR formula, is not affiliated with him, and is not presented as an endorsement.

## Public themes incorporated
- Hitter-first evaluation and current form before name recognition.
- Barrel%, hard-hit%, fly/air-ball quality and sweet-spot contact.
- Recent swing-and-miss as a negative signal.
- Opposing pitcher HR vulnerability, strikeout resistance, hard contact, barrels and air contact allowed.
- Handedness/platoon performance.
- Recent near-HR / unrewarded barrel pressure.
- Lineup-wide barrel depth (10%+ recent barrel-proxy hitters).
- Career BvP remains a capped context adjustment rather than a primary driver.

## New data
Recent whiff rate is derived directly from MLB Gameday pitch descriptions in the same recent-game feeds already downloaded by the app, so it adds no extra network requests. Small samples are blended back toward season K%.

## Integration
The new Kasper-inspired lens receives 55% of the final daily Target Score and the independent HR Chase core receives 45%. This is a convergence approach: public analyst themes improve the model without making the app a clone of a proprietary system. Games, Top Targets and Parlays all use the updated Target Score.
