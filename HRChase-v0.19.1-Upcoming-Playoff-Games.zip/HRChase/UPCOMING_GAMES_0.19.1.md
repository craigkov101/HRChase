# HR Chase 0.19.1 — Upcoming Games

- Games navigation now supports yesterday through seven days ahead.
- Tomorrow receives a dedicated TOMORROW date label.
- Future MLB/postseason games remain visible even when hitter candidates or official lineups have not posted yet.
- Future slates use a wider 10-day recent-game window to improve projected-lineup fallback around postseason off-days.
- Upcoming-game loading text no longer calls future lineups “today’s.”
